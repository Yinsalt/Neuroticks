"""Kompatibilitäts-Shim: der Inhalt von graph_factory.py liegt jetzt im Paket ``neuroticks``.

Bestehende Skripte (z. B. server.py) können weiter ``import graph_factory`` schreiben.
Neuer Code importiert direkt aus den unten genannten Modulen.
"""
# flake8: noqa
from neuroticks.core.graph_factory import (
    _collect_recorders_for_graph, _remap_da_source_in_blueprint,
    _shift_positions_in_blueprint, build_graph_array, find_latest_graph_json,
    get_pop_for_graph_node, ID_OFFSET_PER_AGENT, verify_graph_positions,
)
from neuroticks.core.graph_factory import *
