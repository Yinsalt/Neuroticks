"""Kompatibilitäts-Shim: der Inhalt von ExtraTab.py liegt jetzt im Paket ``neuroticks``.

Bestehende Skripte (z. B. server.py) können weiter ``import ExtraTab`` schreiben.
Neuer Code importiert direkt aus den unten genannten Modulen.
"""
# flake8: noqa
from neuroticks.gui.tabs.sewing.device_tool import SewingDeviceTargetSelector, SewingDeviceTool
from neuroticks.gui.tabs.sewing.graph_view import SewingGraphView
from neuroticks.gui.tabs.sewing.inspector import SewingInspector
from neuroticks.gui.tabs.sewing.offline_connection import (
    OfflineConnectionTargetRow, OfflineConnectionTool,
)
from neuroticks.gui.tabs.sewing.tab import ExtraTabWidget
from neuroticks.gui.tabs.sewing.tools_panel import SewingToolsPanel
