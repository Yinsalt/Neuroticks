"""Kompatibilitäts-Shim: der Inhalt von RetinaTestTab.py liegt jetzt im Paket ``neuroticks``.

Bestehende Skripte (z. B. server.py) können weiter ``import RetinaTestTab`` schreiben.
Neuer Code importiert direkt aus den unten genannten Modulen.
"""
# flake8: noqa
from neuroticks.gui.tabs.retina_test import (
    _standalone_main, _TargetRow, CONNECTION_RULES, HAS_CV2, HAS_RETINA, LGN_GRAPH_NAME,
    RetinaTestTabWidget, SERVER_RETINA_TO_LGN, VideoFrameReader,
)
from neuroticks.retina.virtual_graph import (
    NEURON_MODEL_BY_POP, VirtualRetinaGraph, VirtualRetinaNode,
)


if __name__ == '__main__':
    _standalone_main()
