# Funktionsinventar

Alle Funktionen, Klassen, Methoden und Modul-Konstanten des alten Codes mit altem und neuem Ort.
Automatisch aus dem AST der Originaldateien erzeugt. Zeilennummern beziehen sich auf die Originaldateien.

Umfang: 142 Funktionen, 83 Klassen, 780 Methoden, 106 Modul-Konstanten.


## Main.py

| Name | Art | Zeilen alt | Neuer Ort |
|---|---|---|---|
| `apply_dark_mode` | Funktion | 51-172 | `neuroticks/gui/theme.py` |
| `graph_list` | Konstante | 175-175 | `neuroticks/state.py` |
| `neuron_colors` | Konstante | 178-219 | `neuroticks/constants/colors.py` |
| `convert_widget_to_graph_format` | Funktion | 222-238 | `neuroticks/core/graph_builders.py` |
| `MaximizableViewport` | Klasse | 240-319 | `neuroticks/gui/main_window/widgets.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 256-294 | `neuroticks/gui/main_window/widgets.py` |
| &nbsp;&nbsp;&nbsp;.resizeEvent | Methode | 296-304 | `neuroticks/gui/main_window/widgets.py` |
| &nbsp;&nbsp;&nbsp;.set_maximized_state | Methode | 306-319 | `neuroticks/gui/main_window/widgets.py` |
| `PreviewWidget` | Klasse | 322-347 | `neuroticks/gui/main_window/widgets.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 323-330 | `neuroticks/gui/main_window/widgets.py` |
| &nbsp;&nbsp;&nbsp;.resizeEvent | Methode | 332-341 | `neuroticks/gui/main_window/widgets.py` |
| &nbsp;&nbsp;&nbsp;.sizeHint | Methode | 343-344 | `neuroticks/gui/main_window/widgets.py` |
| &nbsp;&nbsp;&nbsp;.minimumSizeHint | Methode | 346-347 | `neuroticks/gui/main_window/widgets.py` |
| `create_graph_from_widget` | Funktion | 350-379 | `neuroticks/core/graph_builders.py` |
| `Color` | Klasse | 382-388 | `neuroticks/gui/main_window/widgets.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 383-388 | `neuroticks/gui/main_window/widgets.py` |
| `get_neuron_color` | Funktion | 389-390 | `neuroticks/constants/colors.py` |
| `StatusBarWidget` | Klasse | 393-468 | `neuroticks/gui/main_window/widgets.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 394-396 | `neuroticks/gui/main_window/widgets.py` |
| &nbsp;&nbsp;&nbsp;.setup_ui | Methode | 398-430 | `neuroticks/gui/main_window/widgets.py` |
| &nbsp;&nbsp;&nbsp;.set_status | Methode | 432-440 | `neuroticks/gui/main_window/widgets.py` |
| &nbsp;&nbsp;&nbsp;.set_progress | Methode | 442-448 | `neuroticks/gui/main_window/widgets.py` |
| &nbsp;&nbsp;&nbsp;.reset | Methode | 450-460 | `neuroticks/gui/main_window/widgets.py` |
| &nbsp;&nbsp;&nbsp;.show_error | Methode | 462-464 | `neuroticks/gui/main_window/widgets.py` |
| &nbsp;&nbsp;&nbsp;.show_success | Methode | 466-468 | `neuroticks/gui/main_window/widgets.py` |
| `_invalidate_nest_refs` | Funktion | 470-483 | `neuroticks/utils/nest_helpers.py` |
| `MainWindow` | Klasse | 486-5079 | `neuroticks/gui/main_window/window.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 487-501 | `neuroticks/gui/main_window/window.py` |
| &nbsp;&nbsp;&nbsp;.create_menubar | Methode | 504-590 | `neuroticks/gui/main_window/mixins/layout.py` |
| &nbsp;&nbsp;&nbsp;.init_connection_system | Methode | 593-598 | `neuroticks/gui/main_window/mixins/nest_kernel.py` |
| &nbsp;&nbsp;&nbsp;.new_project_dialog | Methode | 599-616 | `neuroticks/gui/main_window/mixins/project.py` |
| &nbsp;&nbsp;&nbsp;.reset_application | Methode | 618-686 | `neuroticks/gui/main_window/mixins/project.py` |
| &nbsp;&nbsp;&nbsp;.safe_reset_kernel | Methode | 687-708 | `neuroticks/gui/main_window/mixins/nest_kernel.py` |
| &nbsp;&nbsp;&nbsp;.rebuild_node_with_new_polynomials | Methode | 711-756 | `neuroticks/gui/main_window/mixins/nest_kernel.py` |
| &nbsp;&nbsp;&nbsp;.toggle_structural_plasticity | Methode | 757-762 | `neuroticks/gui/main_window/mixins/nest_kernel.py` |
| &nbsp;&nbsp;&nbsp;.on_graph_created *(doppelt, wird von Zeile 2573 überschrieben)* | Methode | 764-769 | `neuroticks/gui/main_window/mixins/graph_events.py` |
| &nbsp;&nbsp;&nbsp;.on_graph_deleted | Methode | 771-776 | `neuroticks/gui/main_window/mixins/graph_events.py` |
| &nbsp;&nbsp;&nbsp;.get_connection_summary | Methode | 778-779 | `neuroticks/gui/main_window/mixins/graph_events.py` |
| &nbsp;&nbsp;&nbsp;.export_connections | Methode | 781-788 | `neuroticks/gui/main_window/mixins/graph_events.py` |
| &nbsp;&nbsp;&nbsp;.import_connections | Methode | 790-796 | `neuroticks/gui/main_window/mixins/graph_events.py` |
| &nbsp;&nbsp;&nbsp;.manual_nest_reset | Methode | 798-862 | `neuroticks/gui/main_window/mixins/nest_kernel.py` |
| &nbsp;&nbsp;&nbsp;.verify_nest_populations | Methode | 865-909 | `neuroticks/gui/main_window/mixins/nest_kernel.py` |
| &nbsp;&nbsp;&nbsp;.update_visualizations | Methode | 912-925 | `neuroticks/gui/main_window/mixins/graph_events.py` |
| &nbsp;&nbsp;&nbsp;.setup_ui | Methode | 928-1074 | `neuroticks/gui/main_window/mixins/layout.py` |
| &nbsp;&nbsp;&nbsp;._create_data_view | Methode | 1076-1078 | `neuroticks/gui/main_window/mixins/layout.py` |
| &nbsp;&nbsp;&nbsp;.manual_save_data_dialog | Methode | 1079-1086 | `neuroticks/gui/main_window/mixins/persistence.py` |
| &nbsp;&nbsp;&nbsp;.archive_live_data | Methode | 1092-1215 | `neuroticks/gui/main_window/mixins/persistence.py` |
| &nbsp;&nbsp;&nbsp;._switch_main_view | Methode | 1219-1255 | `neuroticks/gui/main_window/mixins/layout.py` |
| &nbsp;&nbsp;&nbsp;._create_editor_widget | Methode | 1258-1311 | `neuroticks/gui/main_window/mixins/layout.py` |
| &nbsp;&nbsp;&nbsp;._on_viz_toggle_maximize | Methode | 1313-1363 | `neuroticks/gui/main_window/mixins/layout.py` |
| &nbsp;&nbsp;&nbsp;._restore_viewport | Methode | 1365-1401 | `neuroticks/gui/main_window/mixins/layout.py` |
| &nbsp;&nbsp;&nbsp;.create_top_left | Methode | 1406-1576 | `neuroticks/gui/main_window/mixins/layout.py` |
| &nbsp;&nbsp;&nbsp;.start_headless_simulation | Methode | 1580-1619 | `neuroticks/gui/main_window/mixins/headless.py` |
| &nbsp;&nbsp;&nbsp;.headless_loop_step | Methode | 1621-1643 | `neuroticks/gui/main_window/mixins/headless.py` |
| &nbsp;&nbsp;&nbsp;.stop_headless_simulation | Methode | 1645-1658 | `neuroticks/gui/main_window/mixins/headless.py` |
| &nbsp;&nbsp;&nbsp;.finish_headless_simulation | Methode | 1660-1673 | `neuroticks/gui/main_window/mixins/headless.py` |
| &nbsp;&nbsp;&nbsp;._restore_ui_after_headless | Methode | 1675-1684 | `neuroticks/gui/main_window/mixins/headless.py` |
| &nbsp;&nbsp;&nbsp;.reset_from_live_dashboard | Methode | 1688-1696 | `neuroticks/gui/main_window/mixins/simulation.py` |
| &nbsp;&nbsp;&nbsp;._switch_view | Methode | 1703-1740 | `neuroticks/gui/main_window/mixins/layout.py` |
| &nbsp;&nbsp;&nbsp;._on_retina_viz_refresh | Methode | 1742-1763 | `neuroticks/gui/main_window/mixins/visualization.py` |
| &nbsp;&nbsp;&nbsp;.create_neuron_visualization | Methode | 1765-1769 | `neuroticks/gui/main_window/mixins/visualization.py` |
| &nbsp;&nbsp;&nbsp;._on_opacity_changed | Methode | 1771-1774 | `neuroticks/gui/main_window/mixins/visualization.py` |
| &nbsp;&nbsp;&nbsp;.create_graph_visualization | Methode | 1776-1869 | `neuroticks/gui/main_window/mixins/visualization.py` |
| &nbsp;&nbsp;&nbsp;.on_graph_updated | Methode | 1870-1887 | `neuroticks/gui/main_window/mixins/graph_events.py` |
| &nbsp;&nbsp;&nbsp;.create_bottom_left | Methode | 1889-1952 | `neuroticks/gui/main_window/mixins/layout.py` |
| &nbsp;&nbsp;&nbsp;.on_device_tree_click | Methode | 1954-1957 | `neuroticks/gui/main_window/mixins/graph_events.py` |
| &nbsp;&nbsp;&nbsp;.handle_device_update | Methode | 1959-2014 | `neuroticks/gui/main_window/mixins/graph_events.py` |
| &nbsp;&nbsp;&nbsp;.delete_connection_wrapper | Methode | 2017-2032 | `neuroticks/gui/main_window/mixins/graph_events.py` |
| &nbsp;&nbsp;&nbsp;.set_tool_page | Methode | 2034-2044 | `neuroticks/gui/main_window/mixins/layout.py` |
| &nbsp;&nbsp;&nbsp;._on_overview_node_selected | Methode | 2046-2052 | `neuroticks/gui/main_window/mixins/graph_events.py` |
| &nbsp;&nbsp;&nbsp;.open_connection_tool_for_node | Methode | 2053-2063 | `neuroticks/gui/main_window/mixins/graph_events.py` |
| &nbsp;&nbsp;&nbsp;._on_overview_pop_selected | Methode | 2066-2068 | `neuroticks/gui/main_window/mixins/graph_events.py` |
| &nbsp;&nbsp;&nbsp;._on_overview_conn_selected | Methode | 2071-2076 | `neuroticks/gui/main_window/mixins/graph_events.py` |
| &nbsp;&nbsp;&nbsp;._on_connection_edited | Methode | 2078-2103 | `neuroticks/gui/main_window/mixins/graph_events.py` |
| &nbsp;&nbsp;&nbsp;.on_structure_selected | Methode | 2107-2114 | `neuroticks/gui/main_window/mixins/graph_events.py` |
| &nbsp;&nbsp;&nbsp;.closeEvent | Methode | 2118-2164 | `neuroticks/gui/main_window/window.py` |
| &nbsp;&nbsp;&nbsp;.resizeEvent | Methode | 2166-2170 | `neuroticks/gui/main_window/window.py` |
| &nbsp;&nbsp;&nbsp;._update_plotters_after_resize | Methode | 2172-2185 | `neuroticks/gui/main_window/mixins/layout.py` |
| &nbsp;&nbsp;&nbsp;.create_bottom_right | Methode | 2187-2360 | `neuroticks/gui/main_window/mixins/layout.py` |
| &nbsp;&nbsp;&nbsp;.save_all_graphs_dialog | Methode | 2364-2456 | `neuroticks/gui/main_window/mixins/persistence.py` |
| &nbsp;&nbsp;&nbsp;.delete_device_wrapper | Methode | 2463-2506 | `neuroticks/gui/main_window/mixins/graph_events.py` |
| &nbsp;&nbsp;&nbsp;.reconnect_network | Methode | 2508-2571 | `neuroticks/gui/main_window/mixins/nest_kernel.py` |
| &nbsp;&nbsp;&nbsp;.on_graph_created | Methode | 2573-2614 | `neuroticks/gui/main_window/mixins/graph_events.py` |
| &nbsp;&nbsp;&nbsp;.on_visibility_changed | Methode | 2615-2633 | `neuroticks/gui/main_window/mixins/visualization.py` |
| &nbsp;&nbsp;&nbsp;.plot_neuron_points | Methode | 2636-2663 | `neuroticks/gui/main_window/mixins/visualization.py` |
| &nbsp;&nbsp;&nbsp;.plot_graph_skeleton | Methode | 2667-2858 | `neuroticks/gui/main_window/mixins/visualization.py` |
| &nbsp;&nbsp;&nbsp;._draw_single_connection | Methode | 2860-2989 | `neuroticks/gui/main_window/mixins/visualization.py` |
| &nbsp;&nbsp;&nbsp;._format_node_detail_html | Methode | 2991-3017 | `neuroticks/gui/main_window/mixins/visualization.py` |
| &nbsp;&nbsp;&nbsp;._format_connection_detail_html | Methode | 3019-3057 | `neuroticks/gui/main_window/mixins/visualization.py` |
| &nbsp;&nbsp;&nbsp;._on_graph_labels_toggled | Methode | 3059-3068 | `neuroticks/gui/main_window/mixins/visualization.py` |
| &nbsp;&nbsp;&nbsp;._on_skeleton_click | Methode | 3070-3088 | `neuroticks/gui/main_window/mixins/visualization.py` |
| &nbsp;&nbsp;&nbsp;._show_graph_detail_panel | Methode | 3090-3104 | `neuroticks/gui/main_window/mixins/visualization.py` |
| &nbsp;&nbsp;&nbsp;._hide_graph_detail_panel | Methode | 3106-3108 | `neuroticks/gui/main_window/mixins/visualization.py` |
| &nbsp;&nbsp;&nbsp;.update_simulation_speed *(doppelt, wird von Zeile 3418 überschrieben)* | Methode | 3109-3114 | `neuroticks/gui/main_window/mixins/simulation.py` |
| &nbsp;&nbsp;&nbsp;.update_simulation_target | Methode | 3115-3120 | `neuroticks/gui/main_window/mixins/simulation.py` |
| &nbsp;&nbsp;&nbsp;._on_skeleton_hover | Methode | 3121-3164 | `neuroticks/gui/main_window/mixins/visualization.py` |
| &nbsp;&nbsp;&nbsp;.open_live_spectator | Methode | 3166-3168 | `neuroticks/gui/main_window/mixins/visualization.py` |
| &nbsp;&nbsp;&nbsp;.run_nest_simulation | Methode | 3171-3203 | `neuroticks/gui/main_window/mixins/simulation.py` |
| &nbsp;&nbsp;&nbsp;._ensure_spike_recorders | Methode | 3205-3290 | `neuroticks/gui/main_window/mixins/simulation.py` |
| &nbsp;&nbsp;&nbsp;.init_simulation_timer | Methode | 3292-3304 | `neuroticks/gui/main_window/mixins/simulation.py` |
| &nbsp;&nbsp;&nbsp;._global_start | Methode | 3307-3310 | `neuroticks/gui/main_window/mixins/simulation.py` |
| &nbsp;&nbsp;&nbsp;._global_step | Methode | 3312-3314 | `neuroticks/gui/main_window/mixins/simulation.py` |
| &nbsp;&nbsp;&nbsp;._global_pause | Methode | 3316-3318 | `neuroticks/gui/main_window/mixins/simulation.py` |
| &nbsp;&nbsp;&nbsp;._global_stop | Methode | 3320-3322 | `neuroticks/gui/main_window/mixins/simulation.py` |
| &nbsp;&nbsp;&nbsp;._global_reset | Methode | 3324-3327 | `neuroticks/gui/main_window/mixins/simulation.py` |
| &nbsp;&nbsp;&nbsp;._update_global_button_state | Methode | 3329-3342 | `neuroticks/gui/main_window/mixins/simulation.py` |
| &nbsp;&nbsp;&nbsp;.update_global_time_display | Methode | 3344-3356 | `neuroticks/gui/main_window/mixins/simulation.py` |
| &nbsp;&nbsp;&nbsp;._get_nest_time | Methode | 3359-3367 | `neuroticks/gui/main_window/mixins/simulation.py` |
| &nbsp;&nbsp;&nbsp;._simulate_step_and_update | Methode | 3369-3402 | `neuroticks/gui/main_window/mixins/simulation.py` |
| &nbsp;&nbsp;&nbsp;._drive_retina_tab | Methode | 3404-3417 | `neuroticks/gui/main_window/mixins/simulation.py` |
| &nbsp;&nbsp;&nbsp;.update_simulation_speed | Methode | 3418-3420 | `neuroticks/gui/main_window/mixins/simulation.py` |
| &nbsp;&nbsp;&nbsp;.start_continuous_simulation | Methode | 3423-3450 | `neuroticks/gui/main_window/mixins/simulation.py` |
| &nbsp;&nbsp;&nbsp;.step_simulation | Methode | 3453-3460 | `neuroticks/gui/main_window/mixins/simulation.py` |
| &nbsp;&nbsp;&nbsp;.pause_simulation | Methode | 3463-3471 | `neuroticks/gui/main_window/mixins/simulation.py` |
| &nbsp;&nbsp;&nbsp;.stop_simulation *(doppelt, wird von Zeile 3895 überschrieben)* | Methode | 3473-3482 | `neuroticks/gui/main_window/mixins/simulation.py` |
| &nbsp;&nbsp;&nbsp;.on_live_weight_change | Methode | 3487-3512 | `neuroticks/gui/main_window/mixins/simulation.py` |
| &nbsp;&nbsp;&nbsp;.on_sim_timer_timeout | Methode | 3515-3543 | `neuroticks/gui/main_window/mixins/simulation.py` |
| &nbsp;&nbsp;&nbsp;.reset_and_restart | Methode | 3546-3622 | `neuroticks/gui/main_window/mixins/nest_kernel.py` |
| &nbsp;&nbsp;&nbsp;._distribute_simulation_data | Methode | 3628-3764 | `neuroticks/gui/main_window/mixins/simulation.py` |
| &nbsp;&nbsp;&nbsp;.rebuild_all_graphs | Methode | 3769-3889 | `neuroticks/gui/main_window/mixins/nest_kernel.py` |
| &nbsp;&nbsp;&nbsp;.start_simulation | Methode | 3891-3893 | `neuroticks/gui/main_window/mixins/simulation.py` |
| &nbsp;&nbsp;&nbsp;.stop_simulation | Methode | 3895-3897 | `neuroticks/gui/main_window/mixins/simulation.py` |
| &nbsp;&nbsp;&nbsp;.fixed_save_all_graphs_dialog | Methode | 3902-3987 | `neuroticks/gui/main_window/mixins/persistence.py` |
| &nbsp;&nbsp;&nbsp;.load_all_graphs_dialog | Methode | 4000-4244 | `neuroticks/gui/main_window/mixins/persistence.py` |
| &nbsp;&nbsp;&nbsp;.load_thin_graphs_dialog | Methode | 4259-4428 | `neuroticks/gui/main_window/mixins/persistence.py` |
| &nbsp;&nbsp;&nbsp;.save_thin_graphs_dialog | Methode | 4430-4536 | `neuroticks/gui/main_window/mixins/persistence.py` |
| &nbsp;&nbsp;&nbsp;._examples_dir | Methode | 4544-4555 | `neuroticks/gui/main_window/mixins/examples.py` |
| &nbsp;&nbsp;&nbsp;._scan_examples | Methode | 4557-4585 | `neuroticks/gui/main_window/mixins/examples.py` |
| &nbsp;&nbsp;&nbsp;._refresh_examples_buttons | Methode | 4587-4590 | `neuroticks/gui/main_window/mixins/examples.py` |
| &nbsp;&nbsp;&nbsp;._on_example_clicked | Methode | 4592-4609 | `neuroticks/gui/main_window/mixins/examples.py` |
| &nbsp;&nbsp;&nbsp;._import_example_file | Methode | 4611-4801 | `neuroticks/gui/main_window/mixins/examples.py` |
| &nbsp;&nbsp;&nbsp;.merge_graphs_dialog | Methode | 4803-5014 | `neuroticks/gui/main_window/mixins/persistence.py` |
| &nbsp;&nbsp;&nbsp;.collect_simulation_results | Methode | 5018-5079 | `neuroticks/gui/main_window/mixins/simulation.py` |
| `NumpyEncoder` | Klasse | 5087-5092 | `neuroticks/gui/main_window/json_encoder.py` |
| &nbsp;&nbsp;&nbsp;.default | Methode | 5088-5092 | `neuroticks/gui/main_window/json_encoder.py` |
| `_ExamplesPage` | Klasse | 5111-5244 | `neuroticks/gui/main_window/examples_page.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 5122-5126 | `neuroticks/gui/main_window/examples_page.py` |
| &nbsp;&nbsp;&nbsp;._build_ui | Methode | 5128-5178 | `neuroticks/gui/main_window/examples_page.py` |
| &nbsp;&nbsp;&nbsp;.rebuild | Methode | 5180-5244 | `neuroticks/gui/main_window/examples_page.py` |
| `_DisplacementDialog` | Klasse | 5247-5289 | `neuroticks/gui/main_window/dialogs.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 5251-5286 | `neuroticks/gui/main_window/dialogs.py` |
| &nbsp;&nbsp;&nbsp;.get_displacement | Methode | 5288-5289 | `neuroticks/gui/main_window/dialogs.py` |

## WidgetLib.py

| Name | Art | Zeilen alt | Neuer Ort |
|---|---|---|---|
| `MC_MODELS` | Konstante | 90-90 | `neuroticks/utils/nest_helpers.py` |
| `safe_get_model` | Funktion | 92-99 | `neuroticks/utils/nest_helpers.py` |
| `safe_get_status` | Funktion | 101-110 | `neuroticks/utils/nest_helpers.py` |
| `get_receptor_type_for_model` | Funktion | 112-122 | `neuroticks/utils/nest_helpers.py` |
| `get_mc_recordables` | Funktion | 124-131 | `neuroticks/utils/nest_helpers.py` |
| `FlowLayout` | Klasse | 134-238 | `neuroticks/gui/widgets/flow_layout.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 136-144 | `neuroticks/gui/widgets/flow_layout.py` |
| &nbsp;&nbsp;&nbsp;.addItem | Methode | 146-148 | `neuroticks/gui/widgets/flow_layout.py` |
| &nbsp;&nbsp;&nbsp;.addWidget | Methode | 150-152 | `neuroticks/gui/widgets/flow_layout.py` |
| &nbsp;&nbsp;&nbsp;.removeWidget | Methode | 154-159 | `neuroticks/gui/widgets/flow_layout.py` |
| &nbsp;&nbsp;&nbsp;.count | Methode | 161-162 | `neuroticks/gui/widgets/flow_layout.py` |
| &nbsp;&nbsp;&nbsp;.itemAt | Methode | 164-167 | `neuroticks/gui/widgets/flow_layout.py` |
| &nbsp;&nbsp;&nbsp;.takeAt | Methode | 169-174 | `neuroticks/gui/widgets/flow_layout.py` |
| &nbsp;&nbsp;&nbsp;.expandingDirections | Methode | 176-177 | `neuroticks/gui/widgets/flow_layout.py` |
| &nbsp;&nbsp;&nbsp;.hasHeightForWidth | Methode | 179-180 | `neuroticks/gui/widgets/flow_layout.py` |
| &nbsp;&nbsp;&nbsp;.heightForWidth | Methode | 182-183 | `neuroticks/gui/widgets/flow_layout.py` |
| &nbsp;&nbsp;&nbsp;.setGeometry | Methode | 185-187 | `neuroticks/gui/widgets/flow_layout.py` |
| &nbsp;&nbsp;&nbsp;.sizeHint | Methode | 189-190 | `neuroticks/gui/widgets/flow_layout.py` |
| &nbsp;&nbsp;&nbsp;.minimumSize | Methode | 192-199 | `neuroticks/gui/widgets/flow_layout.py` |
| &nbsp;&nbsp;&nbsp;._do_layout | Methode | 201-238 | `neuroticks/gui/widgets/flow_layout.py` |
| `current_graph_metadata` | Konstante | 241-241 | `neuroticks/state.py` |
| `graph_parameters` | Konstante | 242-242 | `neuroticks/state.py` |
| `next_graph_id` | Konstante | 243-243 | `neuroticks/state.py` |
| `POLYNOM_NOISE_LEVEL` | Konstante | 244-244 | `neuroticks/state.py` |
| `_nest_simulation_has_run` | Konstante | 249-249 | `neuroticks/state.py` |
| `NODE_TOOLS` | Konstante | 252-273 | `neuroticks/constants/node_tools.py` |
| `TOOL_PARAM_KEYS` | Konstante | 277-310 | `neuroticks/constants/node_tools.py` |
| `SHAPE_PARAM_KEYS` | Konstante | 315-332 | `neuroticks/constants/node_tools.py` |
| `SHAPE_PARAM_DEFAULTS` | Konstante | 337-362 | `neuroticks/constants/node_tools.py` |
| `extract_shape_params` | Funktion | 365-376 | `neuroticks/constants/node_tools.py` |
| `__all__` | Konstante | 378-417 | `WidgetLib.py` |
| `SYNAPSE_MODELS` *(doppelt, wird von Zeile 6562 überschrieben)* | Konstante | 419-618 | `neuroticks/constants/synapses.py` |
| `generate_biased_polynomial` | Funktion | 621-648 | `neuroticks/utils/polynomials.py` |
| `PositionDialog` | Klasse | 651-685 | `neuroticks/gui/widgets/dialogs.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 652-656 | `neuroticks/gui/widgets/dialogs.py` |
| &nbsp;&nbsp;&nbsp;.init_ui | Methode | 658-682 | `neuroticks/gui/widgets/dialogs.py` |
| &nbsp;&nbsp;&nbsp;.get_position | Methode | 684-685 | `neuroticks/gui/widgets/dialogs.py` |
| `create_nest_mask` | Funktion | 688-767 | `neuroticks/utils/spatial.py` |
| `create_distance_dependent_weight` | Funktion | 770-795 | `neuroticks/utils/spatial.py` |
| `create_distance_dependent_probability` | Funktion | 798-830 | `neuroticks/utils/spatial.py` |
| `create_distance_dependent_delay` | Funktion | 833-856 | `neuroticks/utils/spatial.py` |
| `create_anisotropic_weight` | Funktion | 859-904 | `neuroticks/utils/spatial.py` |
| `SynapseParamWidget` | Klasse | 908-984 | `neuroticks/gui/widgets/synapse_widgets.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 912-916 | `neuroticks/gui/widgets/synapse_widgets.py` |
| &nbsp;&nbsp;&nbsp;._init_ui | Methode | 918-968 | `neuroticks/gui/widgets/synapse_widgets.py` |
| &nbsp;&nbsp;&nbsp;.get_value | Methode | 970-976 | `neuroticks/gui/widgets/synapse_widgets.py` |
| &nbsp;&nbsp;&nbsp;.set_value | Methode | 978-984 | `neuroticks/gui/widgets/synapse_widgets.py` |
| `InlineSynapseConfig` | Klasse | 987-1119 | `neuroticks/gui/widgets/synapse_widgets.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 998-1043 | `neuroticks/gui/widgets/synapse_widgets.py` |
| &nbsp;&nbsp;&nbsp;._on_model_changed | Methode | 1045-1047 | `neuroticks/gui/widgets/synapse_widgets.py` |
| &nbsp;&nbsp;&nbsp;._on_group_toggled | Methode | 1049-1055 | `neuroticks/gui/widgets/synapse_widgets.py` |
| &nbsp;&nbsp;&nbsp;._populate_param_widgets | Methode | 1057-1095 | `neuroticks/gui/widgets/synapse_widgets.py` |
| &nbsp;&nbsp;&nbsp;.get_value | Methode | 1097-1101 | `neuroticks/gui/widgets/synapse_widgets.py` |
| &nbsp;&nbsp;&nbsp;.set_value | Methode | 1103-1119 | `neuroticks/gui/widgets/synapse_widgets.py` |
| `SynapseCreationWidget` | Klasse | 1122-1335 | `neuroticks/gui/widgets/synapse_widgets.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 1127-1131 | `neuroticks/gui/widgets/synapse_widgets.py` |
| &nbsp;&nbsp;&nbsp;._init_ui | Methode | 1133-1224 | `neuroticks/gui/widgets/synapse_widgets.py` |
| &nbsp;&nbsp;&nbsp;._filter_models | Methode | 1228-1238 | `neuroticks/gui/widgets/synapse_widgets.py` |
| &nbsp;&nbsp;&nbsp;._on_model_changed | Methode | 1242-1267 | `neuroticks/gui/widgets/synapse_widgets.py` |
| &nbsp;&nbsp;&nbsp;._reset_to_defaults | Methode | 1269-1280 | `neuroticks/gui/widgets/synapse_widgets.py` |
| &nbsp;&nbsp;&nbsp;._save_preset | Methode | 1282-1291 | `neuroticks/gui/widgets/synapse_widgets.py` |
| &nbsp;&nbsp;&nbsp;.get_synapse_config | Methode | 1293-1309 | `neuroticks/gui/widgets/synapse_widgets.py` |
| &nbsp;&nbsp;&nbsp;.set_synapse_config | Methode | 1311-1330 | `neuroticks/gui/widgets/synapse_widgets.py` |
| &nbsp;&nbsp;&nbsp;._emit_synapse | Methode | 1332-1335 | `neuroticks/gui/widgets/synapse_widgets.py` |
| `create_nest_mask_safe` | Funktion | 1338-1362 | `neuroticks/utils/spatial.py` |
| `DoubleInputField` | Klasse | 1365-1388 | `neuroticks/gui/widgets/input_fields.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 1366-1385 | `neuroticks/gui/widgets/input_fields.py` |
| &nbsp;&nbsp;&nbsp;.get_value | Methode | 1387-1388 | `neuroticks/gui/widgets/input_fields.py` |
| `IntegerInputField` | Klasse | 1390-1404 | `neuroticks/gui/widgets/input_fields.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 1391-1401 | `neuroticks/gui/widgets/input_fields.py` |
| &nbsp;&nbsp;&nbsp;.get_value | Methode | 1403-1404 | `neuroticks/gui/widgets/input_fields.py` |
| `DropdownField` | Klasse | 1406-1420 | `neuroticks/gui/widgets/input_fields.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 1407-1417 | `neuroticks/gui/widgets/input_fields.py` |
| &nbsp;&nbsp;&nbsp;.get_value | Methode | 1419-1420 | `neuroticks/gui/widgets/input_fields.py` |
| `CheckboxField` | Klasse | 1422-1433 | `neuroticks/gui/widgets/input_fields.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 1423-1430 | `neuroticks/gui/widgets/input_fields.py` |
| &nbsp;&nbsp;&nbsp;.get_value | Methode | 1432-1433 | `neuroticks/gui/widgets/input_fields.py` |
| `NeuronParametersWidget` | Klasse | 1436-1615 | `neuroticks/gui/widgets/neuron_parameters.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 1440-1446 | `neuroticks/gui/widgets/neuron_parameters.py` |
| &nbsp;&nbsp;&nbsp;.load_json | Methode | 1448-1470 | `neuroticks/gui/widgets/neuron_parameters.py` |
| &nbsp;&nbsp;&nbsp;.setup_ui | Methode | 1472-1498 | `neuroticks/gui/widgets/neuron_parameters.py` |
| &nbsp;&nbsp;&nbsp;.on_model_changed | Methode | 1500-1509 | `neuroticks/gui/widgets/neuron_parameters.py` |
| &nbsp;&nbsp;&nbsp;.load_params | Methode | 1511-1530 | `neuroticks/gui/widgets/neuron_parameters.py` |
| &nbsp;&nbsp;&nbsp;.clear_params | Methode | 1532-1537 | `neuroticks/gui/widgets/neuron_parameters.py` |
| &nbsp;&nbsp;&nbsp;.create_param_widget | Methode | 1539-1604 | `neuroticks/gui/widgets/neuron_parameters.py` |
| &nbsp;&nbsp;&nbsp;.save_parameters | Methode | 1606-1615 | `neuroticks/gui/widgets/neuron_parameters.py` |
| `NodeParametersWidget` | Klasse | 1621-2009 | `neuroticks/gui/widgets/neuron_parameters.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 1625-1634 | `neuroticks/gui/widgets/neuron_parameters.py` |
| &nbsp;&nbsp;&nbsp;.init_ui | Methode | 1636-1685 | `neuroticks/gui/widgets/neuron_parameters.py` |
| &nbsp;&nbsp;&nbsp;._add_model_selector | Methode | 1689-1700 | `neuroticks/gui/widgets/neuron_parameters.py` |
| &nbsp;&nbsp;&nbsp;.create_tool_stack | Methode | 1702-1709 | `neuroticks/gui/widgets/neuron_parameters.py` |
| &nbsp;&nbsp;&nbsp;._create_panel_custom | Methode | 1711-1719 | `neuroticks/gui/widgets/neuron_parameters.py` |
| &nbsp;&nbsp;&nbsp;._create_panel_ccw | Methode | 1721-1751 | `neuroticks/gui/widgets/neuron_parameters.py` |
| &nbsp;&nbsp;&nbsp;._create_panel_blob | Methode | 1753-1780 | `neuroticks/gui/widgets/neuron_parameters.py` |
| &nbsp;&nbsp;&nbsp;._create_panel_cone | Methode | 1782-1820 | `neuroticks/gui/widgets/neuron_parameters.py` |
| &nbsp;&nbsp;&nbsp;._create_panel_grid | Methode | 1822-1827 | `neuroticks/gui/widgets/neuron_parameters.py` |
| &nbsp;&nbsp;&nbsp;._add_field_to_layout | Methode | 1829-1875 | `neuroticks/gui/widgets/neuron_parameters.py` |
| &nbsp;&nbsp;&nbsp;.on_tool_changed | Methode | 1877-1879 | `neuroticks/gui/widgets/neuron_parameters.py` |
| &nbsp;&nbsp;&nbsp;.add_section | Methode | 1881-1882 | `neuroticks/gui/widgets/neuron_parameters.py` |
| &nbsp;&nbsp;&nbsp;.add_text_field | Methode | 1884-1887 | `neuroticks/gui/widgets/neuron_parameters.py` |
| &nbsp;&nbsp;&nbsp;.add_int_field | Methode | 1889-1892 | `neuroticks/gui/widgets/neuron_parameters.py` |
| &nbsp;&nbsp;&nbsp;.add_float_field | Methode | 1894-1897 | `neuroticks/gui/widgets/neuron_parameters.py` |
| &nbsp;&nbsp;&nbsp;.add_bool_field | Methode | 1899-1902 | `neuroticks/gui/widgets/neuron_parameters.py` |
| &nbsp;&nbsp;&nbsp;.add_vector3_field | Methode | 1904-1908 | `neuroticks/gui/widgets/neuron_parameters.py` |
| &nbsp;&nbsp;&nbsp;.on_change | Methode | 1910-1911 | `neuroticks/gui/widgets/neuron_parameters.py` |
| &nbsp;&nbsp;&nbsp;.set_population_count | Methode | 1913-1924 | `neuroticks/gui/widgets/neuron_parameters.py` |
| &nbsp;&nbsp;&nbsp;.get_current_params | Methode | 1926-1952 | `neuroticks/gui/widgets/neuron_parameters.py` |
| &nbsp;&nbsp;&nbsp;.load_data | Methode | 1954-1993 | `neuroticks/gui/widgets/neuron_parameters.py` |
| &nbsp;&nbsp;&nbsp;._add_neuron_edit_button | Methode | 1995-1997 | `neuroticks/gui/widgets/neuron_parameters.py` |
| &nbsp;&nbsp;&nbsp;._jump_to_neuron_editor | Methode | 1998-2009 | `neuroticks/gui/widgets/neuron_parameters.py` |
| `_set_visible` | Funktion | 2012-2018 | `neuroticks/gui/widgets/input_fields.py` |
| `PolynomialTrioWidget` | Klasse | 2020-2116 | `neuroticks/gui/widgets/polynomial_widgets.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 2021-2051 | `neuroticks/gui/widgets/polynomial_widgets.py` |
| &nbsp;&nbsp;&nbsp;._convert_to_ui_terms | Methode | 2053-2072 | `neuroticks/gui/widgets/polynomial_widgets.py` |
| &nbsp;&nbsp;&nbsp;._convert_from_ui_terms | Methode | 2074-2098 | `neuroticks/gui/widgets/polynomial_widgets.py` |
| &nbsp;&nbsp;&nbsp;.load_polynomials | Methode | 2100-2109 | `neuroticks/gui/widgets/polynomial_widgets.py` |
| &nbsp;&nbsp;&nbsp;.get_polynomials | Methode | 2111-2116 | `neuroticks/gui/widgets/polynomial_widgets.py` |
| `PolynomialTermRow` | Klasse | 2119-2185 | `neuroticks/gui/widgets/polynomial_widgets.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 2120-2172 | `neuroticks/gui/widgets/polynomial_widgets.py` |
| &nbsp;&nbsp;&nbsp;.get_data | Methode | 2174-2179 | `neuroticks/gui/widgets/polynomial_widgets.py` |
| &nbsp;&nbsp;&nbsp;.set_data | Methode | 2181-2185 | `neuroticks/gui/widgets/polynomial_widgets.py` |
| `PolynomialManagerWidget` | Klasse | 2188-2278 | `neuroticks/gui/widgets/polynomial_widgets.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 2191-2195 | `neuroticks/gui/widgets/polynomial_widgets.py` |
| &nbsp;&nbsp;&nbsp;.init_ui | Methode | 2197-2237 | `neuroticks/gui/widgets/polynomial_widgets.py` |
| &nbsp;&nbsp;&nbsp;.set_populations | Methode | 2239-2267 | `neuroticks/gui/widgets/polynomial_widgets.py` |
| &nbsp;&nbsp;&nbsp;.apply_changes | Methode | 2269-2275 | `neuroticks/gui/widgets/polynomial_widgets.py` |
| &nbsp;&nbsp;&nbsp;.get_all_polynomials | Methode | 2277-2278 | `neuroticks/gui/widgets/polynomial_widgets.py` |
| `GraphNameColorWidget` | Klasse | 2281-2312 | `neuroticks/gui/widgets/graph_overview.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 2283-2285 | `neuroticks/gui/widgets/graph_overview.py` |
| &nbsp;&nbsp;&nbsp;.init_ui | Methode | 2287-2298 | `neuroticks/gui/widgets/graph_overview.py` |
| &nbsp;&nbsp;&nbsp;.generate_random_color | Methode | 2300-2304 | `neuroticks/gui/widgets/graph_overview.py` |
| &nbsp;&nbsp;&nbsp;.create_graph | Methode | 2306-2312 | `neuroticks/gui/widgets/graph_overview.py` |
| `GraphOverviewWidget` | Klasse | 2315-2779 | `neuroticks/gui/widgets/graph_overview.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 2330-2334 | `neuroticks/gui/widgets/graph_overview.py` |
| &nbsp;&nbsp;&nbsp;._setup_ui | Methode | 2336-2448 | `neuroticks/gui/widgets/graph_overview.py` |
| &nbsp;&nbsp;&nbsp;._show_context_menu | Methode | 2450-2493 | `neuroticks/gui/widgets/graph_overview.py` |
| &nbsp;&nbsp;&nbsp;.update_tree | Methode | 2496-2542 | `neuroticks/gui/widgets/graph_overview.py` |
| &nbsp;&nbsp;&nbsp;._get_devices_for_pop | Methode | 2545-2570 | `neuroticks/gui/widgets/graph_overview.py` |
| &nbsp;&nbsp;&nbsp;._create_device_item | Methode | 2572-2603 | `neuroticks/gui/widgets/graph_overview.py` |
| &nbsp;&nbsp;&nbsp;._style_item | Methode | 2606-2619 | `neuroticks/gui/widgets/graph_overview.py` |
| &nbsp;&nbsp;&nbsp;._create_node_item | Methode | 2621-2633 | `neuroticks/gui/widgets/graph_overview.py` |
| &nbsp;&nbsp;&nbsp;._on_item_changed | Methode | 2635-2643 | `neuroticks/gui/widgets/graph_overview.py` |
| &nbsp;&nbsp;&nbsp;._create_population_item | Methode | 2645-2666 | `neuroticks/gui/widgets/graph_overview.py` |
| &nbsp;&nbsp;&nbsp;._create_connection_item | Methode | 2668-2721 | `neuroticks/gui/widgets/graph_overview.py` |
| &nbsp;&nbsp;&nbsp;._get_populations | Methode | 2723-2735 | `neuroticks/gui/widgets/graph_overview.py` |
| &nbsp;&nbsp;&nbsp;._get_connections_for_pop | Methode | 2737-2753 | `neuroticks/gui/widgets/graph_overview.py` |
| &nbsp;&nbsp;&nbsp;._expand_all | Methode | 2755-2756 | `neuroticks/gui/widgets/graph_overview.py` |
| &nbsp;&nbsp;&nbsp;._collapse_all | Methode | 2758-2761 | `neuroticks/gui/widgets/graph_overview.py` |
| &nbsp;&nbsp;&nbsp;._on_item_clicked | Methode | 2763-2776 | `neuroticks/gui/widgets/graph_overview.py` |
| &nbsp;&nbsp;&nbsp;._on_item_double_clicked | Methode | 2778-2779 | `neuroticks/gui/widgets/graph_overview.py` |
| `node_parameters1` | Konstante | 2781-2804 | `neuroticks/constants/node_tools.py` |
| `PolynomialBuilderWidget` | Klasse | 2809-2853 | `neuroticks/gui/widgets/polynomial_widgets.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 2810-2834 | `neuroticks/gui/widgets/polynomial_widgets.py` |
| &nbsp;&nbsp;&nbsp;.add_term | Methode | 2836-2844 | `neuroticks/gui/widgets/polynomial_widgets.py` |
| &nbsp;&nbsp;&nbsp;.remove_term | Methode | 2846-2850 | `neuroticks/gui/widgets/polynomial_widgets.py` |
| &nbsp;&nbsp;&nbsp;.get_terms | Methode | 2852-2853 | `neuroticks/gui/widgets/polynomial_widgets.py` |
| `generate_random_polynomial` | Funktion | 2856-2875 | `neuroticks/utils/polynomials.py` |
| `GraphCreatorWidget` | Klasse | 2886-3876 | `neuroticks/gui/widgets/graph_creator.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 2888-2896 | `neuroticks/gui/widgets/graph_creator.py` |
| &nbsp;&nbsp;&nbsp;.init_ui | Methode | 2899-3037 | `neuroticks/gui/widgets/graph_creator.py` |
| &nbsp;&nbsp;&nbsp;.show_add_node_menu | Methode | 3040-3069 | `neuroticks/gui/widgets/graph_creator.py` |
| &nbsp;&nbsp;&nbsp;.add_structure_node | Methode | 3071-3115 | `neuroticks/gui/widgets/graph_creator.py` |
| &nbsp;&nbsp;&nbsp;._update_noise_level | Methode | 3117-3120 | `neuroticks/gui/widgets/graph_creator.py` |
| &nbsp;&nbsp;&nbsp;.create_twin_node | Methode | 3123-3205 | `neuroticks/gui/widgets/graph_creator.py` |
| &nbsp;&nbsp;&nbsp;.add_population | Methode | 3208-3251 | `neuroticks/gui/widgets/graph_creator.py` |
| &nbsp;&nbsp;&nbsp;.open_polynomial_editor | Methode | 3253-3275 | `neuroticks/gui/widgets/graph_creator.py` |
| &nbsp;&nbsp;&nbsp;.on_polynomials_changed | Methode | 3277-3287 | `neuroticks/gui/widgets/graph_creator.py` |
| &nbsp;&nbsp;&nbsp;.create_graph | Methode | 3289-3511 | `neuroticks/gui/widgets/graph_creator.py` |
| &nbsp;&nbsp;&nbsp;.add_node | Methode | 3513-3536 | `neuroticks/gui/widgets/graph_creator.py` |
| &nbsp;&nbsp;&nbsp;.remove_population | Methode | 3538-3571 | `neuroticks/gui/widgets/graph_creator.py` |
| &nbsp;&nbsp;&nbsp;.remove_node | Methode | 3572-3604 | `neuroticks/gui/widgets/graph_creator.py` |
| &nbsp;&nbsp;&nbsp;.select_node | Methode | 3605-3662 | `neuroticks/gui/widgets/graph_creator.py` |
| &nbsp;&nbsp;&nbsp;.load_structure_preset | Methode | 3664-3698 | `neuroticks/gui/widgets/graph_creator.py` |
| &nbsp;&nbsp;&nbsp;.save_node_params | Methode | 3701-3742 | `neuroticks/gui/widgets/graph_creator.py` |
| &nbsp;&nbsp;&nbsp;.update_population_list | Methode | 3745-3762 | `neuroticks/gui/widgets/graph_creator.py` |
| &nbsp;&nbsp;&nbsp;.select_population | Methode | 3765-3812 | `neuroticks/gui/widgets/graph_creator.py` |
| &nbsp;&nbsp;&nbsp;.save_current_population_params | Methode | 3814-3833 | `neuroticks/gui/widgets/graph_creator.py` |
| &nbsp;&nbsp;&nbsp;._on_population_params_saved | Methode | 3835-3837 | `neuroticks/gui/widgets/graph_creator.py` |
| &nbsp;&nbsp;&nbsp;.generate_random_color | Methode | 3839-3843 | `neuroticks/gui/widgets/graph_creator.py` |
| &nbsp;&nbsp;&nbsp;.reset | Methode | 3845-3876 | `neuroticks/gui/widgets/graph_creator.py` |
| `EditGraphWidget` | Klasse | 3878-5403 | `neuroticks/gui/widgets/graph_editor.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 3881-3891 | `neuroticks/gui/widgets/graph_editor.py` |
| &nbsp;&nbsp;&nbsp;.init_ui | Methode | 3893-4050 | `neuroticks/gui/widgets/graph_editor.py` |
| &nbsp;&nbsp;&nbsp;.select_node_by_id | Methode | 4052-4067 | `neuroticks/gui/widgets/graph_editor.py` |
| &nbsp;&nbsp;&nbsp;.select_population_by_ids | Methode | 4069-4075 | `neuroticks/gui/widgets/graph_editor.py` |
| &nbsp;&nbsp;&nbsp;.delete_connection_by_data | Methode | 4077-4129 | `neuroticks/gui/widgets/graph_editor.py` |
| &nbsp;&nbsp;&nbsp;.show_add_node_menu | Methode | 4131-4159 | `neuroticks/gui/widgets/graph_editor.py` |
| &nbsp;&nbsp;&nbsp;.add_structure_node | Methode | 4161-4194 | `neuroticks/gui/widgets/graph_editor.py` |
| &nbsp;&nbsp;&nbsp;.load_connection_editor | Methode | 4196-4232 | `neuroticks/gui/widgets/graph_editor.py` |
| &nbsp;&nbsp;&nbsp;.remove_node | Methode | 4234-4293 | `neuroticks/gui/widgets/graph_editor.py` |
| &nbsp;&nbsp;&nbsp;._sweep_incoming_connections | Methode | 4295-4357 | `neuroticks/gui/widgets/graph_editor.py` |
| &nbsp;&nbsp;&nbsp;.remove_population | Methode | 4359-4417 | `neuroticks/gui/widgets/graph_editor.py` |
| &nbsp;&nbsp;&nbsp;.refresh_graph_list | Methode | 4419-4443 | `neuroticks/gui/widgets/graph_editor.py` |
| &nbsp;&nbsp;&nbsp;.on_graph_selected | Methode | 4445-4462 | `neuroticks/gui/widgets/graph_editor.py` |
| &nbsp;&nbsp;&nbsp;.load_graph_data | Methode | 4464-4504 | `neuroticks/gui/widgets/graph_editor.py` |
| &nbsp;&nbsp;&nbsp;.load_node_from_graph | Methode | 4506-4582 | `neuroticks/gui/widgets/graph_editor.py` |
| &nbsp;&nbsp;&nbsp;.add_node | Methode | 4584-4626 | `neuroticks/gui/widgets/graph_editor.py` |
| &nbsp;&nbsp;&nbsp;.select_node | Methode | 4628-4680 | `neuroticks/gui/widgets/graph_editor.py` |
| &nbsp;&nbsp;&nbsp;.save_node_params | Methode | 4682-4717 | `neuroticks/gui/widgets/graph_editor.py` |
| &nbsp;&nbsp;&nbsp;.add_population | Methode | 4719-4749 | `neuroticks/gui/widgets/graph_editor.py` |
| &nbsp;&nbsp;&nbsp;.update_population_list | Methode | 4751-4762 | `neuroticks/gui/widgets/graph_editor.py` |
| &nbsp;&nbsp;&nbsp;.select_population | Methode | 4764-4804 | `neuroticks/gui/widgets/graph_editor.py` |
| &nbsp;&nbsp;&nbsp;.create_twin_node | Methode | 4806-4872 | `neuroticks/gui/widgets/graph_editor.py` |
| &nbsp;&nbsp;&nbsp;._build_node_params | Methode | 4876-5115 | `neuroticks/gui/widgets/graph_editor.py` |
| &nbsp;&nbsp;&nbsp;.save_current_population_params | Methode | 5120-5134 | `neuroticks/gui/widgets/graph_editor.py` |
| &nbsp;&nbsp;&nbsp;._on_population_params_saved | Methode | 5136-5138 | `neuroticks/gui/widgets/graph_editor.py` |
| &nbsp;&nbsp;&nbsp;.open_polynomial_editor | Methode | 5140-5157 | `neuroticks/gui/widgets/graph_editor.py` |
| &nbsp;&nbsp;&nbsp;.delete_graph | Methode | 5159-5191 | `neuroticks/gui/widgets/graph_editor.py` |
| &nbsp;&nbsp;&nbsp;._node_was_edited | Methode | 5192-5279 | `neuroticks/gui/widgets/graph_editor.py` |
| &nbsp;&nbsp;&nbsp;.save_changes | Methode | 5281-5403 | `neuroticks/gui/widgets/graph_editor.py` |
| `ConnectionTargetRow` | Klasse | 5407-5519 | `neuroticks/gui/widgets/connection_tool.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 5410-5414 | `neuroticks/gui/widgets/connection_tool.py` |
| &nbsp;&nbsp;&nbsp;._init_ui | Methode | 5416-5465 | `neuroticks/gui/widgets/connection_tool.py` |
| &nbsp;&nbsp;&nbsp;.refresh_data | Methode | 5467-5486 | `neuroticks/gui/widgets/connection_tool.py` |
| &nbsp;&nbsp;&nbsp;.on_graph_changed | Methode | 5488-5500 | `neuroticks/gui/widgets/connection_tool.py` |
| &nbsp;&nbsp;&nbsp;.on_node_changed | Methode | 5502-5513 | `neuroticks/gui/widgets/connection_tool.py` |
| &nbsp;&nbsp;&nbsp;.get_selection | Methode | 5515-5519 | `neuroticks/gui/widgets/connection_tool.py` |
| `ConnectionTool` | Klasse | 5522-6331 | `neuroticks/gui/widgets/connection_tool.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 5524-5534 | `neuroticks/gui/widgets/connection_tool.py` |
| &nbsp;&nbsp;&nbsp;.refresh | Methode | 5536-5537 | `neuroticks/gui/widgets/connection_tool.py` |
| &nbsp;&nbsp;&nbsp;.init_ui | Methode | 5539-5746 | `neuroticks/gui/widgets/connection_tool.py` |
| &nbsp;&nbsp;&nbsp;.add_target_row | Methode | 5748-5756 | `neuroticks/gui/widgets/connection_tool.py` |
| &nbsp;&nbsp;&nbsp;.remove_target_row | Methode | 5758-5764 | `neuroticks/gui/widgets/connection_tool.py` |
| &nbsp;&nbsp;&nbsp;.refresh_graph_list | Methode | 5766-5776 | `neuroticks/gui/widgets/connection_tool.py` |
| &nbsp;&nbsp;&nbsp;.on_source_graph_changed | Methode | 5778-5787 | `neuroticks/gui/widgets/connection_tool.py` |
| &nbsp;&nbsp;&nbsp;.on_source_node_changed | Methode | 5789-5801 | `neuroticks/gui/widgets/connection_tool.py` |
| &nbsp;&nbsp;&nbsp;._refresh_da_graph_combo | Methode | 5803-5814 | `neuroticks/gui/widgets/connection_tool.py` |
| &nbsp;&nbsp;&nbsp;.on_da_graph_changed | Methode | 5816-5830 | `neuroticks/gui/widgets/connection_tool.py` |
| &nbsp;&nbsp;&nbsp;.on_da_node_changed | Methode | 5832-5849 | `neuroticks/gui/widgets/connection_tool.py` |
| &nbsp;&nbsp;&nbsp;.add_connection | Methode | 5851-5913 | `neuroticks/gui/widgets/connection_tool.py` |
| &nbsp;&nbsp;&nbsp;.update_connection_list | Methode | 5915-5930 | `neuroticks/gui/widgets/connection_tool.py` |
| &nbsp;&nbsp;&nbsp;.select_connection | Methode | 5932-5935 | `neuroticks/gui/widgets/connection_tool.py` |
| &nbsp;&nbsp;&nbsp;.delete_connection | Methode | 5937-5942 | `neuroticks/gui/widgets/connection_tool.py` |
| &nbsp;&nbsp;&nbsp;.create_all_connections | Methode | 5944-5953 | `neuroticks/gui/widgets/connection_tool.py` |
| &nbsp;&nbsp;&nbsp;.set_source | Methode | 5955-5963 | `neuroticks/gui/widgets/connection_tool.py` |
| &nbsp;&nbsp;&nbsp;._init_spatial_tab | Methode | 5965-6189 | `neuroticks/gui/widgets/connection_tool.py` |
| &nbsp;&nbsp;&nbsp;._on_spatial_rule_changed | Methode | 6191-6198 | `neuroticks/gui/widgets/connection_tool.py` |
| &nbsp;&nbsp;&nbsp;._on_mask_type_changed | Methode | 6200-6205 | `neuroticks/gui/widgets/connection_tool.py` |
| &nbsp;&nbsp;&nbsp;._init_topological_tab | Methode | 6207-6220 | `neuroticks/gui/widgets/connection_tool.py` |
| &nbsp;&nbsp;&nbsp;.on_rule_changed | Methode | 6222-6229 | `neuroticks/gui/widgets/connection_tool.py` |
| &nbsp;&nbsp;&nbsp;.on_synapse_model_changed | Methode | 6231-6266 | `neuroticks/gui/widgets/connection_tool.py` |
| &nbsp;&nbsp;&nbsp;._get_current_params | Methode | 6268-6331 | `neuroticks/gui/widgets/connection_tool.py` |
| `BlinkingNetworkWidget` | Klasse | 6334-6555 | `neuroticks/gui/visualization/blinking_network.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 6335-6367 | `neuroticks/gui/visualization/blinking_network.py` |
| &nbsp;&nbsp;&nbsp;.set_base_opacity | Methode | 6369-6388 | `neuroticks/gui/visualization/blinking_network.py` |
| &nbsp;&nbsp;&nbsp;.build_scene | Methode | 6390-6498 | `neuroticks/gui/visualization/blinking_network.py` |
| &nbsp;&nbsp;&nbsp;.start_simulation | Methode | 6500-6501 | `neuroticks/gui/visualization/blinking_network.py` |
| &nbsp;&nbsp;&nbsp;.stop_simulation | Methode | 6503-6504 | `neuroticks/gui/visualization/blinking_network.py` |
| &nbsp;&nbsp;&nbsp;.animate | Methode | 6506-6548 | `neuroticks/gui/visualization/blinking_network.py` |
| &nbsp;&nbsp;&nbsp;.closeEvent | Methode | 6550-6555 | `neuroticks/gui/visualization/blinking_network.py` |
| `SYNAPSE_MODELS` | Konstante | 6562-6661 | `neuroticks/constants/synapses.py` |
| `CONNECTION_RULES` | Konstante | 6663-6692 | `neuroticks/constants/synapses.py` |
| `create_connection_dict` | Funktion | 6695-6734 | `neuroticks/core/connection_executor.py` |
| `validate_delay` | Funktion | 6737-6747 | `neuroticks/core/connection_executor.py` |
| `validate_connection_params` | Funktion | 6750-6864 | `neuroticks/core/connection_executor.py` |
| `ConnectionExecutor` | Klasse | 6867-7304 | `neuroticks/core/connection_executor.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 6870-6874 | `neuroticks/core/connection_executor.py` |
| &nbsp;&nbsp;&nbsp;._get_next_connection_id | Methode | 6880-6882 | `neuroticks/core/connection_executor.py` |
| &nbsp;&nbsp;&nbsp;._get_population | Methode | 6884-6904 | `neuroticks/core/connection_executor.py` |
| &nbsp;&nbsp;&nbsp;._get_or_create_vt | Methode | 6906-6915 | `neuroticks/core/connection_executor.py` |
| &nbsp;&nbsp;&nbsp;.execute_connection | Methode | 6919-7240 | `neuroticks/core/connection_executor.py` |
| &nbsp;&nbsp;&nbsp;.execute_pending_connections | Methode | 7243-7263 | `neuroticks/core/connection_executor.py` |
| &nbsp;&nbsp;&nbsp;.execute_all | Methode | 7265-7292 | `neuroticks/core/connection_executor.py` |
| &nbsp;&nbsp;&nbsp;.cleanup_custom_models | Methode | 7294-7304 | `neuroticks/core/connection_executor.py` |
| `ConnectionQueueWidget` | Klasse | 7307-7394 | `neuroticks/gui/widgets/connection_tool.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 7312-7315 | `neuroticks/gui/widgets/connection_tool.py` |
| &nbsp;&nbsp;&nbsp;._init_ui | Methode | 7317-7345 | `neuroticks/gui/widgets/connection_tool.py` |
| &nbsp;&nbsp;&nbsp;.add_connection | Methode | 7347-7368 | `neuroticks/gui/widgets/connection_tool.py` |
| &nbsp;&nbsp;&nbsp;._on_item_clicked | Methode | 7370-7373 | `neuroticks/gui/widgets/connection_tool.py` |
| &nbsp;&nbsp;&nbsp;._remove_selected | Methode | 7375-7382 | `neuroticks/gui/widgets/connection_tool.py` |
| &nbsp;&nbsp;&nbsp;.clear_all | Methode | 7384-7387 | `neuroticks/gui/widgets/connection_tool.py` |
| &nbsp;&nbsp;&nbsp;.get_all_connections | Methode | 7389-7390 | `neuroticks/gui/widgets/connection_tool.py` |
| &nbsp;&nbsp;&nbsp;._update_status | Methode | 7392-7394 | `neuroticks/gui/widgets/connection_tool.py` |
| `prune_dangling_connections` | Funktion | 7397-7459 | `neuroticks/core/connection_store.py` |
| `_find_reward_trigger_fallback` | Funktion | 7462-7487 | `neuroticks/core/connection_store.py` |
| `create_nest_connections_from_stored` | Funktion | 7490-7650 | `neuroticks/core/connection_store.py` |
| `repopulate_all_graphs` | Funktion | 7653-7688 | `neuroticks/core/connection_store.py` |
| `safe_nest_reset_and_repopulate` | Funktion | 7691-7752 | `neuroticks/core/connection_store.py` |
| `get_all_connections_summary` | Funktion | 7755-7783 | `neuroticks/core/connection_store.py` |
| `clear_all_connections` | Funktion | 7786-7800 | `neuroticks/core/connection_store.py` |
| `export_connections_to_dict` | Funktion | 7803-7812 | `neuroticks/core/connection_store.py` |
| `import_connections_from_dict` | Funktion | 7815-7857 | `neuroticks/core/connection_store.py` |
| `create_connection_from_gui_params` | Funktion | 7860-7910 | `neuroticks/core/connection_store.py` |
| `validate_SYNAPSE_MODELS` | Funktion | 7913-7935 | `neuroticks/utils/nest_helpers.py` |
| `generate_node_parameters_list` | Funktion | 7938-8081 | `neuroticks/core/node_parameters.py` |
| `SaveLoadWidget` | Klasse | 8083-8196 | `neuroticks/gui/widgets/save_load.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 8085-8089 | `neuroticks/gui/widgets/save_load.py` |
| &nbsp;&nbsp;&nbsp;.setup_ui | Methode | 8091-8130 | `neuroticks/gui/widgets/save_load.py` |
| &nbsp;&nbsp;&nbsp;.save_graph_dialog | Methode | 8132-8160 | `neuroticks/gui/widgets/save_load.py` |
| &nbsp;&nbsp;&nbsp;.load_graph_dialog | Methode | 8162-8196 | `neuroticks/gui/widgets/save_load.py` |
| `add_save_load_buttons` | Funktion | 8198-8213 | `neuroticks/gui/widgets/save_load.py` |
| `SimulationControlWidget` | Klasse | 8215-8257 | `neuroticks/gui/widgets/save_load.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 8216-8218 | `neuroticks/gui/widgets/save_load.py` |
| &nbsp;&nbsp;&nbsp;.init_ui | Methode | 8220-8257 | `neuroticks/gui/widgets/save_load.py` |
| `NumpyEncoder` | Klasse | 8259-8269 | `neuroticks/utils/serialization.py` |
| &nbsp;&nbsp;&nbsp;.default | Methode | 8260-8269 | `neuroticks/utils/serialization.py` |
| `_clean_params` | Funktion | 8271-8302 | `neuroticks/utils/serialization.py` |
| `_serialize_connections` | Funktion | 8304-8322 | `neuroticks/utils/serialization.py` |
| `save_graph` | Funktion | 8324-8396 | `neuroticks/utils/serialization.py` |
| `load_graph` | Funktion | 8398-8470 | `neuroticks/utils/serialization.py` |
| `ConnectionParamWidget` | Klasse | 8474-8956 | `neuroticks/gui/widgets/connection_editor.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 8489-8493 | `neuroticks/gui/widgets/connection_editor.py` |
| &nbsp;&nbsp;&nbsp;.init_ui | Methode | 8495-8578 | `neuroticks/gui/widgets/connection_editor.py` |
| &nbsp;&nbsp;&nbsp;._build_spatial_section | Methode | 8580-8720 | `neuroticks/gui/widgets/connection_editor.py` |
| &nbsp;&nbsp;&nbsp;._toggle_dyn_visibility | Methode | 8722-8726 | `neuroticks/gui/widgets/connection_editor.py` |
| &nbsp;&nbsp;&nbsp;._on_mask_type_changed | Methode | 8728-8731 | `neuroticks/gui/widgets/connection_editor.py` |
| &nbsp;&nbsp;&nbsp;._on_model_changed | Methode | 8733-8777 | `neuroticks/gui/widgets/connection_editor.py` |
| &nbsp;&nbsp;&nbsp;.load_data | Methode | 8779-8862 | `neuroticks/gui/widgets/connection_editor.py` |
| &nbsp;&nbsp;&nbsp;._on_rule_changed | Methode | 8864-8876 | `neuroticks/gui/widgets/connection_editor.py` |
| &nbsp;&nbsp;&nbsp;.apply_changes | Methode | 8878-8956 | `neuroticks/gui/widgets/connection_editor.py` |
| `ConnectionEditorWidget` | Klasse | 8959-9096 | `neuroticks/gui/widgets/connection_editor.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 8974-8978 | `neuroticks/gui/widgets/connection_editor.py` |
| &nbsp;&nbsp;&nbsp;._init_ui | Methode | 8980-9020 | `neuroticks/gui/widgets/connection_editor.py` |
| &nbsp;&nbsp;&nbsp;.load_connection | Methode | 9022-9053 | `neuroticks/gui/widgets/connection_editor.py` |
| &nbsp;&nbsp;&nbsp;._find_live_connection | Methode | 9055-9075 | `neuroticks/gui/widgets/connection_editor.py` |
| &nbsp;&nbsp;&nbsp;.clear | Methode | 9077-9081 | `neuroticks/gui/widgets/connection_editor.py` |
| &nbsp;&nbsp;&nbsp;._on_inner_update | Methode | 9083-9096 | `neuroticks/gui/widgets/connection_editor.py` |
| `DeviceTargetSelector` | Klasse | 9101-9168 | `neuroticks/gui/widgets/device_tools.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 9103-9107 | `neuroticks/gui/widgets/device_tools.py` |
| &nbsp;&nbsp;&nbsp;.init_ui | Methode | 9109-9123 | `neuroticks/gui/widgets/device_tools.py` |
| &nbsp;&nbsp;&nbsp;.refresh | Methode | 9125-9134 | `neuroticks/gui/widgets/device_tools.py` |
| &nbsp;&nbsp;&nbsp;.on_graph_changed | Methode | 9136-9148 | `neuroticks/gui/widgets/device_tools.py` |
| &nbsp;&nbsp;&nbsp;.on_node_changed | Methode | 9150-9161 | `neuroticks/gui/widgets/device_tools.py` |
| &nbsp;&nbsp;&nbsp;.get_selection | Methode | 9163-9168 | `neuroticks/gui/widgets/device_tools.py` |
| `DeviceConfigPage` | Klasse | 9171-9495 | `neuroticks/gui/widgets/device_tools.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 9175-9183 | `neuroticks/gui/widgets/device_tools.py` |
| &nbsp;&nbsp;&nbsp;.init_ui | Methode | 9185-9276 | `neuroticks/gui/widgets/device_tools.py` |
| &nbsp;&nbsp;&nbsp;.load_device_data | Methode | 9278-9324 | `neuroticks/gui/widgets/device_tools.py` |
| &nbsp;&nbsp;&nbsp;.reset_to_create_mode | Methode | 9326-9334 | `neuroticks/gui/widgets/device_tools.py` |
| &nbsp;&nbsp;&nbsp;._gather_data | Methode | 9337-9396 | `neuroticks/gui/widgets/device_tools.py` |
| &nbsp;&nbsp;&nbsp;.create_device | Methode | 9398-9401 | `neuroticks/gui/widgets/device_tools.py` |
| &nbsp;&nbsp;&nbsp;.update_device | Methode | 9403-9410 | `neuroticks/gui/widgets/device_tools.py` |
| &nbsp;&nbsp;&nbsp;._get_color | Methode | 9412-9415 | `neuroticks/gui/widgets/device_tools.py` |
| &nbsp;&nbsp;&nbsp;._build_parameters | Methode | 9417-9474 | `neuroticks/gui/widgets/device_tools.py` |
| &nbsp;&nbsp;&nbsp;._add_param | Methode | 9476-9482 | `neuroticks/gui/widgets/device_tools.py` |
| &nbsp;&nbsp;&nbsp;._add_text_param | Methode | 9484-9487 | `neuroticks/gui/widgets/device_tools.py` |
| &nbsp;&nbsp;&nbsp;._parse_list_input | Methode | 9489-9495 | `neuroticks/gui/widgets/device_tools.py` |
| `ToolsWidget` | Klasse | 9498-9736 | `neuroticks/gui/widgets/device_tools.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 9500-9504 | `neuroticks/gui/widgets/device_tools.py` |
| &nbsp;&nbsp;&nbsp;.update_graphs | Methode | 9506-9511 | `neuroticks/gui/widgets/device_tools.py` |
| &nbsp;&nbsp;&nbsp;.init_ui | Methode | 9513-9580 | `neuroticks/gui/widgets/device_tools.py` |
| &nbsp;&nbsp;&nbsp;.switch_tool | Methode | 9582-9596 | `neuroticks/gui/widgets/device_tools.py` |
| &nbsp;&nbsp;&nbsp;.reset_view | Methode | 9598-9601 | `neuroticks/gui/widgets/device_tools.py` |
| &nbsp;&nbsp;&nbsp;.open_device_editor | Methode | 9603-9626 | `neuroticks/gui/widgets/device_tools.py` |
| &nbsp;&nbsp;&nbsp;.on_device_created | Methode | 9628-9736 | `neuroticks/gui/widgets/device_tools.py` |
| `DeviceHelpWidget` | Klasse | 9739-9797 | `neuroticks/gui/widgets/device_tools.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 9740-9742 | `neuroticks/gui/widgets/device_tools.py` |
| &nbsp;&nbsp;&nbsp;.init_ui | Methode | 9744-9797 | `neuroticks/gui/widgets/device_tools.py` |
| `StructuresWidget` | Klasse | 9800-9892 | `neuroticks/gui/widgets/structures.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 9804-9806 | `neuroticks/gui/widgets/structures.py` |
| &nbsp;&nbsp;&nbsp;.init_ui | Methode | 9808-9892 | `neuroticks/gui/widgets/structures.py` |
| `FlowFieldWidget` | Klasse | 9895-10164 | `neuroticks/gui/visualization/flow_field.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 9896-9906 | `neuroticks/gui/visualization/flow_field.py` |
| &nbsp;&nbsp;&nbsp;.init_ui | Methode | 9908-9970 | `neuroticks/gui/visualization/flow_field.py` |
| &nbsp;&nbsp;&nbsp;.update_dt | Methode | 9972-9973 | `neuroticks/gui/visualization/flow_field.py` |
| &nbsp;&nbsp;&nbsp;.set_target_node | Methode | 9975-9981 | `neuroticks/gui/visualization/flow_field.py` |
| &nbsp;&nbsp;&nbsp;.build_scene | Methode | 9983-10081 | `neuroticks/gui/visualization/flow_field.py` |
| &nbsp;&nbsp;&nbsp;._update_vectors | Methode | 10083-10099 | `neuroticks/gui/visualization/flow_field.py` |
| &nbsp;&nbsp;&nbsp;.perform_step | Methode | 10101-10142 | `neuroticks/gui/visualization/flow_field.py` |
| &nbsp;&nbsp;&nbsp;.reset_positions | Methode | 10144-10164 | `neuroticks/gui/visualization/flow_field.py` |
| `SafeGLViewWidget` | Klasse | 10169-10182 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 10170-10173 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;.paintGL | Methode | 10175-10182 | `neuroticks/gui/visualization/simulation_view.py` |
| `SimulationViewWidget` | Klasse | 10184-11276 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 10187-10232 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;.init_ui | Methode | 10234-10430 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;.update_time_display | Methode | 10432-10432 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;.update_button_styles | Methode | 10433-10433 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;._update_global_radius | Methode | 10434-10455 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;.start_rendering | Methode | 10457-10461 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;.stop_rendering_safe | Methode | 10463-10465 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;.update_animation | Methode | 10467-10493 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;.load_scene | Methode | 10495-10553 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;.unload_scene | Methode | 10555-10563 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;.feed_spikes | Methode | 10565-10570 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;._update_speed_label | Methode | 10572-10572 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;._update_radius | Methode | 10573-10576 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;._update_conn_radius | Methode | 10578-10581 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;._update_gen_type_ui | Methode | 10583-10596 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;._on_conn_rule_changed | Methode | 10598-10606 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;._get_neurons_in_radius | Methode | 10608-10615 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;.set_active_tool | Methode | 10617-10643 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;.project_point_to_screen | Methode | 10645-10661 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;.on_mouse_press | Methode | 10663-10686 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;.create_injector_at | Methode | 10688-10752 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;.handle_tool_click | Methode | 10754-10914 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;.create_injector_ui | Methode | 10917-11065 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;._update_spike_mode_ui | Methode | 11067-11094 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;._update_spike_preview | Methode | 11096-11105 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;._calculate_spike_times | Methode | 11107-11150 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;.trigger_electrode | Methode | 11152-11210 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;._add_electrode_widget | Methode | 11212-11214 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;._remove_electrode_widget | Methode | 11216-11219 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;._rearrange_electrode_grid | Methode | 11221-11239 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;._on_elec_scroll_resize | Methode | 11241-11243 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;.remove_electrode | Methode | 11245-11250 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;.restore_injectors | Methode | 11252-11264 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;._build_conn_spec | Methode | 11266-11273 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;._build_syn_spec | Methode | 11275-11276 | `neuroticks/gui/visualization/simulation_view.py` |
| `InjectorButton` | Klasse | 11279-11386 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;.get_next_letter | Methode | 11291-11299 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;.reset_counter | Methode | 11302-11303 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 11305-11340 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;._apply_style | Methode | 11342-11368 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;.set_active | Methode | 11370-11372 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;.toggle | Methode | 11374-11377 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;._on_click | Methode | 11379-11380 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;._on_right_click | Methode | 11382-11383 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;.sizeHint | Methode | 11385-11386 | `neuroticks/gui/visualization/simulation_view.py` |
| `ElectrodeItem` | Klasse | 11389-11477 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 11394-11474 | `neuroticks/gui/visualization/simulation_view.py` |
| &nbsp;&nbsp;&nbsp;.on_params_changed | Methode | 11476-11477 | `neuroticks/gui/visualization/simulation_view.py` |
| `AnalysisDashboard` | Klasse | 11483-11576 | `neuroticks/gui/dashboards/analysis_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 11484-11487 | `neuroticks/gui/dashboards/analysis_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.init_ui | Methode | 11489-11547 | `neuroticks/gui/dashboards/analysis_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.refresh_all_tabs | Methode | 11549-11554 | `neuroticks/gui/dashboards/analysis_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.switch_view | Methode | 11557-11566 | `neuroticks/gui/dashboards/analysis_dashboard.py` |
| &nbsp;&nbsp;&nbsp;._get_btn_style | Methode | 11568-11576 | `neuroticks/gui/dashboards/analysis_dashboard.py` |
| `SimulationDashboardWidget` | Klasse | 11579-11821 | `neuroticks/gui/dashboards/simulation_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 11585-11588 | `neuroticks/gui/dashboards/simulation_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.init_ui | Methode | 11590-11716 | `neuroticks/gui/dashboards/simulation_dashboard.py` |
| &nbsp;&nbsp;&nbsp;._on_start_clicked | Methode | 11720-11722 | `neuroticks/gui/dashboards/simulation_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.export_script_dialog | Methode | 11723-11756 | `neuroticks/gui/dashboards/simulation_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.set_ui_locked | Methode | 11757-11776 | `neuroticks/gui/dashboards/simulation_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.refresh_data | Methode | 11778-11799 | `neuroticks/gui/dashboards/simulation_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.update_duration_from_external | Methode | 11802-11805 | `neuroticks/gui/dashboards/simulation_dashboard.py` |
| &nbsp;&nbsp;&nbsp;._plot_pie_chart | Methode | 11808-11821 | `neuroticks/gui/dashboards/simulation_dashboard.py` |
| `build_gid_to_meta_map` | Funktion | 11824-11840 | `neuroticks/utils/nest_helpers.py` |
| `ScriptExporter` | Klasse | 11845-12371 | `neuroticks/core/script_exporter.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 11846-11847 | `neuroticks/core/script_exporter.py` |
| &nbsp;&nbsp;&nbsp;.export_project | Methode | 11849-11919 | `neuroticks/core/script_exporter.py` |
| &nbsp;&nbsp;&nbsp;._serialize_graphs | Methode | 11921-12005 | `neuroticks/core/script_exporter.py` |
| &nbsp;&nbsp;&nbsp;._get_template | Methode | 12006-12371 | `neuroticks/core/script_exporter.py` |
| `GraphInfoWidget` | Klasse | 12376-12601 | `neuroticks/gui/widgets/graph_info.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 12377-12380 | `neuroticks/gui/widgets/graph_info.py` |
| &nbsp;&nbsp;&nbsp;.init_ui | Methode | 12382-12412 | `neuroticks/gui/widgets/graph_info.py` |
| &nbsp;&nbsp;&nbsp;.refresh_combo | Methode | 12414-12422 | `neuroticks/gui/widgets/graph_info.py` |
| &nbsp;&nbsp;&nbsp;._create_section | Methode | 12424-12435 | `neuroticks/gui/widgets/graph_info.py` |
| &nbsp;&nbsp;&nbsp;._add_info_row | Methode | 12437-12449 | `neuroticks/gui/widgets/graph_info.py` |
| &nbsp;&nbsp;&nbsp;.generate_report | Methode | 12451-12601 | `neuroticks/gui/widgets/graph_info.py` |
| `TimeSeriesPlotWidget` | Klasse | 12604-12967 | `neuroticks/gui/dashboards/time_series.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 12605-12609 | `neuroticks/gui/dashboards/time_series.py` |
| &nbsp;&nbsp;&nbsp;.init_ui | Methode | 12611-12666 | `neuroticks/gui/dashboards/time_series.py` |
| &nbsp;&nbsp;&nbsp;.refresh_graphs | Methode | 12669-12676 | `neuroticks/gui/dashboards/time_series.py` |
| &nbsp;&nbsp;&nbsp;.on_graph_changed | Methode | 12678-12687 | `neuroticks/gui/dashboards/time_series.py` |
| &nbsp;&nbsp;&nbsp;.on_node_changed | Methode | 12689-12723 | `neuroticks/gui/dashboards/time_series.py` |
| &nbsp;&nbsp;&nbsp;.on_device_changed | Methode | 12725-12744 | `neuroticks/gui/dashboards/time_series.py` |
| &nbsp;&nbsp;&nbsp;._fetch_data | Methode | 12746-12774 | `neuroticks/gui/dashboards/time_series.py` |
| &nbsp;&nbsp;&nbsp;.run_analysis | Methode | 12776-12796 | `neuroticks/gui/dashboards/time_series.py` |
| &nbsp;&nbsp;&nbsp;._plot_2d | Methode | 12799-12873 | `neuroticks/gui/dashboards/time_series.py` |
| &nbsp;&nbsp;&nbsp;._plot_heatmap_2d | Methode | 12875-12918 | `neuroticks/gui/dashboards/time_series.py` |
| &nbsp;&nbsp;&nbsp;._plot_3d | Methode | 12921-12967 | `neuroticks/gui/dashboards/time_series.py` |
| `PythonConsoleWidget` | Klasse | 12970-13077 | `neuroticks/gui/widgets/python_console.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 12971-12979 | `neuroticks/gui/widgets/python_console.py` |
| &nbsp;&nbsp;&nbsp;.init_ui | Methode | 12981-13015 | `neuroticks/gui/widgets/python_console.py` |
| &nbsp;&nbsp;&nbsp;.write_output | Methode | 13017-13020 | `neuroticks/gui/widgets/python_console.py` |
| &nbsp;&nbsp;&nbsp;.execute_command | Methode | 13022-13059 | `neuroticks/gui/widgets/python_console.py` |
| &nbsp;&nbsp;&nbsp;.eventFilter | Methode | 13061-13077 | `neuroticks/gui/widgets/python_console.py` |
| `ToolInspectorWidget` | Klasse | 13080-13151 | `neuroticks/gui/widgets/tool_inspector.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 13081-13084 | `neuroticks/gui/widgets/tool_inspector.py` |
| &nbsp;&nbsp;&nbsp;.init_ui | Methode | 13086-13118 | `neuroticks/gui/widgets/tool_inspector.py` |
| &nbsp;&nbsp;&nbsp;.log | Methode | 13120-13123 | `neuroticks/gui/widgets/tool_inspector.py` |
| &nbsp;&nbsp;&nbsp;.run_inspector | Methode | 13126-13151 | `neuroticks/gui/widgets/tool_inspector.py` |
| `NodeLiveGroup` *(doppelt, wird von Zeile 13218 überschrieben)* | Klasse | 13154-13215 | `neuroticks/gui/dashboards/live_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 13155-13202 | `neuroticks/gui/dashboards/live_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.add_plot | Methode | 13204-13207 | `neuroticks/gui/dashboards/live_dashboard.py` |
| &nbsp;&nbsp;&nbsp;._toggle | Methode | 13209-13212 | `neuroticks/gui/dashboards/live_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.update_summary | Methode | 13214-13215 | `neuroticks/gui/dashboards/live_dashboard.py` |
| `NodeLiveGroup` | Klasse | 13218-13302 | `neuroticks/gui/dashboards/live_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 13219-13277 | `neuroticks/gui/dashboards/live_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.add_device_widget | Methode | 13279-13282 | `neuroticks/gui/dashboards/live_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.toggle_details | Methode | 13284-13287 | `neuroticks/gui/dashboards/live_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.update_sum_plot | Methode | 13289-13302 | `neuroticks/gui/dashboards/live_dashboard.py` |
| `LivePlotWidget` | Klasse | 13306-13477 | `neuroticks/gui/dashboards/live_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 13309-13327 | `neuroticks/gui/dashboards/live_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.set_view_window | Methode | 13329-13332 | `neuroticks/gui/dashboards/live_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.set_buffer_window | Methode | 13334-13337 | `neuroticks/gui/dashboards/live_dashboard.py` |
| &nbsp;&nbsp;&nbsp;._init_ui | Methode | 13339-13387 | `neuroticks/gui/dashboards/live_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.update_data | Methode | 13389-13459 | `neuroticks/gui/dashboards/live_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.set_view_range_to_window | Methode | 13461-13463 | `neuroticks/gui/dashboards/live_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.close_and_flush | Methode | 13465-13467 | `neuroticks/gui/dashboards/live_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.clear_data | Methode | 13469-13477 | `neuroticks/gui/dashboards/live_dashboard.py` |
| `LiveDataDashboard` | Klasse | 13479-13782 | `neuroticks/gui/dashboards/live_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 13483-13493 | `neuroticks/gui/dashboards/live_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.init_ui | Methode | 13495-13572 | `neuroticks/gui/dashboards/live_dashboard.py` |
| &nbsp;&nbsp;&nbsp;._on_view_changed | Methode | 13574-13579 | `neuroticks/gui/dashboards/live_dashboard.py` |
| &nbsp;&nbsp;&nbsp;._on_buffer_changed | Methode | 13581-13586 | `neuroticks/gui/dashboards/live_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.scan_for_devices | Methode | 13588-13683 | `neuroticks/gui/dashboards/live_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.on_tree_item_clicked | Methode | 13685-13701 | `neuroticks/gui/dashboards/live_dashboard.py` |
| &nbsp;&nbsp;&nbsp;._add_pop_rate_plot | Methode | 13703-13711 | `neuroticks/gui/dashboards/live_dashboard.py` |
| &nbsp;&nbsp;&nbsp;._add_dev_plot | Methode | 13713-13724 | `neuroticks/gui/dashboards/live_dashboard.py` |
| &nbsp;&nbsp;&nbsp;._on_widget_closed | Methode | 13726-13728 | `neuroticks/gui/dashboards/live_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.process_incoming_data | Methode | 13730-13766 | `neuroticks/gui/dashboards/live_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.close_all_plots | Methode | 13768-13769 | `neuroticks/gui/dashboards/live_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.clear_all_data | Methode | 13770-13772 | `neuroticks/gui/dashboards/live_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.get_all_data | Methode | 13773-13773 | `neuroticks/gui/dashboards/live_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.reload_and_center | Methode | 13774-13774 | `neuroticks/gui/dashboards/live_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.set_view_mode | Methode | 13775-13780 | `neuroticks/gui/dashboards/live_dashboard.py` |
| &nbsp;&nbsp;&nbsp;._get_mode_btn_style | Methode | 13781-13782 | `neuroticks/gui/dashboards/live_dashboard.py` |
| `PopulationRatePlot` | Klasse | 13785-13868 | `neuroticks/gui/dashboards/live_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 13788-13836 | `neuroticks/gui/dashboards/live_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.set_view_window | Methode | 13838-13840 | `neuroticks/gui/dashboards/live_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.set_buffer_window | Methode | 13842-13844 | `neuroticks/gui/dashboards/live_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.update_from_recorders | Methode | 13846-13861 | `neuroticks/gui/dashboards/live_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.set_view_range_to_window | Methode | 13863-13865 | `neuroticks/gui/dashboards/live_dashboard.py` |
| &nbsp;&nbsp;&nbsp;.clear_data | Methode | 13867-13868 | `neuroticks/gui/dashboards/live_dashboard.py` |
| `LiveConnectionController` | Klasse | 13872-13916 | `neuroticks/gui/dashboards/live_connection_controller.py` |
| &nbsp;&nbsp;&nbsp;.set_weight | Methode | 13874-13900 | `neuroticks/gui/dashboards/live_connection_controller.py` |
| &nbsp;&nbsp;&nbsp;._find_population | Methode | 13903-13916 | `neuroticks/gui/dashboards/live_connection_controller.py` |

## ExtraTab.py

| Name | Art | Zeilen alt | Neuer Ort |
|---|---|---|---|
| `SewingInspector` | Klasse | 66-151 | `neuroticks/gui/tabs/sewing/inspector.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 67-69 | `neuroticks/gui/tabs/sewing/inspector.py` |
| &nbsp;&nbsp;&nbsp;.init_ui | Methode | 71-92 | `neuroticks/gui/tabs/sewing/inspector.py` |
| &nbsp;&nbsp;&nbsp;.clear_content | Methode | 94-97 | `neuroticks/gui/tabs/sewing/inspector.py` |
| &nbsp;&nbsp;&nbsp;.inspect_graph | Methode | 99-120 | `neuroticks/gui/tabs/sewing/inspector.py` |
| &nbsp;&nbsp;&nbsp;.inspect_node | Methode | 122-151 | `neuroticks/gui/tabs/sewing/inspector.py` |
| `OfflineConnectionTargetRow` | Klasse | 157-184 | `neuroticks/gui/tabs/sewing/offline_connection.py` |
| &nbsp;&nbsp;&nbsp;.on_node_changed | Methode | 166-184 | `neuroticks/gui/tabs/sewing/offline_connection.py` |
| `OfflineConnectionTool` | Klasse | 187-279 | `neuroticks/gui/tabs/sewing/offline_connection.py` |
| &nbsp;&nbsp;&nbsp;.on_source_node_changed | Methode | 207-225 | `neuroticks/gui/tabs/sewing/offline_connection.py` |
| &nbsp;&nbsp;&nbsp;.add_target_row | Methode | 228-236 | `neuroticks/gui/tabs/sewing/offline_connection.py` |
| &nbsp;&nbsp;&nbsp;.create_all_connections | Methode | 239-279 | `neuroticks/gui/tabs/sewing/offline_connection.py` |
| `SewingDeviceTool` | Klasse | 282-393 | `neuroticks/gui/tabs/sewing/device_tool.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 283-313 | `neuroticks/gui/tabs/sewing/device_tool.py` |
| &nbsp;&nbsp;&nbsp;.set_selection | Methode | 315-319 | `neuroticks/gui/tabs/sewing/device_tool.py` |
| &nbsp;&nbsp;&nbsp;.update_graphs | Methode | 321-327 | `neuroticks/gui/tabs/sewing/device_tool.py` |
| &nbsp;&nbsp;&nbsp;.on_device_created_offline | Methode | 329-330 | `neuroticks/gui/tabs/sewing/device_tool.py` |
| &nbsp;&nbsp;&nbsp;.on_device_updated_offline | Methode | 332-335 | `neuroticks/gui/tabs/sewing/device_tool.py` |
| &nbsp;&nbsp;&nbsp;._save_device | Methode | 337-376 | `neuroticks/gui/tabs/sewing/device_tool.py` |
| &nbsp;&nbsp;&nbsp;.delete_current_device | Methode | 378-393 | `neuroticks/gui/tabs/sewing/device_tool.py` |
| `SewingDeviceTargetSelector` | Klasse | 395-446 | `neuroticks/gui/tabs/sewing/device_tool.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 396-408 | `neuroticks/gui/tabs/sewing/device_tool.py` |
| &nbsp;&nbsp;&nbsp;.refresh | Methode | 410-413 | `neuroticks/gui/tabs/sewing/device_tool.py` |
| &nbsp;&nbsp;&nbsp;.on_graph_changed | Methode | 415-421 | `neuroticks/gui/tabs/sewing/device_tool.py` |
| &nbsp;&nbsp;&nbsp;.on_node_changed | Methode | 423-432 | `neuroticks/gui/tabs/sewing/device_tool.py` |
| &nbsp;&nbsp;&nbsp;.get_selection | Methode | 434-435 | `neuroticks/gui/tabs/sewing/device_tool.py` |
| &nbsp;&nbsp;&nbsp;.set_selection | Methode | 437-446 | `neuroticks/gui/tabs/sewing/device_tool.py` |
| `SewingToolsPanel` | Klasse | 449-588 | `neuroticks/gui/tabs/sewing/tools_panel.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 461-484 | `neuroticks/gui/tabs/sewing/tools_panel.py` |
| &nbsp;&nbsp;&nbsp;.update_all_graphs | Methode | 486-500 | `neuroticks/gui/tabs/sewing/tools_panel.py` |
| &nbsp;&nbsp;&nbsp;.handle_selection | Methode | 502-548 | `neuroticks/gui/tabs/sewing/tools_panel.py` |
| &nbsp;&nbsp;&nbsp;.use_as_source | Methode | 551-557 | `neuroticks/gui/tabs/sewing/tools_panel.py` |
| &nbsp;&nbsp;&nbsp;.add_as_target | Methode | 559-588 | `neuroticks/gui/tabs/sewing/tools_panel.py` |
| `SewingGraphView` | Klasse | 591-717 | `neuroticks/gui/tabs/sewing/graph_view.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 592-620 | `neuroticks/gui/tabs/sewing/graph_view.py` |
| &nbsp;&nbsp;&nbsp;.toggle_physics | Methode | 622-626 | `neuroticks/gui/tabs/sewing/graph_view.py` |
| &nbsp;&nbsp;&nbsp;.update_data | Methode | 628-663 | `neuroticks/gui/tabs/sewing/graph_view.py` |
| &nbsp;&nbsp;&nbsp;.update_view | Methode | 665-667 | `neuroticks/gui/tabs/sewing/graph_view.py` |
| &nbsp;&nbsp;&nbsp;.start_layout_animation | Methode | 669-669 | `neuroticks/gui/tabs/sewing/graph_view.py` |
| &nbsp;&nbsp;&nbsp;.reset_and_start_animation | Methode | 670-675 | `neuroticks/gui/tabs/sewing/graph_view.py` |
| &nbsp;&nbsp;&nbsp;.step_layout | Methode | 677-717 | `neuroticks/gui/tabs/sewing/graph_view.py` |
| `ExtraTabWidget` | Klasse | 720-1146 | `neuroticks/gui/tabs/sewing/tab.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 721-725 | `neuroticks/gui/tabs/sewing/tab.py` |
| &nbsp;&nbsp;&nbsp;.init_ui | Methode | 727-806 | `neuroticks/gui/tabs/sewing/tab.py` |
| &nbsp;&nbsp;&nbsp;.refresh_all_views | Methode | 808-811 | `neuroticks/gui/tabs/sewing/tab.py` |
| &nbsp;&nbsp;&nbsp;.delete_device_from_overview | Methode | 813-831 | `neuroticks/gui/tabs/sewing/tab.py` |
| &nbsp;&nbsp;&nbsp;.delete_connection_from_overview | Methode | 833-852 | `neuroticks/gui/tabs/sewing/tab.py` |
| &nbsp;&nbsp;&nbsp;._on_tree_clicked | Methode | 854-856 | `neuroticks/gui/tabs/sewing/tab.py` |
| &nbsp;&nbsp;&nbsp;._on_tree_context_menu | Methode | 858-908 | `neuroticks/gui/tabs/sewing/tab.py` |
| &nbsp;&nbsp;&nbsp;._create_header | Methode | 910-912 | `neuroticks/gui/tabs/sewing/tab.py` |
| &nbsp;&nbsp;&nbsp;._get_btn_style | Methode | 914-915 | `neuroticks/gui/tabs/sewing/tab.py` |
| &nbsp;&nbsp;&nbsp;.load_graph_file | Methode | 917-1000 | `neuroticks/gui/tabs/sewing/tab.py` |
| &nbsp;&nbsp;&nbsp;.merge_and_save_project | Methode | 1002-1144 | `neuroticks/gui/tabs/sewing/tab.py` |
| &nbsp;&nbsp;&nbsp;.on_tab_active | Methode | 1146-1146 | `neuroticks/gui/tabs/sewing/tab.py` |

## RetinaTestTab.py

| Name | Art | Zeilen alt | Neuer Ort |
|---|---|---|---|
| `NEURON_MODEL_BY_POP` | Konstante | 79-104 | `neuroticks/retina/virtual_graph.py` |
| `LGN_GRAPH_NAME` | Konstante | 124-124 | `neuroticks/gui/tabs/retina_test.py` |
| `SERVER_RETINA_TO_LGN` | Konstante | 126-140 | `neuroticks/gui/tabs/retina_test.py` |
| `CONNECTION_RULES` | Konstante | 145-151 | `neuroticks/gui/tabs/retina_test.py` |
| `VirtualRetinaNode` | Klasse | 154-213 | `neuroticks/retina/virtual_graph.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 157-188 | `neuroticks/retina/virtual_graph.py` |
| &nbsp;&nbsp;&nbsp;.build | Methode | 194-195 | `neuroticks/retina/virtual_graph.py` |
| &nbsp;&nbsp;&nbsp;.populate_node | Methode | 197-198 | `neuroticks/retina/virtual_graph.py` |
| &nbsp;&nbsp;&nbsp;.connect | Methode | 200-201 | `neuroticks/retina/virtual_graph.py` |
| &nbsp;&nbsp;&nbsp;.verify_and_report | Methode | 203-204 | `neuroticks/retina/virtual_graph.py` |
| &nbsp;&nbsp;&nbsp;.instantiate_devices | Methode | 206-207 | `neuroticks/retina/virtual_graph.py` |
| &nbsp;&nbsp;&nbsp;.add_neighbor | Methode | 209-210 | `neuroticks/retina/virtual_graph.py` |
| &nbsp;&nbsp;&nbsp;.remove_neighbor_if_isolated | Methode | 212-213 | `neuroticks/retina/virtual_graph.py` |
| `VirtualRetinaGraph` | Klasse | 216-274 | `neuroticks/retina/virtual_graph.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 219-231 | `neuroticks/retina/virtual_graph.py` |
| &nbsp;&nbsp;&nbsp;._build_nodes | Methode | 233-257 | `neuroticks/retina/virtual_graph.py` |
| &nbsp;&nbsp;&nbsp;.get_node | Methode | 259-263 | `neuroticks/retina/virtual_graph.py` |
| &nbsp;&nbsp;&nbsp;.remove_node | Methode | 267-268 | `neuroticks/retina/virtual_graph.py` |
| &nbsp;&nbsp;&nbsp;.build_connections | Methode | 270-271 | `neuroticks/retina/virtual_graph.py` |
| &nbsp;&nbsp;&nbsp;.create_node | Methode | 273-274 | `neuroticks/retina/virtual_graph.py` |
| `VideoFrameReader` | Klasse | 281-325 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 290-302 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;.seek | Methode | 304-306 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;.read_next | Methode | 308-320 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;.release | Methode | 322-325 | `neuroticks/gui/tabs/retina_test.py` |
| `RetinaTestTabWidget` | Klasse | 332-1666 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 342-375 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._init_ui | Methode | 381-416 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._build_config_group | Methode | 418-469 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._on_scale_changed | Methode | 471-497 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._build_video_group | Methode | 499-558 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._on_target_resolution_changed | Methode | 560-566 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._build_status_group | Methode | 568-583 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._build_connection_group | Methode | 585-665 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._build_pop_section | Methode | 667-699 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._add_target_row | Methode | 701-713 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._on_target_row_remove | Methode | 715-728 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._iter_all_rows | Methode | 730-734 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._build_playback_group | Methode | 736-795 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._build_log_group | Methode | 797-808 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._log | Methode | 814-817 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._refresh_target_selectors | Methode | 823-828 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._check_server_compat | Methode | 830-859 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._apply_default_targets | Methode | 861-921 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._apply_server_match | Methode | 923-929 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._on_build_clicked | Methode | 935-1047 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._snap_to_power_of_2 | Methode | 1050-1059 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._on_destroy_clicked | Methode | 1061-1084 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._on_target_row_connect | Methode | 1090-1213 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._on_connect_all | Methode | 1215-1221 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._on_disconnect_all | Methode | 1223-1232 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._on_browse_clicked | Methode | 1238-1246 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._try_open_video | Methode | 1248-1264 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._show_preview_frame | Methode | 1266-1282 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._get_effective_fps | Methode | 1288-1298 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._update_bio_per_frame_label | Methode | 1300-1324 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._on_play_clicked | Methode | 1326-1431 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._feed_next_frame_if_needed | Methode | 1433-1452 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;.on_global_tick | Methode | 1454-1489 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;.on_after_global_tick | Methode | 1491-1528 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._on_pause_clicked | Methode | 1530-1535 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._on_rewind_clicked | Methode | 1537-1542 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._on_play_tick | Methode | 1544-1555 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._on_diag_clicked | Methode | 1557-1621 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;.is_retina_active | Methode | 1627-1628 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;.on_tab_activated | Methode | 1630-1632 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;.on_nest_kernel_reset | Methode | 1634-1666 | `neuroticks/gui/tabs/retina_test.py` |
| `_TargetRow` | Klasse | 1676-1978 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 1680-1685 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._init_ui | Methode | 1687-1812 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._on_advanced_toggled | Methode | 1814-1816 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._on_rule_changed | Methode | 1818-1823 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;.get_graph_id | Methode | 1826-1827 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;.get_node_id | Methode | 1829-1830 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;.get_pop_idx | Methode | 1832-1833 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;.get_weight | Methode | 1835-1836 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;.get_delay | Methode | 1838-1839 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;.get_rule | Methode | 1841-1842 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;.get_indegree | Methode | 1844-1845 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;.get_probability | Methode | 1847-1848 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;.get_synapse_model | Methode | 1850-1851 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;.is_connected | Methode | 1853-1854 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;.set_connected | Methode | 1856-1863 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;.apply_server_defaults | Methode | 1865-1875 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;.populate_graphs | Methode | 1878-1894 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;.set_target | Methode | 1896-1938 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._on_graph_changed | Methode | 1940-1957 | `neuroticks/gui/tabs/retina_test.py` |
| &nbsp;&nbsp;&nbsp;._on_node_changed | Methode | 1959-1978 | `neuroticks/gui/tabs/retina_test.py` |
| `_standalone_main` | Funktion | 1997-2063 | `neuroticks/gui/tabs/retina_test.py` |

## CustomExtension.py

| Name | Art | Zeilen alt | Neuer Ort |
|---|---|---|---|
| `CustomTabWidget` | Klasse | 18-331 | `neuroticks/gui/tabs/history_browser.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 19-29 | `neuroticks/gui/tabs/history_browser.py` |
| &nbsp;&nbsp;&nbsp;.init_ui | Methode | 31-101 | `neuroticks/gui/tabs/history_browser.py` |
| &nbsp;&nbsp;&nbsp;.refresh_history_list | Methode | 103-142 | `neuroticks/gui/tabs/history_browser.py` |
| &nbsp;&nbsp;&nbsp;.style_button | Methode | 144-148 | `neuroticks/gui/tabs/history_browser.py` |
| &nbsp;&nbsp;&nbsp;.on_file_selected | Methode | 150-158 | `neuroticks/gui/tabs/history_browser.py` |
| &nbsp;&nbsp;&nbsp;.load_and_show_data | Methode | 160-225 | `neuroticks/gui/tabs/history_browser.py` |
| &nbsp;&nbsp;&nbsp;._reconstruct_graph | Methode | 227-258 | `neuroticks/gui/tabs/history_browser.py` |
| &nbsp;&nbsp;&nbsp;._convert_old_measurements | Methode | 260-299 | `neuroticks/gui/tabs/history_browser.py` |
| &nbsp;&nbsp;&nbsp;.delete_selected_file | Methode | 301-328 | `neuroticks/gui/tabs/history_browser.py` |
| &nbsp;&nbsp;&nbsp;.on_tab_active | Methode | 330-331 | `neuroticks/gui/tabs/history_browser.py` |

## retina_main.py

| Name | Art | Zeilen alt | Neuer Ort |
|---|---|---|---|
| `POP_L_FOVEAL` | Konstante | 113-113 | `neuroticks/retina/populations.py` |
| `POP_M_FOVEAL` | Konstante | 114-114 | `neuroticks/retina/populations.py` |
| `POP_L_PERIPHERAL` | Konstante | 115-115 | `neuroticks/retina/populations.py` |
| `POP_M_PERIPHERAL` | Konstante | 116-116 | `neuroticks/retina/populations.py` |
| `POP_S_PERIPHERAL` | Konstante | 117-117 | `neuroticks/retina/populations.py` |
| `POP_RODS` | Konstante | 118-118 | `neuroticks/retina/populations.py` |
| `PHOTORECEPTOR_POPS` | Konstante | 120-124 | `neuroticks/retina/populations.py` |
| `POP_HORIZONTAL_FOVEAL` | Konstante | 128-128 | `neuroticks/retina/populations.py` |
| `POP_HORIZONTAL_PERIPHERAL` | Konstante | 129-129 | `neuroticks/retina/populations.py` |
| `POP_MIDGET_ON_BIP_FOVEAL` | Konstante | 134-134 | `neuroticks/retina/populations.py` |
| `POP_MIDGET_OFF_BIP_FOVEAL` | Konstante | 135-135 | `neuroticks/retina/populations.py` |
| `POP_MIDGET_ON_BIP_PERIPHERAL` | Konstante | 136-136 | `neuroticks/retina/populations.py` |
| `POP_MIDGET_OFF_BIP_PERIPHERAL` | Konstante | 137-137 | `neuroticks/retina/populations.py` |
| `POP_PARASOL_ON_BIP` | Konstante | 143-143 | `neuroticks/retina/populations.py` |
| `POP_PARASOL_OFF_BIP` | Konstante | 144-144 | `neuroticks/retina/populations.py` |
| `POP_KONIO_S_BIP` | Konstante | 154-154 | `neuroticks/retina/populations.py` |
| `POP_KONIO_GANG` | Konstante | 155-155 | `neuroticks/retina/populations.py` |
| `POP_AMACRINE_FOVEAL` | Konstante | 158-158 | `neuroticks/retina/populations.py` |
| `POP_AMACRINE_PERIPHERAL` | Konstante | 159-159 | `neuroticks/retina/populations.py` |
| `POP_MIDGET_ON_GANG_FOVEAL` | Konstante | 164-164 | `neuroticks/retina/populations.py` |
| `POP_MIDGET_OFF_GANG_FOVEAL` | Konstante | 165-165 | `neuroticks/retina/populations.py` |
| `POP_MIDGET_ON_GANG_PERIPHERAL` | Konstante | 166-166 | `neuroticks/retina/populations.py` |
| `POP_MIDGET_OFF_GANG_PERIPHERAL` | Konstante | 167-167 | `neuroticks/retina/populations.py` |
| `POP_PARASOL_ON_GANG` | Konstante | 169-169 | `neuroticks/retina/populations.py` |
| `POP_PARASOL_OFF_GANG` | Konstante | 170-170 | `neuroticks/retina/populations.py` |
| `BIPOLAR_POPS` | Konstante | 172-177 | `neuroticks/retina/populations.py` |
| `GANGLION_POPS` | Konstante | 179-184 | `neuroticks/retina/populations.py` |
| `VALID_INPUT_RESOLUTIONS` | Konstante | 189-189 | `neuroticks/retina/populations.py` |
| `uniform_cap_points` | Funktion | 202-241 | `neuroticks/retina/geometry.py` |
| `uniform_sphere_band` | Funktion | 244-277 | `neuroticks/retina/geometry.py` |
| `radial_project` | Funktion | 280-298 | `neuroticks/retina/geometry.py` |
| `nearest_k_indices` | Funktion | 301-326 | `neuroticks/retina/geometry.py` |
| `DEFAULT_PARAMS` | Konstante | 333-527 | `neuroticks/retina/defaults.py` |
| `DEFAULT_NEURON_PARAMS` | Konstante | 530-612 | `neuroticks/retina/defaults.py` |
| `DEFAULT_FEEDER_CONFIG` | Konstante | 615-721 | `neuroticks/retina/defaults.py` |
| `_validate_resolution` | Funktion | 724-741 | `neuroticks/retina/feeder.py` |
| `RetinaInputFeeder` | Klasse | 761-1438 | `neuroticks/retina/feeder.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 781-881 | `neuroticks/retina/feeder.py` |
| &nbsp;&nbsp;&nbsp;._build_generators | Methode | 883-922 | `neuroticks/retina/feeder.py` |
| &nbsp;&nbsp;&nbsp;.set_photo_positions | Methode | 924-964 | `neuroticks/retina/feeder.py` |
| &nbsp;&nbsp;&nbsp;.feed | Methode | 966-1025 | `neuroticks/retina/feeder.py` |
| &nbsp;&nbsp;&nbsp;._apply_fem | Methode | 1027-1106 | `neuroticks/retina/feeder.py` |
| &nbsp;&nbsp;&nbsp;.get_fem_position | Methode | 1111-1119 | `neuroticks/retina/feeder.py` |
| &nbsp;&nbsp;&nbsp;.get_fem_stats | Methode | 1121-1135 | `neuroticks/retina/feeder.py` |
| &nbsp;&nbsp;&nbsp;.reset_fem | Methode | 1137-1143 | `neuroticks/retina/feeder.py` |
| &nbsp;&nbsp;&nbsp;._apply_cone_cascade | Methode | 1145-1188 | `neuroticks/retina/feeder.py` |
| &nbsp;&nbsp;&nbsp;._resize_frame | Methode | 1190-1204 | `neuroticks/retina/feeder.py` |
| &nbsp;&nbsp;&nbsp;._sample_frame | Methode | 1206-1256 | `neuroticks/retina/feeder.py` |
| &nbsp;&nbsp;&nbsp;._compute_bipolar_amplitudes | Methode | 1258-1287 | `neuroticks/retina/feeder.py` |
| &nbsp;&nbsp;&nbsp;._compute_bipolar_amplitudes_weber | Methode | 1289-1327 | `neuroticks/retina/feeder.py` |
| &nbsp;&nbsp;&nbsp;._compute_bipolar_amplitudes_cascade | Methode | 1329-1400 | `neuroticks/retina/feeder.py` |
| &nbsp;&nbsp;&nbsp;._update_step_current | Methode | 1402-1425 | `neuroticks/retina/feeder.py` |
| &nbsp;&nbsp;&nbsp;._update_poisson | Methode | 1427-1438 | `neuroticks/retina/feeder.py` |
| `Retina` | Klasse | 1446-2855 | `neuroticks/retina/retina.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 1460-1503 | `neuroticks/retina/retina.py` |
| &nbsp;&nbsp;&nbsp;.compute_counts | Methode | 1509-1621 | `neuroticks/retina/retina.py` |
| &nbsp;&nbsp;&nbsp;._generate_positions | Methode | 1627-1759 | `neuroticks/retina/retina.py` |
| &nbsp;&nbsp;&nbsp;.build | Methode | 1765-1952 | `neuroticks/retina/retina.py` |
| &nbsp;&nbsp;&nbsp;._compute_bipolar_to_photo_mapping | Methode | 1958-2074 | `neuroticks/retina/retina.py` |
| &nbsp;&nbsp;&nbsp;.connect | Methode | 2080-2115 | `neuroticks/retina/retina.py` |
| &nbsp;&nbsp;&nbsp;._resolve_synapse | Methode | 2121-2159 | `neuroticks/retina/retina.py` |
| &nbsp;&nbsp;&nbsp;._connect_nearest | Methode | 2161-2228 | `neuroticks/retina/retina.py` |
| &nbsp;&nbsp;&nbsp;._connect_one_to_one_ribbon | Methode | 2230-2263 | `neuroticks/retina/retina.py` |
| &nbsp;&nbsp;&nbsp;._connect_horizontal_lateral | Methode | 2269-2360 | `neuroticks/retina/retina.py` |
| &nbsp;&nbsp;&nbsp;._connect_bipolar_to_midget_ganglion | Methode | 2362-2405 | `neuroticks/retina/retina.py` |
| &nbsp;&nbsp;&nbsp;._connect_bipolar_to_parasol_ganglion | Methode | 2407-2436 | `neuroticks/retina/retina.py` |
| &nbsp;&nbsp;&nbsp;._connect_konio_pathway | Methode | 2438-2500 | `neuroticks/retina/retina.py` |
| &nbsp;&nbsp;&nbsp;._connect_amacrine_circuit | Methode | 2502-2601 | `neuroticks/retina/retina.py` |
| &nbsp;&nbsp;&nbsp;.create_input_feeder | Methode | 2607-2662 | `neuroticks/retina/retina.py` |
| &nbsp;&nbsp;&nbsp;.get_populations | Methode | 2670-2672 | `neuroticks/retina/retina.py` |
| &nbsp;&nbsp;&nbsp;.get_output_populations | Methode | 2674-2680 | `neuroticks/retina/retina.py` |
| &nbsp;&nbsp;&nbsp;.get_photoreceptor_populations | Methode | 2682-2684 | `neuroticks/retina/retina.py` |
| &nbsp;&nbsp;&nbsp;.get_positions | Methode | 2686-2688 | `neuroticks/retina/retina.py` |
| &nbsp;&nbsp;&nbsp;.get_counts | Methode | 2690-2692 | `neuroticks/retina/retina.py` |
| &nbsp;&nbsp;&nbsp;.get_origin | Methode | 2694-2696 | `neuroticks/retina/retina.py` |
| &nbsp;&nbsp;&nbsp;._compute_grid_maps | Methode | 2702-2714 | `neuroticks/retina/retina.py` |
| &nbsp;&nbsp;&nbsp;._compute_grid_for_resolution | Methode | 2716-2763 | `neuroticks/retina/retina.py` |
| &nbsp;&nbsp;&nbsp;.get_grid_maps | Methode | 2765-2784 | `neuroticks/retina/retina.py` |
| &nbsp;&nbsp;&nbsp;.get_id_to_bucket | Methode | 2786-2793 | `neuroticks/retina/retina.py` |
| &nbsp;&nbsp;&nbsp;.get_bucket_resolution | Methode | 2795-2797 | `neuroticks/retina/retina.py` |
| &nbsp;&nbsp;&nbsp;.print_counts | Methode | 2803-2829 | `neuroticks/retina/retina.py` |
| &nbsp;&nbsp;&nbsp;.create_spike_recorders | Methode | 2831-2855 | `neuroticks/retina/retina.py` |

## retina_scales.py

| Name | Art | Zeilen alt | Neuer Ort |
|---|---|---|---|
| `SCALES` | Konstante | 53-135 | `neuroticks/retina/scales.py` |
| `_RESOLUTION_FOR_SCALE` | Konstante | 158-164 | `neuroticks/retina/scales.py` |
| `_LEGACY_NAME_MAP` | Konstante | 171-179 | `neuroticks/retina/scales.py` |
| `_resolve_scale` | Funktion | 182-205 | `neuroticks/retina/scales.py` |
| `VARIANTS` | Konstante | 212-437 | `neuroticks/retina/scales.py` |
| `NEURON_OVERRIDES` | Konstante | 444-446 | `neuroticks/retina/scales.py` |
| `_feeder_config_for` | Funktion | 453-459 | `neuroticks/retina/scales.py` |
| `_GRAPH_TO_RETINA_RECOMMENDATION` | Konstante | 466-472 | `neuroticks/retina/scales.py` |
| `get_config` | Funktion | 479-529 | `neuroticks/retina/scales.py` |
| `list_scales` | Funktion | 532-534 | `neuroticks/retina/scales.py` |
| `list_variants` | Funktion | 537-539 | `neuroticks/retina/scales.py` |
| `recommend_for_graph` | Funktion | 542-556 | `neuroticks/retina/scales.py` |
| `describe` | Funktion | 559-606 | `neuroticks/retina/scales.py` |

## retina_factory.py

| Name | Art | Zeilen alt | Neuer Ort |
|---|---|---|---|
| `build_retina_array` | Funktion | 43-169 | `neuroticks/retina/factory.py` |
| `_warn_if_too_close` | Funktion | 172-178 | `neuroticks/retina/factory.py` |
| `connect_retina_to_lgn` | Funktion | 189-288 | `neuroticks/retina/factory.py` |

## cone_cascade.py

| Name | Art | Zeilen alt | Neuer Ort |
|---|---|---|---|
| `SIGMA` | Konstante | 100-100 | `neuroticks/retina/cone_cascade.py` |
| `PHI` | Konstante | 101-101 | `neuroticks/retina/cone_cascade.py` |
| `ETA` | Konstante | 102-102 | `neuroticks/retina/cone_cascade.py` |
| `BETA` | Konstante | 107-107 | `neuroticks/retina/cone_cascade.py` |
| `N_HILL` | Konstante | 108-108 | `neuroticks/retina/cone_cascade.py` |
| `BETA_CA` | Konstante | 115-115 | `neuroticks/retina/cone_cascade.py` |
| `Q_CA` | Konstante | 116-116 | `neuroticks/retina/cone_cascade.py` |
| `K_CA_GC` | Konstante | 117-117 | `neuroticks/retina/cone_cascade.py` |
| `I_DARK` | Konstante | 122-122 | `neuroticks/retina/cone_cascade.py` |
| `G_DARK` | Konstante | 123-123 | `neuroticks/retina/cone_cascade.py` |
| `K_I` | Konstante | 124-124 | `neuroticks/retina/cone_cascade.py` |
| `_C_SS_DARK` | Konstante | 139-139 | `neuroticks/retina/cone_cascade.py` |
| `_S_GC_DARK` | Konstante | 140-140 | `neuroticks/retina/cone_cascade.py` |
| `_P_SS_DARK` | Konstante | 141-141 | `neuroticks/retina/cone_cascade.py` |
| `ALPHA_BASE` | Konstante | 142-142 | `neuroticks/retina/cone_cascade.py` |
| `STIMULUS_GAIN` | Konstante | 162-162 | `neuroticks/retina/cone_cascade.py` |
| `ConeCascade` | Klasse | 170-404 | `neuroticks/retina/cone_cascade.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 200-239 | `neuroticks/retina/cone_cascade.py` |
| &nbsp;&nbsp;&nbsp;.step | Methode | 245-360 | `neuroticks/retina/cone_cascade.py` |
| &nbsp;&nbsp;&nbsp;.step_normalized | Methode | 362-382 | `neuroticks/retina/cone_cascade.py` |
| &nbsp;&nbsp;&nbsp;.reset | Methode | 384-393 | `neuroticks/retina/cone_cascade.py` |
| &nbsp;&nbsp;&nbsp;.get_state | Methode | 395-404 | `neuroticks/retina/cone_cascade.py` |
| `RetinaCascadeBundle` | Klasse | 412-519 | `neuroticks/retina/cone_cascade.py` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 446-477 | `neuroticks/retina/cone_cascade.py` |
| &nbsp;&nbsp;&nbsp;.step_all | Methode | 479-510 | `neuroticks/retina/cone_cascade.py` |
| &nbsp;&nbsp;&nbsp;.reset_all | Methode | 512-515 | `neuroticks/retina/cone_cascade.py` |
| &nbsp;&nbsp;&nbsp;.get_states | Methode | 517-519 | `neuroticks/retina/cone_cascade.py` |

## graph_factory.py

| Name | Art | Zeilen alt | Neuer Ort |
|---|---|---|---|
| `ID_OFFSET_PER_AGENT` | Konstante | 43-43 | `neuroticks/core/graph_factory.py` |
| `_shift_positions_in_blueprint` | Funktion | 46-93 | `neuroticks/core/graph_factory.py` |
| `_remap_da_source_in_blueprint` | Funktion | 96-133 | `neuroticks/core/graph_factory.py` |
| `build_graph_array` | Funktion | 136-273 | `neuroticks/core/graph_factory.py` |
| `_collect_recorders_for_graph` | Funktion | 276-312 | `neuroticks/core/graph_factory.py` |
| `find_latest_graph_json` | Funktion | 319-333 | `neuroticks/core/graph_factory.py` |
| `get_pop_for_graph_node` | Funktion | 336-348 | `neuroticks/core/graph_factory.py` |
| `verify_graph_positions` | Funktion | 355-424 | `neuroticks/core/graph_factory.py` |

## neuron_toolbox.py

| Name | Art | Zeilen alt | Neuer Ort |
|---|---|---|---|
| `SCALING_FACTOR` | Konstante | 24-24 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `k` | Konstante | 25-25 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `m` | Konstante | 26-26 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `dt` | Konstante | 27-27 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `positions` | Konstante | 28-28 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `gsl` | Konstante | 29-29 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `VERBOSE_BUILD` | Konstante | 34-34 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `_vprint` | Funktion | 36-39 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `_DOPA_VT_CACHE` | Konstante | 57-57 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `_DOPA_VT_PROP` | Konstante | 63-63 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `_detect_vt_property` | Funktion | 66-94 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `dopa_vt_to_param_value` | Funktion | 97-113 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `clear_dopa_vt_cache` | Funktion | 116-118 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `get_or_create_dopa_vt` | Funktion | 122-195 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `MC_MODELS` | Konstante | 199-199 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `get_mc_recordables` | Funktion | 201-208 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `get_receptor_type_for_model` | Funktion | 210-217 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `area2models` | Konstante | 220-234 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `apply_transform` | Funktion | 236-255 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `compute_angular_similarity_weights` | Funktion | 257-278 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `_is_plasticity_synapse` | Funktion | 280-284 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `_adjust_wmax_if_needed` | Funktion | 287-300 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `connect_neighbors_by_index` | Funktion | 303-360 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `extract_connections` | Funktion | 364-373 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `to_adjacency` | Funktion | 376-383 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `plot_point_clusters` | Funktion | 386-417 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `plot_point_clusters_normalized` | Funktion | 420-465 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `set_axes_equal` | Funktion | 467-482 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `make_div_curl` | Funktion | 486-509 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `generate_direction_similarity_matrix` | Funktion | 512-552 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `generate_direction_similarity_matrix2` | Funktion | 555-610 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `PolynomGenerator` | Klasse | 613-931 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 614-619 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.coefficients | Methode | 622-623 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.coefficients | Methode | 626-651 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.term_matrix | Methode | 653-670 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.random_coefficients | Methode | 672-673 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.create_exponential_prob_vector | Methode | 675-678 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.generate | Methode | 680-731 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.reconstruct | Methode | 734-780 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.reconstruct_from_list | Methode | 782-789 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.generate_multiple | Methode | 791-807 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.decode_polynom | Methode | 809-814 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.encode_multiple | Methode | 816-821 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.decode_multiple | Methode | 823-828 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.derivative | Methode | 830-873 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.gradient | Methode | 875-881 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.gradient_vector | Methode | 884-894 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.derivative_encoded | Methode | 895-922 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.second_derivative | Methode | 925-931 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `circle3d` | Funktion | 935-977 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `create_cone` | Funktion | 980-1032 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `blob_positions` | Funktion | 1035-1063 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `create_Grid` | Funktion | 1066-1106 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `wave_collapse_old` | Funktion | 1109-1250 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `wave_collapse` | Funktion | 1253-1304 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `generate_cube` | Funktion | 1307-1313 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `transform_points` | Funktion | 1316-1351 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `field` | Funktion | 1354-1410 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `generate_torus` | Funktion | 1413-1434 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `simulate_vector_field_flow` | Funktion | 1437-1474 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `field_flow_iteration` | Funktion | 1476-1488 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `add_local_attractor` | Funktion | 1491-1524 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `find_positions_by_type` | Funktion | 1526-1538 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `anisotropic_wave_collapse` | Funktion | 1539-1667 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `wave_collapse_bio` | Funktion | 1669-1688 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `cluster_and_flow` | Funktion | 1690-1771 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `cluster_and_flow_flexible` | Funktion | 1773-1853 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `compute_rotational_similarity_weights` | Funktion | 1856-1877 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `create_CCW` | Funktion | 1878-2013 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `_build_conn_spec` | Funktion | 2016-2030 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `CCW_spike_recorder` | Funktion | 2033-2043 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `connect_cone` | Funktion | 2045-2174 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `connect_cone_ccw` | Funktion | 2177-2206 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `create_blob_population` | Funktion | 2209-2266 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `blob` | Funktion | 2269-2287 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `connect_blob_cone` | Funktion | 2289-2349 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `grid2visual` | Funktion | 2352-2435 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `input_to_receptive_field` | Funktion | 2438-2447 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `filter_params_for_model` | Funktion | 2457-2486 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `clusters_to_neurons` | Funktion | 2489-2549 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `xy_distance` | Funktion | 2551-2552 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `eye_lgn_layer` | Funktion | 2554-2578 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `vis_cortex_pos` | Funktion | 2581-2730 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `vis2neurons` | Funktion | 2733-2764 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `node_parameters` | Konstante | 2767-2811 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `neuron_colors` | Konstante | 2814-2871 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `raw_models` | Konstante | 2872-2872 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `successful_neuron_models` | Konstante | 2873-2873 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `region_names` | Konstante | 2876-2885 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `distributions` | Konstante | 2887-2922 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `distributions2` | Konstante | 2923-3201 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `get_probability_vector` | Funktion | 3204-3213 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `rand_prob_vector` | Funktion | 3215-3218 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `random_direction` | Funktion | 3220-3223 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `create_lambda_array_zero` | Funktion | 3225-3230 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `plot_graph_3d` | Funktion | 3232-3281 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `get_raw_shape_points` | Funktion | 3282-3308 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `Node` | Klasse | 3314-4063 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 3315-3356 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.set_graph_id | Methode | 3358-3358 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.check_function_generator | Methode | 3359-3361 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.build | Methode | 3363-3484 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.populate_node | Methode | 3486-3743 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.add_neighbor | Methode | 3745-3747 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.remove_neighbor_if_isolated | Methode | 3749-3757 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.remove | Methode | 3759-3808 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.instantiate_devices | Methode | 3810-3866 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.verify_and_report | Methode | 3868-3872 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.connect | Methode | 3874-3885 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;._build_single_connection | Methode | 3887-3954 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;._nest_connect | Methode | 3956-4035 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;._build_spatial_conn_spec | Methode | 4037-4063 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `generate_node_parameters_list` | Funktion | 4073-4206 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `Graph` | Klasse | 4208-5053 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 4209-4238 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.random_direction | Methode | 4240-4243 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;._allocate_node_id | Methode | 4245-4279 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.create_node | Methode | 4281-4354 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.populate | Methode | 4357-4437 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.build_connections | Methode | 4440-4447 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.build_all | Methode | 4449-4455 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.get_node | Methode | 4457-4460 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.remove_node | Methode | 4462-4478 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.dispose | Methode | 4480-4494 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.connect_nodes | Methode | 4496-4497 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.list_nodes | Methode | 4499-4507 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.from_json | Methode | 4532-4580 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.load_all_from_json | Methode | 4583-4652 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.to_json | Methode | 4654-4738 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;._read_thin_json | Methode | 4743-4752 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;._extract_graph_block | Methode | 4755-4777 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;._remap_connection_graph_ids | Methode | 4780-4799 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;._build_from_block | Methode | 4802-4852 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;._apply_node_data | Methode | 4854-4942 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;._reconstruct_topology | Methode | 4944-4974 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;._serialize_node | Methode | 4976-5050 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.__repr__ | Methode | 5052-5053 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `_thin_clean_value` | Funktion | 5056-5077 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `createGraph` | Funktion | 5080-5085 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `graphInfo` | Funktion | 5087-5131 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `get_ccw_topology` | Funktion | 5134-5152 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `get_shape_positions` | Funktion | 5154-5182 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `get_connection_snapshot` | Funktion | 5184-5191 | `neuron_toolbox.py (bleibt im Projekt-Root)` |
| `sync_node_attributes_to_parameters` | Funktion | 5193-5201 | `neuron_toolbox.py (bleibt im Projekt-Root)` |

## OtherTab.py

| Name | Art | Zeilen alt | Neuer Ort |
|---|---|---|---|
| `OtherTabWidget` | Klasse | 18-90 | `OtherTab.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.__init__ | Methode | 21-24 | `OtherTab.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;._build_ui | Methode | 26-90 | `OtherTab.py (bleibt im Projekt-Root)` |

## run_template.py

| Name | Art | Zeilen alt | Neuer Ort |
|---|---|---|---|
| `JSON_FILENAME` | Konstante | 44-44 | `run_template.py (bleibt im Projekt-Root)` |
| `OUTPUT_DIR` | Konstante | 45-45 | `run_template.py (bleibt im Projekt-Root)` |
| `OUTPUT_PREFIX` | Konstante | 46-46 | `run_template.py (bleibt im Projekt-Root)` |
| `NEST_RESOLUTION` | Konstante | 49-49 | `run_template.py (bleibt im Projekt-Root)` |
| `NUM_THREADS` | Konstante | 50-50 | `run_template.py (bleibt im Projekt-Root)` |
| `RNG_SEED` | Konstante | 51-51 | `run_template.py (bleibt im Projekt-Root)` |
| `PRINT_TIME` | Konstante | 52-52 | `run_template.py (bleibt im Projekt-Root)` |
| `ENABLE_STRUCTURAL_PLASTICITY` | Konstante | 53-53 | `run_template.py (bleibt im Projekt-Root)` |
| `SIM_DURATION` | Konstante | 56-56 | `run_template.py (bleibt im Projekt-Root)` |
| `DUMP_INTERVAL` | Konstante | 57-57 | `run_template.py (bleibt im Projekt-Root)` |
| `NUM_RUNS` | Konstante | 58-58 | `run_template.py (bleibt im Projekt-Root)` |
| `VERBOSE_BUILD` | Konstante | 63-63 | `run_template.py (bleibt im Projekt-Root)` |
| `HISTORY_INDENT` | Konstante | 66-66 | `run_template.py (bleibt im Projekt-Root)` |
| `NumpyNestEncoder` | Klasse | 73-84 | `run_template.py (bleibt im Projekt-Root)` |
| &nbsp;&nbsp;&nbsp;.default | Methode | 75-84 | `run_template.py (bleibt im Projekt-Root)` |
| `_get_nest_time` | Funktion | 87-94 | `run_template.py (bleibt im Projekt-Root)` |
| `init_kernel` | Funktion | 97-121 | `run_template.py (bleibt im Projekt-Root)` |
| `load_and_build` | Funktion | 124-157 | `run_template.py (bleibt im Projekt-Root)` |
| `cache_active_recorders` | Funktion | 160-202 | `run_template.py (bleibt im Projekt-Root)` |
| `collect_and_flush` | Funktion | 205-230 | `run_template.py (bleibt im Projekt-Root)` |
| `simulate_one_run` | Funktion | 233-257 | `run_template.py (bleibt im Projekt-Root)` |
| `build_history_file` | Funktion | 260-315 | `run_template.py (bleibt im Projekt-Root)` |
| `write_history` | Funktion | 318-330 | `run_template.py (bleibt im Projekt-Root)` |
| `run_one` | Funktion | 333-356 | `run_template.py (bleibt im Projekt-Root)` |
| `main` | Funktion | 359-381 | `run_template.py (bleibt im Projekt-Root)` |
