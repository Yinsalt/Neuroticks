# Refactoring-Bericht

Stand: 15.11.2026. Ausgangsbasis: 13 Python-Dateien mit 33.143 Zeilen, davon WidgetLib.py 13.916 und Main.py 5.296.

## 1. Neue Struktur

Im Projekt-Root bleiben nur der Einstiegspunkt und die Dateien, die per Name gefunden werden müssen:

```
Main.py                  Einstiegspunkt (python Main.py), nur noch 14 Zeilen
neuron_toolbox.py        Engine, weiter eine Datei (wird vom Projekt-Export kopiert, server.py importiert sie)
functional_models.json   unverändert
run_template.py          unverändert
OtherTab.py              unverändert (deine Sandbox)
neuroticks/              der gesamte restliche Code als Paket
docs/                    dieser Bericht und das Funktionsinventar
WidgetLib.py, ExtraTab.py, RetinaTestTab.py, CustomExtension.py, retina_main.py, retina_scales.py,
retina_factory.py, cone_cascade.py, graph_factory.py
                         dünne Weiterleitungen auf die neuen Module (siehe Abschnitt 5)
```

Das Paket (Datei, Zeilen, Inhalt):

```
neuroticks/
    constants/
        colors.py                           46  Farbtabelle der Neuronenmodelle für das Hauptfenster.
        node_tools.py                      152  Node-Tools (CCW, Blob, Cone, ...): Parameter-Schlüssel und Defaults.
        synapses.py                        335  Synapsenmodelle und Verbindungsregeln (Parameter-Metadaten für die GUI).
    core/
        connection_executor.py             624  Validierung und Ausführung von Verbindungen in NEST (ConnectionExecutor).
        connection_store.py                524  Gespeicherte Verbindungen: neu aufbauen, bereinigen, exportieren, importieren.
        graph_builders.py                   55  Baut Graph-Objekte aus den im Graph-Creator gesammelten Parametern.
        graph_factory.py                   424  GraphFactory — baut N "Brain-Sets" aus einer graphs.json (oder v*.json) Blaupa
        node_parameters.py                 149  Übersetzt GUI-Eingaben in Node-Parameterlisten.
        script_exporter.py                 536  Export eines Projekts als eigenständiges Headless-Skript (run.py + graphs.json
    gui/
        dashboards/
            analysis_dashboard.py              106  AnalysisDashboard: Auswertung gespeicherter Simulationsdaten.
            live_connection_controller.py       48  Ändert Gewichte bestehender Verbindungen während der Simulation.
            live_dashboard.py                  728  Live-Plots während der laufenden Simulation.
            simulation_dashboard.py            258  SimulationDashboardWidget: Steuerung von Headless-Läufen und Export.
            time_series.py                     378  TimeSeriesPlotWidget: Zeitreihen aufgezeichneter Devices.
        main_window/
            mixins/
                examples.py                        279  Examples/-Ordner: scannen und Beispiele ins Projekt importieren.
                graph_events.py                    326  Reaktionen auf Änderungen an Graphen, Verbindungen und Devices.
                headless.py                        113  Headless-Simulation aus der GUI heraus.
                layout.py                          961  Aufbau der Oberfläche: Menü, Bereiche, Ansichtswechsel.
                nest_kernel.py                     483  NEST-Kernel: Reset, Neuaufbau und Prüfung der Populationen.
                persistence.py                    1108  Speichern, Laden und Zusammenführen von Projekten sowie Archivieren von Live-D
                project.py                         100  Projekt anlegen und Anwendung zurücksetzen.
                simulation.py                      626  Live-Simulation: Timer, Start/Stop/Step, Recorder und Datenverteilung.
                visualization.py                   685  3D-Darstellung: Neuronenpunkte, Graph-Skelett, Hover und Detail-Panel.
            dialogs.py                          49  Dialoge des Hauptfensters.
            examples_page.py                   140  Seite 'Population Examples': Browser für den Examples/-Ordner.
            json_encoder.py                     11  NumpyEncoder-Variante, die das Hauptfenster beim Speichern benutzt.
            widgets.py                         200  Hilfs-Widgets des Hauptfensters (Viewport, Vorschau, Statusleiste).
            window.py                          102  MainWindow: setzt die Mixins zusammen und hält die Qt-Event-Handler.
        tabs/
            sewing/
                device_tool.py                     171  Device-Werkzeug des Sewing-Tabs (hängt Devices nur ans Datenmodell).
                graph_view.py                      133  SewingGraphView: 2D-Graphansicht mit kraftbasiertem Layout.
                inspector.py                        90  SewingInspector: Detailanzeige für den ausgewählten Graphen oder Node.
                offline_connection.py              130  Offline-Varianten des ConnectionTools (ohne NEST-Verkabelung).
                tab.py                             472  ExtraTabWidget: der Sewing-Arbeitsbereich.
                tools_panel.py                     148  SewingToolsPanel: Inspector, Connect, Edit und Instruments als Tabs.
            history_browser.py                 331  
            retina_test.py                    1898  RetinaTestTab.py
        visualization/
            blinking_network.py                232  BlinkingNetworkWidget: animierte Netzwerk-Vorschau.
            flow_field.py                      280  FlowFieldWidget: 3D-Ansicht der Flussfelder.
            simulation_view.py                1325  Interaktive 3D-Simulationsansicht mit Injektoren und Elektroden.
        widgets/
            connection_editor.py               633  Editor für bereits bestehende Verbindungen.
            connection_tool.py                1032  ConnectionTool: Verbindungen zwischen Populationen anlegen (inkl. Warteschlang
            device_tools.py                    709  Devices (Recorder, Generatoren): Zielauswahl, Konfiguration, Werkzeugleiste.
            dialogs.py                          40  Kleine Dialoge der Widget-Bibliothek.
            flow_layout.py                     109  FlowLayout: Layout mit automatischem Zeilenumbruch.
            graph_creator.py                  1010  GraphCreatorWidget: neuen Graphen samt Nodes und Populationen anlegen.
            graph_editor.py                   1546  EditGraphWidget: bestehende Graphen bearbeiten.
            graph_info.py                      232  Tabellarische Detailansicht eines Graphen.
            graph_overview.py                  509  Baumansicht aller Graphen, Nodes, Populationen, Verbindungen und Devices.
            input_fields.py                     83  Einfache beschriftete Eingabefelder (Zahl, Auswahl, Checkbox).
            neuron_parameters.py               587  Editoren für Neuronenmodell- und Node-Parameter.
            polynomial_widgets.py              315  Editoren für die Flussfeld-Polynome.
            python_console.py                  117  Eingebettete Python-Konsole.
            save_load.py                       183  Speichern/Laden-Buttons und einfache Simulationssteuerung.
            structures.py                      101  Auswahl vordefinierter Hirnregionen-Strukturen.
            synapse_widgets.py                 439  Widgets zur Auswahl und Parametrierung von Synapsenmodellen.
            tool_inspector.py                   77  Inspektor für Node-Tools.
        bootstrap.py                        21  Einmalige GUI-Initialisierung.
        pg_config.py                         6  Globale pyqtgraph-Einstellungen (wird beim Import der GUI-Pakete gesetzt).
        theme.py                           126  Dunkles Farbschema der Anwendung.
    retina/
        cone_cascade.py                    519  ==============================================================================
        defaults.py                        396  Default-Parameter der Retina, der Neuronenmodelle und des Input-Feeders.
        factory.py                         288  RetinaFactory — nimmt ein Positions-Array entgegen.
        feeder.py                          727  RetinaInputFeeder: wandelt Bild-Frames in Photorezeptor-Ströme um.
        geometry.py                        140  Punktverteilungen auf der Retina-Kugelschale und Nachbarschaftssuche.
        populations.py                     131  Namen der Retina-Populationen und gültige Eingangsauflösungen.
        retina.py                         1488  ==============================================================================
        scales.py                          627  retina_scales.py — Skalen- und Varianten-Profile für die Retina
        virtual_graph.py                   166  Duck-typed Graph/Node-Adapter, damit die Retina in den Live-Ansichten erschein
    utils/
        nest_helpers.py                    107  Kleine, defensive Helfer rund um NEST-Populationen und -Modelle.
        polynomials.py                      54  Erzeugung zufälliger Polynome für die Flussfelder.
        serialization.py                   220  JSON-Serialisierung von Graphen, Parametern und Verbindungen.
        spatial.py                         249  Räumliche NEST-Verbindungsparameter: Masken, distanzabhängige Gewichte/Delays.
    paths.py                             5  Zentrale Pfade des Projekts.
    state.py                            17  Gemeinsamer, veränderlicher Laufzeit-Zustand (Graph-Liste, ID-Zähler, Flags).
```

Abhängigkeiten laufen nur in eine Richtung: `gui` -> `core` -> `utils`/`constants` -> `neuron_toolbox`.
`core`, `utils`, `constants` und `retina` importieren kein Qt. Es gibt keine Import-Zyklen.

## 2. Wie verschoben wurde

Nichts wurde abgetippt. Ein Skript zerlegt jede Originaldatei per AST in Blöcke (eine Top-Level-Anweisung
samt der Kommentare und Leerzeilen davor), kopiert jeden Block wortgetreu in sein Zielmodul und berechnet
die Importe jedes Zielmoduls aus der Namensauflösung des Originals. Das war nötig, weil Main.py und
WidgetLib.py per `from neuron_toolbox import *` gearbeitet haben: Namen wie `nest`, `json`, `np`, `Graph`
kamen dort nie aus einem eigenen Import. Jedes neue Modul importiert jetzt explizit, was es benutzt.

`MainWindow` (4.594 Zeilen, 106 Methoden) ist in neun Mixins aufgeteilt. Jede Methode ist unverändert, nur
die Klasse, in der sie steht, ist eine andere. `__init__`, `closeEvent` und `resizeEvent` stehen weiter
direkt in `MainWindow`. Doppelt definierte Methoden liegen bewusst im selben Mixin, damit weiter die
spätere Definition gewinnt.

## 3. Inhaltliche Eingriffe

Vier Arten, alle einzeln in Anhang A und B aufgelistet. Mehr wurde am Code nicht verändert.

1. **Gemeinsamer Zustand.** `next_graph_id`, `POLYNOM_NOISE_LEVEL`, `_nest_simulation_has_run` und
   `successful_neuron_models` wurden per `global` neu gebunden. Über Modulgrenzen funktioniert das nicht
   (ein `from x import NAME` kopiert nur den momentanen Wert). Diese vier Namen leben jetzt in
   `neuroticks/state.py` und werden als `state.NAME` angesprochen. Main.py hat das mit
   `WidgetLib.next_graph_id = ...` schon so gemacht, daraus wurde `state.next_graph_id = ...`.
   `graph_list` und `graph_parameters` liegen auch in `state.py`, werden aber nie neu gebunden und können
   normal importiert werden.
2. **Pfade.** Zwei Stellen haben mit `__file__` den Ordner neben Main.py bzw. WidgetLib.py gesucht
   (Examples-Ordner, Export von neuron_toolbox.py). Beide benutzen jetzt `PROJECT_ROOT` aus
   `neuroticks/paths.py`.
3. **Lokale Importe.** Importe innerhalb von Funktionen und try-Blöcken (`from WidgetLib import ...`,
   `from retina_main import ...`) zeigen auf die neuen Module.
4. **Top-Level-Importe.** Die 197 Import-Zeilen am Dateikopf der zerlegten Dateien sind durch berechnete
   Importe ersetzt. Bei neuron_toolbox.py wurden nur die doppelten Importe im Kopf zusammengefasst
   (22 Zeilen -> 16), der Namensraum des Moduls ist identisch (106 Namen, geprüft).

Zusätzlich neu geschrieben: Modul-Docstrings, `paths.py`, `gui/bootstrap.py`, die `__init__.py`-Dateien,
die Mixin-Klassenköpfe und die Weiterleitungsdateien.

`gui/bootstrap.py` lädt die schweren Bibliotheken in der Reihenfolge des alten Main.py (Qt, pyqtgraph,
pyvista, matplotlib, vtk, zuletzt NEST). Ohne das hätte die neue Struktur NEST vor Qt und vtk importiert.
Ob das bei dir Probleme macht, kann ich ohne echtes NEST nicht wissen, also bleibt die Reihenfolge wie sie war.

## 4. Prüfungen

Echtes NEST gibt es in meiner Umgebung nicht. Geprüft wurde deshalb mit einer NEST-Attrappe (ein Modul,
das jeden Aufruf annimmt). PyQt6, pyqtgraph, pyvista, vtk und matplotlib waren echt.

| Prüfung | Ergebnis |
|---|---|
| Zeilenbilanz: jede nicht leere Originalzeile (ohne Kopf-Importe und protokollierte Eingriffe) muss wortgleich im neuen Baum stehen | 27.243 Zeilen geprüft, 27.242 gefunden. Die eine Ausnahme ist `class MainWindow(QMainWindow):`, das jetzt die Mixins auflistet |
| AST-Vergleich jeder Funktion, Klasse, Methode und Modul-Anweisung | 337 Stück, 317 identisch, 20 abweichend, alle 20 enthalten protokollierte Eingriffe |
| Bytecode und Namensauflösung: löst jede Funktion jeden globalen Namen auf dasselbe Objekt auf wie vorher | 992 Funktionen und Methoden, 946 identisch, 23 direkt editiert, 13 verweisen auf eine editierte Funktion, 0 unerklärt |
| pyflakes auf dem neuen Baum | keine undefinierten Namen (eine Meldung zu einer String-Annotation `"Retina"`, die es so schon gab) |
| Import jedes der 86 Module einzeln, dazu alle alten Modulnamen | ohne Fehler |
| MainWindow starten (Qt offscreen, VTK-Interactor durch Attrappe ersetzt), alt und neu | Widget-Baum identisch (7.434 Qt-Objekte), dieselben 84 Instanz-Attribute |
| Verhalten der editierten Stellen: Graph-Zähler, Rauschpegel, Modellliste, Examples-Pfad, Projekt-Export aus fremdem Arbeitsverzeichnis | alt und neu gleich, exportiertes run.py bytegleich |
| Import-Reihenfolge der schweren Bibliotheken beim Start | identisch zum alten Main.py |

Nicht geprüft, weil ohne NEST und Display nicht möglich: eine echte Simulation, das Rendering in pyvista
und pyqtgraph.opengl, der Retina-Tab mit Video, server.py (lag nicht bei).

## 5. Alte Modulnamen

`import WidgetLib`, `from retina_factory import build_retina_array` usw. funktionieren weiter, weil im Root
je eine Weiterleitungsdatei liegt. Die sind für server.py und andere Skripte gedacht, die ich nicht gesehen
habe. Wenn die auf die neuen Pfade umgestellt sind, können die neun Dateien gelöscht werden.

Eine Sache geht über die Weiterleitung nicht: Schreiben auf Modulvariablen. `WidgetLib.next_graph_id = 5`
ändert nur noch die Kopie in der Weiterleitungsdatei. Richtig ist `from neuroticks import state` und
`state.next_graph_id = 5`. `neuron_toolbox.VERBOSE_BUILD = True` funktioniert wie bisher, weil
neuron_toolbox.py eine echte Datei geblieben ist.

Der Retina-Tab startet eigenständig mit `python RetinaTestTab.py` oder `python -m neuroticks.gui.tabs.retina_test`.

## 6. Auffälligkeiten im alten Code

Alles hier ist unverändert übernommen. Ich habe nichts davon repariert, weil das Verhalten gleich bleiben sollte.

- **Doppelte Definitionen, die frühere ist tot:** `MainWindow.on_graph_created` (Zeile 764 und 2573),
  `MainWindow.update_simulation_speed` (3109 und 3418), `MainWindow.stop_simulation` (3473 und 3895),
  `SYNAPSE_MODELS` in WidgetLib (419 und 6562, unterschiedlicher Aufbau), `NodeLiveGroup` (13154 und 13218).
- **Dreimal NumpyEncoder** mit leicht unterschiedlichem Verhalten: WidgetLib, Main.py (Zeile 5087, den benutzt
  das Hauptfenster beim Speichern) und run_template.py. Der aus Main liegt jetzt in
  `gui/main_window/json_encoder.py`.
- **Zweimal neuron_colors:** Main.py hat eine eigene Farbtabelle (über `get_neuron_color`, benutzt in
  `plot_neuron_points`), alle Widgets nehmen die aus neuron_toolbox. Die beiden Tabellen sind nicht gleich,
  die 3D-Hauptansicht kann ein Modell also anders einfärben als die Dashboards. Die aus Main liegt jetzt in
  `constants/colors.py`.
- **Nie aufgerufen:** `generate_node_parameters_list` aus WidgetLib (jetzt `core/node_parameters.py`). Benutzt
  wird nur die gleichnamige Funktion aus neuron_toolbox.
- **`_nest_simulation_has_run`** wird an vier Stellen auf False gesetzt und nirgends auf True. Die Abfrage in
  `ToolsWidget.on_device_created` kann so nie greifen.
- **run_template.py** wird vom Exporter nicht benutzt. `ScriptExporter` hat eine eigene Vorlage als
  String eingebettet. Falls run_template.py die aktuelle Fassung sein soll, zieht der Export sie noch nicht.
- **neuron_toolbox importiert IPython** (`from IPython.display import Image, display`), auch im Headless-Betrieb.

## 7. Änderungen nach dem Refactoring

- **15.11.2026, Connection Creator und Retina:** Das Bauen oder Zerstören der Retina hat nur die 3D-Ansicht
  aktualisiert, nicht die Graph-Auswahl im Connection Creator. Die Retina erschien dort nur, wenn danach
  zufällig ein Graph angelegt oder geladen wurde. Neu: `GraphEventsMixin._on_retina_graphs_changed` ruft
  `connection_tool.refresh()` auf und hängt an `retinaBuilt` und `retinaDestroyed` (verdrahtet in
  `mixins/layout.py`). Das Verhalten war im alten Main.py identisch, es ist kein Fehler aus dem Umbau.

## Anhang A: Alle inhaltlich geänderten Zeilen

| Datei (alt) | Zeile | vorher | nachher |
|---|---|---|---|
| CustomExtension.py | 15 | `from WidgetLib import AnalysisDashboard` | `from neuroticks.gui.dashboards.analysis_dashboard import AnalysisDashboard` |
| ExtraTab.py | 38 | `from graph_factory import _remap_da_source_in_blueprint` | `from neuroticks.core.graph_factory import _remap_da_source_in_blueprint` |
| Main.py | 32 | `from RetinaTestTab import RetinaTestTabWidget` | `from neuroticks.gui.tabs.retina_test import RetinaTestTabWidget` |
| Main.py | 630 | `WidgetLib.next_graph_id = 0` | `state.next_graph_id = 0` |
| Main.py | 631 | `WidgetLib.graph_parameters.clear()` | `state.graph_parameters.clear()` |
| Main.py | 4035 | `WidgetLib.next_graph_id = 0` | `state.next_graph_id = 0` |
| Main.py | 4036 | `WidgetLib.graph_parameters.clear()` | `state.graph_parameters.clear()` |
| Main.py | 4047 | `if gid >= WidgetLib.next_graph_id:` | `if gid >= state.next_graph_id:` |
| Main.py | 4048 | `WidgetLib.next_graph_id = gid + 1` | `state.next_graph_id = gid + 1` |
| Main.py | 4323 | `if g.graph_id >= WidgetLib.next_graph_id:` | `if g.graph_id >= state.next_graph_id:` |
| Main.py | 4324 | `WidgetLib.next_graph_id = g.graph_id + 1` | `state.next_graph_id = g.graph_id + 1` |
| Main.py | 4358 | `from WidgetLib import validate_connection_params` | `from neuroticks.core.connection_executor import validate_connection_params` |
| Main.py | 4549 | `here = Path(os.path.dirname(os.path.abspath(__file__)))` | `here = Path(PROJECT_ROOT)` |
| Main.py | 4762 | `WidgetLib.next_graph_id = max(g.graph_id for g in graph_list) + 1` | `state.next_graph_id = max(g.graph_id for g in graph_list) + 1` |
| Main.py | 4974 | `WidgetLib.next_graph_id = max(g.graph_id for g in graph_list) + 1` | `state.next_graph_id = max(g.graph_id for g in graph_list) + 1` |
| RetinaTestTab.py | 53 | `from retina_main import (` | `from neuroticks.retina.retina import Retina<br>    from neuroticks.retina.populations import GANGLION_POPS, BIPOLAR_POPS` |
| RetinaTestTab.py | 58 | `from retina_scales import get_config, list_scales, list_variants` | `from neuroticks.retina.scales import get_config, list_scales, list_variants` |
| RetinaTestTab.py | 479 | `from retina_scales import _RESOLUTION_FOR_SCALE, _resolve_scale` | `from neuroticks.retina.scales import _RESOLUTION_FOR_SCALE, _resolve_scale` |
| RetinaTestTab.py | 980 | `from retina_scales import _RESOLUTION_FOR_SCALE, _resolve_scale` | `from neuroticks.retina.scales import _RESOLUTION_FOR_SCALE, _resolve_scale` |
| WidgetLib.py | 624 | `noise = POLYNOM_NOISE_LEVEL` | `noise = state.POLYNOM_NOISE_LEVEL` |
| WidgetLib.py | 1460 | `successful_neuron_models = sorted(raw, key=lambda x: x.lower())` | `state.successful_neuron_models = sorted(raw, key=lambda x: x.lower())` |
| WidgetLib.py | 1464 | `if p in successful_neuron_models:` | `if p in state.successful_neuron_models:` |
| WidgetLib.py | 1465 | `successful_neuron_models.remove(p)` | `state.successful_neuron_models.remove(p)` |
| WidgetLib.py | 1466 | `successful_neuron_models.insert(0, p)` | `state.successful_neuron_models.insert(0, p)` |
| WidgetLib.py | 1695 | `combo.addItems(successful_neuron_models)` | `combo.addItems(state.successful_neuron_models)` |
| WidgetLib.py | 2908 | `self.graph_name_input.setText(f"Graph_{next_graph_id}")` | `self.graph_name_input.setText(f"Graph_{state.next_graph_id}")` |
| WidgetLib.py | 2922 | `self.noise_slider.setValue(int(POLYNOM_NOISE_LEVEL * 100))` | `self.noise_slider.setValue(int(state.POLYNOM_NOISE_LEVEL * 100))` |
| WidgetLib.py | 2925 | `self.noise_value_lbl = QLabel(f"{POLYNOM_NOISE_LEVEL:.2f}")` | `self.noise_value_lbl = QLabel(f"{state.POLYNOM_NOISE_LEVEL:.2f}")` |
| WidgetLib.py | 3119 | `POLYNOM_NOISE_LEVEL = value / 100.0` | `state.POLYNOM_NOISE_LEVEL = value / 100.0` |
| WidgetLib.py | 3120 | `self.noise_value_lbl.setText(f"{POLYNOM_NOISE_LEVEL:.2f}")` | `self.noise_value_lbl.setText(f"{state.POLYNOM_NOISE_LEVEL:.2f}")` |
| WidgetLib.py | 3290 | `global next_graph_id, graph_parameters` | `global graph_parameters` |
| WidgetLib.py | 3329 | `graph_id = next_graph_id` | `graph_id = state.next_graph_id` |
| WidgetLib.py | 3330 | `next_graph_id += 1` | `state.next_graph_id += 1` |
| WidgetLib.py | 3873 | `next_name = f"Graph_{next_graph_id}"` | `next_name = f"Graph_{state.next_graph_id}"` |
| WidgetLib.py | 5185 | `_nest_simulation_has_run = False` | `state._nest_simulation_has_run = False` |
| WidgetLib.py | 5325 | `_nest_simulation_has_run = False` | `state._nest_simulation_has_run = False` |
| WidgetLib.py | 7723 | `_nest_simulation_has_run = False` | `state._nest_simulation_has_run = False` |
| WidgetLib.py | 7959 | `available_models = successful_neuron_models` | `available_models = state.successful_neuron_models` |
| WidgetLib.py | 9634 | `if _nest_simulation_has_run:` | `if state._nest_simulation_has_run:` |
| WidgetLib.py | 9638 | `_nest_simulation_has_run = False` | `state._nest_simulation_has_run = False` |
| WidgetLib.py | 11874 | `from WidgetLib import NumpyEncoder` | `from neuroticks.utils.serialization import NumpyEncoder` |
| WidgetLib.py | 11881 | `current_dir = os.path.dirname(os.path.abspath(__file__))` | `current_dir = PROJECT_ROOT` |
| WidgetLib.py | 11922 | `from WidgetLib import _clean_params, _serialize_connections` | `from neuroticks.utils.serialization import _clean_params, _serialize_connections` |
| retina_factory.py | 35 | `from retina_main import Retina` | `from neuroticks.retina.retina import Retina` |
| retina_factory.py | 36 | `from retina_scales import get_config` | `from neuroticks.retina.scales import get_config` |
| retina_main.py | 938 | `from cone_cascade import RetinaCascadeBundle, STIMULUS_GAIN` | `from neuroticks.retina.cone_cascade import RetinaCascadeBundle, STIMULUS_GAIN` |

## Anhang B: Entfallene Zeilen

Nur `global`-Deklarationen, die durch `state.NAME` überflüssig wurden, und Folgezeilen eines mehrzeiligen Imports, der neu geschrieben wurde.

| Datei (alt) | Zeile | Inhalt |
|---|---|---|
| RetinaTestTab.py | 54 | `Retina,` |
| RetinaTestTab.py | 55 | `GANGLION_POPS,` |
| RetinaTestTab.py | 56 | `BIPOLAR_POPS,` |
| RetinaTestTab.py | 57 | `)` |
| WidgetLib.py | 623 | `global POLYNOM_NOISE_LEVEL` |
| WidgetLib.py | 1453 | `global successful_neuron_models` |
| WidgetLib.py | 2907 | `global next_graph_id` |
| WidgetLib.py | 3118 | `global POLYNOM_NOISE_LEVEL` |
| WidgetLib.py | 3872 | `global next_graph_id` |
| WidgetLib.py | 5182 | `global _nest_simulation_has_run` |
| WidgetLib.py | 5323 | `global _nest_simulation_has_run` |
| WidgetLib.py | 7700 | `global _nest_simulation_has_run` |
| WidgetLib.py | 9629 | `global _nest_simulation_has_run` |
