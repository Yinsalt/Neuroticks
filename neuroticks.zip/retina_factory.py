"""Kompatibilitäts-Shim: der Inhalt von retina_factory.py liegt jetzt im Paket ``neuroticks``.

Bestehende Skripte (z. B. server.py) können weiter ``import retina_factory`` schreiben.
Neuer Code importiert direkt aus den unten genannten Modulen.
"""
# flake8: noqa
from neuroticks.retina.factory import _warn_if_too_close, build_retina_array, connect_retina_to_lgn
from neuroticks.retina.factory import *
