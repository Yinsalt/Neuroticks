"""Kompatibilitäts-Shim: der Inhalt von CustomExtension.py liegt jetzt im Paket ``neuroticks``.

Bestehende Skripte (z. B. server.py) können weiter ``import CustomExtension`` schreiben.
Neuer Code importiert direkt aus den unten genannten Modulen.
"""
# flake8: noqa
from neuroticks.gui.tabs.history_browser import CustomTabWidget
from neuroticks.gui.tabs.history_browser import *
