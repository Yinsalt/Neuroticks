"""Kompatibilitäts-Shim: der Inhalt von retina_main.py liegt jetzt im Paket ``neuroticks``.

Bestehende Skripte (z. B. server.py) können weiter ``import retina_main`` schreiben.
Neuer Code importiert direkt aus den unten genannten Modulen.
"""
# flake8: noqa
from neuroticks.retina.defaults import DEFAULT_FEEDER_CONFIG, DEFAULT_NEURON_PARAMS, DEFAULT_PARAMS
from neuroticks.retina.feeder import _validate_resolution, RetinaInputFeeder
from neuroticks.retina.geometry import (
    nearest_k_indices, radial_project, uniform_cap_points, uniform_sphere_band,
)
from neuroticks.retina.populations import (
    BIPOLAR_POPS, GANGLION_POPS, PHOTORECEPTOR_POPS, POP_AMACRINE_FOVEAL,
    POP_AMACRINE_PERIPHERAL, POP_HORIZONTAL_FOVEAL, POP_HORIZONTAL_PERIPHERAL,
    POP_KONIO_GANG, POP_KONIO_S_BIP, POP_L_FOVEAL, POP_L_PERIPHERAL, POP_M_FOVEAL,
    POP_M_PERIPHERAL, POP_MIDGET_OFF_BIP_FOVEAL, POP_MIDGET_OFF_BIP_PERIPHERAL,
    POP_MIDGET_OFF_GANG_FOVEAL, POP_MIDGET_OFF_GANG_PERIPHERAL, POP_MIDGET_ON_BIP_FOVEAL,
    POP_MIDGET_ON_BIP_PERIPHERAL, POP_MIDGET_ON_GANG_FOVEAL, POP_MIDGET_ON_GANG_PERIPHERAL,
    POP_PARASOL_OFF_BIP, POP_PARASOL_OFF_GANG, POP_PARASOL_ON_BIP, POP_PARASOL_ON_GANG,
    POP_RODS, POP_S_PERIPHERAL, VALID_INPUT_RESOLUTIONS,
)
from neuroticks.retina.retina import Retina
