"""Kompatibilitäts-Shim: der Inhalt von retina_scales.py liegt jetzt im Paket ``neuroticks``.

Bestehende Skripte (z. B. server.py) können weiter ``import retina_scales`` schreiben.
Neuer Code importiert direkt aus den unten genannten Modulen.
"""
# flake8: noqa
from neuroticks.retina.scales import (
    _feeder_config_for, _GRAPH_TO_RETINA_RECOMMENDATION, _LEGACY_NAME_MAP,
    _RESOLUTION_FOR_SCALE, _resolve_scale, describe, get_config, list_scales, list_variants,
    NEURON_OVERRIDES, recommend_for_graph, SCALES, VARIANTS,
)
from neuroticks.retina.scales import *
