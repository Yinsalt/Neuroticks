#!/bin/bash
# NeuroTicks installer (Ubuntu 22.04 / 24.04)
#   bash install.sh
# Optional environment overrides:
#   INSTALL_DIR=~/neuroticks  NEUROTICKS_REPO=<git url>  NEUROTICKS_BRANCH=main
#   SKIP_SYSTEM=1 (no apt)  SKIP_PYTHON=1 (no venv/pip)  SKIP_NEST=1 (no NEST build)
set -euo pipefail

INSTALL_DIR="${INSTALL_DIR:-${HOME}/neuroticks}"
VENV_DIR="${INSTALL_DIR}/venv"
NEST_SRC="${INSTALL_DIR}/nest-src"
NEST_BUILD="${INSTALL_DIR}/nest-build"
NEST_VERSION="v3.8"
NEUROTICKS_REPO="${NEUROTICKS_REPO:-https://github.com/Yinsalt/Neuroticks.git}"
NEUROTICKS_BRANCH="${NEUROTICKS_BRANCH:-main}"
EXCLUDE_DIR="old"                                                   # never fetched from the repo
REQUIRED=(Main.py neuron_toolbox.py functional_models.json neuroticks/__init__.py neuroticks/state.py)
NUM_CORES=$(nproc)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]:-$0}")" 2>/dev/null && pwd || pwd)"

say()  { echo -e "\n==> $*"; }
fail() { echo -e "\nERROR: $*" >&2; exit 1; }

missing_in() {                                                      # prints required files missing in $1
    local d="$1" f
    for f in "${REQUIRED[@]}"; do [ -e "${d}/${f}" ] || echo "${f}"; done
}

fetch_repo() {                                                      # fetch repo into $1, without old/
    local dest="$1"
    rm -rf "${dest}"; mkdir -p "${dest}"
    if command -v git >/dev/null 2>&1 && (
        set -e
        git clone --quiet --no-checkout --depth 1 --branch "${NEUROTICKS_BRANCH}" \
            --filter=blob:none "${NEUROTICKS_REPO}" "${dest}"
        cd "${dest}"
        git sparse-checkout init --no-cone >/dev/null 2>&1 || git config core.sparseCheckout true
        printf '/*\n!/%s/\n' "${EXCLUDE_DIR}" > .git/info/sparse-checkout
        git checkout --quiet "${NEUROTICKS_BRANCH}"
    ); then
        return 0
    fi
    echo "    git sparse checkout failed, falling back to tarball download"
    case "${NEUROTICKS_REPO}" in
        https://github.com/*) ;;
        *) fail "Could not fetch ${NEUROTICKS_REPO}" ;;
    esac
    local url="${NEUROTICKS_REPO%.git}/archive/refs/heads/${NEUROTICKS_BRANCH}.tar.gz"
    rm -rf "${dest}"; mkdir -p "${dest}"
    curl -fsSL "${url}" | tar -xz -C "${dest}" --strip-components=1 \
        --anchored --no-wildcards-match-slash --exclude="*/${EXCLUDE_DIR}" \
        || fail "Could not download ${url}"
}

# ─── 1. Locate or fetch the NeuroTicks files ────────────────────────
say "Locating NeuroTicks files"
MISSING_LOCAL="$(missing_in "${SCRIPT_DIR}")"
if [ -z "${MISSING_LOCAL}" ]; then
    NEUROTICKS_DIR="${SCRIPT_DIR}"                                  # everything sits next to this script
    echo "    using files next to install.sh: ${NEUROTICKS_DIR}"
elif [ "$(echo "${MISSING_LOCAL}" | wc -l)" -lt "${#REQUIRED[@]}" ]; then
    NEUROTICKS_DIR="${SCRIPT_DIR}"                                  # partly there: pull only what is missing
    echo "    missing next to install.sh:"; echo "${MISSING_LOCAL}" | sed 's/^/      /'
    command -v git >/dev/null 2>&1 || command -v curl >/dev/null 2>&1 || fail "need git or curl to fetch files"
    TMP_FETCH="$(mktemp -d)"
    fetch_repo "${TMP_FETCH}/repo"
    rm -rf "${TMP_FETCH}/repo/.git"
    cp -rn "${TMP_FETCH}/repo/." "${NEUROTICKS_DIR}/"               # -n: never overwrite existing files
    rm -rf "${TMP_FETCH}"
    echo "    missing files pulled from ${NEUROTICKS_REPO} (existing files untouched, ${EXCLUDE_DIR}/ skipped)"
else
    NEUROTICKS_DIR="${INSTALL_DIR}/NeuroTicks"                      # nothing local: fresh checkout
    if [ -z "$(missing_in "${NEUROTICKS_DIR}")" ]; then
        echo "    already present: ${NEUROTICKS_DIR}"
        if [ -d "${NEUROTICKS_DIR}/.git" ]; then
            git -C "${NEUROTICKS_DIR}" pull --quiet --ff-only || echo "    (git pull skipped: local changes or offline)"
        fi
    else
        if [ -e "${NEUROTICKS_DIR}" ] && [ -n "$(ls -A "${NEUROTICKS_DIR}" 2>/dev/null)" ]; then
            mv "${NEUROTICKS_DIR}" "${NEUROTICKS_DIR}.bak.$(date +%Y%m%d_%H%M%S)"
            echo "    incomplete folder moved aside to ${NEUROTICKS_DIR}.bak.*"
        fi
        mkdir -p "${INSTALL_DIR}"
        if ! command -v git >/dev/null 2>&1 && ! command -v curl >/dev/null 2>&1; then
            [ "${SKIP_SYSTEM:-0}" = "1" ] && fail "need git or curl to fetch files"
            sudo apt-get update && sudo apt-get install -y git curl
        fi
        fetch_repo "${NEUROTICKS_DIR}"
        echo "    fetched ${NEUROTICKS_REPO} (${NEUROTICKS_BRANCH}) without ${EXCLUDE_DIR}/ into ${NEUROTICKS_DIR}"
    fi
fi
STILL_MISSING="$(missing_in "${NEUROTICKS_DIR}")"
if [ -n "${STILL_MISSING}" ]; then
    echo "${STILL_MISSING}" | sed 's/^/      missing: /'
    fail "NeuroTicks files are incomplete in ${NEUROTICKS_DIR}.
       If neuroticks/ is missing, the repository still has the old single-file layout."
fi

# ─── 2. System packages ─────────────────────────────────────────────
if [ "${SKIP_SYSTEM:-0}" != "1" ]; then
    say "Installing system packages (sudo)"
    sudo apt-get update
    if [ -z "${PYTHON_VERSION:-}" ]; then                           # 24.04 ships 3.12, 22.04 ships 3.10
        if apt-cache show python3.12-venv >/dev/null 2>&1; then PYTHON_VERSION="3.12"
        else PYTHON_VERSION="$(python3 -c 'import sys; print("%d.%d" % sys.version_info[:2])')"; fi
    fi
    sudo apt-get install -y \
        build-essential cmake git wget curl autoconf automake libtool pkg-config \
        libgsl-dev libltdl-dev libncurses-dev libreadline-dev \
        libboost-dev libboost-filesystem-dev libboost-system-dev cython3 \
        "python${PYTHON_VERSION}" "python${PYTHON_VERSION}-dev" "python${PYTHON_VERSION}-venv" \
        qt6-base-dev libqt6opengl6-dev libgl1-mesa-dev libglu1-mesa-dev libegl1 \
        libxrender1 libxcb-xinerama0 libxcb-cursor0 libxkbcommon-x11-0 \
        libxcb-icccm4 libxcb-image0 libxcb-keysyms1 libxcb-randr0 \
        libxcb-render-util0 libxcb-shape0 libdbus-1-3 libfontconfig1 libgtk-3-0 \
        xvfb xauth
fi
PYTHON_VERSION="${PYTHON_VERSION:-$(python3 -c 'import sys; print("%d.%d" % sys.version_info[:2])')}"

# ─── 3. Python environment ──────────────────────────────────────────
mkdir -p "${INSTALL_DIR}"
if [ "${SKIP_PYTHON:-0}" != "1" ]; then
    say "Creating virtual environment (Python ${PYTHON_VERSION})"
    [ -x "${VENV_DIR}/bin/python" ] || "python${PYTHON_VERSION}" -m venv "${VENV_DIR}"
    # shellcheck disable=SC1091
    source "${VENV_DIR}/bin/activate"
    pip install --upgrade pip wheel setuptools
    pip install numpy 'cython<3'
    pip install pandas scipy networkx matplotlib
    pip install PyQt6 PyQt6-WebEngine pyqtgraph
    pip install vtk pyvista pyvistaqt
    pip install PyOpenGL==3.1.10
    pip install ipython
    pip install pygame Pillow opencv-python-headless
elif [ -f "${VENV_DIR}/bin/activate" ]; then
    # shellcheck disable=SC1091
    source "${VENV_DIR}/bin/activate"
fi

# ─── 4. NEST ────────────────────────────────────────────────────────
if [ "${SKIP_NEST:-0}" != "1" ]; then
    if [ -f "${VENV_DIR}/bin/nest_vars.sh" ] && \
       (source "${VENV_DIR}/bin/nest_vars.sh" && python -c "import nest" >/dev/null 2>&1); then
        say "NEST already installed in ${VENV_DIR}, skipping build"
    else
        say "Building NEST ${NEST_VERSION} (${NUM_CORES} cores, this takes a while)"
        [ -d "${NEST_SRC}/.git" ] || git clone --branch "${NEST_VERSION}" --depth 1 \
            https://github.com/nest/nest-simulator.git "${NEST_SRC}"
        mkdir -p "${NEST_BUILD}"
        cd "${NEST_BUILD}"
        cmake "${NEST_SRC}" \
            -DCMAKE_INSTALL_PREFIX="${VENV_DIR}" \
            -DPYTHON_EXECUTABLE="${VENV_DIR}/bin/python" \
            -Dwith-python=ON \
            -Dwith-gsl=ON \
            -Dwith-readline=ON \
            -Dwith-ltdl=ON \
            -Dwith-openmp=ON \
            -Dwith-boost=ON \
            -DCMAKE_BUILD_TYPE=Release
        make -j"${NUM_CORES}"
        make install
    fi
fi

# ─── 5. activate.sh ─────────────────────────────────────────────────
cat > "${INSTALL_DIR}/activate.sh" << EOF
#!/bin/bash
source "${VENV_DIR}/bin/activate"
[ -f "${VENV_DIR}/bin/nest_vars.sh" ] && source "${VENV_DIR}/bin/nest_vars.sh"
export NEUROTICKS_DIR="${NEUROTICKS_DIR}"
cd "${NEUROTICKS_DIR}"
EOF
chmod +x "${INSTALL_DIR}/activate.sh"

# ─── 6. Self-check ──────────────────────────────────────────────────
say "Checking the installation"
CHECK_OK=1
if [ -f "${VENV_DIR}/bin/activate" ]; then
    set +u
    # shellcheck disable=SC1091
    source "${VENV_DIR}/bin/activate"
    [ -f "${VENV_DIR}/bin/nest_vars.sh" ] && source "${VENV_DIR}/bin/nest_vars.sh"
    set -u
    cd "${NEUROTICKS_DIR}"
    if python -c "import nest" >/dev/null 2>&1; then echo "    ok    NEST imports"
    else echo "    FAIL  NEST does not import"; CHECK_OK=0; fi
    if python -c "import neuron_toolbox" >/dev/null 2>&1; then echo "    ok    neuron_toolbox imports (headless core)"
    else echo "    FAIL  neuron_toolbox does not import"; CHECK_OK=0; fi
    if QT_QPA_PLATFORM=offscreen python -c "import neuroticks.gui.main_window" >/dev/null 2>&1; then
        echo "    ok    GUI modules import"
    else echo "    FAIL  GUI modules do not import (run: QT_QPA_PLATFORM=offscreen python -c 'import neuroticks.gui.main_window')"; CHECK_OK=0; fi
else
    echo "    no virtual environment at ${VENV_DIR}, import checks skipped"; CHECK_OK=0
fi

echo ""
echo "============================================"
if [ "${CHECK_OK}" = "1" ]; then echo "  Installation complete!"
else echo "  Installation finished WITH PROBLEMS (see above)"; fi
echo "============================================"
echo ""
echo "  Virtual environment: ${VENV_DIR}"
echo "  NeuroTicks location: ${NEUROTICKS_DIR}"
echo ""
echo "  To run NeuroTicks:"
echo "    source ${INSTALL_DIR}/activate.sh"
echo "    python Main.py"
echo ""
[ "${CHECK_OK}" = "1" ]
