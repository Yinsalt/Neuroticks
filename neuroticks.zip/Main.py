"""Neuroticks - Einstiegspunkt.  Start:  python Main.py"""
import sys

from PyQt6.QtWidgets import QApplication

from neuroticks.gui.main_window.window import MainWindow
from neuroticks.gui.theme import apply_dark_mode

if __name__ == "__main__":
    app = QApplication(sys.argv)
    apply_dark_mode(app)
    window = MainWindow()
    window.showMaximized()
    sys.exit(app.exec())
