"""Kleine, defensive Helfer rund um NEST-Populationen und -Modelle."""
import nest

from neuroticks.constants.synapses import SYNAPSE_MODELS

# Multi-Compartment Neuron Models - require explicit receptor_type
MC_MODELS = {'iaf_cond_alpha_mc', 'cm_default', 'cm_main', 'iaf_cond_beta_mc'}

def safe_get_model(population, default='unknown'):
    """Safely get model name from a NEST population."""
    try:
        if population is None or len(population) == 0:
            return default
        return nest.GetStatus(population, 'model')[0]
    except Exception:
        return default

def safe_get_status(population, key=None):
    """Safely get status from a NEST population. Returns None on error."""
    try:
        if population is None or len(population) == 0:
            return None
        if key:
            return nest.GetStatus(population, key)
        return nest.GetStatus(population)
    except Exception:
        return None

def get_receptor_type_for_model(model_name: str, excitatory: bool = True) -> int:
    """
    Returns appropriate receptor_type for multi-compartment models.
    For standard models returns 0 (default).
    
    iaf_cond_alpha_mc receptors:
        1: soma_exc, 2: soma_inh, 3: prox_exc, 4: prox_inh, 5: dist_exc, 6: dist_inh
    """
    if model_name in MC_MODELS:
        return 1 if excitatory else 2  # soma_exc or soma_inh
    return 0

def get_mc_recordables(model_name: str) -> list:
    """
    Returns appropriate recordables for multi-compartment models.
    Standard models use ['V_m'], MC models use compartment-specific variables.
    """
    if model_name in MC_MODELS:
        return ['V_m_s']  # Soma membrane potential
    return ['V_m']


def validate_SYNAPSE_MODELS():
    
    nest_synapses = set(nest.SYNAPSE_MODELS)
    
    
    invalid = []
    valid = []
    
    for model in SYNAPSE_MODELS.keys():
        if model in nest_synapses:
            valid.append(model)
            print(f"{model}")
        else:
            invalid.append(model)
            print(f"{model} - NOT A VALID SYNAPSE MODEL!")
    
    print(f"\nValid: {len(valid)} | Invalid: {len(invalid)}")
    
    if invalid:
        for m in invalid:
            print(f'    "{m}": {{}},')
    
    return invalid


def build_gid_to_meta_map(graph_list):
    gid_map = {}
    
    for graph in graph_list:
        for node in graph.node_list:
            if hasattr(node, 'population') and node.population:
                for pop_idx, pop in enumerate(node.population):
                    if pop:
                        for local_idx, gid in enumerate(pop.tolist()):
                            gid_map[gid] = {
                                'graph_id': graph.graph_id,
                                'node_id': node.id,
                                'node_name': getattr(node, 'name', 'unnamed'),
                                'pop_idx': pop_idx,
                                'local_idx': local_idx
                            }
    return gid_map

def _invalidate_nest_refs(graphs):
    """Remove auto-devices and null runtime_gids before ResetKernel to prevent stale NodeCollection access."""
    for graph in graphs:
        for node in graph.node_list:
            if hasattr(node, 'devices'):
                node.devices = [d for d in node.devices if not d.get('is_auto', False)]
                for d in node.devices:
                    d['runtime_gid'] = None
            if hasattr(node, 'parameters') and 'devices' in node.parameters:
                node.parameters['devices'] = [d for d in node.parameters['devices'] if not d.get('is_auto', False)]
                for d in node.parameters['devices']:
                    d['runtime_gid'] = None
            if hasattr(node, 'population'):
                node.population = []
