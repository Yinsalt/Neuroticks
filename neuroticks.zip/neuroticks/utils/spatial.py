"""Räumliche NEST-Verbindungsparameter: Masken, distanzabhängige Gewichte/Delays."""
from typing import Any, Dict, Optional

import nest

def create_nest_mask(mask_type: str, params: Dict[str, Any]) -> Optional[Any]:
    """
    Builds a NEST spatial connection mask. Supported types:
      - 'spherical' / 'sphere'                : symmetric, radius
      - 'rectangular' / 'box'                 : symmetric cube around origin
      - 'box_asym'                            : independent lower_left / upper_right
      - 'doughnut'                            : sphere minus inner sphere
      - 'elliptical'                          : 2D ellipse (major/minor)
      - 'ellipsoidal'                         : 3D ellipsoid (three axes)
    
    All types support optional 'anchor': [dx,dy,dz] to offset the mask
    center from the source neuron (asymmetric receptive fields).
    """
    try:
        r_outer = float(params.get('mask_radius', params.get('radius', params.get('outer_radius', 1.0))))
        r_inner = float(params.get('mask_inner_radius', params.get('inner_radius', params.get('inner', 0.0))))
        
        anchor = params.get('anchor', None)
        use_anchor = bool(params.get('use_anchor', False)) and anchor is not None
        
        if mask_type in ('spherical', 'sphere'):
            spec = {'radius': r_outer}
            if use_anchor: spec['anchor'] = list(anchor)
            return nest.CreateMask('spherical', spec)
            
        elif mask_type in ('rectangular', 'box'):
            s = r_outer 
            spec = {
                'lower_left': [-s, -s, -s],
                'upper_right': [s, s, s]
            }
            if use_anchor: spec['anchor'] = list(anchor)
            return nest.CreateMask('rectangular', spec)
        
        elif mask_type == 'box_asym':
            # Independent corners — receptive field doesn't have to be cubic.
            ll = params.get('lower_left', [-r_outer, -r_outer, -r_outer])
            ur = params.get('upper_right', [r_outer, r_outer, r_outer])
            spec = {'lower_left': list(ll), 'upper_right': list(ur)}
            if use_anchor: spec['anchor'] = list(anchor)
            return nest.CreateMask('rectangular', spec)
            
        elif mask_type == 'doughnut':
            outer_spec = {'radius': r_outer}
            if use_anchor: outer_spec['anchor'] = list(anchor)
            m_outer = nest.CreateMask('spherical', outer_spec)
            
            if r_inner > 0:
                inner_spec = {'radius': r_inner}
                if use_anchor: inner_spec['anchor'] = list(anchor)
                m_inner = nest.CreateMask('spherical', inner_spec)
                return m_outer & ~m_inner
            else:
                return m_outer
            
        elif mask_type == 'elliptical':
             major = float(params.get('major_axis', params.get('mask_major', 2.0 * r_outer)))
             minor = float(params.get('minor_axis', params.get('mask_minor', r_outer)))
             spec = {'major_axis': major, 'minor_axis': minor}
             if use_anchor: spec['anchor'] = list(anchor)
             # NEST uses 'elliptical' for 2D, 'ellipsoidal' for 3D layers.
             # Try elliptical first, fall back if NEST complains.
             try:
                 return nest.CreateMask('elliptical', spec)
             except Exception:
                 # Promote to 3D ellipsoidal with polar = minor as fallback
                 spec3 = dict(spec); spec3['polar_axis'] = minor
                 return nest.CreateMask('ellipsoidal', spec3)
        
        elif mask_type == 'ellipsoidal':
             major = float(params.get('major_axis', params.get('mask_major', 2.0 * r_outer)))
             minor = float(params.get('minor_axis', params.get('mask_minor', r_outer)))
             polar = float(params.get('polar_axis', params.get('mask_polar', minor)))
             spec = {'major_axis': major, 'minor_axis': minor, 'polar_axis': polar}
             if use_anchor: spec['anchor'] = list(anchor)
             return nest.CreateMask('ellipsoidal', spec)

    except Exception as e:
        print(f"Mask Creation Error: {e}")
        return None


def create_distance_dependent_weight(base_weight: float,
                                     factor: float = 1.0,
                                     offset: float = 0.0,
                                     mode: str = 'linear') -> Any:
    
    try:
        dist = nest.spatial.distance
        
        if mode == 'linear':
            return base_weight + dist * factor + offset
            
        elif mode == 'exponential':
            import nest.math as nm
            return base_weight * nm.exp(-dist * factor)
            
        elif mode == 'gaussian':
            import nest.math as nm
            sigma = factor if factor > 0 else 1.0
            return base_weight * nm.exp(-(dist / sigma) ** 2)
            
        else:
            return base_weight
            
    except Exception as e:
        print(f"Distance weight creation failed: {e}, using base weight")
        return base_weight


def create_distance_dependent_probability(p_max: float,
                                          profile: str = 'constant',
                                          sigma: float = 1.0) -> Any:
    """
    Builds a NEST connection-probability expression.
    
    profile = 'constant'    -> p_max (no distance dependence)
            = 'gaussian'    -> p_max * exp(-d^2 / (2 * sigma^2))
            = 'exponential' -> p_max * exp(-d / sigma)
            = 'linear'      -> max(0, p_max * (1 - d / sigma))
    
    Used in conn_spec for pairwise_bernoulli with spatial mask.
    """
    try:
        if profile == 'constant':
            return float(p_max)
        
        dist = nest.spatial.distance
        s = sigma if sigma > 0 else 1.0
        import nest.math as nm
        
        if profile == 'gaussian':
            return float(p_max) * nm.exp(-(dist / s) ** 2 / 2.0)
        elif profile == 'exponential':
            return float(p_max) * nm.exp(-dist / s)
        elif profile == 'linear':
            # NEST will clip to [0,1] internally; use max() to be safe.
            return nm.max(0.0, float(p_max) * (1.0 - dist / s))
        else:
            return float(p_max)
    except Exception as e:
        print(f"Distance-dependent p creation failed: {e}, using constant {p_max}")
        return float(p_max)


def create_distance_dependent_delay(base_delay: float,
                                    factor: float = 0.0,
                                    mode: str = 'linear') -> Any:
    """
    Builds a NEST distance-dependent delay expression.
    
    mode = 'linear'      -> base_delay + d * factor   (axon-like: faster=smaller factor)
         = 'inverse'     -> base_delay + factor / max(d, 1e-3) (rare, mostly debug)
    
    factor=0 returns the scalar base_delay (back-compat).
    """
    try:
        if abs(factor) < 1e-12:
            return float(base_delay)
        dist = nest.spatial.distance
        if mode == 'linear':
            return float(base_delay) + dist * float(factor)
        elif mode == 'inverse':
            return float(base_delay) + float(factor) / nest.math.max(dist, 1e-3)
        else:
            return float(base_delay)
    except Exception as e:
        print(f"Distance-dependent delay creation failed: {e}, using base {base_delay}")
        return float(base_delay)


def create_anisotropic_weight(base_weight: float,
                               theta_deg: float = 0.0,
                               freq: float = 1.0,
                               mode: str = 'cosine',
                               sigma: float = 1.0) -> Any:
    """
    Direction-encoded synapse weight — for orientation-tuned receptive fields,
    Gabor-like profiles, etc. Uses NEST's nest.spatial.target_pos /
    source_pos to project the displacement vector onto a preferred axis.
    
    theta_deg : preferred orientation in degrees (counter-clockwise from +x)
    freq      : spatial frequency (cycles per spatial unit)
    mode      : 'cosine'  ->  base * cos(2π · freq · projection)
                'gabor'   ->  base * cos(2π · freq · projection) · exp(-d²/(2σ²))
    sigma     : envelope width for gabor mode
    
    Used as syn_spec['weight']. Only meaningful when both source and target
    populations have spatial positions.
    """
    try:
        import math
        import nest.math as nm
        theta_rad = math.radians(theta_deg)
        cos_t = math.cos(theta_rad)
        sin_t = math.sin(theta_rad)
        
        # Displacement vector source -> target
        dx = nest.spatial.target_pos.x - nest.spatial.source_pos.x
        dy = nest.spatial.target_pos.y - nest.spatial.source_pos.y
        # Project onto preferred axis (theta)
        projection = cos_t * dx + sin_t * dy
        
        carrier = nm.cos(2.0 * math.pi * float(freq) * projection)
        
        if mode == 'cosine':
            return float(base_weight) * carrier
        elif mode == 'gabor':
            d = nest.spatial.distance
            s = sigma if sigma > 0 else 1.0
            envelope = nm.exp(-(d / s) ** 2 / 2.0)
            return float(base_weight) * carrier * envelope
        else:
            return float(base_weight) * carrier
    except Exception as e:
        print(f"Anisotropic weight failed: {e}, using base {base_weight}")
        return float(base_weight)


def create_nest_mask_safe(mask_type, params):
    """Build a NEST mask. Optional 'anchor': [dx,dy,dz] offsets the mask
    center relative to the source neuron — needed for asymmetric receptive
    fields and retinotopic shifts."""
    anchor = params.get('anchor', None)
    try:
        if mask_type in ('sphere', 'spherical'):
            spec = {'r': params.get('radius', 1.0)}
            if anchor: spec['anchor'] = list(anchor)
            return nest.CreateMask('spherical', spec)
        elif mask_type in ('box', 'rectangular'):
            s = params.get('size', 1.0)
            spec = {'lower_left': [-s, -s, -s], 'upper_right': [s, s, s]}
            if anchor: spec['anchor'] = list(anchor)
            return nest.CreateMask('rectangular', spec)
        elif mask_type == 'doughnut':
            spec = {
                'inner_radius': params.get('inner', 0.2),
                'outer_radius': params.get('outer', 1.0),
            }
            if anchor: spec['anchor'] = list(anchor)
            return nest.CreateMask('doughnut', spec)
    except Exception as e:
        print(f"⚠ Mask: {e}")
    return None
