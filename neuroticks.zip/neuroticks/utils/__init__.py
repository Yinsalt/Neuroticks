"""Allgemeine Hilfsfunktionen ohne GUI-Abhängigkeit."""
