"""Erzeugung zufälliger Polynome für die Flussfelder."""
import random

from neuroticks import state

def generate_biased_polynomial(axis_idx, max_degree=2, num_noise_terms=2):

    noise = state.POLYNOM_NOISE_LEVEL
    
    main_coeff = 1.0 + random.uniform(-noise, noise)
    
    indices = [[axis_idx, 1]]
    coefficients = [main_coeff]
    
    for _ in range(num_noise_terms):
        v_idx = random.randint(0, 2)
        power = random.randint(0, max_degree)
        
        if v_idx == axis_idx and power == 1:
            power = 0
            
        coeff = random.uniform(-1.0, 1.0) * noise
        
        indices.append([v_idx, power])
        coefficients.append(coeff)
        
    return {
        'indices': indices,
        'coefficients': coefficients,
        'n': max_degree,
        'decay': 0.5
    }


def generate_random_polynomial(max_degree=2, num_terms=3):
    indices = []
    coefficients = []
        
    for _ in range(num_terms):
        var_idx = random.randint(0, 2)
            
        power = random.randint(0, max_degree)
            
        coeff = random.uniform(-1.0, 1.0)
            
        indices.append([var_idx, power])
        coefficients.append(coeff)
        
    return {
            'indices': indices,
            'coefficients': coefficients,
            'n': max_degree,
            'decay': 0.5
    }
