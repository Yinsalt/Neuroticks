"""Zentrale Pfade des Projekts."""
import os

# Projekt-Root = Ordner, in dem Main.py, neuron_toolbox.py und functional_models.json liegen
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
