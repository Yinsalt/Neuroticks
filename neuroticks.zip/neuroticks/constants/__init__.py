"""Statische Tabellen und Konstanten."""
