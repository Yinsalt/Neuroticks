"""Synapsenmodelle und Verbindungsregeln (Parameter-Metadaten für die GUI)."""

SYNAPSE_MODELS = {
    "static_synapse": {
        "category": "basic",
        "description": "Standard-Synapse mit konstantem Gewicht",
        "params": {}
    },
    
    "bernoulli_synapse": {
        "category": "basic",
        "description": "Stochastische Synapse mit Transmissionswahrscheinlichkeit",
        "params": {
            "p_transmit": {
                "default": 1.0, "type": "float", "min": 0.0, "max": 1.0,
                "unit": "", "description": "Transmission probability"
            }
        }
    },

    "cont_delay_synapse": {
        "category": "basic",
        "description": "Synapse mit kontinuierlichem Delay",
        "params": {}
    },

    "gap_junction": {
        "category": "electrical",
        "description": "Elektrische Synapse (Kein Delay!)",
        "no_delay": True,
        "params": {}
    },

    "stdp_synapse": {
        "category": "plasticity",
        "description": "Standard STDP nach Song et al. (lambda und alpha tunen die Lerndynamik; tau_minus wird auf dem postsynaptischen Neuron gesetzt, nicht hier)",
        "params": {
            "tau_plus": {"default": 20.0, "type": "float", "min": 0.1, "max": 1000.0, "unit": "ms",
                         "step": 1.0, "decimals": 2,
                         "description": "Time constant of potentiation window"},
            "lambda": {"default": 0.01, "type": "float", "min": 0.0, "max": 1.0, "unit": "",
                       "step": 0.001, "decimals": 5,
                       "description": "Learning rate"},
            "alpha": {"default": 1.0, "type": "float", "min": 0.0, "max": 10.0, "unit": "",
                      "step": 0.1, "decimals": 3,
                      "description": "Asymmetry parameter (depression scale, >1 = LTD dominant)"},
            "mu_plus": {"default": 1.0, "type": "float", "min": 0.0, "max": 10.0, "unit": "",
                        "step": 0.1, "decimals": 2,
                        "description": "Weight dependence exponent (potentiation)"},
            "mu_minus": {"default": 1.0, "type": "float", "min": 0.0, "max": 10.0, "unit": "",
                         "step": 0.1, "decimals": 2,
                         "description": "Weight dependence exponent (depression)"},
            "Wmax": {"default": 3.5, "type": "float", "min": 0.0, "max": 10000.0, "unit": "",
                     "step": 0.5, "decimals": 2,
                     "description": "Maximum weight"}
        }
    },

    "stdp_synapse_hom": {
        "category": "plasticity",
        "description": "Homeostatic STDP",
        "params": {
            "tau_plus": {"default": 20.0, "type": "float", "min": 0.1, "max": 1000.0, "unit": "ms"},
            "lambda": {"default": 0.01, "type": "float", "min": 0.0, "max": 1.0, "unit": ""},
            "alpha": {"default": 1.0, "type": "float", "min": 0.0, "max": 10.0, "unit": ""},
            "Wmax": {"default": 100.0, "type": "float", "min": 0.0, "max": 10000.0, "unit": ""}
        }
    },

    "stdp_triplet_synapse": {
        "category": "plasticity",
        "description": "Triplet STDP (Pfister & Gerstner 2006)",
        "params": {
            "tau_plus": {"default": 16.8, "type": "float", "min": 0.1, "unit": "ms",
                         "description": "Time constant of 1st potentiation window"},
            "tau_minus": {"default": 33.7, "type": "float", "min": 0.1, "unit": "ms",
                          "description": "Time constant of 1st depression window"},
            "tau_x": {"default": 101.0, "type": "float", "min": 0.1, "unit": "ms",
                      "description": "Time constant of presynaptic trace"},
            "tau_y": {"default": 125.0, "type": "float", "min": 0.1, "unit": "ms",
                      "description": "Time constant of postsynaptic trace"},
            "Wmax": {"default": 100.0, "type": "float", "min": 0.0, "unit": ""}
        }
    },

    "stdp_dopamine_synapse": {
        "category": "plasticity",
        "description": "Neuromoduliertes STDP (Reward-Learning)",
        "params": {
            "b": {"default": 0.0, "type": "float", "min": -10.0, "max": 10.0, "unit": "",
                  "description": "Dopamine baseline concentration"},
            "tau_plus": {"default": 20.0, "type": "float", "min": 0.1, "unit": "ms"},
            "tau_n": {"default": 200.0, "type": "float", "min": 0.1, "unit": "ms",
                      "description": "Time constant of eligibility trace"},
            "Wmin": {"default": 0.0, "type": "float", "min": -10000.0, "unit": ""},
            "Wmax": {"default": 100.0, "type": "float", "min": 0.0, "unit": ""}
        }
    },

    "vogels_sprekeler_synapse": {
        "category": "plasticity",
        "description": "Inhibitory STDP (Vogels et al. 2011)",
        "params": {
            "tau": {"default": 20.0, "type": "float", "min": 0.1, "unit": "ms",
                    "description": "STDP time constant"},
            "eta": {"default": 0.001, "type": "float", "min": 0.0, "unit": "",
                    "description": "Learning rate"},
            "alpha": {"default": 0.12, "type": "float", "min": 0.0, "unit": "",
                      "description": "Target firing rate parameter"},
            "Wmax": {"default": 100.0, "type": "float", "min": 0.0, "unit": ""}
        }
    },

    "clopath_synapse": {
        "category": "plasticity",
        "description": "Voltage-based STDP (Clopath et al. 2010)",
        "params": {
            "tau_x": {"default": 10.0, "type": "float", "min": 0.1, "unit": "ms"},
            "A_LTP": {"default": 0.00014, "type": "float", "min": 0.0, "unit": "",
                      "description": "LTP amplitude"},
            "A_LTD": {"default": 0.00008, "type": "float", "min": 0.0, "unit": "",
                      "description": "LTD amplitude"},
            "Wmax": {"default": 100.0, "type": "float", "min": 0.0, "unit": ""}
        }
    },

    "urbanczik_synapse": {
        "category": "plasticity",
        "description": "Gradient-based learning (Dendritic)",
        "params": {
            "tau_Delta": {"default": 100.0, "type": "float", "min": 0.1, "unit": "ms",
                          "description": "Time constant of eligibility trace"},
            "eta": {"default": 0.01, "type": "float", "min": 0.0, "unit": "",
                    "description": "Learning rate"},
            "Wmax": {"default": 100.0, "type": "float", "min": 0.0, "unit": ""}
        }
    },

    "tsodyks_synapse": {
        "category": "stp",
        "description": "Short-Term Plasticity (Tsodyks & Markram)",
        "params": {
            "U": {"default": 0.5, "type": "float", "min": 0.0, "max": 1.0, "unit": "",
                  "description": "Utilization of synaptic efficacy"},
            "tau_rec": {"default": 800.0, "type": "float", "min": 0.1, "unit": "ms",
                        "description": "Recovery time constant"},
            "tau_fac": {"default": 0.0, "type": "float", "min": 0.0, "unit": "ms",
                        "description": "Facilitation time constant"},
            "x": {"default": 1.0, "type": "float", "min": 0.0, "max": 1.0, "unit": "",
                  "description": "Initial fraction of resources"}
        }
    },

    "tsodyks2_synapse": {
        "category": "stp",
        "description": "Short-Term Plasticity (Alternative)",
        "params": {
            "U": {"default": 0.5, "type": "float", "min": 0.0, "max": 1.0, "unit": ""},
            "tau_rec": {"default": 800.0, "type": "float", "min": 0.1, "unit": "ms"},
            "tau_fac": {"default": 0.0, "type": "float", "min": 0.0, "unit": "ms"}
        }
    },

    "quantal_stp_synapse": {
        "category": "stp",
        "description": "Quantal STP mit Release Sites",
        "params": {
            "U": {"default": 0.5, "type": "float", "min": 0.0, "max": 1.0, "unit": ""},
            "tau_rec": {"default": 800.0, "type": "float", "min": 0.1, "unit": "ms"},
            "tau_fac": {"default": 0.0, "type": "float", "min": 0.0, "unit": "ms"},
            "n": {"default": 1, "type": "int", "min": 1, "max": 100, "unit": "",
                  "description": "Number of release sites"},
            "a": {"default": 1, "type": "int", "min": 0, "max": 100, "unit": "",
                  "description": "Initial available release sites"}
        }
    },

    "ht_synapse": {
        "category": "special",
        "description": "Hill-Tononi Synapse",
        "params": {}
    },

    "diffusion_connection": {
        "category": "special",
        "description": "Diffusion-Verbindung (rate neurons)",
        "params": {}
    },

    "rate_connection_instantaneous": {
        "category": "special",
        "description": "Instantane Rate-Verbindung",
        "no_delay": True,
        "params": {}
    },

    "rate_connection_delayed": {
        "category": "special",
        "description": "Verzögerte Rate-Verbindung",
        "params": {}
    }
}


SYNAPSE_MODELS = {
    'static_synapse': {
        'weight': {'type': 'float', 'default': 1.0, 'unit': 'pA or nS'},
        'delay': {'type': 'float', 'default': 1.0, 'min': 0.1, 'unit': 'ms'},
    },
    'stdp_synapse': {
        'weight': {'type': 'float', 'default': 1.0, 'min': 0.0, 'max': 1000.0, 'step': 0.1, 'decimals': 4},
        'delay': {'type': 'float', 'default': 1.0, 'min': 0.1, 'max': 100.0, 'step': 0.1, 'decimals': 2},
        'tau_plus': {'type': 'float', 'default': 20.0, 'unit': 'ms', 'min': 0.1, 'max': 1000.0, 'step': 1.0, 'decimals': 2},
        'lambda': {'type': 'float', 'default': 0.01, 'min': 0.0, 'max': 1.0, 'step': 0.001, 'decimals': 5},
        'alpha': {'type': 'float', 'default': 1.0, 'min': 0.0, 'max': 10.0, 'step': 0.05, 'decimals': 3},
        'mu_plus': {'type': 'float', 'default': 1.0, 'min': 0.0, 'max': 10.0, 'step': 0.1, 'decimals': 2},
        'mu_minus': {'type': 'float', 'default': 1.0, 'min': 0.0, 'max': 10.0, 'step': 0.1, 'decimals': 2},
        'Wmax': {'type': 'float', 'default': 3.5, 'min': 0.0, 'max': 10000.0, 'step': 0.1, 'decimals': 2},
    },
    'stdp_synapse_hom': {
        'weight': {'type': 'float', 'default': 1.0, 'min': 0.0, 'max': 1000.0, 'step': 0.1, 'decimals': 4},
        'delay': {'type': 'float', 'default': 1.0, 'min': 0.1, 'max': 100.0, 'step': 0.1, 'decimals': 2},
        'tau_plus': {'type': 'float', 'default': 20.0, 'min': 0.1, 'max': 1000.0, 'step': 1.0, 'decimals': 2},
        'lambda': {'type': 'float', 'default': 0.01, 'min': 0.0, 'max': 1.0, 'step': 0.001, 'decimals': 5},
        'alpha': {'type': 'float', 'default': 1.0, 'min': 0.0, 'max': 10.0, 'step': 0.05, 'decimals': 3},
        'mu_plus': {'type': 'float', 'default': 1.0, 'min': 0.0, 'max': 10.0, 'step': 0.1, 'decimals': 2},
        'mu_minus': {'type': 'float', 'default': 1.0, 'min': 0.0, 'max': 10.0, 'step': 0.1, 'decimals': 2},
        'Wmax': {'type': 'float', 'default': 3.5, 'min': 0.0, 'max': 10000.0, 'step': 0.1, 'decimals': 2},
    },
    'tsodyks_synapse': {
        'weight': {'type': 'float', 'default': 1.0},
        'delay': {'type': 'float', 'default': 1.0, 'min': 0.1},
        'U': {'type': 'float', 'default': 0.5, 'min': 0.0, 'max': 1.0},
        'tau_rec': {'type': 'float', 'default': 800.0, 'unit': 'ms'},
        'tau_fac': {'type': 'float', 'default': 0.0, 'unit': 'ms'},
    },
    'tsodyks2_synapse': {
        'weight': {'type': 'float', 'default': 1.0},
        'delay': {'type': 'float', 'default': 1.0, 'min': 0.1},
        'U': {'type': 'float', 'default': 0.5},
        'u': {'type': 'float', 'default': 0.5},
        'x': {'type': 'float', 'default': 1.0},
        'tau_rec': {'type': 'float', 'default': 800.0},
        'tau_fac': {'type': 'float', 'default': 0.0},
    },
    'quantal_stp_synapse': {
        'weight': {'type': 'float', 'default': 1.0},
        'delay': {'type': 'float', 'default': 1.0, 'min': 0.1},
        'U': {'type': 'float', 'default': 0.5},
        'tau_rec': {'type': 'float', 'default': 800.0},
        'tau_fac': {'type': 'float', 'default': 0.0},
        'n': {'type': 'int', 'default': 1},
    },
    'stdp_dopamine_synapse': {
        'weight': {'type': 'float', 'default': 1.0},
        'delay': {'type': 'float', 'default': 1.0, 'min': 0.1},
        'tau_plus': {'type': 'float', 'default': 20.0},
        'tau_c': {'type': 'float', 'default': 1000.0},
        'tau_n': {'type': 'float', 'default': 200.0},
        'b': {'type': 'float', 'default': 0.0},
        'Wmin': {'type': 'float', 'default': 0.0},
        'Wmax': {'type': 'float', 'default': 200.0},
    },
    'ht_synapse': {
        'weight': {'type': 'float', 'default': 1.0},
        'delay': {'type': 'float', 'default': 1.0, 'min': 0.1},
    },
    'bernoulli_synapse': {
        'weight': {'type': 'float', 'default': 1.0},
        'delay': {'type': 'float', 'default': 1.0, 'min': 0.1},
        'p_transmit': {'type': 'float', 'default': 1.0, 'min': 0.0, 'max': 1.0},
    },
    'cont_delay_synapse': {
        'weight': {'type': 'float', 'default': 1.0},
        'delay': {'type': 'float', 'default': 1.0, 'min': 0.1},
    },
    'clopath_synapse': {
        'weight': {'type': 'float', 'default': 0.5},
        'delay': {'type': 'float', 'default': 1.0, 'min': 0.1},
        'Wmax': {'type': 'float', 'default': 1.0},
        'Wmin': {'type': 'float', 'default': 0.0},
    },
    'vogels_sprekeler_synapse': {
        'weight': {'type': 'float', 'default': 1.0},
        'delay': {'type': 'float', 'default': 1.0, 'min': 0.1},
        'tau': {'type': 'float', 'default': 20.0},
        'eta': {'type': 'float', 'default': 0.001},
        'alpha': {'type': 'float', 'default': 0.12},
        'Wmax': {'type': 'float', 'default': -1.0},
    },
    'gap_junction': {
        'weight': {'type': 'float', 'default': 1.0},
    },
    'rate_connection_instantaneous': {
        'weight': {'type': 'float', 'default': 1.0},
    },
    'rate_connection_delayed': {
        'weight': {'type': 'float', 'default': 1.0},
        'delay': {'type': 'float', 'default': 1.0, 'min': 0.1},
    },
    'diffusion_connection': {
        'weight': {'type': 'float', 'default': 1.0},
    },
}

CONNECTION_RULES = {
    'all_to_all': {
        'params': ['allow_autapses', 'allow_multapses'],
        'description': 'Connect all sources to all targets'
    },
    'one_to_one': {
        'params': [],
        'description': 'Connect source i to target i (requires equal sizes)'
    },
    'fixed_indegree': {
        'params': ['indegree', 'allow_autapses', 'allow_multapses'],
        'description': 'Each target receives fixed number of connections'
    },
    'fixed_outdegree': {
        'params': ['outdegree', 'allow_autapses', 'allow_multapses'],
        'description': 'Each source sends fixed number of connections'
    },
    'fixed_total_number': {
        'params': ['N', 'allow_autapses', 'allow_multapses'],
        'description': 'Create exactly N connections total'
    },
    'pairwise_bernoulli': {
        'params': ['p', 'allow_autapses', 'allow_multapses'],
        'description': 'Connect each pair with probability p'
    },
    'symmetric_pairwise_bernoulli': {
        'params': ['p', 'allow_autapses', 'allow_multapses'],
        'description': 'Like pairwise_bernoulli but symmetric'
    },
}
