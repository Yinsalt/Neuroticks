"""Farbtabelle der Neuronenmodelle für das Hauptfenster."""

neuron_colors = {
    'iaf_psc_alpha':            '#00FF88',
    'iaf_psc_exp':              '#00FF00',
    'iaf_psc_delta':            '#00CC66',
    'iaf_psc_alpha_multisynapse': '#00FFAA',
    'iaf_psc_exp_multisynapse': '#00FF44',

    'iaf_cond_alpha':           '#0088FF',
    'iaf_cond_exp':             '#00FFFF',
    'iaf_cond_beta':            '#0088CC',
    'iaf_cond_alpha_mc':        '#00AAFF',

    'aeif_cond_alpha':          '#FF00FF',
    'aeif_cond_exp':            '#FF00AA',
    'aeif_psc_alpha':           '#CC00FF',
    'aeif_psc_exp':             '#FF33FF',
    'aeif_cond_beta_multisynapse': '#AA00FF',

    'hh_psc_alpha':             '#FF4400',
    'hh_cond_exp_traub':        '#FF0000',
    'hh_cond_beta_gap_traub':   '#CC0000',
    'hh_psc_alpha_gap':         '#FF2200',

    'gif_cond_exp':             '#FFFF00',
    'gif_psc_exp':              '#FFCC00',
    'gif_cond_exp_multisynapse': '#FFEE00',
    'glif_cond':                '#FFD700',
    'glif_psc':                 '#FFAA00',

    'izhikevich':               '#FF8800',
    'mat2_psc_exp':             '#FF6600',
    'amat2_psc_exp':            '#FF9933',
    'ht_neuron':                '#FF33AA',
    'pp_psc_delta':             '#FF0066',
    'siegert_neuron':           '#00FFCC',

    'parrot_neuron':            '#888888',
    'parrot_neuron_ps':         '#666666',
    'mcculloch_pitts_neuron':   '#444444',
    'unknown':                  '#FFFFFF',
    'default':                  '#8888FF'
}
def get_neuron_color(model_name):
        return neuron_colors.get(model_name, neuron_colors['default'])
