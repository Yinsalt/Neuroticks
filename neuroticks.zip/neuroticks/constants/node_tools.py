"""Node-Tools (CCW, Blob, Cone, ...): Parameter-Schlüssel und Defaults."""

NODE_TOOLS = {
    "custom": {
        "label": "WFC & Flow Field (Custom)",
        "params": ["grid_size", "sparsity_factor", "sparse_holes", "num_steps", "dt"]
    },
    "CCW": {
        "label": "CCW Ring (Attractor)",
        "params": ["n_neurons", "radius", "k", "bidirectional"]
    },
    "Blob": {
        "label": "Random Blob",
        "params": ["n_neurons", "radius"]
    },
    "Cone": {
        "label": "Cone / Column",
        "params": ["n_neurons", "radius_bottom", "radius_top", "height"]
    },
    "Grid": {
        "label": "2D Grid",
        "params": ["grid_side_length"]
    }
}

# Tool-spezifische Key-Mappings für geteilte Parameter
# Mappt generische Namen auf tool-spezifische Widget-Keys
TOOL_PARAM_KEYS = {
    'CCW': {
        'n_neurons': 'ccw_n_neurons',
        'radius': 'ccw_radius',
        'tool_neuron_model': 'ccw_tool_neuron_model'
    },
    'Blob': {
        'n_neurons': 'blob_n_neurons',
        'radius': 'blob_radius',
        'tool_neuron_model': 'blob_tool_neuron_model'
    },
    'Cone': {
        # Cone teilt KEINE widget-keys mit CCW (weil das self.widgets
        # überschreiben würde). Eigene cone_*-Keys werden hier zurück
        # zu den generischen Namen gemappt, die SHAPE_PARAM_KEYS und
        # die Build-Funktionen erwarten.
        'n_neurons': 'cone_n_neurons',
        'tool_neuron_model': 'cone_tool_neuron_model',
        'bidirectional': 'cone_bidirectional',
        'conn_rule': 'cone_conn_rule',
        'conn_p': 'cone_conn_p',
        'conn_indegree': 'cone_conn_indegree',
        'conn_outdegree': 'cone_conn_outdegree',
        'ccw_syn_config': 'cone_syn_config',
        'ccw_weight_ex': 'cone_weight_ex',
        'ccw_delay_ex': 'cone_delay_ex',
        'weight_in_factor': 'cone_weight_in_factor',
        'k': 'cone_k',
    },
    'Grid': {
        'tool_neuron_model': 'grid_tool_neuron_model'
    },
    'custom': {}
}

# Welche Keys (in generischer Form, post-mapping) gehören PRO POPULATION
# zu einem Tool-Type-Knoten? Diese landen in pop['shape_params'].
# Position/Transform/Probability-Keys gehören weiter zum Knoten global.
SHAPE_PARAM_KEYS = {
    'CCW':    ['n_neurons', 'radius', 'bidirectional',
               'ccw_weight_ex', 'ccw_delay_ex', 'weight_in_factor',
               'ccw_syn_config', 'k',
               'conn_rule', 'conn_p', 'conn_indegree', 'conn_outdegree'],
    'Blob':   ['n_neurons', 'radius',
               'blob_p_ex', 'blob_p_in',
               'blob_weight_ex', 'blob_weight_in',
               'blob_delay_ex', 'blob_delay_in',
               'blob_syn_config_ex', 'blob_syn_config_in',
               'blob_allow_autapses'],
    'Cone':   ['n_neurons', 'radius_top', 'radius_bottom', 'height',
               'bidirectional', 'ccw_weight_ex', 'ccw_delay_ex',
               'weight_in_factor', 'ccw_syn_config', 'k',
               'conn_rule', 'conn_p', 'conn_indegree', 'conn_outdegree'],
    'Grid':   ['grid_side_length'],
    'custom': []
}

# Defaults pro Tool-Type für neu angelegte Populations.
# Werden verwendet, wenn keine shape_params vorliegen. Werte sind 1:1
# aligned mit den Defaults der Build-Funktionen in neuron_toolbox.py.
SHAPE_PARAM_DEFAULTS = {
    'CCW':    {'n_neurons': 100, 'radius': 5.0, 'bidirectional': False,
               'ccw_weight_ex': 30.0, 'ccw_delay_ex': 1.0,
               'weight_in_factor': 1.0,
               'ccw_syn_config': {'synapse_model': 'static_synapse', 'extra_params': {}},
               'k': 10.0,
               'conn_rule': 'similarity', 'conn_p': 1.0,
               'conn_indegree': 10, 'conn_outdegree': 10},
    'Blob':   {'n_neurons': 100, 'radius': 5.0,
               'blob_p_ex': 0.8, 'blob_p_in': 0.2,
               'blob_weight_ex': 2.0, 'blob_weight_in': -10.0,
               'blob_delay_ex': 1.0, 'blob_delay_in': 1.0,
               'blob_syn_config_ex': {'synapse_model': 'static_synapse', 'extra_params': {}},
               'blob_syn_config_in': {'synapse_model': 'static_synapse', 'extra_params': {}},
               'blob_allow_autapses': False},
    'Cone':   {'n_neurons': 500, 'radius_top': 1.0, 'radius_bottom': 5.0,
               'height': 10.0, 'bidirectional': False,
               'ccw_weight_ex': 30.0, 'ccw_delay_ex': 1.0,
               'weight_in_factor': 1.0,
               'ccw_syn_config': {'synapse_model': 'static_synapse', 'extra_params': {}},
               'k': 10.0,
               'conn_rule': 'similarity', 'conn_p': 1.0,
               'conn_indegree': 10, 'conn_outdegree': 10},
    'Grid':   {'grid_side_length': 10},
    'custom': {}
}


def extract_shape_params(tool_type, params_dict):
    """Extrahiert die Shape-Parameter aus einem Params-Dict für den gegebenen Tool-Type.
    Fehlende Keys werden aus SHAPE_PARAM_DEFAULTS aufgefüllt."""
    keys = SHAPE_PARAM_KEYS.get(tool_type, [])
    defaults = SHAPE_PARAM_DEFAULTS.get(tool_type, {})
    result = {}
    for k in keys:
        if k in params_dict:
            result[k] = params_dict[k]
        elif k in defaults:
            result[k] = defaults[k]
    return result
            
node_parameters1 = {
    "grid_size": [8, 8, 8],
    "m": [0.0, 0.0, 0.0],
    "rot_theta": 0.0,
    "rot_phi": 0.0,
    "stretch_x": 1.0,
    "stretch_y": 1.0,
    "stretch_z": 1.0,
    "transform_matrix": [[1.0, 0, 0], [0, 1.0, 0], [0, 0, 1.0]],
    "dt": 0.001,
    "old": True,
    "num_steps": 5,
    "sparse_holes": 0,
    "sparsity_factor": 0.9,
    "probability_vector": [0.3, 0.2, 0.4],
    "name": "Node",
    "id": 0,
    "polynom_max_power": 2,
    "center_of_mass": [0.0, 0.0, 0.0],
    "displacement": [0.0, 0.0, 0.0],
    "displacement_factor": 1.0,
    "devices": [],
    "connections": []
}
