"""Kleine Dialoge der Widget-Bibliothek."""
from PyQt6.QtWidgets import (
    QDialog, QDialogButtonBox, QDoubleSpinBox, QFormLayout, QLabel, QVBoxLayout,
)

class PositionDialog(QDialog):
    def __init__(self, current_pos=[0.0, 0.0, 0.0], parent=None):
        super().__init__(parent)
        self.setWindowTitle("Target Position for Twin")
        self.selected_pos = list(current_pos)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        
        info = QLabel("Set the Center of Mass (m) for the Twin Node.\n"
                      "The structure will be regenerated locally at this new position.")
        layout.addWidget(info)

        form = QFormLayout()
        self.spins = []
        labels = ['X:', 'Y:', 'Z:']
        
        for i, lbl in enumerate(labels):
            spin = QDoubleSpinBox()
            spin.setRange(-10000, 10000)
            spin.setDecimals(3)
            spin.setValue(self.selected_pos[i])
            form.addRow(lbl, spin)
            self.spins.append(spin)
            
        layout.addLayout(form)
        
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def get_position(self):
        return [s.value() for s in self.spins]
