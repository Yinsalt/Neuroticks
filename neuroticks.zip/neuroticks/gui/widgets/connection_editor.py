"""Editor für bereits bestehende Verbindungen."""
from PyQt6.QtCore import pyqtSignal, Qt
from PyQt6.QtWidgets import (
    QComboBox, QDoubleSpinBox, QFormLayout, QFrame, QGroupBox, QHBoxLayout, QLabel,
    QLineEdit, QPushButton, QScrollArea, QSpinBox, QStackedWidget, QVBoxLayout, QWidget,
)

from neuroticks.constants.synapses import SYNAPSE_MODELS
from neuroticks.gui.widgets.synapse_widgets import SynapseParamWidget

class ConnectionParamWidget(QWidget):
    """
    Editor for an existing connection. Mirrors the ConnectionTool feature
    set: synapse model with model-specific parameters (STDP, Tsodyks2,
    etc.), connection rule, plus the full spatial section (mask shape,
    distance-dep p / weight / delay, anchor offset, anisotropic /
    orientation-tuned weights).
    
    Reads SYNAPSE_MODELS the same way the ConnectionTool does — directly
    from the FLAT key-set (every key except weight/delay is a model param),
    not via a nested 'params' sub-dict that doesn't exist in the runtime
    SYNAPSE_MODELS definition.
    """
    connectionUpdated = pyqtSignal(dict)
    
    def __init__(self):
        super().__init__()
        self.current_conn_data = None
        self.syn_param_widgets = {}
        self.init_ui()
        
    def init_ui(self):
        layout = QVBoxLayout(self)
        
        header = QLabel("EDIT CONNECTION")
        header.setStyleSheet("font-weight: bold; font-size: 14px; color: #673AB7; padding: 5px; border-bottom: 2px solid #673AB7;")
        layout.addWidget(header)
        
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        
        content_widget = QWidget()
        self.form_layout = QFormLayout(content_widget)
        self.form_layout.setSpacing(10)
        
        self.name_input = QLineEdit()
        self.form_layout.addRow("Name:", self.name_input)
        
        self.weight_spin = QDoubleSpinBox()
        self.weight_spin.setRange(-1e6, 1e6)
        self.weight_spin.setDecimals(3)
        self.weight_spin.setPrefix("W: ")
        self.form_layout.addRow("Weight:", self.weight_spin)
        
        self.delay_spin = QDoubleSpinBox()
        self.delay_spin.setRange(0.1, 10000.0)
        self.delay_spin.setDecimals(2)
        self.delay_spin.setSuffix(" ms")
        self.delay_spin.setPrefix("D: ")
        self.form_layout.addRow("Delay:", self.delay_spin)
        
        self.syn_model_combo = QComboBox()
        self.syn_model_combo.addItems(sorted(SYNAPSE_MODELS.keys()))
        self.syn_model_combo.currentTextChanged.connect(self._on_model_changed)
        self.form_layout.addRow("Model:", self.syn_model_combo)
        
        # Description for the chosen synapse (no_delay warning, etc.)
        self.syn_desc_label = QLabel("")
        self.syn_desc_label.setStyleSheet("color: #888; font-size: 10px; font-style: italic;")
        self.syn_desc_label.setWordWrap(True)
        self.form_layout.addRow(self.syn_desc_label)
        
        self.rule_combo = QComboBox()
        self.rule_combo.addItems(["all_to_all", "fixed_indegree", "fixed_outdegree", "fixed_total_number", "pairwise_bernoulli", "one_to_one"])
        self.rule_combo.currentTextChanged.connect(self._on_rule_changed)
        self.form_layout.addRow("Rule:", self.rule_combo)
        
        self.rule_param_container = QWidget()
        self.rule_param_layout = QFormLayout(self.rule_param_container)
        self.rule_param_layout.setContentsMargins(0,0,0,0)
        self.form_layout.addRow(self.rule_param_container)
        
        self.spin_indegree = QSpinBox(); self.spin_indegree.setRange(0, int(1e9))
        self.spin_outdegree = QSpinBox(); self.spin_outdegree.setRange(0, int(1e9))
        self.spin_N = QSpinBox(); self.spin_N.setRange(0, int(1e9))
        self.spin_p = QDoubleSpinBox(); self.spin_p.setRange(0.0, 1.0); self.spin_p.setDecimals(4); self.spin_p.setSingleStep(0.001)
        
        # ── Synapse Model Parameters (collapsible) ──
        # Default expanded so people see immediately that there are knobs
        # available when they pick a non-trivial synapse model.
        self.dyn_groupbox = QGroupBox("Synapse Model Parameters")
        self.dyn_groupbox.setCheckable(True); self.dyn_groupbox.setChecked(True)
        self.dyn_groupbox.toggled.connect(self._toggle_dyn_visibility)
        self.dyn_layout = QVBoxLayout(self.dyn_groupbox)
        self.dyn_layout.setContentsMargins(8, 8, 8, 8)
        self.form_layout.addRow(self.dyn_groupbox)
        
        # ── Spatial section ──
        self._build_spatial_section()
        
        scroll.setWidget(content_widget)
        layout.addWidget(scroll)
        
        btn_layout = QHBoxLayout()
        self.btn_apply = QPushButton("UPDATE CONNECTION")
        self.btn_apply.setMinimumHeight(40)
        self.btn_apply.setStyleSheet("background-color: #673AB7; color: white; font-weight: bold; border-radius: 4px;")
        self.btn_apply.clicked.connect(self.apply_changes)
        btn_layout.addWidget(self.btn_apply)
        
        layout.addLayout(btn_layout)
        
        # Trigger initial population for default model so the dyn box isn't empty
        self._on_model_changed(self.syn_model_combo.currentText())
    
    def _build_spatial_section(self):
        """All spatial features — mask, distance-dep p / weight / delay,
        anchor, anisotropy. Parity with ConnectionTool._init_spatial_tab.
        Wrapped in a single checkable group-box so users can ignore it
        completely for non-spatial connections."""
        spatial = QGroupBox("Spatial (use NEST mask + position-aware specs)")
        spatial.setCheckable(True); spatial.setChecked(False)
        sp_v = QVBoxLayout(spatial)
        sp_v.setSpacing(6)
        
        # Mask shape + radii
        mask_form = QFormLayout()
        self.mask_type_combo = QComboBox()
        self.mask_type_combo.addItems([
            "sphere", "box", "box_asym", "doughnut", "elliptical", "ellipsoidal"
        ])
        self.mask_type_combo.currentTextChanged.connect(self._on_mask_type_changed)
        mask_form.addRow("Mask Shape:", self.mask_type_combo)
        self.mask_radius_spin = QDoubleSpinBox(); self.mask_radius_spin.setRange(0.001, 1000.0); self.mask_radius_spin.setValue(0.5); self.mask_radius_spin.setDecimals(4)
        mask_form.addRow("Outer Radius/Size:", self.mask_radius_spin)
        self.mask_inner_spin = QDoubleSpinBox(); self.mask_inner_spin.setRange(0.0, 1000.0); self.mask_inner_spin.setValue(0.0); self.mask_inner_spin.setDecimals(4)
        mask_form.addRow("Inner Radius:", self.mask_inner_spin)
        sp_v.addLayout(mask_form)
        
        # Asymmetric box corners
        self.box_asym_box = QGroupBox("Asymmetric Box (lower_left / upper_right)")
        ab_v = QVBoxLayout(self.box_asym_box)
        ab_top = QHBoxLayout()
        self.ll_x = QDoubleSpinBox(); self.ll_x.setRange(-1000, 1000); self.ll_x.setValue(-0.5); self.ll_x.setPrefix("ll_x="); self.ll_x.setDecimals(3)
        self.ll_y = QDoubleSpinBox(); self.ll_y.setRange(-1000, 1000); self.ll_y.setValue(-0.5); self.ll_y.setPrefix("ll_y="); self.ll_y.setDecimals(3)
        self.ll_z = QDoubleSpinBox(); self.ll_z.setRange(-1000, 1000); self.ll_z.setValue(-0.5); self.ll_z.setPrefix("ll_z="); self.ll_z.setDecimals(3)
        for w in (self.ll_x, self.ll_y, self.ll_z): ab_top.addWidget(w)
        ab_v.addLayout(ab_top)
        ab_bot = QHBoxLayout()
        self.ur_x = QDoubleSpinBox(); self.ur_x.setRange(-1000, 1000); self.ur_x.setValue(0.5); self.ur_x.setPrefix("ur_x="); self.ur_x.setDecimals(3)
        self.ur_y = QDoubleSpinBox(); self.ur_y.setRange(-1000, 1000); self.ur_y.setValue(0.5); self.ur_y.setPrefix("ur_y="); self.ur_y.setDecimals(3)
        self.ur_z = QDoubleSpinBox(); self.ur_z.setRange(-1000, 1000); self.ur_z.setValue(0.5); self.ur_z.setPrefix("ur_z="); self.ur_z.setDecimals(3)
        for w in (self.ur_x, self.ur_y, self.ur_z): ab_bot.addWidget(w)
        ab_v.addLayout(ab_bot)
        self.box_asym_box.setVisible(False)
        sp_v.addWidget(self.box_asym_box)
        
        # Ellipsoid axes
        self.ellipsoid_box = QGroupBox("Ellipsoid Axes")
        ell_h = QHBoxLayout(self.ellipsoid_box)
        self.major_axis_spin = QDoubleSpinBox(); self.major_axis_spin.setRange(0.001, 1000); self.major_axis_spin.setValue(2.0); self.major_axis_spin.setPrefix("major="); self.major_axis_spin.setDecimals(3)
        self.minor_axis_spin = QDoubleSpinBox(); self.minor_axis_spin.setRange(0.001, 1000); self.minor_axis_spin.setValue(1.0); self.minor_axis_spin.setPrefix("minor="); self.minor_axis_spin.setDecimals(3)
        self.polar_axis_spin = QDoubleSpinBox(); self.polar_axis_spin.setRange(0.001, 1000); self.polar_axis_spin.setValue(1.0); self.polar_axis_spin.setPrefix("polar="); self.polar_axis_spin.setDecimals(3)
        for w in (self.major_axis_spin, self.minor_axis_spin, self.polar_axis_spin):
            ell_h.addWidget(w)
        self.ellipsoid_box.setVisible(False)
        sp_v.addWidget(self.ellipsoid_box)
        
        # Anchor offset
        self.anchor_box = QGroupBox("Mask Anchor Offset (asymmetric RF)")
        self.anchor_box.setCheckable(True); self.anchor_box.setChecked(False)
        anchor_h = QHBoxLayout(self.anchor_box)
        self.anchor_x = QDoubleSpinBox(); self.anchor_x.setRange(-1000, 1000); self.anchor_x.setPrefix("dx="); self.anchor_x.setDecimals(3)
        self.anchor_y = QDoubleSpinBox(); self.anchor_y.setRange(-1000, 1000); self.anchor_y.setPrefix("dy="); self.anchor_y.setDecimals(3)
        self.anchor_z = QDoubleSpinBox(); self.anchor_z.setRange(-1000, 1000); self.anchor_z.setPrefix("dz="); self.anchor_z.setDecimals(3)
        for w in (self.anchor_x, self.anchor_y, self.anchor_z): anchor_h.addWidget(w)
        sp_v.addWidget(self.anchor_box)
        
        # Distance-dependent probability
        prob_box = QGroupBox("Connection Probability")
        prob_v = QVBoxLayout(prob_box)
        prob_top = QHBoxLayout()
        prob_top.addWidget(QLabel("p_max:"))
        self.spatial_prob_spin = QDoubleSpinBox()
        self.spatial_prob_spin.setRange(0.0, 1.0); self.spatial_prob_spin.setValue(1.0)
        self.spatial_prob_spin.setSingleStep(0.001); self.spatial_prob_spin.setDecimals(4)
        prob_top.addWidget(self.spatial_prob_spin)
        prob_top.addWidget(QLabel("Profile:"))
        self.prob_profile_combo = QComboBox()
        self.prob_profile_combo.addItems(["constant", "gaussian", "exponential", "linear"])
        prob_top.addWidget(self.prob_profile_combo)
        prob_v.addLayout(prob_top)
        sigma_row = QHBoxLayout()
        sigma_row.addWidget(QLabel("σ (decay scale):"))
        self.prob_sigma_spin = QDoubleSpinBox(); self.prob_sigma_spin.setRange(0.001, 1000.0); self.prob_sigma_spin.setValue(1.0); self.prob_sigma_spin.setDecimals(3)
        self.prob_sigma_spin.setEnabled(False)
        sigma_row.addWidget(self.prob_sigma_spin); sigma_row.addStretch()
        prob_v.addLayout(sigma_row)
        self.prob_profile_combo.currentTextChanged.connect(
            lambda t: self.prob_sigma_spin.setEnabled(t != "constant")
        )
        sp_v.addWidget(prob_box)
        
        # Distance-dependent weight
        self.weight_box = QGroupBox("Distance-Dependent Weight")
        self.weight_box.setCheckable(True); self.weight_box.setChecked(False)
        wb_v = QVBoxLayout(self.weight_box)
        wm_top = QHBoxLayout()
        wm_top.addWidget(QLabel("Mode:"))
        self.weight_mode_combo = QComboBox()
        self.weight_mode_combo.addItems(["linear", "exponential", "gaussian"])
        wm_top.addWidget(self.weight_mode_combo); wm_top.addStretch()
        wb_v.addLayout(wm_top)
        wm_p = QHBoxLayout()
        wm_p.addWidget(QLabel("factor:"))
        self.dist_factor_spin = QDoubleSpinBox(); self.dist_factor_spin.setRange(-1000, 1000); self.dist_factor_spin.setValue(1.0); self.dist_factor_spin.setDecimals(4)
        wm_p.addWidget(self.dist_factor_spin)
        wm_p.addWidget(QLabel("offset:"))
        self.dist_offset_spin = QDoubleSpinBox(); self.dist_offset_spin.setRange(-1000, 1000); self.dist_offset_spin.setValue(0.0); self.dist_offset_spin.setDecimals(4)
        wm_p.addWidget(self.dist_offset_spin)
        wb_v.addLayout(wm_p)
        sp_v.addWidget(self.weight_box)
        
        # Distance-dependent delay
        self.delay_box = QGroupBox("Distance-Dependent Delay (axonal)")
        self.delay_box.setCheckable(True); self.delay_box.setChecked(False)
        db_h = QHBoxLayout(self.delay_box)
        db_h.addWidget(QLabel("delay_factor (ms/unit):"))
        self.delay_factor_spin = QDoubleSpinBox(); self.delay_factor_spin.setRange(0, 1000); self.delay_factor_spin.setValue(1.0); self.delay_factor_spin.setDecimals(4)
        db_h.addWidget(self.delay_factor_spin); db_h.addStretch()
        sp_v.addWidget(self.delay_box)
        
        # Anisotropic weight (orientation tuning)
        self.aniso_box = QGroupBox("Anisotropic Weight (orientation tuning)")
        self.aniso_box.setCheckable(True); self.aniso_box.setChecked(False)
        ab_v2 = QVBoxLayout(self.aniso_box)
        am_top = QHBoxLayout()
        am_top.addWidget(QLabel("Mode:"))
        self.ani_mode_combo = QComboBox(); self.ani_mode_combo.addItems(["cosine", "gabor"])
        am_top.addWidget(self.ani_mode_combo); am_top.addStretch()
        ab_v2.addLayout(am_top)
        am_p = QHBoxLayout()
        am_p.addWidget(QLabel("θ (deg):"))
        self.ani_theta_spin = QDoubleSpinBox(); self.ani_theta_spin.setRange(-360, 360); self.ani_theta_spin.setValue(0.0); self.ani_theta_spin.setDecimals(2); self.ani_theta_spin.setSingleStep(15)
        am_p.addWidget(self.ani_theta_spin)
        am_p.addWidget(QLabel("freq:"))
        self.ani_freq_spin = QDoubleSpinBox(); self.ani_freq_spin.setRange(0.001, 1000); self.ani_freq_spin.setValue(0.5); self.ani_freq_spin.setDecimals(4)
        am_p.addWidget(self.ani_freq_spin)
        am_p.addWidget(QLabel("σ:"))
        self.ani_sigma_spin = QDoubleSpinBox(); self.ani_sigma_spin.setRange(0.001, 1000); self.ani_sigma_spin.setValue(1.0); self.ani_sigma_spin.setDecimals(3)
        am_p.addWidget(self.ani_sigma_spin)
        ab_v2.addLayout(am_p)
        sp_v.addWidget(self.aniso_box)
        
        self.spatial_box = spatial
        self.form_layout.addRow(spatial)
    
    def _toggle_dyn_visibility(self, checked):
        """Hide/show all model-param widgets when the group-box is collapsed."""
        for i in range(self.dyn_layout.count()):
            w = self.dyn_layout.itemAt(i).widget()
            if w: w.setVisible(checked)
    
    def _on_mask_type_changed(self, mask_type):
        self.box_asym_box.setVisible(mask_type == "box_asym")
        self.ellipsoid_box.setVisible(mask_type in ("elliptical", "ellipsoidal"))
        self.polar_axis_spin.setEnabled(mask_type == "ellipsoidal")
    
    def _on_model_changed(self, model_name):
        # Wipe old dynamic widgets
        while self.dyn_layout.count():
            item = self.dyn_layout.takeAt(0)
            w = item.widget()
            if w:
                w.setParent(None); w.deleteLater()
        self.syn_param_widgets.clear()
        
        if model_name not in SYNAPSE_MODELS:
            self.syn_desc_label.setText(f"Unknown model: {model_name}")
            return
        
        info = SYNAPSE_MODELS[model_name]
        no_delay = info.get('no_delay', False)
        
        # Iterate the FLAT structure — every key except weight/delay is a
        # model parameter. Same logic as ConnectionTool.on_synapse_model_changed.
        added = 0
        for pname, pinfo in info.items():
            if pname in ('weight', 'delay'):
                continue
            if not isinstance(pinfo, dict):
                continue
            try:
                widget = SynapseParamWidget(pname, pinfo)
            except Exception:
                continue
            self.dyn_layout.addWidget(widget)
            self.syn_param_widgets[pname] = widget
            added += 1
        
        if added == 0:
            empty = QLabel("Only weight/delay (no extra params for this model).")
            empty.setStyleSheet("color: #888; font-style: italic;")
            self.dyn_layout.addWidget(empty)
            self.syn_desc_label.setText("Static-style synapse — no plasticity params.")
        else:
            note = f"{added} model-specific parameter(s)"
            if no_delay:
                note += " — note: this model has no delay."
            self.syn_desc_label.setText(note)
        
        # Sync visibility with collapse state
        self._toggle_dyn_visibility(self.dyn_groupbox.isChecked())
    
    def load_data(self, conn_data):
        self.current_conn_data = conn_data
        params = conn_data.get('params', {})
        
        self.name_input.setText(conn_data.get('name', ''))
        self.weight_spin.setValue(float(params.get('weight', 1.0)))
        self.delay_spin.setValue(float(params.get('delay', 1.0)))
        
        # Set model — triggers _on_model_changed which rebuilds dyn widgets
        model = params.get('synapse_model', 'static_synapse')
        idx = self.syn_model_combo.findText(model)
        if idx >= 0:
            self.syn_model_combo.setCurrentIndex(idx)
        else:
            self.syn_model_combo.addItem(model)
            self.syn_model_combo.setCurrentText(model)
        # Force refresh in case the index was already correct (no signal)
        self._on_model_changed(model)
        
        rule = params.get('rule', 'all_to_all')
        idx_r = self.rule_combo.findText(rule)
        if idx_r >= 0: self.rule_combo.setCurrentIndex(idx_r)
        self._on_rule_changed(rule)
        
        if 'indegree' in params: self.spin_indegree.setValue(int(params['indegree']))
        if 'outdegree' in params: self.spin_outdegree.setValue(int(params['outdegree']))
        if 'N' in params: self.spin_N.setValue(int(params['N']))
        if 'p' in params: self.spin_p.setValue(float(params['p']))
        
        # Synapse model parameters
        for param_name, widget in self.syn_param_widgets.items():
            if param_name in params:
                try:
                    widget.set_value(params[param_name])
                except Exception:
                    pass
        
        # ── Spatial ──
        self.spatial_box.setChecked(bool(params.get('use_spatial', False)))
        mt = params.get('mask_type', 'sphere')
        idx_m = self.mask_type_combo.findText(mt)
        if idx_m >= 0:
            self.mask_type_combo.setCurrentIndex(idx_m)
        self._on_mask_type_changed(mt)
        if 'mask_radius' in params: self.mask_radius_spin.setValue(float(params['mask_radius']))
        if 'mask_inner_radius' in params: self.mask_inner_spin.setValue(float(params['mask_inner_radius']))
        # box_asym corners
        ll = params.get('lower_left'); ur = params.get('upper_right')
        if isinstance(ll, (list, tuple)) and len(ll) == 3:
            self.ll_x.setValue(float(ll[0])); self.ll_y.setValue(float(ll[1])); self.ll_z.setValue(float(ll[2]))
        if isinstance(ur, (list, tuple)) and len(ur) == 3:
            self.ur_x.setValue(float(ur[0])); self.ur_y.setValue(float(ur[1])); self.ur_z.setValue(float(ur[2]))
        if 'major_axis' in params: self.major_axis_spin.setValue(float(params['major_axis']))
        if 'minor_axis' in params: self.minor_axis_spin.setValue(float(params['minor_axis']))
        if 'polar_axis' in params: self.polar_axis_spin.setValue(float(params['polar_axis']))
        # Anchor
        self.anchor_box.setChecked(bool(params.get('use_anchor', False)))
        anchor = params.get('anchor')
        if isinstance(anchor, (list, tuple)) and len(anchor) == 3:
            self.anchor_x.setValue(float(anchor[0])); self.anchor_y.setValue(float(anchor[1])); self.anchor_z.setValue(float(anchor[2]))
        # Probability profile
        if 'p' in params: self.spatial_prob_spin.setValue(float(params['p']))
        if 'p_profile' in params:
            i_pp = self.prob_profile_combo.findText(params['p_profile'])
            if i_pp >= 0: self.prob_profile_combo.setCurrentIndex(i_pp)
        if 'p_sigma' in params: self.prob_sigma_spin.setValue(float(params['p_sigma']))
        # Distance weight
        self.weight_box.setChecked(bool(params.get('distance_dependent_weight', False)))
        if 'weight_mode' in params:
            i_wm = self.weight_mode_combo.findText(params['weight_mode'])
            if i_wm >= 0: self.weight_mode_combo.setCurrentIndex(i_wm)
        if 'dist_factor' in params: self.dist_factor_spin.setValue(float(params['dist_factor']))
        if 'dist_offset' in params: self.dist_offset_spin.setValue(float(params['dist_offset']))
        # Distance delay
        self.delay_box.setChecked(bool(params.get('distance_dependent_delay', False)))
        if 'delay_factor' in params: self.delay_factor_spin.setValue(float(params['delay_factor']))
        # Anisotropy
        self.aniso_box.setChecked(bool(params.get('anisotropic_weight', False)))
        if 'aniso_mode' in params:
            i_am = self.ani_mode_combo.findText(params['aniso_mode'])
            if i_am >= 0: self.ani_mode_combo.setCurrentIndex(i_am)
        if 'aniso_theta_deg' in params: self.ani_theta_spin.setValue(float(params['aniso_theta_deg']))
        if 'aniso_freq' in params: self.ani_freq_spin.setValue(float(params['aniso_freq']))
        if 'aniso_sigma' in params: self.ani_sigma_spin.setValue(float(params['aniso_sigma']))

    def _on_rule_changed(self, rule_name):
        while self.rule_param_layout.count():
            item = self.rule_param_layout.takeAt(0)
            if item.widget(): item.widget().setParent(None)
            
        if rule_name == 'fixed_indegree':
            self.rule_param_layout.addRow("Indegree:", self.spin_indegree)
        elif rule_name == 'fixed_outdegree':
            self.rule_param_layout.addRow("Outdegree:", self.spin_outdegree)
        elif rule_name == 'fixed_total_number':
            self.rule_param_layout.addRow("Total N:", self.spin_N)
        elif 'bernoulli' in rule_name:
            self.rule_param_layout.addRow("Prob (p):", self.spin_p)

    def apply_changes(self):
        if self.current_conn_data is None: return
        
        self.current_conn_data['name'] = self.name_input.text()
        params = self.current_conn_data['params']
        
        params['weight'] = self.weight_spin.value()
        params['delay'] = self.delay_spin.value()
        params['synapse_model'] = self.syn_model_combo.currentText()
        
        rule = self.rule_combo.currentText()
        params['rule'] = rule
        
        # Clear stale rule-specific keys before writing the new one
        for k in ('indegree', 'outdegree', 'N'):
            params.pop(k, None)
        if rule == 'fixed_indegree': params['indegree'] = self.spin_indegree.value()
        elif rule == 'fixed_outdegree': params['outdegree'] = self.spin_outdegree.value()
        elif rule == 'fixed_total_number': params['N'] = self.spin_N.value()
        elif 'bernoulli' in rule: params['p'] = self.spin_p.value()
        
        # Synapse model params — drop stale keys from the previous model
        # before writing new ones (otherwise a leftover tau_plus from STDP
        # would tag along when the user switches to static_synapse).
        all_known_syn_keys = set()
        for m_name, m_info in SYNAPSE_MODELS.items():
            for k in m_info.keys():
                if k not in ('weight', 'delay'):
                    all_known_syn_keys.add(k)
        for k in list(params.keys()):
            if k in all_known_syn_keys and k not in self.syn_param_widgets:
                params.pop(k, None)
        # Write current model's params
        for param_name, widget in self.syn_param_widgets.items():
            try:
                params[param_name] = widget.get_value()
            except Exception:
                pass
        
        # ── Spatial ──
        params['use_spatial'] = bool(self.spatial_box.isChecked())
        if params['use_spatial']:
            params['mask_type'] = self.mask_type_combo.currentText()
            params['mask_radius'] = self.mask_radius_spin.value()
            params['mask_inner_radius'] = self.mask_inner_spin.value()
            params['lower_left'] = [self.ll_x.value(), self.ll_y.value(), self.ll_z.value()]
            params['upper_right'] = [self.ur_x.value(), self.ur_y.value(), self.ur_z.value()]
            params['major_axis'] = self.major_axis_spin.value()
            params['minor_axis'] = self.minor_axis_spin.value()
            params['polar_axis'] = self.polar_axis_spin.value()
            params['use_anchor'] = bool(self.anchor_box.isChecked())
            params['anchor'] = [self.anchor_x.value(), self.anchor_y.value(), self.anchor_z.value()]
            params['p_profile'] = self.prob_profile_combo.currentText()
            params['p_sigma'] = self.prob_sigma_spin.value()
            # Bernoulli p uses spatial_prob_spin for distance-dep profile;
            # plain spin_p covers the simple-rule case.
            if 'bernoulli' in rule:
                params['p'] = self.spatial_prob_spin.value()
            params['distance_dependent_weight'] = bool(self.weight_box.isChecked())
            params['weight_mode'] = self.weight_mode_combo.currentText()
            params['dist_factor'] = self.dist_factor_spin.value()
            params['dist_offset'] = self.dist_offset_spin.value()
            params['distance_dependent_delay'] = bool(self.delay_box.isChecked())
            params['delay_factor'] = self.delay_factor_spin.value()
            params['anisotropic_weight'] = bool(self.aniso_box.isChecked())
            params['aniso_mode'] = self.ani_mode_combo.currentText()
            params['aniso_theta_deg'] = self.ani_theta_spin.value()
            params['aniso_freq'] = self.ani_freq_spin.value()
            params['aniso_sigma'] = self.ani_sigma_spin.value()
        
        print(f"Connection '{self.current_conn_data['name']}' updated locally. "
              f"(Model: {params['synapse_model']}, Rule: {rule}, "
              f"spatial: {params.get('use_spatial', False)})")
        # Tell anyone interested (the ConnectionEditorWidget wrapper) that
        # the underlying dict was mutated. Listeners typically rebuild NEST
        # synapses from scratch since changing weight / synapse_model on
        # an existing connection is not safely doable in NEST without
        # recreating it.
        self.connectionUpdated.emit(self.current_conn_data)
        

class ConnectionEditorWidget(QWidget):
    """
    Standalone editor page for existing connections. Routed to from the
    Graph Overview when the user clicks an arrow. Wraps the
    ConnectionParamWidget plus a header that shows which connection is
    being edited and a helper to look up the original connection dict
    from a graph_list by source/id.
    
    Why a separate widget? Connection editing used to live inside the
    Graph Inspector, which got crowded fast. Splitting Connection
    Creation (ConnectionTool) and Connection Editing (this widget) into
    two separate nav pages keeps each focused on one job.
    """
    connectionUpdated = pyqtSignal(dict)  # forwarded from inner editor
    
    def __init__(self, graph_list, parent=None):
        super().__init__(parent)
        self.graph_list = graph_list
        self.current_conn_ref = None  # the actual dict in node.connections
        self._init_ui()
    
    def _init_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        
        # Header bar with the source/target summary. Updated whenever a
        # connection is loaded so the user always knows which one they're
        # editing.
        header = QFrame()
        header.setStyleSheet("background-color: #2b1b3b; border-bottom: 2px solid #673AB7;")
        hl = QVBoxLayout(header)
        hl.setContentsMargins(12, 10, 12, 10)
        hl.setSpacing(2)
        title = QLabel("CONNECTION EDITOR")
        title.setStyleSheet("font-weight: bold; font-size: 13px; color: #BB86FC;")
        hl.addWidget(title)
        self._summary_label = QLabel("No connection selected.")
        self._summary_label.setStyleSheet("color: #ccc; font-size: 11px;")
        self._summary_label.setWordWrap(True)
        hl.addWidget(self._summary_label)
        outer.addWidget(header)
        
        # Empty-state vs editor stack. When no connection is selected we
        # show a friendly placeholder; clicking an arrow swaps to the editor.
        self._stack = QStackedWidget()
        
        empty = QLabel(
            "Click a connection arrow in the graph view to edit it here.\n\n"
            "You can change the synapse model (e.g. static → STDP / "
            "tsodyks2), the connection rule, and all spatial features."
        )
        empty.setAlignment(Qt.AlignmentFlag.AlignCenter)
        empty.setWordWrap(True)
        empty.setStyleSheet("color: #888; font-style: italic; padding: 30px;")
        self._stack.addWidget(empty)
        
        self.editor = ConnectionParamWidget()
        self.editor.connectionUpdated.connect(self._on_inner_update)
        self._stack.addWidget(self.editor)
        
        outer.addWidget(self._stack, 1)
    
    def load_connection(self, connection_data):
        """
        Look up the LIVE connection dict from graph_list (so edits actually
        persist on the node), fall back to the passed-in dict if the live
        one isn't found. Mirrors the original logic from
        EditGraphWidget.load_connection_editor.
        """
        if not connection_data:
            return
        live_ref = self._find_live_connection(connection_data)
        ref = live_ref if live_ref is not None else connection_data
        self.current_conn_ref = ref
        
        # Header summary
        src = ref.get('source', {}) or {}
        tgt = ref.get('target', {}) or {}
        params = ref.get('params', {}) or {}
        name = ref.get('name', f"Connection #{ref.get('id', '?')}")
        sm = params.get('synapse_model', '?')
        w = params.get('weight', '?')
        d = params.get('delay', '?')
        rule = params.get('rule', '?')
        self._summary_label.setText(
            f"<b>{name}</b>  —  "
            f"G{src.get('graph_id','?')}.N{src.get('node_id','?')}.P{src.get('pop_id','?')} → "
            f"G{tgt.get('graph_id','?')}.N{tgt.get('node_id','?')}.P{tgt.get('pop_id','?')}"
            f"<br><span style='color:#aaa;'>{sm} | {rule} | w={w}, d={d}</span>"
        )
        self._summary_label.setTextFormat(Qt.TextFormat.RichText)
        
        self.editor.load_data(ref)
        self._stack.setCurrentIndex(1)
    
    def _find_live_connection(self, connection_data):
        """Find the actual dict instance in node.connections — editing the
        passed copy would silently lose the changes on save. Match by
        source IDs + connection id."""
        try:
            src = connection_data.get('source', {}) or {}
            target_gid = src.get('graph_id')
            target_nid = src.get('node_id')
            target_cid = connection_data.get('id')
            if target_gid is None or target_nid is None:
                return None
            for g in self.graph_list:
                if g.graph_id != target_gid: continue
                for n in g.node_list:
                    if n.id != target_nid: continue
                    for c in (getattr(n, 'connections', []) or []):
                        if c.get('id') == target_cid:
                            return c
        except Exception:
            pass
        return None
    
    def clear(self):
        """Reset to the empty placeholder state."""
        self.current_conn_ref = None
        self._summary_label.setText("No connection selected.")
        self._stack.setCurrentIndex(0)
    
    def _on_inner_update(self, conn_dict):
        # Forward upward; refresh header in case fields changed.
        params = conn_dict.get('params', {}) or {}
        name = conn_dict.get('name', '?')
        sm = params.get('synapse_model', '?')
        rule = params.get('rule', '?')
        w = params.get('weight', '?')
        d = params.get('delay', '?')
        # Keep src/tgt static (those don't change); just update the param tail
        existing = self._summary_label.text()
        # Cheap approach: re-render from scratch if we still have the ref
        if self.current_conn_ref is not None:
            self.load_connection(self.current_conn_ref)
        self.connectionUpdated.emit(conn_dict)
