"""Auswahl vordefinierter Hirnregionen-Strukturen."""
from PyQt6.QtCore import pyqtSignal, Qt
from PyQt6.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QPushButton, QScrollArea, QVBoxLayout, QWidget,
)

from neuron_toolbox import distributions, region_names

class StructuresWidget(QWidget):

    structureSelected = pyqtSignal(str, list, list)

    def __init__(self):
        super().__init__()
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        
        header_frame = QFrame()
        header_frame.setStyleSheet("background-color: #2b2b2b; border-bottom: 1px solid #444;")
        hl = QVBoxLayout(header_frame)
        hl.setContentsMargins(10, 10, 10, 10)
        
        header_lbl = QLabel("CORTICAL STRUCTURES")
        header_lbl.setStyleSheet("font-weight: bold; font-size: 14px; color: #E91E63;")
        hl.addWidget(header_lbl)
        
        info = QLabel("Select a region to auto-generate a node patch.")
        info.setStyleSheet("color: #888; font-style: italic;")
        hl.addWidget(info)
        
        layout.addWidget(header_frame)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("border: none; background-color: #1e1e1e;")
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        
        container = QWidget()
        container.setStyleSheet("background-color: #1e1e1e;")
        
        self.items_layout = QHBoxLayout(container)
        self.items_layout.setSpacing(5)
        self.items_layout.setContentsMargins(10, 10, 10, 10)
        self.items_layout.setAlignment(Qt.AlignmentFlag.AlignLeft)

        region_data = {r_key: {} for r_key in region_names.values()}
        
        for model, region_map in distributions.items():
            for r_key, prob in region_map.items():
                if prob > 0:
                    region_data[r_key][model] = prob

        for display_name, r_key in region_names.items():
            if r_key not in region_data or not region_data[r_key]:
                continue
            
            models_probs = region_data[r_key]
            model_list = list(models_probs.keys())
            prob_list = list(models_probs.values())
            
            total = sum(prob_list)
            if total > 0:
                prob_list = [p/total for p in prob_list]
            
            btn = QPushButton(display_name)
            btn.setMinimumHeight(60)
            btn.setFixedWidth(160)
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.setStyleSheet("""
                QPushButton {
                    background-color: #37474F;
                    color: white;
                    font-weight: bold;
                    border: 1px solid #455A64;
                    border-radius: 4px;
                    font-size: 11px;
                    text-align: center;
                    padding: 5px;
                }
                QPushButton:hover {
                    background-color: #E91E63;
                    border: 1px solid #F48FB1;
                }
            """)
            
            tooltip_txt = f"<b>{display_name}</b><br>Contains:<br>"
            for m, p in zip(model_list, prob_list):
                tooltip_txt += f"• {m}: {p*100:.1f}%<br>"
            btn.setToolTip(tooltip_txt)
            
            btn.clicked.connect(lambda checked, n=display_name, m=model_list, p=prob_list:
                              self.structureSelected.emit(n, m, p))
            
            self.items_layout.addWidget(btn)
        
        scroll.setWidget(container)
        layout.addWidget(scroll)
