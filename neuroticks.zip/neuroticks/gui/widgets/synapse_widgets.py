"""Widgets zur Auswahl und Parametrierung von Synapsenmodellen."""
from typing import Any, Dict

from PyQt6.QtCore import pyqtSignal
from PyQt6.QtWidgets import (
    QCheckBox, QComboBox, QDoubleSpinBox, QFormLayout, QFrame, QGroupBox, QHBoxLayout,
    QLabel, QLineEdit, QMessageBox, QPushButton, QScrollArea, QSpinBox, QVBoxLayout, QWidget,
)

from neuroticks.constants.synapses import SYNAPSE_MODELS

class SynapseParamWidget(QWidget):
    
    valueChanged = pyqtSignal()
    
    def __init__(self, name: str, info: Dict[str, Any], parent=None):
        super().__init__(parent)
        self.name = name
        self.info = info
        self._init_ui()
        
    def _init_ui(self):
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 2, 0, 2)
        
        label = QLabel(f"{self.name}:")
        label.setMinimumWidth(100)
        desc = self.info.get('description', self.name)
        unit = self.info.get('unit', '')
        if unit:
            label.setToolTip(f"{desc} [{unit}]")
        else:
            label.setToolTip(desc)
        layout.addWidget(label)
        
        ptype = self.info.get('type', 'float')
        default = self.info.get('default', 0.0)
        
        if ptype == 'float':
            self.input = QDoubleSpinBox()
            self.input.setDecimals(6)
            self.input.setRange(
                self.info.get('min', -1e10),
                self.info.get('max', 1e10)
            )
            self.input.setValue(float(default))
            self.input.valueChanged.connect(self.valueChanged.emit)
            
        elif ptype == 'int' or ptype == 'integer':
            self.input = QSpinBox()
            self.input.setRange(
                int(self.info.get('min', 0)),
                int(self.info.get('max', 10000))
            )
            self.input.setValue(int(default))
            self.input.valueChanged.connect(self.valueChanged.emit)
            
        elif ptype == 'bool':
            self.input = QCheckBox()
            self.input.setChecked(bool(default))
            self.input.stateChanged.connect(self.valueChanged.emit)
            
        else:
            self.input = QLineEdit(str(default))
            self.input.textChanged.connect(self.valueChanged.emit)
        
        layout.addWidget(self.input, 1)
        
        if unit:
            unit_label = QLabel(unit)
            unit_label.setStyleSheet("color: #888; font-size: 10px;")
            layout.addWidget(unit_label)
    
    def get_value(self):
        if isinstance(self.input, (QDoubleSpinBox, QSpinBox)):
            return self.input.value()
        elif isinstance(self.input, QCheckBox):
            return self.input.isChecked()
        else:
            return self.input.text()
    
    def set_value(self, value):
        if isinstance(self.input, (QDoubleSpinBox, QSpinBox)):
            self.input.setValue(value)
        elif isinstance(self.input, QCheckBox):
            self.input.setChecked(bool(value))
        else:
            self.input.setText(str(value))


class InlineSynapseConfig(QWidget):
    """
    Kompakte Synapse-Config für Tool-Panels (CCW/Cone/Blob).
    Combo zum Synapsen-Modell + ausklappbare model-spezifische Parameter
    (z.B. tau_plus/lambda/alpha bei stdp_synapse). Funktioniert wie
    der Connection Manager, nur als Inline-Widget.
    
    Wert: dict {'synapse_model': str, 'extra_params': {pname: value, ...}}.
    """
    valueChanged = pyqtSignal()
    
    def __init__(self, label="Synapse", default_model='static_synapse',
                 collapsed=True, parent=None):
        super().__init__(parent)
        self.param_widgets: Dict[str, SynapseParamWidget] = {}
        
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 4, 0, 4)
        outer.setSpacing(2)
        
        # Title row
        title_lbl = QLabel(label)
        title_lbl.setStyleSheet("font-weight: bold; color: #FFC107;")
        outer.addWidget(title_lbl)
        
        # Synapse model combo
        row = QHBoxLayout()
        row.addWidget(QLabel("Model:", styleSheet="min-width:60px;"))
        self.model_combo = QComboBox()
        for name in SYNAPSE_MODELS.keys():
            self.model_combo.addItem(name)
        if default_model in SYNAPSE_MODELS:
            self.model_combo.setCurrentText(default_model)
        self.model_combo.currentTextChanged.connect(self._on_model_changed)
        row.addWidget(self.model_combo, 1)
        outer.addLayout(row)
        
        # Description label (small, italic)
        self.desc_label = QLabel("")
        self.desc_label.setStyleSheet("color: #888; font-size: 10px; font-style: italic;")
        self.desc_label.setWordWrap(True)
        outer.addWidget(self.desc_label)
        
        # Collapsible group for model-specific params
        self.params_group = QGroupBox("Model Parameters")
        self.params_group.setCheckable(True)
        self.params_group.setChecked(not collapsed)  # checked = expanded
        self.params_group.toggled.connect(self._on_group_toggled)
        self.params_layout = QVBoxLayout(self.params_group)
        self.params_layout.setContentsMargins(8, 8, 8, 8)
        self.params_layout.setSpacing(2)
        outer.addWidget(self.params_group)
        
        # Erste Befüllung
        self._populate_param_widgets(default_model)
        # Initial: visibility nach collapsed-Status
        self._on_group_toggled(self.params_group.isChecked())
    
    def _on_model_changed(self, model_name):
        self._populate_param_widgets(model_name)
        self.valueChanged.emit()
    
    def _on_group_toggled(self, checked):
        # GroupBox content visibility manuell steuern
        for i in range(self.params_layout.count()):
            item = self.params_layout.itemAt(i)
            w = item.widget()
            if w:
                w.setVisible(checked)
    
    def _populate_param_widgets(self, model_name):
        # Bestehende Widgets entfernen
        while self.params_layout.count():
            item = self.params_layout.takeAt(0)
            w = item.widget()
            if w:
                w.setParent(None)
                w.deleteLater()
        self.param_widgets.clear()
        
        if model_name not in SYNAPSE_MODELS:
            self.desc_label.setText(f"Unbekanntes Modell: {model_name}")
            return
        
        # Hinweis: SYNAPSE_MODELS hat FLAT-Struktur (gleich wie der
        # Connection-Manager). Jeder key (außer weight/delay) ist ein
        # Synapsen-Param. weight/delay werden separat im Tool-Panel
        # geführt. Diese Iterations-Logik ist 1:1 wie
        # ConnectionTool.on_synapse_model_changed.
        info = SYNAPSE_MODELS[model_name]
        added = 0
        for pname, pinfo in info.items():
            if pname in ('weight', 'delay'):
                continue
            if not isinstance(pinfo, dict):
                continue
            widget = SynapseParamWidget(pname, pinfo)
            widget.valueChanged.connect(self.valueChanged.emit)
            self.params_layout.addWidget(widget)
            self.param_widgets[pname] = widget
            added += 1
        
        if added == 0:
            empty_lbl = QLabel("Nur weight/delay (kein zusätzlicher Param).")
            empty_lbl.setStyleSheet("color: #888; font-style: italic;")
            self.params_layout.addWidget(empty_lbl)
            self.desc_label.setText("")
        else:
            self.desc_label.setText(f"{added} modell-spezifische Parameter")
    
    def get_value(self) -> dict:
        return {
            'synapse_model': self.model_combo.currentText(),
            'extra_params': {n: w.get_value() for n, w in self.param_widgets.items()}
        }
    
    def set_value(self, config):
        if not isinstance(config, dict):
            return
        m = config.get('synapse_model')
        if m and m in SYNAPSE_MODELS:
            self.model_combo.blockSignals(True)
            self.model_combo.setCurrentText(m)
            self.model_combo.blockSignals(False)
            self._populate_param_widgets(m)
            # Visibility wieder synchron mit GroupBox-Toggle
            self._on_group_toggled(self.params_group.isChecked())
        for pname, val in (config.get('extra_params', {}) or {}).items():
            if pname in self.param_widgets:
                try:
                    self.param_widgets[pname].set_value(val)
                except Exception:
                    pass


class SynapseCreationWidget(QWidget):

    
    synapseCreated = pyqtSignal(str, dict)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.param_widgets: Dict[str, SynapseParamWidget] = {}
        self.custom_synapses: Dict[str, Dict] = {}
        self._init_ui()
        
    def _init_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(5, 5, 5, 5)
        
        header = QLabel("Synapse Configuration")
        header.setStyleSheet("font-size: 14px; font-weight: bold; color: #2196F3;")
        main_layout.addWidget(header)
        
        sel_group = QGroupBox("Model Selection")
        sel_layout = QFormLayout(sel_group)
        
        self.category_combo = QComboBox()
        self.category_combo.addItems(["All", "basic", "plasticity", "stp", "electrical", "special"])
        self.category_combo.currentTextChanged.connect(self._filter_models)
        sel_layout.addRow("Category:", self.category_combo)
        
        self.model_combo = QComboBox()
        self.model_combo.currentTextChanged.connect(self._on_model_changed)
        sel_layout.addRow("Synapse Model:", self.model_combo)
        
        self.desc_label = QLabel("")
        self.desc_label.setWordWrap(True)
        self.desc_label.setStyleSheet("color: #888; font-style: italic; padding: 5px;")
        sel_layout.addRow(self.desc_label)
        
        main_layout.addWidget(sel_group)
        
        base_group = QGroupBox("Base Parameters")
        base_layout = QFormLayout(base_group)
        
        self.weight_spin = QDoubleSpinBox()
        self.weight_spin.setRange(-100000, 100000)
        self.weight_spin.setValue(1.0)
        self.weight_spin.setDecimals(4)
        base_layout.addRow("Weight:", self.weight_spin)
        
        self.delay_spin = QDoubleSpinBox()
        self.delay_spin.setRange(0.1, 10000)
        self.delay_spin.setValue(1.0)
        self.delay_spin.setDecimals(2)
        self.delay_spin.setSuffix(" ms")
        base_layout.addRow("Delay:", self.delay_spin)
        
        self.delay_warning = QLabel("")
        self.delay_warning.setStyleSheet("color: #FF9800; font-size: 10px;")
        base_layout.addRow(self.delay_warning)
        
        main_layout.addWidget(base_group)
        
        params_group = QGroupBox("Model-Specific Parameters")
        self.params_scroll = QScrollArea()
        self.params_scroll.setWidgetResizable(True)
        self.params_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.params_scroll.setMaximumHeight(200)
        
        self.params_container = QWidget()
        self.params_layout = QVBoxLayout(self.params_container)
        self.params_layout.setContentsMargins(5, 5, 5, 5)
        self.params_scroll.setWidget(self.params_container)
        
        params_group_layout = QVBoxLayout(params_group)
        params_group_layout.addWidget(self.params_scroll)
        main_layout.addWidget(params_group)
        
        custom_group = QGroupBox("Custom Model (Optional)")
        custom_layout = QFormLayout(custom_group)
        
        self.custom_name_input = QLineEdit()
        self.custom_name_input.setPlaceholderText("Leave empty to use base model")
        custom_layout.addRow("Custom Name:", self.custom_name_input)
        
        save_btn = QPushButton("Save as Preset")
        save_btn.clicked.connect(self._save_preset)
        custom_layout.addRow(save_btn)
        
        main_layout.addWidget(custom_group)
        
        action_layout = QHBoxLayout()
        
        self.apply_btn = QPushButton("Apply Synapse")
        self.apply_btn.setStyleSheet("background-color: #4CAF50; font-weight: bold;")
        self.apply_btn.clicked.connect(self._emit_synapse)
        action_layout.addWidget(self.apply_btn)
        
        reset_btn = QPushButton("Reset")
        reset_btn.clicked.connect(self._reset_to_defaults)
        action_layout.addWidget(reset_btn)
        
        main_layout.addLayout(action_layout)
        main_layout.addStretch()
        
        self._filter_models("All")
        


    def _filter_models(self, category: str):
        self.model_combo.blockSignals(True)
        self.model_combo.clear()
        
        for name, info in SYNAPSE_MODELS.items():
            if category == "All" or info.get('category', 'basic') == category:
                self.model_combo.addItem(name)
        
        self.model_combo.blockSignals(False)
        if self.model_combo.count() > 0:
            self._on_model_changed(self.model_combo.currentText())
    


    def _on_model_changed(self, model_name: str):
        if not model_name or model_name not in SYNAPSE_MODELS:
            return
            
        info = SYNAPSE_MODELS[model_name]
        
        self.desc_label.setText(info.get('description', ''))
        
        if info.get('no_delay', False):
            self.delay_spin.setEnabled(False)
            self.delay_warning.setText("This synapse type does not use delay!")
        else:
            self.delay_spin.setEnabled(True)
            self.delay_warning.setText("")
        
        for widget in self.param_widgets.values():
            widget.deleteLater()
        self.param_widgets.clear()
        
        params = info.get('params', {})
        for param_name, param_info in params.items():
            widget = SynapseParamWidget(param_name, param_info)
            self.params_layout.addWidget(widget)
            self.param_widgets[param_name] = widget
        
        self.params_layout.addStretch()
    
    def _reset_to_defaults(self):
        model = self.model_combo.currentText()
        if model in SYNAPSE_MODELS:
            info = SYNAPSE_MODELS[model]
            for name, widget in self.param_widgets.items():
                if name in info.get('params', {}):
                    default = info['params'][name].get('default', 0)
                    widget.set_value(default)
        
        self.weight_spin.setValue(1.0)
        self.delay_spin.setValue(1.0)
        self.custom_name_input.clear()
    
    def _save_preset(self):
        name = self.custom_name_input.text().strip()
        if not name:
            QMessageBox.warning(self, "Name Required",
                              "Please enter a custom name to save as preset.")
            return
        
        self.custom_synapses[name] = self.get_synapse_config()
        QMessageBox.information(self, "Saved",
                               f"Synapse preset '{name}' saved!")
    
    def get_synapse_config(self) -> Dict[str, Any]:
        model = self.model_combo.currentText()
        info = SYNAPSE_MODELS.get(model, {})
        
        config = {
            'base_model': model,
            'weight': self.weight_spin.value(),
            'delay': self.delay_spin.value() if not info.get('no_delay') else None,
            'custom_name': self.custom_name_input.text().strip() or None,
            'no_delay': info.get('no_delay', False),
            'params': {}
        }
        
        for name, widget in self.param_widgets.items():
            config['params'][name] = widget.get_value()
        
        return config
    
    def set_synapse_config(self, config: Dict[str, Any]):
        model = config.get('base_model', 'static_synapse')
        
        if model in SYNAPSE_MODELS:
            cat = SYNAPSE_MODELS[model].get('category', 'All')
            self.category_combo.setCurrentText(cat)
        
        idx = self.model_combo.findText(model)
        if idx >= 0:
            self.model_combo.setCurrentIndex(idx)
        
        self.weight_spin.setValue(config.get('weight', 1.0))
        if config.get('delay') is not None:
            self.delay_spin.setValue(config['delay'])
        
        self.custom_name_input.setText(config.get('custom_name', '') or '')
        
        for name, value in config.get('params', {}).items():
            if name in self.param_widgets:
                self.param_widgets[name].set_value(value)
    
    def _emit_synapse(self):
        config = self.get_synapse_config()
        name = config['custom_name'] or config['base_model']
        self.synapseCreated.emit(name, config)
