"""FlowLayout: Layout mit automatischem Zeilenumbruch."""
from PyQt6.QtCore import QPoint, QRect, QSize, Qt
from PyQt6.QtWidgets import QLayout, QWidgetItem

class FlowLayout(QLayout):

    def __init__(self, parent=None, margin=5, spacing=5):
        super().__init__(parent)
        self._margin = margin
        self._spacing = spacing
        self._items = []
        self._cached_height = 0
        
        if parent is not None:
            self.setContentsMargins(margin, margin, margin, margin)
    
    def addItem(self, item):
        self._items.append(item)
        self.invalidate()
    
    def addWidget(self, widget):
        item = QWidgetItem(widget)
        self.addItem(item)
    
    def removeWidget(self, widget):
        for i, item in enumerate(self._items):
            if item.widget() == widget:
                self._items.pop(i)
                self.invalidate()
                break
    
    def count(self):
        return len(self._items)
    
    def itemAt(self, index):
        if 0 <= index < len(self._items):
            return self._items[index]
        return None
    
    def takeAt(self, index):
        if 0 <= index < len(self._items):
            item = self._items.pop(index)
            self.invalidate()
            return item
        return None
    
    def expandingDirections(self):
        return Qt.Orientation(0)
    
    def hasHeightForWidth(self):
        return True
    
    def heightForWidth(self, width):
        return self._do_layout(QRect(0, 0, width, 0), test_only=True)
    
    def setGeometry(self, rect):
        super().setGeometry(rect)
        self._do_layout(rect, test_only=False)
    
    def sizeHint(self):
        return self.minimumSize()
    
    def minimumSize(self):
        size = QSize(0, 0)
        for item in self._items:
            if item.widget() and item.widget().isVisible():
                size = size.expandedTo(item.minimumSize())
        margins = self.contentsMargins()
        size += QSize(margins.left() + margins.right(), margins.top() + margins.bottom())
        return size
    
    def _do_layout(self, rect, test_only):
        margins = self.contentsMargins()
        effective_rect = rect.adjusted(margins.left(), margins.top(), -margins.right(), -margins.bottom())
        
        x = effective_rect.x()
        y = effective_rect.y()
        line_height = 0
        row_start_x = effective_rect.x()
        
        for item in self._items:
            widget = item.widget()
            if widget is None or not widget.isVisible():
                continue
            
            item_size = item.sizeHint()
            if item_size.isEmpty():
                item_size = widget.sizeHint()
            if item_size.isEmpty():
                item_size = QSize(60, 70) 
            if x + item_size.width() > effective_rect.right() + 1 and x > row_start_x:
                x = row_start_x
                y = y + line_height + self._spacing
                line_height = 0
            
            if not test_only:
                item.setGeometry(QRect(QPoint(x, y), item_size))
            
            x = x + item_size.width() + self._spacing
            line_height = max(line_height, item_size.height())
        
        final_height = y + line_height - rect.y() + margins.bottom()
        self._cached_height = max(final_height, 10)
        
        if not test_only and self.parentWidget():
            parent = self.parentWidget()
            parent.setMinimumHeight(self._cached_height)
        
        return self._cached_height
