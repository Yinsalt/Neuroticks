"""Tabellarische Detailansicht eines Graphen."""
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QComboBox, QFrame, QHBoxLayout, QLabel, QScrollArea, QVBoxLayout, QWidget,
)

class GraphInfoWidget(QWidget):
    def __init__(self, graph_list):
        super().__init__()
        self.graph_list = graph_list
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        
        sel_layout = QHBoxLayout()
        lbl = QLabel("Select Graph:")
        lbl.setStyleSheet("color: white;")
        sel_layout.addWidget(lbl)
        
        self.combo = QComboBox()
        self.combo.setStyleSheet("background-color: #333; color: white; border: 1px solid #555;")
        self.combo.currentIndexChanged.connect(self.generate_report)
        sel_layout.addWidget(self.combo)
        sel_layout.addStretch()
        layout.addLayout(sel_layout)
        
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.scroll.setStyleSheet("background-color: #1e1e1e; border: none;")
        
        self.content_widget = QWidget()
        self.content_widget.setStyleSheet("background-color: #1e1e1e;")
        self.content_layout = QVBoxLayout(self.content_widget)
        self.content_layout.setSpacing(15)
        self.content_layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        
        self.scroll.setWidget(self.content_widget)
        layout.addWidget(self.scroll)
        
        self.refresh_combo()

    def refresh_combo(self):
        self.combo.blockSignals(True)
        self.combo.clear()
        for g in self.graph_list:
            name = getattr(g, 'graph_name', f"Graph {g.graph_id}")
            self.combo.addItem(f"{name} (ID: {g.graph_id})", g)
        self.combo.blockSignals(False)
        if self.combo.count() > 0:
            self.generate_report()

    def _create_section(self, title, color="#FF9800"):
        frame = QFrame()
        frame.setStyleSheet(f"background-color: #2b2b2b; border: 1px solid #444; border-radius: 5px;")
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(15, 10, 15, 15)
        layout.setSpacing(8)
        
        lbl_title = QLabel(title)
        lbl_title.setStyleSheet(f"color: {color}; font-weight: bold; font-size: 14px; border: none; padding-bottom: 5px;")
        layout.addWidget(lbl_title)
        
        return frame, layout

    def _add_info_row(self, layout, label, value, value_color="#00E5FF"):
        row = QHBoxLayout()
        lbl = QLabel(f"{label}:")
        lbl.setStyleSheet("color: #888; font-size: 12px; border: none;")
        lbl.setFixedWidth(180)
        
        val = QLabel(str(value))
        val.setStyleSheet(f"color: {value_color}; font-size: 12px; font-weight: bold; border: none;")
        val.setWordWrap(True)
        
        row.addWidget(lbl)
        row.addWidget(val, 1)
        layout.addLayout(row)

    def generate_report(self):
        while self.content_layout.count():
            item = self.content_layout.takeAt(0)
            if item.widget(): 
                item.widget().deleteLater()
        
        graph = self.combo.currentData()
        if not graph: 
            return

        total_nodes = len(graph.node_list)
        total_conns = sum(len(n.connections) for n in graph.node_list if hasattr(n, 'connections'))
        
        gen_frame, gen_layout = self._create_section("GENERAL INFORMATION", "#00E5FF")
        self._add_info_row(gen_layout, "Graph Name", getattr(graph, 'graph_name', 'Unknown'))
        self._add_info_row(gen_layout, "Graph ID", graph.graph_id)
        self._add_info_row(gen_layout, "Total Nodes", total_nodes)
        self._add_info_row(gen_layout, "Total Connections", total_conns)
        self.content_layout.addWidget(gen_frame)
        
        pop_frame, pop_layout = self._create_section("POPULATION DISTRIBUTION", "#E91E63")
        
        model_counts = {}
        total_neurons = 0
        for node in graph.node_list:
            if hasattr(node, 'neuron_models') and node.neuron_models:
                for model in node.neuron_models:
                    model_counts[model] = model_counts.get(model, 0) + 1
            if hasattr(node, 'positions') and node.positions:
                for pos_list in node.positions:
                    if pos_list is not None:
                        total_neurons += len(pos_list)
        
        self._add_info_row(pop_layout, "Total Neuron Count", total_neurons, "#4CAF50")
        self._add_info_row(pop_layout, "Unique Models", len(model_counts))
        
        if model_counts:
            lbl_dist = QLabel("Model Distribution:")
            lbl_dist.setStyleSheet("color: #888; font-size: 12px; border: none; margin-top: 5px;")
            pop_layout.addWidget(lbl_dist)
            
            for model, count in sorted(model_counts.items(), key=lambda x: -x[1]):
                row = QHBoxLayout()
                model_lbl = QLabel(f"  • {model}")
                model_lbl.setStyleSheet("color: #ccc; font-size: 11px; border: none;")
                count_lbl = QLabel(f"{count} population(s)")
                count_lbl.setStyleSheet("color: #FF9800; font-size: 11px; border: none;")
                row.addWidget(model_lbl)
                row.addStretch()
                row.addWidget(count_lbl)
                pop_layout.addLayout(row)
        
        self.content_layout.addWidget(pop_frame)
        
        dev_frame, dev_layout = self._create_section("RECORDING DEVICES", "#9C27B0")
        
        device_counts = {}
        total_devices = 0
        for node in graph.node_list:
            if hasattr(node, 'devices') and node.devices:
                for dev in node.devices:
                    model = dev.get('model', 'unknown')
                    device_counts[model] = device_counts.get(model, 0) + 1
                    total_devices += 1
        
        self._add_info_row(dev_layout, "Total Devices", total_devices, "#4CAF50")
        
        if device_counts:
            for dev_type, count in sorted(device_counts.items(), key=lambda x: -x[1]):
                row = QHBoxLayout()
                dev_lbl = QLabel(f"  • {dev_type}")
                dev_lbl.setStyleSheet("color: #ccc; font-size: 11px; border: none;")
                count_lbl = QLabel(f"{count}x")
                count_lbl.setStyleSheet("color: #FF9800; font-size: 11px; border: none;")
                row.addWidget(dev_lbl)
                row.addStretch()
                row.addWidget(count_lbl)
                dev_layout.addLayout(row)
        else:
            no_dev = QLabel("  No devices found")
            no_dev.setStyleSheet("color: #666; font-style: italic; font-size: 11px; border: none;")
            dev_layout.addWidget(no_dev)
        
        self.content_layout.addWidget(dev_frame)
        
        if total_nodes > 0:
            node_frame, node_layout = self._create_section("NODE DETAILS", "#FF9800")
            
            for node in graph.node_list:
                node_box = QFrame()
                node_box.setStyleSheet("background-color: #1e1e1e; border: 1px solid #333; border-radius: 3px; margin: 2px;")
                nb_layout = QVBoxLayout(node_box)
                nb_layout.setContentsMargins(10, 8, 10, 8)
                nb_layout.setSpacing(4)
                
                header = QLabel(f"Node {node.id}: {node.name}")
                header.setStyleSheet("color: #00E5FF; font-weight: bold; font-size: 12px; border: none;")
                nb_layout.addWidget(header)
                
                details = []
                
                if hasattr(node, 'center_of_mass'):
                    com = node.center_of_mass
                    details.append(f"Position: [{com[0]:.1f}, {com[1]:.1f}, {com[2]:.1f}]")
                
                pop_count = 0
                neuron_count = 0
                if hasattr(node, 'positions') and node.positions:
                    pop_count = len([p for p in node.positions if p is not None])
                    neuron_count = sum(len(p) for p in node.positions if p is not None)
                details.append(f"Populations: {pop_count}  |  Neurons: {neuron_count}")
                
                if hasattr(node, 'neuron_models') and node.neuron_models:
                    models_str = ", ".join(node.neuron_models[:3])
                    if len(node.neuron_models) > 3:
                        models_str += f" (+{len(node.neuron_models)-3} more)"
                    details.append(f"Models: {models_str}")
                
                if hasattr(node, 'connections'):
                    details.append(f"Connections: {len(node.connections)}")
                
                dev_count = len(node.devices) if hasattr(node, 'devices') else 0
                if dev_count > 0:
                    details.append(f"Devices: {dev_count}")
                
                for detail in details:
                    d_lbl = QLabel(detail)
                    d_lbl.setStyleSheet("color: #888; font-size: 11px; border: none; padding-left: 10px;")
                    nb_layout.addWidget(d_lbl)
                
                node_layout.addWidget(node_box)
            
            self.content_layout.addWidget(node_frame)
        
        hist_frame, hist_layout = self._create_section("SIMULATION HISTORY", "#4CAF50")
        
        total_runs = 0
        total_recordings = 0
        for node in graph.node_list:
            if hasattr(node, 'results') and 'history' in node.results:
                for run in node.results['history']:
                    total_runs += 1
                    if 'devices' in run:
                        total_recordings += len(run['devices'])
        
        self._add_info_row(hist_layout, "Simulation Runs", total_runs)
        self._add_info_row(hist_layout, "Total Recordings", total_recordings)
        
        self.content_layout.addWidget(hist_frame)
        
        self.content_layout.addStretch()
