"""GraphCreatorWidget: neuen Graphen samt Nodes und Populationen anlegen."""
import copy
import random

from PyQt6.QtCore import pyqtSignal, Qt
from PyQt6.QtGui import QAction
from PyQt6.QtWidgets import (
    QHBoxLayout, QLabel, QLineEdit, QMenu, QPushButton, QScrollArea, QSlider,
    QStackedWidget, QVBoxLayout, QWidget,
)

from neuron_toolbox import distributions, region_names
from neuroticks import state
from neuroticks.constants.node_tools import (
    extract_shape_params, node_parameters1, SHAPE_PARAM_DEFAULTS,
)
from neuroticks.gui.widgets.dialogs import PositionDialog
from neuroticks.gui.widgets.neuron_parameters import NeuronParametersWidget, NodeParametersWidget
from neuroticks.gui.widgets.polynomial_widgets import PolynomialManagerWidget
from neuroticks.state import graph_parameters
from neuroticks.utils.polynomials import generate_biased_polynomial

class GraphCreatorWidget(QWidget):
    graphCreated = pyqtSignal(int)
    def __init__(self):
        super().__init__()
        self.node_list = []
        self.current_node_idx = None
        self.current_pop_idx = None
        self._last_polynomial_node_idx = None
        self.init_ui()

        self.polynom_manager.polynomialsChanged.connect(self.on_polynomials_changed)


    def init_ui(self):
        import copy
        main_layout = QVBoxLayout(self)
        
        header_layout = QHBoxLayout()
        header_layout.addWidget(QLabel("Graph Name:"))
        self.graph_name_input = QLineEdit()
        
        self.graph_name_input.setText(f"Graph_{state.next_graph_id}")
        self.graph_name_input.setPlaceholderText("e.g., Visual Cortex")
        
        header_layout.addWidget(self.graph_name_input)
        main_layout.addLayout(header_layout)

        noise_layout = QHBoxLayout()
        noise_layout.setContentsMargins(0, 5, 0, 10)
        
        lbl_noise = QLabel("Polynomial Noise:")
        lbl_noise.setToolTip("Determines how much new nodes deviate from Identity (f(x)=x).")
        
        self.noise_slider = QSlider(Qt.Orientation.Horizontal)
        self.noise_slider.setRange(0, 200)
        self.noise_slider.setValue(int(state.POLYNOM_NOISE_LEVEL * 100))
        self.noise_slider.valueChanged.connect(self._update_noise_level)
        
        self.noise_value_lbl = QLabel(f"{state.POLYNOM_NOISE_LEVEL:.2f}")
        self.noise_value_lbl.setFixedWidth(40)
        self.noise_value_lbl.setStyleSheet("color: #00E5FF; font-weight: bold;")
        
        noise_layout.addWidget(lbl_noise)
        noise_layout.addWidget(self.noise_slider)
        noise_layout.addWidget(self.noise_value_lbl)
        
        main_layout.addLayout(noise_layout)
        
        content_layout = QHBoxLayout()
        
        node_col = QVBoxLayout()
        node_col.addWidget(QLabel("NODES", alignment=Qt.AlignmentFlag.AlignCenter))
        
        node_scroll = QScrollArea()
        node_scroll.setWidgetResizable(True)
        self.node_list_widget = QWidget()
        self.node_list_layout = QVBoxLayout(self.node_list_widget)
        node_scroll.setWidget(self.node_list_widget)
        node_col.addWidget(node_scroll)
        
        btns_layout = QHBoxLayout()
        
        self.btn_add_node = QPushButton("+ Add Node")
        self.btn_add_node.clicked.connect(self.add_node)
        self.btn_add_node.setStyleSheet("background-color: #2196F3; color: white; font-weight: bold;")
        
        self.btn_add_node.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.btn_add_node.customContextMenuRequested.connect(self.show_add_node_menu)
        self.btn_add_node.setToolTip("Left-Click: Add Empty Node\nRight-Click: Add Cortical Structure Preset")
        
        btns_layout.addWidget(self.btn_add_node)
        
        twin_btn = QPushButton("Twin")
        twin_btn.setToolTip("Clone selected node with same parameters at new position")
        twin_btn.clicked.connect(self.create_twin_node)
        twin_btn.setStyleSheet("background-color: #9C27B0; color: white; font-weight: bold;")
        btns_layout.addWidget(twin_btn)

        self.remove_node_btn = QPushButton("🗑️")
        self.remove_node_btn.setFixedWidth(40)
        self.remove_node_btn.setToolTip("Remove selected node")
        self.remove_node_btn.clicked.connect(self.remove_node)
        self.remove_node_btn.setEnabled(False)
        self.remove_node_btn.setStyleSheet("background-color: #F44336; color: white; font-weight: bold;")
        btns_layout.addWidget(self.remove_node_btn)
        
        node_col.addLayout(btns_layout)
        content_layout.addLayout(node_col, 2)
        
        pop_col = QVBoxLayout()
        pop_col.addWidget(QLabel("POPULATIONS", alignment=Qt.AlignmentFlag.AlignCenter))
        
        pop_scroll = QScrollArea()
        pop_scroll.setWidgetResizable(True)
        self.pop_list_widget = QWidget()
        self.pop_list_layout = QVBoxLayout(self.pop_list_widget)
        pop_scroll.setWidget(self.pop_list_widget)
        pop_col.addWidget(pop_scroll)
        
        pop_btns_layout = QHBoxLayout()
        
        self.add_pop_btn = QPushButton("+ Add Pop")
        self.add_pop_btn.clicked.connect(self.add_population)
        self.add_pop_btn.setEnabled(False)
        self.add_pop_btn.setStyleSheet("background-color: #2196F3; color: white; font-weight: bold;")
        pop_btns_layout.addWidget(self.add_pop_btn)
        
        self.remove_pop_btn = QPushButton("🗑️")
        self.remove_pop_btn.setFixedWidth(40)
        self.remove_pop_btn.setToolTip("Remove selected population")
        self.remove_pop_btn.clicked.connect(self.remove_population)
        self.remove_pop_btn.setEnabled(False)
        self.remove_pop_btn.setStyleSheet("background-color: #F44336; color: white; font-weight: bold;")
        pop_btns_layout.addWidget(self.remove_pop_btn)
        
        pop_col.addLayout(pop_btns_layout)
        
        content_layout.addLayout(pop_col, 2)
        
        editor_col = QVBoxLayout()
        self.editor_stack = QStackedWidget()
        placeholder = QLabel("← Select a Node or Population", alignment=Qt.AlignmentFlag.AlignCenter)
        placeholder.setStyleSheet("font-size: 14px; color: #999;")
        self.editor_stack.addWidget(placeholder)
        self.node_param_widget = NodeParametersWidget(copy.deepcopy(node_parameters1))
        self.node_param_widget.paramsChanged.connect(self.save_node_params)
        self.editor_stack.addWidget(self.node_param_widget)
        self.pop_param_widget = NeuronParametersWidget()
        self.pop_param_widget.parametersSaved.connect(self._on_population_params_saved)  # FIX: Connect signal
        self.editor_stack.addWidget(self.pop_param_widget)
        self.polynom_manager = PolynomialManagerWidget()
        self.editor_stack.addWidget(self.polynom_manager)
        editor_col.addWidget(self.editor_stack)
        content_layout.addLayout(editor_col, 6)
        
        main_layout.addLayout(content_layout)
        
        bottom_layout = QHBoxLayout()
        polynom_btn = QPushButton("Edit Polynomial Flow Field")
        polynom_btn.clicked.connect(self.open_polynomial_editor)
        polynom_btn.setMinimumHeight(50)
        polynom_btn.setStyleSheet("background-color: #FF9800; color: white; font-weight: bold;")
        bottom_layout.addWidget(polynom_btn)
        
        create_btn = QPushButton("CREATE GRAPH")
        create_btn.setMinimumHeight(60)
        create_btn.clicked.connect(self.create_graph)
        create_btn.setStyleSheet("background-color: #4CAF50; color: white; font-weight: bold; font-size: 16px;")
        bottom_layout.addWidget(create_btn)
        
        main_layout.addLayout(bottom_layout)


    def show_add_node_menu(self, pos):
        menu = QMenu(self)
        menu.setStyleSheet("QMenu { background-color: #2b2b2b; color: white; border: 1px solid #555; }")
        
        header = QAction("Add Structure Patch:", self)
        header.setEnabled(False)
        menu.addAction(header)
        menu.addSeparator()

        region_data = {r_key: {} for r_key in region_names.values()}
        for model, region_map in distributions.items():
            for r_key, prob in region_map.items():
                if prob > 0: region_data[r_key][model] = prob

        for display_name, r_key in region_names.items():
            if r_key not in region_data or not region_data[r_key]: continue
            
            models_probs = region_data[r_key]
            model_list = list(models_probs.keys())
            prob_list = list(models_probs.values())
            
            total = sum(prob_list)
            if total > 0: prob_list = [p/total for p in prob_list]

            action = QAction(display_name, self)
            action.triggered.connect(lambda checked, n=display_name, m=model_list, p=prob_list:
                                   self.add_structure_node(n, m, p))
            menu.addAction(action)

        menu.exec(self.btn_add_node.mapToGlobal(pos))

    def add_structure_node(self, name, models, probs):
        
        node_idx = len(self.node_list)
        node_btn = QPushButton(f"Node {node_idx + 1}")
        node_btn.setMinimumHeight(50)
        node_btn.clicked.connect(lambda checked=False, idx=node_idx: self.select_node(idx))
        self.node_list_layout.addWidget(node_btn)
        
        import copy
        node_params = copy.deepcopy(node_parameters1)
        node_params['id'] = node_idx
        node_params['m'] = [0.0, 0.0, 0.0]
        node_params['center_of_mass'] = [0.0, 0.0, 0.0]
        node_params['displacement'] = [0.0, 0.0, 0.0]
        
        safe_name = name.replace(" ", "_").replace("/", "-")
        node_params['name'] = f"{safe_name}_{node_idx}"
        node_params['grid_size'] = [10, 10, 10]
        node_params['probability_vector'] = probs
        node_params['sparsity_factor'] = 0.85
        
        node_btn.setText(f"Node {node_idx + 1}: {node_params['name']}")
        
        populations = []
        for i, model in enumerate(models):
            default_polynomials = {
                'x': generate_biased_polynomial(axis_idx=0, max_degree=2),
                'y': generate_biased_polynomial(axis_idx=1, max_degree=2),
                'z': generate_biased_polynomial(axis_idx=2, max_degree=2)
            }
            populations.append({
                'model': model,
                'params': {},
                'polynomials': default_polynomials
            })
            
        self.node_list.append({
            'params': node_params,
            'populations': populations,
            'button': node_btn,
            'original_node': None
        })
        
        self.select_node(node_idx)
        print(f"Added Structure Node: {name}")

    def _update_noise_level(self, value):
        state.POLYNOM_NOISE_LEVEL = value / 100.0
        self.noise_value_lbl.setText(f"{state.POLYNOM_NOISE_LEVEL:.2f}")


    def create_twin_node(self):
        if self.current_node_idx is None:
            print("Please select a node to clone first.")
            return
            
        self.save_node_params(self.node_param_widget.get_current_params())
        self.save_current_population_params()
        
        source_node = self.node_list[self.current_node_idx]
        
        clean_populations = []
        if 'populations' in source_node:
            for pop in source_node['populations']:
                clean_pop = {
                    'model': pop.get('model'),
                    'params': pop.get('params', {}),
                    'polynomials': pop.get('polynomials', {})
                }
                # shape_params (Tool-Geometrie pro Pop) mitkopieren
                if 'shape_params' in pop:
                    clean_pop['shape_params'] = dict(pop['shape_params'])
                clean_populations.append(clean_pop)

        data_to_copy = {
            'params': source_node['params'],
            'populations': clean_populations
        }
        
        import copy
        new_node_data = copy.deepcopy(data_to_copy)
        
        current_pos = source_node['params'].get('center_of_mass', [0,0,0])
        old_id = source_node['params'].get('id')
        
        dlg = PositionDialog(current_pos, self)
        if dlg.exec():
            new_pos = dlg.get_position()
            
            import copy
            import time
            
            
            new_node_data['original_node'] = None
            
            new_idx = len(self.node_list)
            new_node_data['params']['id'] = new_idx
            new_node_data['params']['name'] = f"{source_node['params'].get('name', 'Node')}_Twin"
            
            new_node_data['params']['m'] = list(new_pos)
            new_node_data['params']['center_of_mass'] = list(new_pos)
            new_node_data['params']['old_center_of_mass'] = list(new_pos)
            
            source_conns = source_node['params'].get('connections', [])
            twin_conns = []
            
            for i, conn in enumerate(source_conns):
                src_id = conn['source'].get('node_id')
                tgt_id = conn['target'].get('node_id')
                
                if src_id == old_id and tgt_id == old_id:
                    new_conn = copy.deepcopy(conn)
                    
                    new_conn['source']['node_id'] = new_idx
                    new_conn['target']['node_id'] = new_idx
                    
                    new_conn['id'] = int(time.time() * 10000) + i
                    new_conn['name'] = f"{conn.get('name', 'conn')}_Twin"
                    
                    twin_conns.append(new_conn)
            
            new_node_data['params']['connections'] = twin_conns
            
            node_btn = QPushButton(f"Node {new_idx + 1}: {new_node_data['params']['name']}")
            node_btn.setMinimumHeight(50)
            node_btn.clicked.connect(lambda checked=False, idx=new_idx: self.select_node(idx))
            self.node_list_layout.addWidget(node_btn)
            
            new_node_data['button'] = node_btn
            
            self.node_list.append(new_node_data)
            self.select_node(new_idx)
            
            print(f"Twin created at {new_pos} with {len(twin_conns)} internal connections.")


    def add_population(self):
        if self.current_node_idx is None:
            return
        
        self.save_current_population_params()
        
        node = self.node_list[self.current_node_idx]
        pop_idx = len(node['populations'])
        tool_type = node['params'].get('tool_type', 'custom')
        
        default_polynomials = {
            'x': generate_biased_polynomial(axis_idx=0, max_degree=2),
            'y': generate_biased_polynomial(axis_idx=1, max_degree=2),
            'z': generate_biased_polynomial(axis_idx=2, max_degree=2)
        }
        
        # Bei Tool-Types: shape_params aus aktuellem Tool-Panel snapshotten,
        # bzw. von Defaults nehmen. Dadurch erbt die neue Pop sinnvolle Werte.
        new_pop = {
            'model': 'iaf_psc_alpha',
            'params': {},
            'polynomials': default_polynomials
        }
        if tool_type != 'custom':
            current_panel = self.node_param_widget.get_current_params()
            shape_params = extract_shape_params(tool_type, current_panel)
            # Falls gar nichts im Panel: pure Defaults
            if not shape_params:
                shape_params = dict(SHAPE_PARAM_DEFAULTS.get(tool_type, {}))
            new_pop['shape_params'] = shape_params
            # Modell aus Tool-Panel übernehmen falls gesetzt
            tool_model = current_panel.get('tool_neuron_model')
            if tool_model:
                new_pop['model'] = tool_model
        
        node['populations'].append(new_pop)
        
        num_pops = len(node['populations'])
        self.node_param_widget.set_population_count(num_pops)
        node['params']['probability_vector'] = [1.0/num_pops] * num_pops
        self.node_param_widget.load_data(node['params'])
        
        self.update_population_list()
        self.select_population(pop_idx)
    
    def open_polynomial_editor(self):
        if self.current_node_idx is None:
            print("Please select a node first!")
            return
        
        node = self.node_list[self.current_node_idx]
        if not node['populations']:
            print("Please add populations first!")
            return
        
        self.save_current_population_params()
        
        if hasattr(self, '_last_polynomial_node_idx') and self._last_polynomial_node_idx is not None:
            last_node = self.node_list[self._last_polynomial_node_idx]
            all_polynomials = self.polynom_manager.get_all_polynomials()
            for i, poly_dict in enumerate(all_polynomials):
                if i < len(last_node['populations']):
                    last_node['populations'][i]['polynomials'] = poly_dict
        
        self._last_polynomial_node_idx = self.current_node_idx
        
        self.polynom_manager.set_populations(node['populations'], self.current_node_idx)
        self.editor_stack.setCurrentIndex(3)
    
    def on_polynomials_changed(self, node_idx, polynomials):
        if node_idx >= len(self.node_list):
            return
        
        node = self.node_list[node_idx]
        
        for i, poly_dict in enumerate(polynomials):
            if i < len(node['populations']):
                node['populations'][i]['polynomials'] = poly_dict
        
        print(f"Updated polynomials for Node {node_idx}")
    
    def create_graph(self):
        global graph_parameters
        
        if not self.graph_name_input.text():
            print("ERROR: Graph name required!")
            return
        
        if not self.node_list:
            print("ERROR: Add at least one node!")
            return
        
        for i, node in enumerate(self.node_list):
            tool_type = node['params'].get('tool_type', 'custom')
            
            if tool_type == 'custom' and not node['populations']:
                print(f"ERROR: Node {i+1} (Custom) has no populations! Please add populations.")
                return
            
            if node['populations']:
                prob_vec = node['params'].get('probability_vector', [])
                total_prob = sum(prob_vec)
                if abs(total_prob - 1.0) > 0.01:
                    print(f"ERROR: Node {i+1} probability vector sums to {total_prob:.2f}, must be 1.0!")
                    return
        
        if self.current_node_idx is not None:
            current_params = self.node_param_widget.get_current_params()
            if 'center_of_mass' in current_params:
                current_params['m'] = current_params['center_of_mass'].copy()
            self.node_list[self.current_node_idx]['params'] = current_params
        
        self.save_current_population_params()
        
        if hasattr(self, '_last_polynomial_node_idx') and self._last_polynomial_node_idx is not None:
            last_node = self.node_list[self._last_polynomial_node_idx]
            all_polynomials = self.polynom_manager.get_all_polynomials()
            for i, poly_dict in enumerate(all_polynomials):
                if i < len(last_node['populations']):
                    last_node['populations'][i]['polynomials'] = poly_dict
        
        graph_id = state.next_graph_id
        state.next_graph_id += 1
        
        converted_nodes = []
        
        for node_idx, node in enumerate(self.node_list):
            tool_type = node['params'].get('tool_type', 'custom')
            populations = node['populations']
            
            if tool_type != 'custom' and not populations:
                print(f"Auto-configuring {tool_type} node structure...")
                
                selected_model = node['params'].get('tool_neuron_model', 'iaf_psc_alpha')
                neuron_models = [selected_model]
                
                types = [0]
                encoded_polynoms_per_type = [[]]
                prob_vec = [1.0]
                pop_nest_params = [{}]
                # Shape-Params aus den Node-Globalen Werten ableiten
                shape_params_per_pop = [extract_shape_params(tool_type, node['params'])]
            elif tool_type in ('Blob', 'Cone', 'CCW', 'Grid'):
                # WICHTIG: Pro Population eigenes neuron_model erlauben.
                # Falls eine Population kein gültiges Modell hat, fällt sie auf
                # den globalen tool_neuron_model-Default zurück.
                fallback_model = node['params'].get('tool_neuron_model', 'iaf_psc_alpha')
                if populations:
                    neuron_models = [pop.get('model') or fallback_model
                                     for pop in populations]
                else:
                    neuron_models = [fallback_model]
                
                types = list(range(len(populations))) if populations else [0]
                
                encoded_polynoms_per_type = []
                for pop in populations:
                    poly_dict = pop.get('polynomials', None)
                    if poly_dict and all(k in poly_dict for k in ['x', 'y', 'z']):
                        encoded_polynoms_per_type.append([poly_dict['x'], poly_dict['y'], poly_dict['z']])
                    else:
                        encoded_polynoms_per_type.append([])
                if not encoded_polynoms_per_type:
                    encoded_polynoms_per_type = [[]]
                
                num_pops = len(neuron_models)
                prob_vec = node['params'].get('probability_vector', [])
                if not prob_vec or len(prob_vec) != num_pops:
                    prob_vec = [1.0 / num_pops] * num_pops if num_pops > 0 else [1.0]
                
                # Pro-Pop NEST-Params (ohne den frühreren "model_changed reset",
                # der per-Pop-Params killte wenn ein anderer Mix vorlag)
                pop_nest_params = ([pop.get('params', {}) for pop in populations]
                                    if populations else [{}])
                
                # Pro-Pop SHAPE-Params: Wenn pop['shape_params'] fehlt,
                # aus den Node-Globalen Werten ableiten (Backward-Compat).
                shape_params_per_pop = []
                for pop in populations:
                    sp = pop.get('shape_params')
                    if not sp:
                        sp = extract_shape_params(tool_type, node['params'])
                    shape_params_per_pop.append(dict(sp))
                if not shape_params_per_pop:
                    shape_params_per_pop = [extract_shape_params(tool_type, node['params'])]
            else:
                neuron_models = [pop['model'] for pop in populations]
                types = list(range(len(populations)))
                
                encoded_polynoms_per_type = []
                for pop in populations:
                    poly_dict = pop.get('polynomials', None)
                    if poly_dict and all(k in poly_dict for k in ['x', 'y', 'z']):
                        encoded_polynoms_per_type.append([poly_dict['x'], poly_dict['y'], poly_dict['z']])
                    else:
                        encoded_polynoms_per_type.append([])
                
                num_pops = len(populations)
                prob_vec = node['params'].get('probability_vector', [])
                if not prob_vec or len(prob_vec) != num_pops:
                    prob_vec = [1.0 / num_pops] * num_pops if num_pops > 0 else []
                
                if num_pops > 0 and abs(sum(prob_vec) - 1.0) > 0.01:
                    s = sum(prob_vec)
                    prob_vec = [p/s for p in prob_vec] if s > 0 else [1.0/num_pops]*num_pops
                
                pop_nest_params = [pop.get('params', {}) for pop in populations]
                shape_params_per_pop = [{} for _ in populations]

            node_params = {
                'grid_size': node['params'].get('grid_size', [10, 10, 10]),
                'm': node['params'].get('center_of_mass', [0.0, 0.0, 0.0]),
                'center_of_mass': node['params'].get('center_of_mass', [0.0, 0.0, 0.0]),
                'displacement': node['params'].get('displacement', [0.0, 0.0, 0.0]),
                'displacement_factor': node['params'].get('displacement_factor', 1.0),
                'rot_theta': node['params'].get('rot_theta', 0.0),
                'rot_phi': node['params'].get('rot_phi', 0.0),
                'auto_spike_recorder': node['params'].get('auto_spike_recorder', False),
                'auto_multimeter': node['params'].get('auto_multimeter', False),
                'tool_type': tool_type,
                # Diese Top-Level-Tool-Werte bleiben als FALLBACK / Default für den
                # Fall dass shape_params_per_pop fehlt (Backward-Kompat).
                'n_neurons': node['params'].get('n_neurons', 100),
                'radius': node['params'].get('radius', 5.0),
                'radius_top': node['params'].get('radius_top', 1.0),
                'radius_bottom': node['params'].get('radius_bottom', 5.0),
                'height': node['params'].get('height', 10.0),
                'grid_side_length': node['params'].get('grid_side_length', 10),
                
                'k': node['params'].get('k', 10.0),
                'bidirectional': node['params'].get('bidirectional', False),
                
                # CCW/Cone synaptic Defaults (Top-Level Fallback)
                'ccw_syn_config': node['params'].get('ccw_syn_config',
                                                     {'synapse_model': 'static_synapse', 'extra_params': {}}),
                # Backward-Compat: alter scalar key bleibt für ältere Save-States
                'ccw_syn_model': node['params'].get('ccw_syn_model', 'static_synapse'),
                'ccw_weight_ex': node['params'].get('ccw_weight_ex', 30.0),
                'ccw_delay_ex': node['params'].get('ccw_delay_ex', 1.0),
                'weight_in_factor': node['params'].get('weight_in_factor', 1.0),
                
                # CCW/Cone connection-rule Defaults (für non-similarity Modi)
                'conn_rule': node['params'].get('conn_rule', 'similarity'),
                'conn_p': node['params'].get('conn_p', 1.0),
                'conn_indegree': node['params'].get('conn_indegree', 10),
                'conn_outdegree': node['params'].get('conn_outdegree', 10),
                
                # Blob synaptic Defaults
                'blob_p_ex': node['params'].get('blob_p_ex', 0.8),
                'blob_p_in': node['params'].get('blob_p_in', 0.2),
                'blob_weight_ex': node['params'].get('blob_weight_ex', 2.0),
                'blob_weight_in': node['params'].get('blob_weight_in', -10.0),
                'blob_delay_ex': node['params'].get('blob_delay_ex', 1.0),
                'blob_delay_in': node['params'].get('blob_delay_in', 1.0),
                'blob_syn_config_ex': node['params'].get('blob_syn_config_ex',
                                                          {'synapse_model': 'static_synapse', 'extra_params': {}}),
                'blob_syn_config_in': node['params'].get('blob_syn_config_in',
                                                          {'synapse_model': 'static_synapse', 'extra_params': {}}),
                # Backward-Compat
                'blob_syn_model_ex': node['params'].get('blob_syn_model_ex', 'static_synapse'),
                'blob_syn_model_in': node['params'].get('blob_syn_model_in', 'static_synapse'),
                'blob_allow_autapses': node['params'].get('blob_allow_autapses', False),
                
                'stretch_x': node['params'].get('stretch_x', 1.0),
                'stretch_y': node['params'].get('stretch_y', 1.0),
                'stretch_z': node['params'].get('stretch_z', 1.0),
                'transform_matrix': node['params'].get('transform_matrix', [[1, 0, 0], [0, 1, 0], [0, 0, 1]]),
                
                'dt': node['params'].get('dt', 0.01),
                'old': node['params'].get('old', True),
                'num_steps': node['params'].get('num_steps', 8),
                'sparse_holes': node['params'].get('sparse_holes', 0),
                'sparsity_factor': node['params'].get('sparsity_factor', 0.9),
                
                'name': node['params'].get('name', f'Node_{node_idx}'),
                'id': node_idx,
                'graph_id': graph_id,
                'neuron_models': neuron_models,
                'types': types,
                'probability_vector': prob_vec,
                'distribution': prob_vec,
                'encoded_polynoms_per_type': encoded_polynoms_per_type,
                'population_nest_params': pop_nest_params,
                'shape_params_per_pop': shape_params_per_pop,  # NEU: pro-Pop Tool-Geometrie
                'polynom_max_power': node['params'].get('polynom_max_power', 5),
                'conn_prob': [],
                'field': None,
                'coefficients': None,
                'connections': []
            }
            
            node['populations'] = populations.copy()
            converted_nodes.append(node_params)
        
        graph_parameters[graph_id] = {
            'graph_name': self.graph_name_input.text(),
            'graph_id': graph_id,
            'color': self.generate_random_color(),
            'parameter_list': converted_nodes,
            'max_nodes': len(converted_nodes)
        }
        
        self.graphCreated.emit(graph_id)
        self.reset()
        
    def add_node(self):
        node_idx = len(self.node_list)
        node_btn = QPushButton(f"Node {node_idx + 1}")
        node_btn.setMinimumHeight(50)
        node_btn.clicked.connect(lambda checked=False, idx=node_idx: self.select_node(idx))
        self.node_list_layout.addWidget(node_btn)
        
        node_params = copy.deepcopy(node_parameters1)
        
        node_params['id'] = node_idx
        node_params['name'] = f"Node_{node_idx}"
        node_params['probability_vector'] = []
        
        node_params['m'] = [0.0, 0.0, 0.0]
        node_params['center_of_mass'] = [0.0, 0.0, 0.0]
        node_params['displacement'] = [0.0, 0.0, 0.0]
        
        self.node_list.append({
            'params': node_params,
            'populations': [],
            'button': node_btn
        })
        
        self.select_node(node_idx)

    def remove_population(self):
        if self.current_node_idx is None or self.current_pop_idx is None:
            return
            
        node = self.node_list[self.current_node_idx]
        
        # User-Wunsch: letzte Pop darf gelöscht werden, kein Auto-Anlegen.
        # Knoten bleibt dann ohne Pop, User muss explizit Add Pop klicken.
        
        prob_vec = node['params'].get('probability_vector', [])
        deleted_prob = 0.0
        if len(prob_vec) > self.current_pop_idx:
            deleted_prob = prob_vec.pop(self.current_pop_idx)
        
        if prob_vec and deleted_prob > 0:
            add_each = deleted_prob / len(prob_vec)
            node['params']['probability_vector'] = [p + add_each for p in prob_vec]
        
        node['populations'].pop(self.current_pop_idx)
        
        self.update_population_list()
        
        num_pops = len(node['populations'])
        
        self.node_param_widget.set_population_count(num_pops)
        self.node_param_widget.load_data(node['params'])
        
        if num_pops > 0:
            new_idx = max(0, self.current_pop_idx - 1)
            self.select_population(new_idx)
        else:
            self.current_pop_idx = None
            self.remove_pop_btn.setEnabled(False)
            self.editor_stack.setCurrentIndex(1)
    def remove_node(self):
        if self.current_node_idx is None:
            return

        node_data = self.node_list.pop(self.current_node_idx)
        
        if 'button' in node_data:
            node_data['button'].deleteLater()

        for i, node in enumerate(self.node_list):
            name = node['params'].get('name', 'Node')
            node['button'].setText(f"Node {i + 1}: {name}")
            
            node['params']['id'] = i
            
            try: node['button'].clicked.disconnect()  # May not be connected
            except RuntimeError: pass  # No connections
            node['button'].clicked.connect(lambda checked=False, idx=i: self.select_node(idx))

        if self.node_list:
            new_idx = max(0, self.current_node_idx - 1)
            self.select_node(new_idx)
        else:
            self.current_node_idx = None
            self.editor_stack.setCurrentIndex(0)
            self.remove_node_btn.setEnabled(False)
            
            while self.pop_list_layout.count():
                item = self.pop_list_layout.takeAt(0)
                widget = item.widget()
                if widget is not None:
                    widget.setParent(None)
                    widget.deleteLater()
    def select_node(self, node_idx):
        if node_idx < 0 or node_idx >= len(self.node_list): return
        
        self.save_current_population_params()
        self.current_node_idx = node_idx
        self.current_pop_idx = None
        
        self.remove_node_btn.setEnabled(True)
        self.add_pop_btn.setEnabled(True)
        self.remove_pop_btn.setEnabled(False)
        
        for i, node in enumerate(self.node_list):
            node['button'].setStyleSheet("background-color: #2196F3; color: white;" if i == node_idx else "")
        self.remove_node_btn.setEnabled(len(self.node_list) > 1)

        node_data = self.node_list[node_idx]
        tool_type = node_data['params'].get('tool_type', 'custom')

        # Auto-add EINE Default-Pop nur beim allerersten Anwählen (UX-Hilfe).
        # Für Tool-Types: shape_params aus den Node-Defaults snapshotten,
        # damit die erste Pop sinnvolle Werte hat.
        if tool_type != 'custom' and not node_data['populations']:
            model = node_data['params'].get('tool_neuron_model', 'iaf_psc_alpha')
            shape_params = extract_shape_params(tool_type, node_data['params'])
            node_data['populations'].append({
                'model': model,
                'params': {},
                'shape_params': shape_params,
                'polynomials': {'x': [], 'y': [], 'z': []}
            })
            # WICHTIG: prob_vec mit der neuen Pop synchronisieren, sonst
            # bleibt es [] und die Build-Validierung schlägt fehl.
            node_data['params']['probability_vector'] = [1.0]

        num_pops = len(node_data['populations'])
        self.node_param_widget.set_population_count(num_pops)
        
        # Tool-Panel: bei Tool-Types die Shape-Params der ersten Pop einmergen,
        # damit der User die pop-spezifischen Werte sieht (statt veralteter
        # Node-Globaler-Werte).
        load_params = dict(node_data['params'])
        if tool_type != 'custom' and num_pops > 0:
            first_pop = node_data['populations'][0]
            shape = first_pop.get('shape_params', {})
            if not shape:
                shape = dict(SHAPE_PARAM_DEFAULTS.get(tool_type, {}))
                first_pop['shape_params'] = shape
            load_params.update(shape)
            load_params['tool_neuron_model'] = first_pop.get(
                'model', load_params.get('tool_neuron_model'))
        
        self.node_param_widget.load_data(load_params)
        self.editor_stack.setCurrentIndex(1)
        
        self.update_population_list()
        
        # FIX: Add Pop ist jetzt für ALLE Tool-Typen erlaubt (Multi-Pop)
        self.add_pop_btn.setEnabled(True)

    def load_structure_preset(self, name, models, probs, grid_size=[10,10,10]):
        print(f"Loading Structure Preset: {name}")
        
        self.reset()
        
        safe_name = name.replace(" ", "_").replace("/", "-")
        self.graph_name_input.setText(f"Graph_{safe_name}")
        
        self.add_node()
        
        node = self.node_list[0]
        
        node['params']['name'] = f"{safe_name}_Node"
        node['params']['grid_size'] = grid_size
        node['params']['probability_vector'] = probs
        
        node['params']['sparsity_factor'] = 0.85
        node['params']['dt'] = 0.01
        
        node['populations'] = []
        
        for i, model in enumerate(models):
            default_polynomials = {
                'x': generate_biased_polynomial(axis_idx=0, max_degree=2),
                'y': generate_biased_polynomial(axis_idx=1, max_degree=2),
                'z': generate_biased_polynomial(axis_idx=2, max_degree=2)
            }
            
            node['populations'].append({
                'model': model,
                'params': {},
                'polynomials': default_polynomials
            })
            
        self.select_node(0)
    
    
    def save_node_params(self, params):
        if self.current_node_idx is not None:
            if 'center_of_mass' in params:
                params['m'] = params['center_of_mass'].copy()
            
            node = self.node_list[self.current_node_idx]
            num_pops = len(node['populations'])
            if num_pops > 0:
                # Robuste prob_vec Behandlung: bei Mismatch oder Null-Summe
                # gleichmäßig re-initialisieren (statt mit 0.0 padden).
                current_probs = params.get('probability_vector', [])
                needs_reset = (
                    not current_probs
                    or len(current_probs) != num_pops
                    or sum(current_probs) <= 1e-9
                )
                if needs_reset:
                    current_probs = [1.0 / num_pops] * num_pops
                params['probability_vector'] = current_probs
                
                self.node_param_widget.auto_save = False
                self.node_param_widget.load_data(params)
                self.node_param_widget.auto_save = True
            
            # Bei Tool-Types: Shape-Params auf die aktuell gewählte Pop spiegeln
            # (oder Pop 0, wenn keine explizit gewählt). Tool-Type-Wechsel auf
            # 'custom' überspringen.
            tool_type = params.get('tool_type', 'custom')
            if tool_type != 'custom' and num_pops > 0:
                target_pop_idx = self.current_pop_idx if self.current_pop_idx is not None else 0
                if 0 <= target_pop_idx < num_pops:
                    target_pop = node['populations'][target_pop_idx]
                    target_pop['shape_params'] = extract_shape_params(tool_type, params)
                    # Modell aus Tool-Panel auch übernehmen
                    tm = params.get('tool_neuron_model')
                    if tm:
                        target_pop['model'] = tm
                        if 'button' in target_pop:
                            target_pop['button'].setText(
                                f"Pop {target_pop_idx+1}: {tm}")
            
            self.node_list[self.current_node_idx]['params'] = params
    
    
    def update_population_list(self):
        while self.pop_list_layout.count():
            item = self.pop_list_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.setParent(None)
                widget.deleteLater()
        
        if self.current_node_idx is None:
            return
            
        node = self.node_list[self.current_node_idx]
        for i, pop in enumerate(node['populations']):
            pop_btn = QPushButton(f"Pop {i+1}: {pop['model']}")
            pop_btn.setMinimumHeight(40)
            pop_btn.clicked.connect(lambda checked, idx=i: self.select_population(idx))
            self.pop_list_layout.addWidget(pop_btn)
            pop['button'] = pop_btn
    
    
    def select_population(self, pop_idx):
        self.save_current_population_params()
        
        self.current_pop_idx = pop_idx
        self.remove_pop_btn.setEnabled(True)
        node = self.node_list[self.current_node_idx]
        for i, pop in enumerate(node['populations']):
            if i == pop_idx:
                pop['button'].setStyleSheet("background-color: #2196F3; color: white;")
            else:
                pop['button'].setStyleSheet("")
        
        pop = node['populations'][pop_idx]
        
        # Tool-Panel im NodeParametersWidget mit den Shape-Params dieser Pop
        # syncen, damit beim Zurückwechseln zum Node-Editor die richtigen
        # Werte angezeigt werden. (Tool-Panel selbst ist gerade nicht sichtbar.)
        tool_type = node['params'].get('tool_type', 'custom')
        if tool_type != 'custom':
            merged = dict(node['params'])
            shape = pop.get('shape_params', {})
            if not shape:
                shape = dict(SHAPE_PARAM_DEFAULTS.get(tool_type, {}))
                pop['shape_params'] = shape
            merged.update(shape)
            # Modell ins Tool-Panel
            merged['tool_neuron_model'] = pop.get('model', merged.get('tool_neuron_model'))
            self.node_param_widget.auto_save = False
            self.node_param_widget.load_data(merged)
            self.node_param_widget.auto_save = True
        
        # KRITISCH: NEST-Param-Widget IMMER frisch aus dem Modell rebuilden.
        # Vorher: bei leeren pop['params'] blieben Geist-Werte vom letzten Pop
        # in der UI stehen und wurden beim "Save Parameters"-Click auf den
        # neuen Pop kopiert. Jetzt: blockSignals + manueller on_model_changed
        # garantiert clear_params + Default-Werte aus functional_models.json,
        # SYNCHRON (kein QTimer mehr - das war die zweite Race).
        self.pop_param_widget.blockSignals(True)
        self.pop_param_widget.model_combo.blockSignals(True)
        self.pop_param_widget.model_combo.setCurrentText(pop['model'])
        self.pop_param_widget.model_combo.blockSignals(False)
        self.pop_param_widget.on_model_changed(pop['model'])
        # Synchron load_params, NICHT via QTimer (race-prone)
        if pop.get('params'):
            self.pop_param_widget.load_params(pop['params'])
        self.pop_param_widget.blockSignals(False)
        
        self.editor_stack.setCurrentIndex(2)
    
    def save_current_population_params(self):
        if self.current_node_idx is not None and self.current_pop_idx is not None:
            if self.current_node_idx >= len(self.node_list):
                print(f"[DEBUG] Skipping save_current_population_params - invalid index {self.current_node_idx}")
                return
            
            node = self.node_list[self.current_node_idx]
            
            if self.current_pop_idx >= len(node['populations']):
                print(f"[DEBUG] Skipping save_current_population_params - invalid pop index {self.current_pop_idx}")
                return
            
            pop = node['populations'][self.current_pop_idx]
            
            if self.pop_param_widget.current_model:
                pop['model'] = self.pop_param_widget.current_model
                pop['params'] = {k: w.get_value() for k, w in self.pop_param_widget.parameter_widgets.items()}
                
                if 'button' in pop:
                    pop['button'].setText(f"Pop {self.current_pop_idx+1}: {pop['model']}")

    def _on_population_params_saved(self, model_name, params):
        """FIX: Handler for when 'Save Parameters' button is clicked in NeuronParametersWidget"""
        self.save_current_population_params()
    
    def generate_random_color(self):
        r = random.randint(0, 255)
        g = random.randint(0, 255)
        b = random.randint(0, 255)
        return f"0x{r:02x}{g:02x}{b:02x}"
    
    def reset(self):
        self.current_node_idx = None
        self.current_pop_idx = None
        
        self.node_list.clear()
        
        while self.node_list_layout.count():
            item = self.node_list_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.setParent(None)
                widget.deleteLater()
        
        while self.pop_list_layout.count():
            item = self.pop_list_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.setParent(None)
                widget.deleteLater()
        
        self.editor_stack.setCurrentIndex(0)
        self.add_pop_btn.setEnabled(False)
        
        custom_idx = self.node_param_widget.tool_combo.findData("custom")
        if custom_idx >= 0:
            self.node_param_widget.tool_combo.setCurrentIndex(custom_idx)
        
        next_name = f"Graph_{state.next_graph_id}"
        
        self.graph_name_input.setText(next_name)
        self.graph_name_input.setCursorPosition(len(next_name))
