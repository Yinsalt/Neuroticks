"""Editoren für Neuronenmodell- und Node-Parameter."""
import json

from PyQt6.QtCore import pyqtSignal
from PyQt6.QtWidgets import (
    QCheckBox, QComboBox, QDoubleSpinBox, QFrame, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QScrollArea, QSpinBox, QStackedWidget, QVBoxLayout, QWidget,
)

from neuron_toolbox import neuron_colors
from neuroticks import state
from neuroticks.constants.node_tools import NODE_TOOLS, TOOL_PARAM_KEYS
from neuroticks.gui.widgets.synapse_widgets import InlineSynapseConfig

class NeuronParametersWidget(QWidget):
    # FIX: Add signal to notify parent when parameters are saved
    parametersSaved = pyqtSignal(str, dict)  # model_name, params_dict
    
    def __init__(self):
        super().__init__()
        self.all_models = {}
        self.current_model = None
        self.parameter_widgets = {}
        self.load_json()
        self.setup_ui()

    def load_json(self):
        try:
            with open("functional_models.json") as f:
                self.all_models = json.load(f)
            
            
            for model in self.all_models:
                if model not in neuron_colors:
                    neuron_colors[model] = "#FFFFFF"
            
            raw = list(self.all_models.keys())
            state.successful_neuron_models = sorted(raw, key=lambda x: x.lower())
            
            priority = ['iaf_psc_alpha']
            for p in reversed(priority):
                if p in state.successful_neuron_models:
                    state.successful_neuron_models.remove(p)
                    state.successful_neuron_models.insert(0, p)

        except FileNotFoundError:
            print("Warning: functional_models.json not found")
            self.all_models = {}

    def setup_ui(self):
        layout = QVBoxLayout()
        self.setLayout(layout)

        model_layout = QHBoxLayout()
        model_label = QLabel("Neuron Model:")
        self.model_combo = QComboBox()
        self.model_combo.addItems(list(self.all_models.keys()))
        self.model_combo.currentTextChanged.connect(self.on_model_changed)
        model_layout.addWidget(model_label)
        model_layout.addWidget(self.model_combo)
        layout.addLayout(model_layout)

        self.params_scroll = QScrollArea()
        self.params_scroll.setWidgetResizable(True)
        self.params_container = QWidget()
        self.params_layout = QVBoxLayout()
        self.params_container.setLayout(self.params_layout)
        self.params_scroll.setWidget(self.params_container)
        layout.addWidget(self.params_scroll)

        self.save_button = QPushButton("Save Parameters")
        self.save_button.clicked.connect(self.save_parameters)
        layout.addWidget(self.save_button)

        if self.model_combo.count() > 0:
            self.on_model_changed(self.model_combo.currentText())

    def on_model_changed(self, model_name):
        self.current_model = model_name
        self.clear_params()
        if model_name in self.all_models:
            params = self.all_models[model_name]
            for param_name, param_info in params.items():
                widget = self.create_param_widget(param_name, param_info)
                if widget:
                    self.params_layout.addWidget(widget)
                    self.parameter_widgets[param_name] = widget

    def load_params(self, saved_params):
        """FIX: Load saved parameter values into the UI widgets"""
        if not saved_params:
            return
        
        for param_name, value in saved_params.items():
            if param_name in self.parameter_widgets:
                widget = self.parameter_widgets[param_name]
                # Find the actual input widget (spinbox, checkbox, etc.)
                if hasattr(widget, 'get_value'):
                    # Find the spinbox/checkbox inside the container widget
                    for child in widget.findChildren(QDoubleSpinBox):
                        child.setValue(float(value))
                        break
                    for child in widget.findChildren(QSpinBox):
                        child.setValue(int(value))
                        break
                    for child in widget.findChildren(QCheckBox):
                        child.setChecked(bool(value))
                        break

    def clear_params(self):
        while self.params_layout.count():
            item = self.params_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self.parameter_widgets.clear()

    def create_param_widget(self, param_name, param_info):
        param_type = param_info.get('type', 'float')
        default = param_info.get('default', 0.0)
        min_val = param_info.get('min')
        min_val = -1e9 if min_val is None else min_val
        max_val = param_info.get('max')
        max_val = 1e9 if max_val is None else max_val
        
        widget = None
        layout = QHBoxLayout()
        label = QLabel(f"{param_name}:")
        layout.addWidget(label)

        if param_type == 'float':
            spinbox = QDoubleSpinBox()
            spinbox.setRange(min_val, max_val)
            
            # Step und Decimals aus Param-Info lesen, sonst auto-bestimmen
            step = param_info.get('step')
            decimals = param_info.get('decimals')
            
            if step is None:
                # Auto: Step ist 10% von Default, oder 1.0 wenn Default 0
                if abs(default) > 1e-9:
                    step = abs(default) / 10
                else:
                    step = 0.01
            
            if decimals is None:
                # Auto: genug Decimals um Step darzustellen
                if step >= 1.0:
                    decimals = 2
                elif step >= 0.001:
                    decimals = 4
                elif step >= 1e-6:
                    decimals = 7
                else:
                    decimals = 10
            
            spinbox.setSingleStep(step)
            spinbox.setDecimals(decimals)
            spinbox.setValue(default)
            
            layout.addWidget(spinbox)
            widget = QWidget()
            widget.setLayout(layout)
            widget.get_value = spinbox.value
            
        elif param_type == 'integer':
            spinbox = QSpinBox()
            spinbox.setRange(int(min_val), int(max_val))
            spinbox.setValue(int(default))
            layout.addWidget(spinbox)
            widget = QWidget()
            widget.setLayout(layout)
            widget.get_value = spinbox.value
            
        elif param_type == 'boolean':
            checkbox = QCheckBox()
            checkbox.setChecked(default)
            layout.addWidget(checkbox)
            widget = QWidget()
            widget.setLayout(layout)
            widget.get_value = checkbox.isChecked
            
        return widget

    def save_parameters(self):
        if not self.current_model:
            print("No model selected")
            return
        params = {}
        for param_name, widget in self.parameter_widgets.items():
            params[param_name] = widget.get_value()
        
        # FIX: Emit signal to notify parent widget
        self.parametersSaved.emit(self.current_model, params)





class NodeParametersWidget(QWidget):

    paramsChanged = pyqtSignal(dict)

    def __init__(self, node_data=None):
        super().__init__()
        self.node_data = node_data if node_data else {}
        self.widgets = {}
        self.tool_panels = {}
        self.auto_save = True
        self.num_populations = 0
        self.init_ui()
        if node_data:
            self.load_data(node_data)

    def init_ui(self):
        layout = QVBoxLayout(self)
        
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        content = QWidget()
        self.content_layout = QVBoxLayout(content)
        scroll.setWidget(content)
        layout.addWidget(scroll)

        self.add_section("🔧 Node Type")
        self.tool_combo = QComboBox()
        for key, info in NODE_TOOLS.items():
            self.tool_combo.addItem(info["label"], key)
        self.tool_combo.currentIndexChanged.connect(self.on_tool_changed)
        self.content_layout.addWidget(self.tool_combo)
        self.widgets['tool_type'] = {'type': 'combo', 'widget': self.tool_combo}
        

        self.add_section("Basic Info")
        self.add_text_field("name", "Name")
        self.add_int_field("id", "ID", min_val=0)
        
        self.add_section("Auto-Instrumentation")
        self.add_bool_field("auto_spike_recorder", "Auto-Record Spikes (Raster)", default=False)
        self.add_bool_field("auto_multimeter", "Auto-Record Voltage (V_m)", default=False)

        self.add_section("Position & Transform")
        self.add_vector3_field("center_of_mass", "Center (X,Y,Z)")
        self.add_vector3_field("displacement", "Displacement")
        self.add_float_field("displacement_factor", "Disp. Factor", 0.0, 100.0)
        self.add_float_field("rot_theta", "Rotation θ (X-Axis)", -360, 360)
        self.add_float_field("rot_phi", "Rotation φ (Y-Axis)", -360, 360)
        self.add_float_field("stretch_x", "Scale X", 0.1, 100.0)
        self.add_float_field("stretch_y", "Scale Y", 0.1, 100.0)
        self.add_float_field("stretch_z", "Scale Z", 0.1, 100.0)
        

        self.add_section("Tool Parameters")
        self.create_tool_stack()
        

        self.add_section("Probability Vector (Population Weights)")
        self.probability_container = QWidget()
        self.probability_layout = QVBoxLayout(self.probability_container)
        self.content_layout.addWidget(self.probability_container)
        

        self.on_tool_changed()
        self.content_layout.addStretch()

    

    def _add_model_selector(self, layout, key="tool_neuron_model", label="Neuron Model"):
        row = QHBoxLayout()
        lbl = QLabel(f"{label}:")
        lbl.setMinimumWidth(150)
        lbl.setStyleSheet("font-weight: bold;")
        combo = QComboBox()
        combo.addItems(state.successful_neuron_models)
        combo.currentTextChanged.connect(self.on_change)
        row.addWidget(lbl)
        row.addWidget(combo)
        layout.addLayout(row)
        self.widgets[key] = {'type': 'combo_text', 'widget': combo, 'row_layout': row}

    def create_tool_stack(self):
        self.tool_stack = QStackedWidget()
        self.content_layout.addWidget(self.tool_stack)
        self.tool_stack.addWidget(self._create_panel_custom()); self.tool_panels['custom'] = 0
        self.tool_stack.addWidget(self._create_panel_ccw()); self.tool_panels['CCW'] = 1
        self.tool_stack.addWidget(self._create_panel_blob()); self.tool_panels['Blob'] = 2
        self.tool_stack.addWidget(self._create_panel_cone()); self.tool_panels['Cone'] = 3
        self.tool_stack.addWidget(self._create_panel_grid()); self.tool_panels['Grid'] = 4

    def _create_panel_custom(self):
        panel = QWidget(); layout = QVBoxLayout(panel)
        layout.addWidget(QLabel("Wave Function Collapse", styleSheet="color:#4CAF50; font-weight:bold;"))
        self._add_field_to_layout(layout, "old", "Use WFC (Multitype)", field_type="bool", default=False)
        self._add_field_to_layout(layout, "grid_size", "Grid Size", field_type="vector3_int")
        self._add_field_to_layout(layout, "sparsity_factor", "Sparsity", field_type="float", default=0.9)
        self._add_field_to_layout(layout, "num_steps", "Flow Steps", field_type="int", default=8)
        self._add_field_to_layout(layout, "dt", "dt", field_type="float", default=0.01)
        layout.addStretch(); return panel

    def _create_panel_ccw(self):
        panel = QWidget(); layout = QVBoxLayout(panel)
        layout.addWidget(QLabel("Ring Attractor", styleSheet="color:#FF9800; font-weight:bold;"))
        self._add_model_selector(layout, key="ccw_tool_neuron_model")
        self._add_neuron_edit_button(layout)
        self._add_field_to_layout(layout, "ccw_n_neurons", "Count", field_type="int", default=100)
        self._add_field_to_layout(layout, "ccw_radius", "Radius", field_type="float", default=5.0)
        self._add_field_to_layout(layout, "bidirectional", "Bidirectional", field_type="bool", default=False)
        layout.addWidget(QFrame(frameShape=QFrame.Shape.HLine))
        # Connection rule
        conn_rule_choices = ['similarity', 'one_to_one', 'all_to_all',
                             'pairwise_bernoulli', 'fixed_indegree', 'fixed_outdegree']
        self._add_field_to_layout(layout, "conn_rule", "Connection Rule",
                                  field_type="combo_text", choices=conn_rule_choices,
                                  default='similarity')
        self._add_field_to_layout(layout, "conn_p", "Bernoulli p", field_type="float",
                                  default=1.0, min_val=0.0, max_val=1.0)
        self._add_field_to_layout(layout, "conn_indegree", "Indegree", field_type="int",
                                  default=10, min_val=1, max_val=100000)
        self._add_field_to_layout(layout, "conn_outdegree", "Outdegree", field_type="int",
                                  default=10, min_val=1, max_val=100000)
        # Synaptik (volle Synapse-Config inkl. modell-spezifische Params)
        self._add_field_to_layout(layout, "ccw_syn_config", "Synapse",
                                  field_type="synapse_config", default='static_synapse')
        self._add_field_to_layout(layout, "ccw_weight_ex", "Weight (ex)", field_type="float", default=30.0)
        self._add_field_to_layout(layout, "ccw_delay_ex", "Delay [ms]", field_type="float", default=1.0,
                                  min_val=0.1, max_val=1000.0)
        self._add_field_to_layout(layout, "weight_in_factor", "Weight Inhib Factor",
                                  field_type="float", default=1.0, min_val=0.0, max_val=100.0)
        self._add_field_to_layout(layout, "k", "Inhibition (k)", field_type="float", default=10.0)
        layout.addStretch(); return panel

    def _create_panel_blob(self):
        panel = QWidget(); layout = QVBoxLayout(panel)
        layout.addWidget(QLabel("Random Blob", styleSheet="color:#9C27B0; font-weight:bold;"))
        self._add_model_selector(layout, key="blob_tool_neuron_model"); self._add_neuron_edit_button(layout)
        self._add_field_to_layout(layout, "blob_n_neurons", "Count", field_type="int", default=100)
        self._add_field_to_layout(layout, "blob_radius", "Radius", field_type="float", default=5.0)
        layout.addWidget(QFrame(frameShape=QFrame.Shape.HLine))
        # Excitatory subnet — eigene Synapse-Config + p/weight/delay
        layout.addWidget(QLabel("Excitatory Sub-Network", styleSheet="color:#66BB6A; font-weight:bold;"))
        self._add_field_to_layout(layout, "blob_syn_config_ex", "Synapse (Ex)",
                                  field_type="synapse_config", default='static_synapse')
        self._add_field_to_layout(layout, "blob_p_ex", "Connection p", field_type="float",
                                  default=0.8, min_val=0.0, max_val=1.0)
        self._add_field_to_layout(layout, "blob_weight_ex", "Weight", field_type="float", default=2.0)
        self._add_field_to_layout(layout, "blob_delay_ex", "Delay [ms]", field_type="float",
                                  default=1.0, min_val=0.1, max_val=1000.0)
        # Inhibitory subnet — eigene Synapse-Config + p/weight/delay
        layout.addWidget(QLabel("Inhibitory Sub-Network", styleSheet="color:#EF5350; font-weight:bold;"))
        self._add_field_to_layout(layout, "blob_syn_config_in", "Synapse (In)",
                                  field_type="synapse_config", default='static_synapse')
        self._add_field_to_layout(layout, "blob_p_in", "Connection p", field_type="float",
                                  default=0.2, min_val=0.0, max_val=1.0)
        self._add_field_to_layout(layout, "blob_weight_in", "Weight", field_type="float", default=-10.0)
        self._add_field_to_layout(layout, "blob_delay_in", "Delay [ms]", field_type="float",
                                  default=1.0, min_val=0.1, max_val=1000.0)
        self._add_field_to_layout(layout, "blob_allow_autapses", "Allow Autapses",
                                  field_type="bool", default=False)
        layout.addStretch(); return panel

    def _create_panel_cone(self):
        panel = QWidget(); layout = QVBoxLayout(panel)
        layout.addWidget(QLabel("Cone / Column", styleSheet="color:#E91E63; font-weight:bold;"))
        self._add_model_selector(layout, key="cone_tool_neuron_model"); self._add_neuron_edit_button(layout)
        self._add_field_to_layout(layout, "cone_n_neurons", "Count", field_type="int", default=500)
        self._add_field_to_layout(layout, "radius_bottom", "R Bottom", field_type="float", default=5.0)
        self._add_field_to_layout(layout, "radius_top", "R Top", field_type="float", default=1.0)
        self._add_field_to_layout(layout, "height", "Height", field_type="float", default=10.0)
        # KRITISCH: Alle hier verwendeten widget-Keys MÜSSEN eindeutig zu Cone
        # sein. CCW-Panel registriert dieselben generischen Keys (bidirectional,
        # conn_rule, ccw_syn_config, ...) — wenn Cone die wieder verwendet,
        # überschreibt das letzte registrierte Widget (Cone) die CCW-Einträge
        # in self.widgets, sodass User-Edits am sichtbaren CCW-Widget nicht
        # ankommen. Daher cone_*-Präfix + entsprechendes Mapping in
        # TOOL_PARAM_KEYS['Cone'] für die generischen Output-Namen.
        self._add_field_to_layout(layout, "cone_bidirectional", "Bidirectional", field_type="bool", default=False)
        layout.addWidget(QFrame(frameShape=QFrame.Shape.HLine))
        # Connection rule
        conn_rule_choices = ['similarity', 'one_to_one', 'all_to_all',
                             'pairwise_bernoulli', 'fixed_indegree', 'fixed_outdegree']
        self._add_field_to_layout(layout, "cone_conn_rule", "Connection Rule",
                                  field_type="combo_text", choices=conn_rule_choices,
                                  default='similarity')
        self._add_field_to_layout(layout, "cone_conn_p", "Bernoulli p", field_type="float",
                                  default=1.0, min_val=0.0, max_val=1.0)
        self._add_field_to_layout(layout, "cone_conn_indegree", "Indegree", field_type="int",
                                  default=10, min_val=1, max_val=100000)
        self._add_field_to_layout(layout, "cone_conn_outdegree", "Outdegree", field_type="int",
                                  default=10, min_val=1, max_val=100000)
        # Synaptik (volle Synapse-Config) — eigene Cone-Keys, gemappt zu generic
        self._add_field_to_layout(layout, "cone_syn_config", "Synapse",
                                  field_type="synapse_config", default='static_synapse')
        self._add_field_to_layout(layout, "cone_weight_ex", "Weight (ex)", field_type="float", default=30.0)
        self._add_field_to_layout(layout, "cone_delay_ex", "Delay [ms]", field_type="float", default=1.0,
                                  min_val=0.1, max_val=1000.0)
        self._add_field_to_layout(layout, "cone_weight_in_factor", "Weight Inhib Factor",
                                  field_type="float", default=1.0, min_val=0.0, max_val=100.0)
        self._add_field_to_layout(layout, "cone_k", "Inhibition (k)", field_type="float", default=10.0)
        layout.addStretch(); return panel

    def _create_panel_grid(self):
        panel = QWidget(); layout = QVBoxLayout(panel)
        layout.addWidget(QLabel("2D Grid", styleSheet="color:#00BCD4; font-weight:bold;"))
        self._add_model_selector(layout, key="grid_tool_neuron_model")
        self._add_field_to_layout(layout, "grid_side_length", "Side Length", field_type="int", default=10)
        layout.addStretch(); return panel

    def _add_field_to_layout(self, layout, key, label, field_type="float", min_val=None, max_val=None, default=None, choices=None):
        row = QHBoxLayout()
        row.addWidget(QLabel(f"{label}:", styleSheet="font-weight:bold; min-width:100px;"))
        if field_type == "int":
            w = QSpinBox()
            w.setRange(min_val if min_val is not None else 0,
                       max_val if max_val is not None else 100000)
            w.setValue(default if default is not None else 0)
        elif field_type == "float":
            w = QDoubleSpinBox()
            w.setRange(min_val if min_val is not None else -1e6,
                       max_val if max_val is not None else 1e6)
            w.setDecimals(4)
            w.setValue(default if default is not None else 0.0)
        elif field_type == "bool":
            w = QCheckBox(); w.setChecked(bool(default) if default is not None else False)
        elif field_type == "combo_text":
            w = QComboBox()
            for c in (choices or []):
                w.addItem(c)
            if default and default in (choices or []):
                w.setCurrentText(default)
            w.currentTextChanged.connect(self.on_change)
            row.addWidget(w)
            self.widgets[key] = {'type': 'combo_text', 'widget': w}
            layout.addLayout(row); return
        elif field_type == "synapse_config":
            # Vollbreite, kein Row-Label; InlineSynapseConfig hat eigenen Header.
            w = InlineSynapseConfig(label=label,
                                    default_model=default if isinstance(default, str) else 'static_synapse',
                                    collapsed=True)
            w.valueChanged.connect(self.on_change)
            layout.addWidget(w)
            self.widgets[key] = {'type': 'synapse_config', 'widget': w}
            return
        elif field_type == "vector3_int":
            w = None; ws = []
            for p in ["X","Y","Z"]: s=QSpinBox(); s.setRange(1,1000); s.setPrefix(p); s.setValue(default if default is not None else 10); s.valueChanged.connect(self.on_change); row.addWidget(s); ws.append(s)
            self.widgets[key] = {'type': 'vector3_int', 'widgets': ws}; layout.addLayout(row); return
            
        if w:
            if hasattr(w, 'valueChanged'): w.valueChanged.connect(self.on_change)
            if hasattr(w, 'stateChanged'): w.stateChanged.connect(self.on_change)
            row.addWidget(w)
            if field_type=="bool": row.addStretch()
            self.widgets[key] = {'type': field_type, 'widget': w}
        layout.addLayout(row)

    def on_tool_changed(self):
        self.tool_stack.setCurrentIndex(self.tool_panels.get(self.tool_combo.currentData(), 0))
        self.on_change()

    def add_section(self, title):
        self.content_layout.addWidget(QLabel(title, styleSheet="font-weight:bold; color:#2196F3; margin-top:10px; border-bottom:1px solid #2196F3;"))

    def add_text_field(self, key, label, parent=None):
        l = parent or self.content_layout; r=QHBoxLayout(); w=QLineEdit(); w.textChanged.connect(self.on_change)
        r.addWidget(QLabel(f"{label}:", styleSheet="font-weight:bold;")); r.addWidget(w); l.addLayout(r)
        self.widgets[key] = {'type':'text', 'widget':w}

    def add_int_field(self, key, label, min_val=0, parent=None):
        l = parent or self.content_layout; r=QHBoxLayout(); w=QSpinBox(); w.setRange(min_val, 10000); w.valueChanged.connect(self.on_change)
        r.addWidget(QLabel(f"{label}:", styleSheet="font-weight:bold;")); r.addWidget(w); l.addLayout(r)
        self.widgets[key] = {'type':'int', 'widget':w}

    def add_float_field(self, key, label, min_val=-1000, max_val=1000, parent=None):
        l = parent or self.content_layout; r=QHBoxLayout(); w=QDoubleSpinBox(); w.setRange(min_val, max_val); w.valueChanged.connect(self.on_change)
        r.addWidget(QLabel(f"{label}:", styleSheet="font-weight:bold;")); r.addWidget(w); l.addLayout(r)
        self.widgets[key] = {'type':'float', 'widget':w}

    def add_bool_field(self, key, label, default=False, parent=None):
        l = parent or self.content_layout; r=QHBoxLayout(); w=QCheckBox(); w.setChecked(default); w.stateChanged.connect(self.on_change)
        r.addWidget(QLabel(f"{label}:", styleSheet="font-weight:bold;")); r.addWidget(w); r.addStretch(); l.addLayout(r)
        self.widgets[key] = {'type':'bool', 'widget':w}

    def add_vector3_field(self, key, label, parent=None):
        l = parent or self.content_layout; r=QHBoxLayout(); ws=[]
        r.addWidget(QLabel(f"{label}:", styleSheet="font-weight:bold;"))
        for p in ["X","Y","Z"]: s=QDoubleSpinBox(); s.setRange(-1000,1000); s.setPrefix(p); s.valueChanged.connect(self.on_change); r.addWidget(s); ws.append(s)
        l.addLayout(r); self.widgets[key] = {'type':'vector3', 'widgets':ws}

    def on_change(self):
        if self.auto_save: self.paramsChanged.emit(self.get_current_params())

    def set_population_count(self, count):
        self.num_populations = count
        while self.probability_layout.count(): item=self.probability_layout.takeAt(0); item.widget().deleteLater() if item.widget() else None
        if 'probability_vector' in self.widgets: del self.widgets['probability_vector']
        
        if count == 0: self.probability_layout.addWidget(QLabel("No populations"))
        else:
            ws = []
            for i in range(count):
                r=QHBoxLayout(); s=QDoubleSpinBox(); s.setRange(0,1); s.setValue(1.0/count); s.valueChanged.connect(self.on_change)
                r.addWidget(QLabel(f"Pop {i+1}:")); r.addWidget(s); self.probability_layout.addLayout(r); ws.append(s)
            self.widgets['probability_vector'] = {'type':'prob_list', 'widgets':ws}

    def get_current_params(self):
        res = {}
        
        # Hole aktuelles Tool
        current_tool = self.tool_combo.currentData() or 'custom'
        tool_mapping = TOOL_PARAM_KEYS.get(current_tool, {})
        # Inverses Mapping: tool-spezifischer Key -> generischer Key
        inverse_mapping = {v: k for k, v in tool_mapping.items()}
        
        for k, info in self.widgets.items():
            t = info['type']; w = info.get('widget')
            
            # Bestimme den Output-Key (generischer Name falls gemappt)
            output_key = inverse_mapping.get(k, k)
            
            if t=='text': res[output_key]=w.text()
            elif t=='int' or t=='float': res[output_key]=w.value()
            elif t=='bool': res[output_key]=w.isChecked()
            elif t=='combo': res[output_key]=w.currentData()
            elif t=='combo_text': res[output_key]=w.currentText()
            elif t=='synapse_config': res[output_key]=w.get_value()  # dict
            elif t in ['vector3', 'vector3_int', 'prob_list']: res[output_key]=[s.value() for s in info['widgets']]
        
        if 'center_of_mass' in res: res['m'] = res['center_of_mass']
        sx=res.get('stretch_x',1); sy=res.get('stretch_y',1); sz=res.get('stretch_z',1)
        res['transform_matrix'] = [[sx,0,0],[0,sy,0],[0,0,sz]]
        return res

    def load_data(self, data):
        self.auto_save = False
        self.node_data = data
        
        # Setze zuerst das Tool, damit wir das richtige Mapping haben
        if 'tool_type' in data: 
            self.tool_stack.setCurrentIndex(self.tool_panels.get(data['tool_type'], 0))
            # Update auch die ComboBox
            idx = self.tool_combo.findData(data['tool_type'])
            if idx >= 0:
                self.tool_combo.setCurrentIndex(idx)
        
        # Hole Mapping für das aktuelle Tool
        current_tool = data.get('tool_type', 'custom')
        tool_mapping = TOOL_PARAM_KEYS.get(current_tool, {})
        
        # Falls tool_neuron_model nicht gesetzt ist, aber neuron_models existiert, übertrage den Wert
        if 'tool_neuron_model' not in data and 'neuron_models' in data:
            nm = data['neuron_models']
            if isinstance(nm, list) and nm:
                data['tool_neuron_model'] = nm[0]
        
        for k, info in self.widgets.items():
            # Prüfe ob dieser Widget-Key zu einem generischen Key gemappt werden soll
            # Falls ja, hole den Wert vom generischen Key
            inverse_mapping = {v: k_gen for k_gen, v in tool_mapping.items()}
            data_key = inverse_mapping.get(k, k)  # Generischer Key oder originaler Key
            
            if data_key not in data: continue
            v = data[data_key]; t = info['type']; w = info.get('widget')
            if t=='text': w.setText(str(v))
            elif t in ['int', 'float']: w.setValue(v)
            elif t=='bool': w.setChecked(bool(v))
            elif t=='combo': idx=w.findData(v); w.setCurrentIndex(idx) if idx>=0 else None
            elif t=='combo_text': w.setCurrentText(str(v))
            elif t=='synapse_config': w.set_value(v)  # v is a dict
            elif t in ['vector3', 'vector3_int', 'prob_list']:
                for i, s in enumerate(info['widgets']):
                    if i < len(v): s.setValue(v[i])
        self.auto_save = True

    def _add_neuron_edit_button(self, layout):
        btn = QPushButton("⚙️ Edit Neurons"); btn.clicked.connect(self._jump_to_neuron_editor)
        layout.addWidget(btn)
    def _jump_to_neuron_editor(self):
        # Traversiere die Parent-Hierarchie um das QTabWidget zu finden
        widget = self
        while widget is not None:
            if hasattr(widget, 'setCurrentIndex'):
                widget.setCurrentIndex(2)
                return
            if hasattr(widget, 'parent') and callable(widget.parent):
                widget = widget.parent()
            else:
                break
        print("⚠ Could not find tab widget to switch to neuron editor")
