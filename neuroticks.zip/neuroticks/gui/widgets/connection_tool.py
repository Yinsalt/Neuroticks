"""ConnectionTool: Verbindungen zwischen Populationen anlegen (inkl. Warteschlange)."""
import copy
from typing import Dict, List

from PyQt6.QtCore import pyqtSignal, Qt, QTimer
from PyQt6.QtGui import QColor
from PyQt6.QtWidgets import (
    QCheckBox, QComboBox, QDoubleSpinBox, QFormLayout, QFrame, QGridLayout, QGroupBox,
    QHBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem, QPushButton, QScrollArea,
    QSizePolicy, QSpinBox, QTabWidget, QVBoxLayout, QWidget,
)

from neuroticks.constants.synapses import SYNAPSE_MODELS
from neuroticks.core.connection_executor import ConnectionExecutor
from neuroticks.gui.widgets.input_fields import DoubleInputField, IntegerInputField
from neuroticks.utils.nest_helpers import safe_get_model

class ConnectionTargetRow(QWidget):

    removeClicked = pyqtSignal(QWidget)
    def __init__(self, graph_list, index, parent=None):
        super().__init__(parent)
        self.graph_list = graph_list
        self.index = index
        self._init_ui()

    def _init_ui(self):
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(5)

        frame = QFrame()
        frame.setStyleSheet("background-color: #2b2b2b; border: 1px solid #444; border-radius: 4px;")
        frame_layout = QGridLayout(frame)
        frame_layout.setContentsMargins(5, 5, 5, 5)
        
        lbl_title = QLabel(f"Target #{self.index + 1}")
        lbl_title.setStyleSheet("color: #FF9800; font-weight: bold; font-size: 10px;")
        
        self.btn_del = QPushButton("×")
        self.btn_del.setFixedSize(20, 20)
        self.btn_del.setStyleSheet("""
            QPushButton { background-color: #D32F2F; color: white; border: none; border-radius: 2px; font-weight: bold; }
            QPushButton:hover { background-color: #F44336; }
        """)
        self.btn_del.clicked.connect(lambda: self.removeClicked.emit(self))
        
        if self.index == 0:
            self.btn_del.setVisible(False)

        self.combo_graph = QComboBox()
        self.combo_node = QComboBox()
        self.combo_pop = QComboBox()
        
        for c in [self.combo_graph, self.combo_node, self.combo_pop]:
            c.setStyleSheet("background-color: #1e1e1e; border: 1px solid #555; padding: 2px;")
            c.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

        self.combo_graph.currentIndexChanged.connect(self.on_graph_changed)
        self.combo_node.currentIndexChanged.connect(self.on_node_changed)

        frame_layout.addWidget(lbl_title, 0, 0)
        frame_layout.addWidget(self.btn_del, 0, 1, alignment=Qt.AlignmentFlag.AlignRight)
        
        frame_layout.addWidget(QLabel("G:"), 1, 0)
        frame_layout.addWidget(self.combo_graph, 1, 1)
        
        frame_layout.addWidget(QLabel("N:"), 2, 0)
        frame_layout.addWidget(self.combo_node, 2, 1)
        
        frame_layout.addWidget(QLabel("P:"), 3, 0)
        frame_layout.addWidget(self.combo_pop, 3, 1)

        layout.addWidget(frame)
        
        self.refresh_data()

    def refresh_data(self, new_graph_list=None):
        if new_graph_list is not None:
            self.graph_list = new_graph_list
            
        current_g = self.combo_graph.currentData()
        
        self.combo_graph.blockSignals(True)
        self.combo_graph.clear()
        for graph in self.graph_list:
            name = getattr(graph, 'graph_name', f'Graph {graph.graph_id}')
            self.combo_graph.addItem(f"{name} (ID: {graph.graph_id})", graph.graph_id)
        
        if current_g is not None:
            idx = self.combo_graph.findData(current_g)
            if idx >= 0: self.combo_graph.setCurrentIndex(idx)
            
        self.combo_graph.blockSignals(False)
        
        if self.combo_graph.count() > 0:
            self.on_graph_changed()

    def on_graph_changed(self):
        self.combo_node.blockSignals(True)
        self.combo_node.clear()
        
        graph_id = self.combo_graph.currentData()
        graph = next((g for g in self.graph_list if g.graph_id == graph_id), None)
        
        if graph:
            for node in graph.node_list:
                self.combo_node.addItem(f"{node.name} (ID: {node.id})", node.id)
        
        self.combo_node.blockSignals(False)
        self.on_node_changed()

    def on_node_changed(self):
        self.combo_pop.clear()
        graph_id = self.combo_graph.currentData()
        node_id = self.combo_node.currentData()
        
        graph = next((g for g in self.graph_list if g.graph_id == graph_id), None)
        if graph:
            node = next((n for n in graph.node_list if n.id == node_id), None)
            if node and hasattr(node, 'population'):
                for i, pop in enumerate(node.population):
                    model = safe_get_model(pop, "empty")
                    self.combo_pop.addItem(f"Pop {i}: {model}", i)

    def get_selection(self):
        g = self.combo_graph.currentData()
        n = self.combo_node.currentData()
        p = self.combo_pop.currentData()
        return g, n, p


class ConnectionTool(QWidget):
    connectionsCreated = pyqtSignal()
    def __init__(self, graph_list):
        super().__init__()
        self.graph_list = graph_list
        self.connections = []
        self.next_conn_id = 0
        self.current_conn_idx = None
        self.syn_param_widgets = {}
        
        self.target_rows = []
        
        self.init_ui()

    def refresh(self):
        self.refresh_graph_list()

    def init_ui(self):
        main_layout = QHBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)

        left_col = QVBoxLayout()
        left_col.setContentsMargins(5, 5, 5, 5)
        
        src_group = QGroupBox("Source Population (1)")
        src_group.setStyleSheet("QGroupBox { border: 1px solid #4CAF50; font-weight: bold; margin-top: 10px; } QGroupBox::title { color: #4CAF50; }")
        src_layout = QFormLayout(src_group)
        
        self.source_graph_combo = QComboBox()
        self.source_graph_combo.currentIndexChanged.connect(self.on_source_graph_changed)
        src_layout.addRow("Graph:", self.source_graph_combo)
        
        self.source_node_combo = QComboBox()
        self.source_node_combo.currentIndexChanged.connect(self.on_source_node_changed)
        src_layout.addRow("Node:", self.source_node_combo)
        
        self.source_pop_combo = QComboBox()
        src_layout.addRow("Pop:", self.source_pop_combo)
        
        left_col.addWidget(src_group)
        
        lbl_arrow = QLabel("⬇ connects to ⬇")
        lbl_arrow.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lbl_arrow.setStyleSheet("font-weight: bold; color: #888; margin: 5px;")
        left_col.addWidget(lbl_arrow)
        
        tgt_group = QGroupBox("Target Populations (N)")
        tgt_group.setStyleSheet("QGroupBox { border: 1px solid #FF9800; font-weight: bold; margin-top: 10px; } QGroupBox::title { color: #FF9800; }")
        tgt_outer_layout = QVBoxLayout(tgt_group)
        tgt_outer_layout.setContentsMargins(2, 10, 2, 2)
        
        self.scroll_targets = QScrollArea()
        self.scroll_targets.setWidgetResizable(True)
        self.scroll_targets.setFrameShape(QFrame.Shape.NoFrame)
        self.scroll_targets.setStyleSheet("background: transparent;")
        
        self.targets_container = QWidget()
        self.targets_layout = QVBoxLayout(self.targets_container)
        self.targets_layout.setContentsMargins(0, 0, 0, 0)
        self.targets_layout.setSpacing(5)
        self.targets_layout.addStretch()
        
        self.scroll_targets.setWidget(self.targets_container)
        tgt_outer_layout.addWidget(self.scroll_targets)
        
        self.btn_add_target = QPushButton("+ Add Target")
        self.btn_add_target.setStyleSheet("background-color: #333; color: #FF9800; border: 1px solid #FF9800; border-radius: 4px; padding: 4px;")
        self.btn_add_target.clicked.connect(self.add_target_row)
        tgt_outer_layout.addWidget(self.btn_add_target)
        
        left_col.addWidget(tgt_group, 2)
        
        main_layout.addLayout(left_col, 2)
        
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setFrameShape(QFrame.Shape.NoFrame)
        
        middle_container = QWidget()
        middle_col = QVBoxLayout(middle_container)
        middle_col.setContentsMargins(10, 0, 10, 0)
        
        name_layout = QHBoxLayout()
        self.conn_name_input = QLineEdit()
        self.conn_name_input.setPlaceholderText("Connection Name (Base)")
        name_layout.addWidget(QLabel("Name:"))
        name_layout.addWidget(self.conn_name_input)
        middle_col.addLayout(name_layout)

        self.tabs = QTabWidget()
        self.tab_spatial = QWidget()
        self._init_spatial_tab()
        self.tabs.addTab(self.tab_spatial, "🌍 Spatial")
        
        self.tab_topo = QWidget()
        self._init_topological_tab()
        self.tabs.addTab(self.tab_topo, "🕸️ Topological")
        
        middle_col.addWidget(self.tabs)
        
        syn_group = QGroupBox("Synapse Properties")
        syn_layout = QFormLayout(syn_group)
        
        self.syn_model_combo = QComboBox()
        self.syn_model_combo.addItems(sorted(SYNAPSE_MODELS.keys()))
        self.syn_model_combo.currentTextChanged.connect(self.on_synapse_model_changed)
        syn_layout.addRow("Model:", self.syn_model_combo)
        
        wd_layout = QHBoxLayout()
        self.weight_spin = QDoubleSpinBox()
        self.weight_spin.setRange(-1000000, 1000000)
        self.weight_spin.setValue(1.0)
        self.weight_spin.setDecimals(3)
        self.weight_spin.setPrefix("W: ")
        
        self.delay_spin = QDoubleSpinBox()
        self.delay_spin.setRange(0.1, 10000)
        self.delay_spin.setValue(1.0)
        self.delay_spin.setDecimals(2)
        self.delay_spin.setPrefix("D: ")
        self.delay_spin.setSuffix(" ms")
        
        wd_layout.addWidget(self.weight_spin)
        wd_layout.addWidget(self.delay_spin)
        syn_layout.addRow("Base Params:", wd_layout)
        
        self.dynamic_syn_params_container = QWidget()
        self.dynamic_syn_params_layout = QVBoxLayout(self.dynamic_syn_params_container)
        self.dynamic_syn_params_layout.setContentsMargins(0,0,0,0)
        syn_layout.addRow(self.dynamic_syn_params_container)
        
        opts_layout = QHBoxLayout()
        self.allow_autapses_check = QCheckBox("Autapses")
        self.allow_autapses_check.setChecked(True)
        self.allow_multapses_check = QCheckBox("Multapses")
        self.allow_multapses_check.setChecked(True)
        self.receptor_spin = QSpinBox()
        self.receptor_spin.setRange(0, 255)
        self.receptor_spin.setPrefix("Receptor: ")
        
        opts_layout.addWidget(self.allow_autapses_check)
        opts_layout.addWidget(self.allow_multapses_check)
        opts_layout.addWidget(self.receptor_spin)
        syn_layout.addRow(opts_layout)
        
        middle_col.addWidget(syn_group)
        
        # ── Dopamine source picker (for stdp_dopamine_synapse) ──────
        # Only visible when a dopamine-modulated synapse model is
        # selected. Picks the population that drives the synapse's
        # volume_transmitter (the dopaminergic projection neurons).
        self.da_group = QGroupBox("Dopamine Source")
        self.da_group.setStyleSheet(
            "QGroupBox { border: 1px solid #E91E63; font-weight: bold; "
            "margin-top: 10px; } QGroupBox::title { color: #E91E63; }"
        )
        da_layout = QFormLayout(self.da_group)
        
        self.da_graph_combo = QComboBox()
        self.da_graph_combo.currentIndexChanged.connect(self.on_da_graph_changed)
        da_layout.addRow("Graph:", self.da_graph_combo)
        
        self.da_node_combo = QComboBox()
        self.da_node_combo.currentIndexChanged.connect(self.on_da_node_changed)
        da_layout.addRow("Node:", self.da_node_combo)
        
        self.da_pop_combo = QComboBox()
        da_layout.addRow("Pop:", self.da_pop_combo)
        
        da_help = QLabel(
            "Pop providing dopamine spikes. Drives the volume_transmitter "
            "that modulates plasticity. For test setups you may pick the "
            "same pop as source/target — the connection will build but "
            "won't learn anything biologically meaningful."
        )
        da_help.setWordWrap(True)
        da_help.setStyleSheet("color: #aaa; font-style: italic; font-size: 11px;")
        da_layout.addRow(da_help)
        
        self.da_group.setVisible(False)
        middle_col.addWidget(self.da_group)
        
        middle_col.addStretch()
        
        scroll_area.setWidget(middle_container)
        main_layout.addWidget(scroll_area, 3)
        
        right_col = QVBoxLayout()
        right_col.addWidget(QLabel("Connection Queue", alignment=Qt.AlignmentFlag.AlignCenter))
        
        self.conn_list_widget = QWidget()
        self.conn_list_layout = QVBoxLayout(self.conn_list_widget)
        conn_scroll = QScrollArea()
        conn_scroll.setWidgetResizable(True)
        conn_scroll.setWidget(self.conn_list_widget)
        right_col.addWidget(conn_scroll)
        
        self.add_conn_btn = QPushButton("⬇ Add All to Queue")
        self.add_conn_btn.setStyleSheet("background-color: #2196F3; font-weight: bold; padding: 8px;")
        self.add_conn_btn.clicked.connect(self.add_connection)
        right_col.addWidget(self.add_conn_btn)
        
        self.delete_conn_btn = QPushButton("Remove Selected")
        self.delete_conn_btn.clicked.connect(self.delete_connection)
        self.delete_conn_btn.setEnabled(False)
        right_col.addWidget(self.delete_conn_btn)
        
        self.create_all_btn = QPushButton("CREATE IN NEST")
        self.create_all_btn.setMinimumHeight(50)
        self.create_all_btn.setStyleSheet("background-color: #4CAF50; color: white; font-weight: bold; font-size: 14px;")
        self.create_all_btn.clicked.connect(self.create_all_connections)
        right_col.addWidget(self.create_all_btn)
        
        self.status_label = QLabel("")
        self.status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.status_label.setStyleSheet("color: #bbb; font-size: 11px; font-weight: bold;")
        self.status_label.setWordWrap(True)
        right_col.addWidget(self.status_label)
        
        main_layout.addLayout(right_col, 2)
        
        self.refresh_graph_list()
        self.add_target_row()
        if self.syn_model_combo.count() > 0:
            self.on_synapse_model_changed(self.syn_model_combo.currentText())

    def add_target_row(self):
        idx = len(self.target_rows)
        row = ConnectionTargetRow(self.graph_list, idx, self)
        row.removeClicked.connect(self.remove_target_row)
        self.target_rows.append(row)
        self.targets_layout.insertWidget(idx, row)
        QTimer.singleShot(100, lambda: self.scroll_targets.verticalScrollBar().setValue(
            self.scroll_targets.verticalScrollBar().maximum()
        ))

    def remove_target_row(self, row_widget):
        if row_widget in self.target_rows:
            self.target_rows.remove(row_widget)
            self.targets_layout.removeWidget(row_widget)
            row_widget.deleteLater()
            for i, r in enumerate(self.target_rows):
                r.index = i

    def refresh_graph_list(self):
        self.source_graph_combo.clear()
        for graph in self.graph_list:
            name = getattr(graph, 'graph_name', f'Graph {graph.graph_id}')
            self.source_graph_combo.addItem(f"{name} (ID: {graph.graph_id})", graph.graph_id)
        if len(self.graph_list) > 0:
            self.on_source_graph_changed(0)
        for row in self.target_rows:
            row.refresh_data(self.graph_list)
        # Keep DA-source combos in sync with the same graph list.
        self._refresh_da_graph_combo()

    def on_source_graph_changed(self, index):
        self.source_node_combo.clear()
        self.source_pop_combo.clear()
        if index < 0: return
        graph_id = self.source_graph_combo.currentData()
        graph = next((g for g in self.graph_list if g.graph_id == graph_id), None)
        if not graph: return
        for node in graph.node_list:
            self.source_node_combo.addItem(f"{node.name} (ID: {node.id})", node.id)
        if len(graph.node_list) > 0: self.on_source_node_changed(0)

    def on_source_node_changed(self, index):
        self.source_pop_combo.clear()
        if index < 0: return
        graph_id = self.source_graph_combo.currentData()
        node_id = self.source_node_combo.currentData()
        graph = next((g for g in self.graph_list if g.graph_id == graph_id), None)
        if not graph: return
        node = next((n for n in graph.node_list if n.id == node_id), None)
        if not node: return
        if hasattr(node, 'population') and node.population:
            for i, pop in enumerate(node.population):
                model = safe_get_model(pop, "empty")
                self.source_pop_combo.addItem(f"Pop {i}: {model}", i)

    def _refresh_da_graph_combo(self):
        """Populate the DA-source graph combo. Called from refresh_graph_list."""
        if not hasattr(self, 'da_graph_combo'):
            return
        self.da_graph_combo.blockSignals(True)
        self.da_graph_combo.clear()
        for graph in self.graph_list:
            name = getattr(graph, 'graph_name', f'Graph {graph.graph_id}')
            self.da_graph_combo.addItem(f"{name} (ID: {graph.graph_id})", graph.graph_id)
        self.da_graph_combo.blockSignals(False)
        if len(self.graph_list) > 0:
            self.on_da_graph_changed(0)

    def on_da_graph_changed(self, index):
        if not hasattr(self, 'da_node_combo'):
            return
        self.da_node_combo.clear()
        self.da_pop_combo.clear()
        if index < 0:
            return
        graph_id = self.da_graph_combo.currentData()
        graph = next((g for g in self.graph_list if g.graph_id == graph_id), None)
        if not graph:
            return
        for node in graph.node_list:
            self.da_node_combo.addItem(f"{node.name} (ID: {node.id})", node.id)
        if len(graph.node_list) > 0:
            self.on_da_node_changed(0)

    def on_da_node_changed(self, index):
        if not hasattr(self, 'da_pop_combo'):
            return
        self.da_pop_combo.clear()
        if index < 0:
            return
        graph_id = self.da_graph_combo.currentData()
        node_id = self.da_node_combo.currentData()
        graph = next((g for g in self.graph_list if g.graph_id == graph_id), None)
        if not graph:
            return
        node = next((n for n in graph.node_list if n.id == node_id), None)
        if not node:
            return
        if hasattr(node, 'population') and node.population:
            for i, pop in enumerate(node.population):
                model = safe_get_model(pop, "empty")
                self.da_pop_combo.addItem(f"Pop {i}: {model}", i)

    def add_connection(self):
        s_gid = self.source_graph_combo.currentData()
        s_nid = self.source_node_combo.currentData()
        s_pid = self.source_pop_combo.currentData()
        
        if None in [s_gid, s_nid, s_pid]:
            print("Source not fully selected!")
            return

        base_params = self._get_current_params()
        base_name = self.conn_name_input.text().strip() or "Conn"
        
        # If a dopamine synapse is selected, capture the DA-source pick now
        # (same value applies to all target rows in this batch).
        da_source_for_batch = None
        syn_model = base_params.get('synapse_model', '')
        if 'stdp_dopamine' in syn_model:
            da_gid = self.da_graph_combo.currentData()
            da_nid = self.da_node_combo.currentData()
            da_pid = self.da_pop_combo.currentData()
            if None in [da_gid, da_nid, da_pid]:
                self.status_label.setText(
                    "Dopamine source not fully selected — required for "
                    f"{syn_model}."
                )
                return
            da_source_for_batch = {
                'graph_id': da_gid, 'node_id': da_nid, 'pop_id': da_pid
            }
        
        count_added = 0
        
        for i, row in enumerate(self.target_rows):
            t_gid, t_nid, t_pid = row.get_selection()
            if None in [t_gid, t_nid, t_pid]:
                print(f"Skipping Target Row {i+1}: Incomplete selection")
                continue
            
            current_name = base_name
            if len(self.target_rows) > 1:
                current_name = f"{base_name}_{i+1}"
                
            params_copy = copy.deepcopy(base_params)
            
            conn_dict = {
                'id': self.next_conn_id,
                'name': current_name,
                'source': {'graph_id': s_gid, 'node_id': s_nid, 'pop_id': s_pid},
                'target': {'graph_id': t_gid, 'node_id': t_nid, 'pop_id': t_pid},
                'params': params_copy
            }
            if da_source_for_batch is not None:
                conn_dict['da_source'] = copy.deepcopy(da_source_for_batch)
            
            self.connections.append(conn_dict)
            self.next_conn_id += 1
            count_added += 1
            
        if count_added > 0:
            self.update_connection_list()
            self.status_label.setText(f"Added {count_added} connections to queue.")
        else:
            self.status_label.setText("No valid targets found.")

    def update_connection_list(self):
        while self.conn_list_layout.count():
            item = self.conn_list_layout.takeAt(0)
            if item.widget(): item.widget().deleteLater()
        for i, conn in enumerate(self.connections):
            mode_icon = "🌍" if conn['params'].get('use_spatial', False) else "🕸️"
            btn = QPushButton(f"{mode_icon} {conn['name']}")
            btn.setMinimumHeight(30)
            btn.clicked.connect(lambda checked, idx=i: self.select_connection(idx))
            if 'error' in conn:
                btn.setStyleSheet("background-color: #4a1818; color: #ff9999; border: 1px solid #ff5555;")
                btn.setToolTip(f"Failed: {conn['error']}")
            if i == self.current_conn_idx:
                btn.setStyleSheet("background-color: #2196F3; color: white; font-weight: bold;")
            self.conn_list_layout.addWidget(btn)
        self.conn_list_layout.addStretch()

    def select_connection(self, idx):
        self.current_conn_idx = idx
        self.delete_conn_btn.setEnabled(True)
        self.update_connection_list()

    def delete_connection(self):
        if self.current_conn_idx is not None:
            self.connections.pop(self.current_conn_idx)
            self.current_conn_idx = None
            self.delete_conn_btn.setEnabled(False)
            self.update_connection_list()

    def create_all_connections(self):
        if not self.connections: return
        graphs_dict = {g.graph_id: g for g in self.graph_list}
        self.connection_executor = ConnectionExecutor(graphs_dict)
        success, fail, failed_items = self.connection_executor.execute_pending_connections(self.connections)
        self.connections = failed_items
        self.update_connection_list()
        if fail == 0: self.status_label.setText(f"All {success} created.")
        else: self.status_label.setText(f"{success} created, {fail} failed.")
        if success > 0: self.connectionsCreated.emit()

    def set_source(self, graph_id, node_id, pop_id):
        idx_graph = self.source_graph_combo.findData(graph_id)
        if idx_graph >= 0:
            self.source_graph_combo.setCurrentIndex(idx_graph)
            idx_node = self.source_node_combo.findData(node_id)
            if idx_node >= 0:
                self.source_node_combo.setCurrentIndex(idx_node)
                idx_pop = self.source_pop_combo.findData(pop_id)
                if idx_pop >= 0: self.source_pop_combo.setCurrentIndex(idx_pop)

    def _init_spatial_tab(self):
        layout = QVBoxLayout(self.tab_spatial)
        layout.addWidget(QLabel("Connects neurons based on spatial positions.", styleSheet="color: #AAA; font-style: italic;"))
        
        # ── Rule selection (allow fixed_indegree/outdegree with mask too) ──
        rule_form = QFormLayout()
        self.spatial_rule_combo = QComboBox()
        self.spatial_rule_combo.addItems([
            "pairwise_bernoulli", "fixed_indegree", "fixed_outdegree"
        ])
        self.spatial_rule_combo.setToolTip(
            "pairwise_bernoulli: each pair connects with probability p\n"
            "fixed_indegree:     each target picks N sources within mask\n"
            "fixed_outdegree:    each source picks N targets within mask"
        )
        rule_form.addRow("Connection Rule:", self.spatial_rule_combo)
        self.spatial_indegree_spin = QSpinBox()
        self.spatial_indegree_spin.setRange(1, 100000); self.spatial_indegree_spin.setValue(10)
        self.spatial_outdegree_spin = QSpinBox()
        self.spatial_outdegree_spin.setRange(1, 100000); self.spatial_outdegree_spin.setValue(10)
        self.spatial_indegree_label = QLabel("Indegree (per target):")
        self.spatial_outdegree_label = QLabel("Outdegree (per source):")
        rule_form.addRow(self.spatial_indegree_label, self.spatial_indegree_spin)
        rule_form.addRow(self.spatial_outdegree_label, self.spatial_outdegree_spin)
        # Hide indegree/outdegree until needed
        self.spatial_indegree_label.setVisible(False); self.spatial_indegree_spin.setVisible(False)
        self.spatial_outdegree_label.setVisible(False); self.spatial_outdegree_spin.setVisible(False)
        layout.addLayout(rule_form)
        self.spatial_rule_combo.currentTextChanged.connect(self._on_spatial_rule_changed)
        
        # ── Mask geometry ──
        mask_box = QGroupBox("Mask Geometry")
        mask_layout = QVBoxLayout(mask_box)
        form = QFormLayout()
        self.mask_type_combo = QComboBox()
        self.mask_type_combo.addItems([
            "sphere", "box", "box_asym", "doughnut", "elliptical", "ellipsoidal"
        ])
        self.mask_type_combo.setToolTip(
            "sphere       : symmetric, single radius\n"
            "box          : symmetric cube of side 2·radius\n"
            "box_asym     : independent lower_left / upper_right corners\n"
            "doughnut     : sphere minus inner sphere\n"
            "elliptical   : 2D ellipse — major/minor axes\n"
            "ellipsoidal  : 3D ellipsoid — major/minor/polar axes"
        )
        self.mask_type_combo.currentTextChanged.connect(self._on_mask_type_changed)
        form.addRow("Mask Shape:", self.mask_type_combo)
        self.radius_spin = QDoubleSpinBox()
        self.radius_spin.setRange(0.01, 1000.0); self.radius_spin.setValue(0.5)
        form.addRow("Outer Radius/Size:", self.radius_spin)
        self.inner_radius_spin = QDoubleSpinBox()
        self.inner_radius_spin.setRange(0.0, 1000.0); self.inner_radius_spin.setValue(0.0)
        form.addRow("Inner Radius:", self.inner_radius_spin)
        mask_layout.addLayout(form)
        
        # Asymmetric box fields (only used when mask_type='box_asym')
        self.box_asym_box = QGroupBox("Asymmetric Box (lower_left / upper_right)")
        ab_layout = QVBoxLayout(self.box_asym_box)
        ab_top = QHBoxLayout()
        self.ll_x = QDoubleSpinBox(); self.ll_x.setRange(-1000, 1000); self.ll_x.setValue(-0.5); self.ll_x.setPrefix("ll_x=")
        self.ll_y = QDoubleSpinBox(); self.ll_y.setRange(-1000, 1000); self.ll_y.setValue(-0.5); self.ll_y.setPrefix("ll_y=")
        self.ll_z = QDoubleSpinBox(); self.ll_z.setRange(-1000, 1000); self.ll_z.setValue(-0.5); self.ll_z.setPrefix("ll_z=")
        for w in (self.ll_x, self.ll_y, self.ll_z):
            w.setDecimals(3); w.setSingleStep(0.1); ab_top.addWidget(w)
        ab_layout.addLayout(ab_top)
        ab_bot = QHBoxLayout()
        self.ur_x = QDoubleSpinBox(); self.ur_x.setRange(-1000, 1000); self.ur_x.setValue(0.5); self.ur_x.setPrefix("ur_x=")
        self.ur_y = QDoubleSpinBox(); self.ur_y.setRange(-1000, 1000); self.ur_y.setValue(0.5); self.ur_y.setPrefix("ur_y=")
        self.ur_z = QDoubleSpinBox(); self.ur_z.setRange(-1000, 1000); self.ur_z.setValue(0.5); self.ur_z.setPrefix("ur_z=")
        for w in (self.ur_x, self.ur_y, self.ur_z):
            w.setDecimals(3); w.setSingleStep(0.1); ab_bot.addWidget(w)
        ab_layout.addLayout(ab_bot)
        mask_layout.addWidget(self.box_asym_box)
        self.box_asym_box.setVisible(False)
        
        # Elliptical / ellipsoidal axes
        self.ellipsoid_box = QGroupBox("Ellipsoid Axes")
        el_layout = QHBoxLayout(self.ellipsoid_box)
        self.major_axis_spin = QDoubleSpinBox(); self.major_axis_spin.setRange(0.001, 1000); self.major_axis_spin.setValue(2.0); self.major_axis_spin.setPrefix("major=")
        self.minor_axis_spin = QDoubleSpinBox(); self.minor_axis_spin.setRange(0.001, 1000); self.minor_axis_spin.setValue(1.0); self.minor_axis_spin.setPrefix("minor=")
        self.polar_axis_spin = QDoubleSpinBox(); self.polar_axis_spin.setRange(0.001, 1000); self.polar_axis_spin.setValue(1.0); self.polar_axis_spin.setPrefix("polar=")
        for w in (self.major_axis_spin, self.minor_axis_spin, self.polar_axis_spin):
            w.setDecimals(3); w.setSingleStep(0.1); el_layout.addWidget(w)
        mask_layout.addWidget(self.ellipsoid_box)
        self.ellipsoid_box.setVisible(False)
        
        layout.addWidget(mask_box)
        
        # ── Anchor offset (asymmetric receptive fields) ──
        anchor_box = QGroupBox("Mask Anchor Offset (asymmetric RF)")
        anchor_box.setCheckable(True); anchor_box.setChecked(False)
        anchor_box.setToolTip("Shifts the mask center relative to the source neuron. "
                              "Useful for retinotopic offsets, directional receptive fields.")
        anchor_layout = QHBoxLayout(anchor_box)
        self.anchor_x = QDoubleSpinBox(); self.anchor_x.setRange(-1000, 1000); self.anchor_x.setValue(0.0); self.anchor_x.setPrefix("dx=")
        self.anchor_y = QDoubleSpinBox(); self.anchor_y.setRange(-1000, 1000); self.anchor_y.setValue(0.0); self.anchor_y.setPrefix("dy=")
        self.anchor_z = QDoubleSpinBox(); self.anchor_z.setRange(-1000, 1000); self.anchor_z.setValue(0.0); self.anchor_z.setPrefix("dz=")
        for w in (self.anchor_x, self.anchor_y, self.anchor_z):
            w.setDecimals(3); w.setSingleStep(0.1)
            anchor_layout.addWidget(w)
        self.anchor_box = anchor_box
        layout.addWidget(anchor_box)
        
        # ── Distance-dependent probability ──
        prob_box = QGroupBox("Connection Probability")
        prob_layout_v = QVBoxLayout(prob_box)
        prob_top = QHBoxLayout()
        prob_top.addWidget(QLabel("p_max:"))
        self.spatial_prob_spin = QDoubleSpinBox()
        self.spatial_prob_spin.setRange(0.0, 1.0); self.spatial_prob_spin.setValue(1.0)
        self.spatial_prob_spin.setSingleStep(0.001); self.spatial_prob_spin.setDecimals(4)
        prob_top.addWidget(self.spatial_prob_spin)
        prob_top.addWidget(QLabel("Profile:"))
        self.prob_profile_combo = QComboBox()
        self.prob_profile_combo.addItems(["constant", "gaussian", "exponential", "linear"])
        self.prob_profile_combo.setToolTip(
            "constant: p = p_max\n"
            "gaussian: p = p_max · exp(-d² / (2σ²))\n"
            "exponential: p = p_max · exp(-d / σ)\n"
            "linear: p = p_max · max(0, 1 - d/σ)"
        )
        prob_top.addWidget(self.prob_profile_combo)
        prob_layout_v.addLayout(prob_top)
        prob_sigma_row = QHBoxLayout()
        prob_sigma_row.addWidget(QLabel("σ (decay scale):"))
        self.prob_sigma_spin = QDoubleSpinBox()
        self.prob_sigma_spin.setRange(0.001, 1000.0); self.prob_sigma_spin.setValue(1.0)
        self.prob_sigma_spin.setSingleStep(0.1); self.prob_sigma_spin.setDecimals(3)
        self.prob_sigma_spin.setEnabled(False)
        prob_sigma_row.addWidget(self.prob_sigma_spin)
        prob_sigma_row.addStretch()
        prob_layout_v.addLayout(prob_sigma_row)
        self.prob_profile_combo.currentTextChanged.connect(
            lambda t: self.prob_sigma_spin.setEnabled(t != "constant")
        )
        layout.addWidget(prob_box)
        
        # ── Distance-dependent weight ──
        wbox = QGroupBox("Distance-Dependent Weight")
        wbox.setCheckable(True); wbox.setChecked(False)
        wbox_layout = QVBoxLayout(wbox)
        w_top = QHBoxLayout()
        w_top.addWidget(QLabel("Mode:"))
        self.weight_mode_combo = QComboBox()
        self.weight_mode_combo.addItems(["linear", "exponential", "gaussian"])
        self.weight_mode_combo.setToolTip(
            "linear:      w = base + d · factor + offset\n"
            "exponential: w = base · exp(-d · factor)\n"
            "gaussian:    w = base · exp(-(d/factor)²)   (factor = σ)"
        )
        w_top.addWidget(self.weight_mode_combo)
        w_top.addStretch()
        wbox_layout.addLayout(w_top)
        w_params = QHBoxLayout()
        w_params.addWidget(QLabel("factor:"))
        self.dist_factor_spin = QDoubleSpinBox()
        self.dist_factor_spin.setRange(-1000.0, 1000.0); self.dist_factor_spin.setValue(1.0)
        self.dist_factor_spin.setDecimals(4); self.dist_factor_spin.setSingleStep(0.1)
        w_params.addWidget(self.dist_factor_spin)
        w_params.addWidget(QLabel("offset:"))
        self.dist_offset_spin = QDoubleSpinBox()
        self.dist_offset_spin.setRange(-1000.0, 1000.0); self.dist_offset_spin.setValue(0.0)
        self.dist_offset_spin.setDecimals(4); self.dist_offset_spin.setSingleStep(0.1)
        w_params.addWidget(self.dist_offset_spin)
        wbox_layout.addLayout(w_params)
        self.dist_dep_check = wbox
        self.weight_box = wbox
        layout.addWidget(wbox)
        
        # ── Distance-dependent delay ──
        dbox = QGroupBox("Distance-Dependent Delay (axonal conduction)")
        dbox.setCheckable(True); dbox.setChecked(False)
        dbox.setToolTip(
            "delay(d) = base_delay + d · delay_factor\n"
            "delay_factor in ms per spatial unit (1 / conduction velocity)."
        )
        dbox_layout = QHBoxLayout(dbox)
        dbox_layout.addWidget(QLabel("delay_factor (ms/unit):"))
        self.delay_factor_spin = QDoubleSpinBox()
        self.delay_factor_spin.setRange(0.0, 1000.0); self.delay_factor_spin.setValue(1.0)
        self.delay_factor_spin.setDecimals(4); self.delay_factor_spin.setSingleStep(0.1)
        dbox_layout.addWidget(self.delay_factor_spin)
        dbox_layout.addStretch()
        self.delay_box = dbox
        layout.addWidget(dbox)
        
        # ── Anisotropic (orientation-tuned) weight — gabor / V1-like ──
        anibox = QGroupBox("Anisotropic Weight (orientation tuning)")
        anibox.setCheckable(True); anibox.setChecked(False)
        anibox.setToolTip(
            "Direction-encoded weight using NEST spatial.target_pos / source_pos.\n"
            "cosine: w = base · cos(2π · freq · projection_onto_θ)\n"
            "gabor:  cosine carrier · gaussian envelope (V1 simple-cell-like)\n"
            "Only meaningful when both source and target have spatial layouts."
        )
        ani_layout = QVBoxLayout(anibox)
        ani_top = QHBoxLayout()
        ani_top.addWidget(QLabel("Mode:"))
        self.ani_mode_combo = QComboBox()
        self.ani_mode_combo.addItems(["cosine", "gabor"])
        ani_top.addWidget(self.ani_mode_combo)
        ani_top.addStretch()
        ani_layout.addLayout(ani_top)
        ani_params = QHBoxLayout()
        ani_params.addWidget(QLabel("θ (deg):"))
        self.ani_theta_spin = QDoubleSpinBox()
        self.ani_theta_spin.setRange(-360, 360); self.ani_theta_spin.setValue(0.0)
        self.ani_theta_spin.setSingleStep(15); self.ani_theta_spin.setDecimals(2)
        ani_params.addWidget(self.ani_theta_spin)
        ani_params.addWidget(QLabel("freq (cyc/unit):"))
        self.ani_freq_spin = QDoubleSpinBox()
        self.ani_freq_spin.setRange(0.001, 1000); self.ani_freq_spin.setValue(0.5)
        self.ani_freq_spin.setSingleStep(0.1); self.ani_freq_spin.setDecimals(4)
        ani_params.addWidget(self.ani_freq_spin)
        ani_params.addWidget(QLabel("σ (gabor):"))
        self.ani_sigma_spin = QDoubleSpinBox()
        self.ani_sigma_spin.setRange(0.001, 1000); self.ani_sigma_spin.setValue(1.0)
        self.ani_sigma_spin.setSingleStep(0.1); self.ani_sigma_spin.setDecimals(3)
        ani_params.addWidget(self.ani_sigma_spin)
        ani_layout.addLayout(ani_params)
        self.aniso_box = anibox
        layout.addWidget(anibox)
        
        layout.addStretch()
    
    def _on_spatial_rule_changed(self, rule):
        """Show indegree/outdegree fields only when relevant."""
        is_in = (rule == "fixed_indegree")
        is_out = (rule == "fixed_outdegree")
        self.spatial_indegree_label.setVisible(is_in)
        self.spatial_indegree_spin.setVisible(is_in)
        self.spatial_outdegree_label.setVisible(is_out)
        self.spatial_outdegree_spin.setVisible(is_out)
    
    def _on_mask_type_changed(self, mask_type):
        """Show only the param fields relevant for the chosen mask shape."""
        self.box_asym_box.setVisible(mask_type == "box_asym")
        self.ellipsoid_box.setVisible(mask_type in ("elliptical", "ellipsoidal"))
        # Polar axis is only meaningful for full 3D ellipsoidal
        self.polar_axis_spin.setEnabled(mask_type == "ellipsoidal")

    def _init_topological_tab(self):
        layout = QVBoxLayout(self.tab_topo)
        self.rule_combo = QComboBox()
        self.rule_combo.addItems(["all_to_all", "fixed_indegree", "fixed_outdegree", "fixed_total_number", "pairwise_bernoulli", "one_to_one"])
        self.rule_combo.currentTextChanged.connect(self.on_rule_changed)
        layout.addWidget(QLabel("Connection Rule:"))
        layout.addWidget(self.rule_combo)
        self.topo_params_widget = QWidget(); self.topo_params_layout = QFormLayout(self.topo_params_widget)
        layout.addWidget(self.topo_params_widget)
        self.indegree_spin = QSpinBox(); self.indegree_spin.setRange(1, 100000); self.indegree_spin.setValue(10)
        self.outdegree_spin = QSpinBox(); self.outdegree_spin.setRange(1, 100000); self.outdegree_spin.setValue(10)
        self.total_num_spin = QSpinBox(); self.total_num_spin.setRange(1, 1000000); self.total_num_spin.setValue(100)
        self.topo_prob_spin = QDoubleSpinBox(); self.topo_prob_spin.setRange(0, 1); self.topo_prob_spin.setValue(0.1); self.topo_prob_spin.setDecimals(4); self.topo_prob_spin.setSingleStep(0.001)
        self.on_rule_changed("all_to_all"); layout.addStretch()

    def on_rule_changed(self, rule):
        while self.topo_params_layout.count():
            item = self.topo_params_layout.takeAt(0)
            if item.widget(): item.widget().setParent(None)
        if rule == "fixed_indegree": self.topo_params_layout.addRow("Indegree:", self.indegree_spin)
        elif rule == "fixed_outdegree": self.topo_params_layout.addRow("Outdegree:", self.outdegree_spin)
        elif rule == "fixed_total_number": self.topo_params_layout.addRow("Total Connections:", self.total_num_spin)
        elif "bernoulli" in rule: self.topo_params_layout.addRow("Probability:", self.topo_prob_spin)

    def on_synapse_model_changed(self, model_name):
        while self.dynamic_syn_params_layout.count():
            item = self.dynamic_syn_params_layout.takeAt(0)
            if item.widget(): item.widget().deleteLater()
        self.syn_param_widgets.clear()
        
        # Toggle DA-source picker visibility — only dopa synapses need it
        if hasattr(self, 'da_group'):
            self.da_group.setVisible('stdp_dopamine' in (model_name or ''))
        
        if model_name not in SYNAPSE_MODELS: return
        params = SYNAPSE_MODELS[model_name]
        
        for param_name, info in params.items():
            if param_name in ['weight', 'delay']: continue
            
            p_type = info.get('type', 'float'); p_default = info.get('default', 0.0)
            p_min = info.get('min', -1000000.0)
            p_max = info.get('max', 1000000.0)
            p_decimals = info.get('decimals', 2)
            p_step = info.get('step', None)
            widget = None
            if p_type == 'float':
                widget = DoubleInputField(
                    param_name, default_value=float(p_default),
                    min_val=float(p_min), max_val=float(p_max),
                    decimals=int(p_decimals), step=p_step,
                )
            elif p_type == 'integer':
                widget = IntegerInputField(
                    param_name, default_value=int(p_default),
                    min_val=int(p_min), max_val=int(p_max),
                )
            if widget:
                self.dynamic_syn_params_layout.addWidget(widget)
                self.syn_param_widgets[param_name] = widget

    def _get_current_params(self):
        is_spatial = (self.tabs.currentIndex() == 0)
        params = {
            'synapse_model': self.syn_model_combo.currentText(),
            'weight': self.weight_spin.value(),
            'delay': self.delay_spin.value(),
            'allow_autapses': self.allow_autapses_check.isChecked(),
            'allow_multapses': self.allow_multapses_check.isChecked(),
            'receptor_type': self.receptor_spin.value(),
            'use_spatial': is_spatial
        }
        if is_spatial:
            rule = self.spatial_rule_combo.currentText()
            params.update({
                'rule': rule,
                'p': self.spatial_prob_spin.value(),
                'mask_type': self.mask_type_combo.currentText(),
                'mask_radius': self.radius_spin.value(),
                'mask_inner_radius': self.inner_radius_spin.value(),
                # Asymmetric box corners (used when mask_type='box_asym')
                'lower_left': [self.ll_x.value(), self.ll_y.value(), self.ll_z.value()],
                'upper_right': [self.ur_x.value(), self.ur_y.value(), self.ur_z.value()],
                # Ellipsoid axes (used when mask_type='elliptical' or 'ellipsoidal')
                'major_axis': self.major_axis_spin.value(),
                'minor_axis': self.minor_axis_spin.value(),
                'polar_axis': self.polar_axis_spin.value(),
                # Distance-dependent weight (group-box checked = enabled)
                'distance_dependent_weight': self.weight_box.isChecked(),
                'weight_mode': self.weight_mode_combo.currentText(),
                'dist_factor': self.dist_factor_spin.value(),
                'dist_offset': self.dist_offset_spin.value(),
                # Distance-dependent probability profile
                'p_profile': self.prob_profile_combo.currentText(),
                'p_sigma': self.prob_sigma_spin.value(),
                # Distance-dependent delay
                'distance_dependent_delay': self.delay_box.isChecked(),
                'delay_factor': self.delay_factor_spin.value(),
                # Anchor offset
                'use_anchor': self.anchor_box.isChecked(),
                'anchor': [
                    self.anchor_x.value(),
                    self.anchor_y.value(),
                    self.anchor_z.value(),
                ],
                # Anisotropic (orientation-tuned) weight
                'anisotropic_weight': self.aniso_box.isChecked(),
                'aniso_mode': self.ani_mode_combo.currentText(),
                'aniso_theta_deg': self.ani_theta_spin.value(),
                'aniso_freq': self.ani_freq_spin.value(),
                'aniso_sigma': self.ani_sigma_spin.value(),
            })
            # Include indegree/outdegree only when the chosen rule needs it
            if rule == 'fixed_indegree':
                params['indegree'] = self.spatial_indegree_spin.value()
            elif rule == 'fixed_outdegree':
                params['outdegree'] = self.spatial_outdegree_spin.value()
        else:
            rule = self.rule_combo.currentText(); params['rule'] = rule
            if rule == 'fixed_indegree': params['indegree'] = self.indegree_spin.value()
            elif rule == 'fixed_outdegree': params['outdegree'] = self.outdegree_spin.value()
            elif rule == 'fixed_total_number': params['N'] = self.total_num_spin.value()
            elif 'bernoulli' in rule: params['p'] = self.topo_prob_spin.value()
        for name, widget in self.syn_param_widgets.items(): params[name] = widget.get_value()
        return params


class ConnectionQueueWidget(QWidget):
    
    connectionSelected = pyqtSignal(int)
    connectionRemoved = pyqtSignal(int)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.connections: List[Dict] = []
        self._init_ui()
        
    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        
        header = QLabel("Connection Queue")
        header.setStyleSheet("font-weight: bold;")
        layout.addWidget(header)
        
        self.list_widget = QListWidget()
        self.list_widget.setAlternatingRowColors(True)
        self.list_widget.itemClicked.connect(self._on_item_clicked)
        layout.addWidget(self.list_widget)
        
        btn_layout = QHBoxLayout()
        
        self.remove_btn = QPushButton("Remove")
        self.remove_btn.clicked.connect(self._remove_selected)
        self.remove_btn.setEnabled(False)
        btn_layout.addWidget(self.remove_btn)
        
        clear_btn = QPushButton("Clear All")
        clear_btn.clicked.connect(self.clear_all)
        btn_layout.addWidget(clear_btn)
        
        layout.addLayout(btn_layout)
        
        self.status_label = QLabel("0 connections")
        self.status_label.setStyleSheet("color: #888; font-size: 10px;")
        layout.addWidget(self.status_label)
    
    def add_connection(self, conn: Dict):
        self.connections.append(conn)
        
        name = conn.get('name', f"Connection {len(self.connections)}")
        src = conn.get('source', {})
        tgt = conn.get('target', {})
        
        label = f"{name}: G{src.get('graph_id',0)}N{src.get('node_id',0)}P{src.get('pop_id',0)} → " \
                f"G{tgt.get('graph_id',0)}N{tgt.get('node_id',0)}P{tgt.get('pop_id',0)}"
        
        item = QListWidgetItem(label)
        
        syn = conn.get('params', {}).get('synapse_model', 'static')
        if 'stdp' in syn:
            item.setBackground(QColor(100, 50, 150, 50))
        elif 'gap' in syn:
            item.setBackground(QColor(50, 150, 100, 50))
        elif 'tsodyks' in syn or 'stp' in syn:
            item.setBackground(QColor(150, 100, 50, 50))
        
        self.list_widget.addItem(item)
        self._update_status()
    
    def _on_item_clicked(self, item):
        idx = self.list_widget.row(item)
        self.remove_btn.setEnabled(True)
        self.connectionSelected.emit(idx)
    
    def _remove_selected(self):
        idx = self.list_widget.currentRow()
        if idx >= 0:
            self.list_widget.takeItem(idx)
            del self.connections[idx]
            self.connectionRemoved.emit(idx)
            self._update_status()
        self.remove_btn.setEnabled(False)
    
    def clear_all(self):
        self.list_widget.clear()
        self.connections.clear()
        self._update_status()
    
    def get_all_connections(self) -> List[Dict]:
        return self.connections.copy()
    
    def _update_status(self):
        n = len(self.connections)
        self.status_label.setText(f"{n} connection{'s' if n != 1 else ''}")
