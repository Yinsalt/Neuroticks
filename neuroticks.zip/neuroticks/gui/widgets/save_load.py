"""Speichern/Laden-Buttons und einfache Simulationssteuerung."""
from PyQt6.QtWidgets import (
    QFileDialog, QHBoxLayout, QMessageBox, QPushButton, QSizePolicy, QVBoxLayout, QWidget,
)

from neuron_toolbox import Graph
from neuroticks.utils.serialization import load_graph, save_graph

class SaveLoadWidget(QWidget):
    
    def __init__(self, main_window, Graph_class=None, parent=None):
        super().__init__(parent)
        self.main_window = main_window
        self.Graph_class = Graph_class
        self.setup_ui()
    
    def setup_ui(self):
        layout = QHBoxLayout(self)
        layout.setContentsMargins(5, 5, 5, 5)
        layout.setSpacing(10)
        
        self.save_btn = QPushButton("Save Graph")
        self.save_btn.setMinimumWidth(100)
        self.save_btn.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover { background-color: #45a049; }
            QPushButton:pressed { background-color: #3d8b40; }
        """)
        self.save_btn.clicked.connect(self.save_graph_dialog)
        
        self.load_btn = QPushButton("Load Graph")
        self.load_btn.setMinimumWidth(100)
        self.load_btn.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover { background-color: #1976D2; }
            QPushButton:pressed { background-color: #1565C0; }
        """)
        self.load_btn.clicked.connect(self.load_graph_dialog)
        
        layout.addWidget(self.save_btn)
        layout.addWidget(self.load_btn)
        layout.addStretch()

    def save_graph_dialog(self):
        if not hasattr(self.main_window, 'graph_list') or not self.main_window.graph_list:
            QMessageBox.warning(self, "No Graph", "no graph available")
            return
        
        current_idx = getattr(self.main_window, 'current_graph_idx', -1)
        if current_idx < 0 or current_idx >= len(self.main_window.graph_list):
            current_idx = len(self.main_window.graph_list) - 1
        
        graph = self.main_window.graph_list[current_idx]
        
        filepath, _ = QFileDialog.getSaveFileName(
            self, "Graph speichern",
            f"{getattr(graph, 'graph_name', 'graph')}.json",
            "JSON Files (*.json);;All Files (*)"
        )
        
        if filepath:
            if not filepath.endswith('.json'):
                filepath += '.json'
            
            success = save_graph(graph, filepath)
            
            if success:
                QMessageBox.information(self, "Gespeichert",
                    f"Graph '{graph.graph_name}' erfolgreich gespeichert!")
            else:
                QMessageBox.critical(self, "Fehler",
                    "Fehler beim Speichern des Graphs!")

    def load_graph_dialog(self):
        filepath, _ = QFileDialog.getOpenFileName(
            self, "Load Graph", "",
            "JSON Files (*.json);;All Files (*)"
        )
        
        if not filepath:
            return
        
        GraphClass = self.Graph_class
        if GraphClass is None and hasattr(self.main_window, 'Graph'):
            GraphClass = self.main_window.Graph
        
        if GraphClass is None:
            GraphClass = Graph
        
        if GraphClass is None:
            QMessageBox.critical(self, "Error", "Graph type not available")
            return
        
        graph = load_graph(filepath, GraphClass)
        
        if graph:
            if hasattr(self.main_window, 'graph_list'):
                self.main_window.graph_list.append(graph)
            
            if hasattr(self.main_window, 'update_visualizations'):
                self.main_window.update_visualizations()
            if hasattr(self.main_window, 'graph_overview'):
                self.main_window.graph_overview.update_tree()
            
            QMessageBox.information(self, "Loaded",
                f"Graph '{graph.graph_name}' loaded.\nNodes: {len(graph.node_list)}")
        else:
            QMessageBox.critical(self, "Error", "Loading Error!")

def add_save_load_buttons(main_window, Graph_class=None, target_layout=None):
    
    widget = SaveLoadWidget(main_window, Graph_class)
    
    if target_layout:
        target_layout.addWidget(widget)
    elif hasattr(main_window, 'statusBar'):
        main_window.statusBar().addPermanentWidget(widget)
    else:
        widget.setParent(main_window)
        widget.move(main_window.width() - 260, main_window.height() - 60)
        widget.show()
    
    main_window.save_load_widget = widget
    print("Save/Load buttons added")
    return widget

class SimulationControlWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.init_ui()
        
    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(2)
        
        btn_style = """
            QPushButton {
                border: none;
                border-radius: 0px; /* Eckig, um Lücken zu füllen */
                font-weight: bold;
                font-size: 14px;
            }
            QPushButton:hover { border: 2px solid rgba(255,255,255,0.3); }
        """
        
        start_style = btn_style + "QPushButton { background-color: #4CAF50; color: white; }"
        stop_style = btn_style + "QPushButton { background-color: #F44336; color: white; }"
        io_style = btn_style + "QPushButton { background-color: #2196F3; color: white; }"
        
        self.btn_start = QPushButton("RUN SIMULATION")
        self.btn_start.setStyleSheet(start_style)
        
        self.btn_stop = QPushButton("STOP SIMULATION")
        self.btn_stop.setStyleSheet(stop_style)
        
        self.btn_save = QPushButton("SAVE GRAPHS")
        self.btn_save.setStyleSheet(io_style)
    
        self.btn_load = QPushButton("LOAD GRAPHS")
        self.btn_load.setStyleSheet(io_style)
        
        for btn in [self.btn_start, self.btn_stop, self.btn_save, self.btn_load]:
            btn.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        
        layout.addWidget(self.btn_start)
        layout.addWidget(self.btn_stop)
        layout.addWidget(self.btn_save)
        layout.addWidget(self.btn_load)
