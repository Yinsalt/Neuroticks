"""Devices (Recorder, Generatoren): Zielauswahl, Konfiguration, Werkzeugleiste."""
import nest
import numpy as np
from PyQt6.QtCore import pyqtSignal, Qt
from PyQt6.QtGui import QColor
from PyQt6.QtWidgets import (
    QComboBox, QDoubleSpinBox, QFormLayout, QFrame, QGroupBox, QHBoxLayout, QLabel,
    QLineEdit, QPushButton, QStackedWidget, QTextEdit, QVBoxLayout, QWidget,
)

from neuroticks import state
from neuroticks.utils.nest_helpers import safe_get_model

class DeviceTargetSelector(QGroupBox):

    def __init__(self, graph_list, parent=None):
        super().__init__("Target Selection", parent)
        self.graph_list = graph_list
        self.setStyleSheet("QGroupBox { border: 1px solid #444; border-radius: 5px; margin-top: 10px; font-weight: bold; color: #ddd; } QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 3px; }")
        self.init_ui()

    def init_ui(self):
        layout = QFormLayout(self)
        
        self.combo_graph = QComboBox()
        self.combo_node = QComboBox()
        self.combo_pop = QComboBox()
        
        layout.addRow("Graph:", self.combo_graph)
        layout.addRow("Node:", self.combo_node)
        layout.addRow("Population:", self.combo_pop)
        
        self.combo_graph.currentIndexChanged.connect(self.on_graph_changed)
        self.combo_node.currentIndexChanged.connect(self.on_node_changed)
        
        self.refresh()

    def refresh(self):
        self.combo_graph.blockSignals(True)
        self.combo_graph.clear()
        for graph in self.graph_list:
            name = getattr(graph, 'graph_name', f'Graph {graph.graph_id}')
            self.combo_graph.addItem(f"{name} (ID: {graph.graph_id})", graph.graph_id)
        self.combo_graph.blockSignals(False)
        
        if self.graph_list:
            self.on_graph_changed()

    def on_graph_changed(self):
        self.combo_node.blockSignals(True)
        self.combo_node.clear()
        
        graph_id = self.combo_graph.currentData()
        graph = next((g for g in self.graph_list if g.graph_id == graph_id), None)
        
        if graph:
            for node in graph.node_list:
                self.combo_node.addItem(f"{node.name} (ID: {node.id})", node.id)
        
        self.combo_node.blockSignals(False)
        self.on_node_changed()

    def on_node_changed(self):
        self.combo_pop.clear()
        graph_id = self.combo_graph.currentData()
        node_id = self.combo_node.currentData()
        
        graph = next((g for g in self.graph_list if g.graph_id == graph_id), None)
        if graph:
            node = next((n for n in graph.node_list if n.id == node_id), None)
            if node and hasattr(node, 'population'):
                for i, pop in enumerate(node.population):
                    model = safe_get_model(pop, "empty")
                    self.combo_pop.addItem(f"Pop {i}: {model}", i)

    def get_selection(self):
        return {
            'graph_id': self.combo_graph.currentData(),
            'node_id': self.combo_node.currentData(),
            'pop_id': self.combo_pop.currentData()
        }


class DeviceConfigPage(QWidget):
    deviceCreated = pyqtSignal(dict)
    deviceUpdated = pyqtSignal(dict, dict)

    def __init__(self, device_label, device_type, graph_list, parent=None):
        super().__init__(parent)
        self.device_type = device_type
        self.device_label = device_label
        self.graph_list = graph_list
        self.param_widgets = {}
        self.current_edit_device = None
        
        self.init_ui()

    def init_ui(self):
        main_layout = QHBoxLayout(self)
        
        left_container = QWidget()
        left_layout = QVBoxLayout(left_container)
        left_layout.setContentsMargins(0,0,0,0)
        
        self.target_selector = DeviceTargetSelector(self.graph_list)
        left_layout.addWidget(self.target_selector)
        left_layout.addStretch()
        
        right_container = QWidget()
        right_layout = QVBoxLayout(right_container)
        
        self.header_label = QLabel(f"Configure {self.device_label}")
        self.header_label.setStyleSheet(f"font-size: 14px; font-weight: bold; color: {self._get_color()}; margin-bottom: 5px;")
        right_layout.addWidget(self.header_label)
        
        form_group = QGroupBox("Device Parameters")
        self.form_layout = QFormLayout(form_group)
        
        self._build_parameters()
        
        right_layout.addWidget(form_group)
        right_layout.addStretch()
        
        base_btn_style = """
            QPushButton {
                color: white; 
                font-weight: bold; 
                font-size: 14px;
                border-radius: 4px;
                padding: 5px;
            }
            QPushButton:pressed {
                margin-top: 2px;
                border-bottom: 0px solid;
            }
        """
        
        c_main = self._get_color()
        c_dark = QColor(c_main).darker(150).name()
        
        style_create = base_btn_style + f"""
            QPushButton {{
                background-color: {c_main};
                border-bottom: 3px solid {c_dark};
            }}
            QPushButton:hover {{ background-color: {QColor(c_main).lighter(110).name()}; }}
        """
        
        style_save = base_btn_style + """
            QPushButton {
                background-color: #4CAF50;
                border-bottom: 3px solid #2E7D32;
            }
            QPushButton:hover { background-color: #66BB6A; }
        """
        
        style_cancel = base_btn_style + """
            QPushButton {
                background-color: #607D8B;
                border-bottom: 3px solid #455A64;
                font-size: 12px;
            }
            QPushButton:hover { background-color: #78909C; }
        """

        self.btn_create = QPushButton(f"✚ Create {self.device_label}")
        self.btn_create.setMinimumHeight(45)
        self.btn_create.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_create.setStyleSheet(style_create)
        self.btn_create.clicked.connect(self.create_device)
        right_layout.addWidget(self.btn_create)

        self.btn_save = QPushButton(f"Save Changes & Reset")
        self.btn_save.setMinimumHeight(45)
        self.btn_save.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_save.setStyleSheet(style_save)
        self.btn_save.clicked.connect(self.update_device)
        self.btn_save.setVisible(False)
        right_layout.addWidget(self.btn_save)
        
        self.btn_cancel = QPushButton("Cancel Edit")
        self.btn_cancel.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_cancel.setStyleSheet(style_cancel)
        self.btn_cancel.clicked.connect(self.reset_to_create_mode)
        self.btn_cancel.setVisible(False)
        right_layout.addWidget(self.btn_cancel)

        main_layout.addWidget(left_container, 1)
        main_layout.addWidget(right_container, 2)

    def load_device_data(self, device_data):
        print(f"Loading data into editor for: {device_data.get('model')}")
        self.current_edit_device = device_data
        
        self.header_label.setText(f"EDIT MODE: {self.device_label} (ID: {device_data.get('id')})")
        self.header_label.setStyleSheet(f"font-size: 14px; font-weight: bold; color: #4CAF50; border-bottom: 2px solid #4CAF50;")
        
        self.btn_create.setVisible(False)
        self.btn_save.setVisible(True)
        self.btn_cancel.setVisible(True)
        
        target = device_data.get('target', {})
        gid = target.get('graph_id')
        idx_g = self.target_selector.combo_graph.findData(gid)
        if idx_g >= 0:
            self.target_selector.combo_graph.setCurrentIndex(idx_g)
            self.target_selector.on_graph_changed()
        
        nid = target.get('node_id')
        idx_n = self.target_selector.combo_node.findData(nid)
        if idx_n >= 0:
            self.target_selector.combo_node.setCurrentIndex(idx_n)
            self.target_selector.on_node_changed()
        
        pid = target.get('pop_id')
        idx_p = self.target_selector.combo_pop.findData(pid)
        if idx_p >= 0:
            self.target_selector.combo_pop.setCurrentIndex(idx_p)
        
        params = device_data.get('params', {})
        conn_params = device_data.get('conn_params', {})
        all_data = {**params, **conn_params}
        
        if 'weight' in conn_params: all_data['conn_weight'] = conn_params['weight']
        if 'delay' in conn_params: all_data['conn_delay'] = conn_params['delay']

        for key, widget in self.param_widgets.items():
            if key in all_data:
                val = all_data[key]
                if isinstance(widget, QDoubleSpinBox):
                    try: widget.setValue(float(val))
                    except (ValueError, TypeError): pass
                elif isinstance(widget, QLineEdit):
                    if isinstance(val, list):
                        widget.setText(", ".join(map(str, val)))
                    else:
                        widget.setText(str(val))

    def reset_to_create_mode(self):
        self.current_edit_device = None
        
        self.header_label.setText(f"Configure {self.device_label}")
        self.header_label.setStyleSheet(f"font-size: 14px; font-weight: bold; color: {self._get_color()};")
        
        self.btn_create.setVisible(True)
        self.btn_save.setVisible(False)
        self.btn_cancel.setVisible(False)
        

    def _gather_data(self):
        target = self.target_selector.get_selection()
        if target['graph_id'] is None:
            print("No target selected!")
            return None

        device_params = {}
        conn_params = {}
        
        periodic_config = {}
        
        for key, widget in self.param_widgets.items():
            val = None
            if isinstance(widget, QDoubleSpinBox):
                val = widget.value()
            elif isinstance(widget, QLineEdit):
                text_val = widget.text()
                if key in ["amplitude_times", "amplitude_values", "spike_times"]:
                    val = self._parse_list_input(text_val, dtype=float)
                elif key == "spike_multiplicities":
                    val = self._parse_list_input(text_val, dtype=int)
                elif key == "record_from":
                    cleaned = text_val.replace('[', '').replace(']', '').replace('"', '').replace("'", "")
                    parts = [s.strip() for s in cleaned.split(',') if s.strip()]
                    val = parts if parts else ["V_m"]
                else:
                    val = text_val
            
            if key.startswith("conn_"):
                clean_key = key.replace("conn_", "")
                conn_params[clean_key] = val
            elif key.startswith("gen_p_"):
                periodic_config[key] = val
            else:
                if val is not None:
                    device_params[key] = val
        
        if "spike_generator" in self.device_type:
            p_int = periodic_config.get("gen_p_interval", 0.0)
            p_start = periodic_config.get("gen_p_start", 0.0)
            p_stop = periodic_config.get("gen_p_stop", 0.0)
            
            manual_times = device_params.get("spike_times", [])
            
            if p_int > 0.0001 and p_stop > p_start:
                generated_times = np.arange(p_start, p_stop, p_int).tolist()
                print(f"Auto-Generated {len(generated_times)} spikes (Interval {p_int}ms)")
                
                all_times = sorted(list(set(manual_times + generated_times)))
                device_params["spike_times"] = all_times
                
                if "spike_multiplicities" in device_params and device_params["spike_multiplicities"]:
                    del device_params["spike_multiplicities"]

        return {
            "model": self.device_type,
            "target": target,
            "params": device_params,
            "conn_params": conn_params
        }

    def create_device(self):
        data = self._gather_data()
        if data:
            self.deviceCreated.emit(data)

    def update_device(self):
        if self.current_edit_device is None: return
        
        new_data = self._gather_data()
        if new_data:
            new_data['id'] = self.current_edit_device.get('id')
            self.deviceUpdated.emit(self.current_edit_device, new_data)
            self.reset_to_create_mode()

    def _get_color(self):
        if "generator" in self.device_type: return "#FF9800"
        if "recorder" in self.device_type or "meter" in self.device_type: return "#E91E63"
        return "#999"

    def _build_parameters(self):
        self.form_layout.addRow(QLabel("--- Device Settings ---"))
        
        if "recorder" in self.device_type or "meter" in self.device_type:
             self._add_param("start", 0.0, "Start Time (ms)")
             self._add_param("stop", 10000.0, "Stop Time (ms)")
        
        if "poisson_generator" in self.device_type:
            self._add_param("rate", 1000.0, "Rate (Hz)")
            self._add_param("start", 0.0, "Start Time (ms)")
            self._add_param("stop", 10000.0, "Stop Time (ms)")

        elif "noise_generator" in self.device_type:
            self._add_param("mean", 0.0, "Mean (pA)")
            self._add_param("std", 200.0, "Std Dev (pA)")
            self._add_param("dt", 1.0, "Time Step (ms)")
            self._add_param("start", 0.0, "Start (ms)")

        elif "dc_generator" in self.device_type:
            self._add_param("amplitude", 100.0, "Amplitude (pA)")
            self._add_param("start", 0.0, "Start (ms)")
            self._add_param("stop", 10000.0, "Stop (ms)")

        elif "ac_generator" in self.device_type:
            self._add_param("amplitude", 50.0, "Amplitude (pA)")
            self._add_param("frequency", 10.0, "Frequency (Hz)")
            self._add_param("phase", 0.0, "Phase (deg)")
            self._add_param("offset", 0.0, "Offset (pA)")
            
        elif "step_current_generator" in self.device_type:
            self._add_text_param("amplitude_times", "100.0, 300.0, 500.0", "Times (ms)")
            self._add_text_param("amplitude_values", "100.0, 0.0, -50.0", "Currents (pA)")
            
        elif "spike_generator" in self.device_type:
             self.form_layout.addRow(QLabel("<b>Manual Spikes:</b>"))
             self._add_text_param("spike_times", "10.0, 20.5", "Exact Times (ms)")
             self._add_text_param("spike_multiplicities", "", "Multiplicities")
             
             self.form_layout.addRow(QLabel("<b>Periodic Pattern (Optional):</b>"))
             self._add_param("gen_p_start", 0.0, "Start (ms)")
             self._add_param("gen_p_stop", 1000.0, "Stop (ms)")
             self._add_param("gen_p_interval", 0.0, "Interval (ms, 0=Off)")
             self.form_layout.addRow(QLabel("<small style='color:#888'>If Interval > 0, spikes are auto-generated.</small>"))
             
        elif "recorder" in self.device_type:
            self._add_text_param("label", "record", "File Label")
            
        elif "multimeter" in self.device_type:
            self._add_param("interval", 1.0, "Recording Interval (ms)")
            self._add_text_param("record_from", "V_m", "Record (e.g. V_m)")
            
        elif "voltmeter" in self.device_type:
            self._add_param("interval", 1.0, "Recording Interval (ms)")

        self.form_layout.addRow(QLabel("--- Connection Settings ---"))
        default_weight = 10.0 if "generator" in self.device_type else 1.0
        self._add_param("conn_weight", default_weight, "Synapse Weight (pA)")
        self._add_param("conn_delay", 1.0, "Synapse Delay (ms)")

    def _add_param(self, key, default, label):
        spin = QDoubleSpinBox()
        spin.setRange(-1e6, 1e6)
        spin.setDecimals(2)
        spin.setValue(default)
        self.form_layout.addRow(label, spin)
        self.param_widgets[key] = spin

    def _add_text_param(self, key, default, label):
        le = QLineEdit(str(default))
        self.form_layout.addRow(label, le)
        self.param_widgets[key] = le

    def _parse_list_input(self, text, dtype=float):
        if not text.strip(): return []
        try:
            cleaned = text.replace('[', '').replace(']', '')
            parts = cleaned.split(',')
            return [dtype(p.strip()) for p in parts if p.strip()]
        except (ValueError, TypeError): return []


class ToolsWidget(QWidget):
    deviceAdded = pyqtSignal()
    def __init__(self):
        super().__init__()
        self.graph_list = []
        self.button_map = {}
        self.init_ui()
        
    def update_graphs(self, graph_list):
        self.graph_list = graph_list
        current_widget = self.config_stack.currentWidget()
        if isinstance(current_widget, DeviceConfigPage):
            current_widget.target_selector.graph_list = graph_list
            current_widget.target_selector.refresh()
            
    def init_ui(self):
        main_layout = QHBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        
        menu_container = QWidget()
        menu_container.setFixedWidth(160)
        menu_container.setStyleSheet("background-color: #232323; border-right: 1px solid #444;")
        menu_layout = QVBoxLayout(menu_container)
        
        lbl_menu = QLabel("TOOLBOX")
        lbl_menu.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lbl_menu.setStyleSheet("color: #888; font-weight: bold; font-size: 10px; letter-spacing: 1px;")
        menu_layout.addWidget(lbl_menu)
        
        self.devices = [
            ("Spike Recorder", "spike_recorder", "#E91E63"),
            ("Voltmeter", "voltmeter", "#E91E63"),
            ("Multimeter", "multimeter", "#E91E63"),
            None,
            ("Poisson Gen", "poisson_generator", "#FF9800"),
            ("Noise Gen", "noise_generator", "#FF9800"),
            ("DC Gen", "dc_generator", "#FF9800"),
            ("AC Gen", "ac_generator", "#FF9800"),
            ("Step Current", "step_current_generator", "#FF9800"),
            ("Spike Gen", "spike_generator", "#FF9800"),
        ]
        
        self.config_stack = QStackedWidget()
        
        self.help_page = DeviceHelpWidget()
        self.config_stack.addWidget(self.help_page)
        
        self.btn_group = []

        for item in self.devices:
            if item is None:
                line = QFrame()
                line.setFrameShape(QFrame.Shape.HLine)
                line.setStyleSheet("color: #444;")
                menu_layout.addWidget(line)
                continue
                
            label, model, color = item
            
            btn = QPushButton(label)
            btn.setCheckable(True)
            btn.setStyleSheet(f"""
                QPushButton {{
                    text-align: left; padding: 8px; border: none; background: transparent; color: #bbb; border-left: 3px solid transparent;
                }}
                QPushButton:checked {{ background: #333; color: white; border-left: 3px solid {color}; }}
                QPushButton:hover {{ background: #2c2c2c; }}
            """)
            
            page = DeviceConfigPage(label, model, self.graph_list)
            page.deviceCreated.connect(self.on_device_created)
            
            idx = self.config_stack.addWidget(page)
            btn.clicked.connect(lambda checked, i=idx, b=btn: self.switch_tool(i, b))
            
            self.button_map[btn] = idx
            self.btn_group.append(btn)
            menu_layout.addWidget(btn)
            
        menu_layout.addStretch()
        
        main_layout.addWidget(menu_container)
        main_layout.addWidget(self.config_stack)
        
    def switch_tool(self, index, clicked_btn):
        current = self.config_stack.currentWidget()
        if isinstance(current, DeviceConfigPage):
            current.reset_to_create_mode()

        for btn in self.button_map:
            btn.setChecked(btn == clicked_btn)
            
        self.config_stack.setCurrentIndex(index)
        
        widget = self.config_stack.widget(index)
        if isinstance(widget, DeviceConfigPage):
            widget.target_selector.graph_list = self.graph_list
            widget.target_selector.refresh()
            widget.reset_to_create_mode()

    def reset_view(self):
        self.config_stack.setCurrentIndex(0)
        for btn in self.button_map:
            btn.setChecked(False)

    def open_device_editor(self, device_data):
        model = device_data.get('model')
        target_index = -1
        target_widget = None
        
        for i in range(self.config_stack.count()):
            widget = self.config_stack.widget(i)
            if isinstance(widget, DeviceConfigPage):
                if widget.device_type == model:
                    target_index = i
                    target_widget = widget
                    break
        
        if target_widget:
            for btn, idx in self.button_map.items():
                btn.setChecked(idx == target_index)
            
            self.config_stack.setCurrentIndex(target_index)
            
            target_widget.target_selector.graph_list = self.graph_list
            target_widget.target_selector.refresh()
            target_widget.load_device_data(device_data)
        else:
            print(f"No editor for '{model}' found.")

    def on_device_created(self, data):
        
        model_name = data['model']
        print(f"\nCreating Device: {model_name}")
        
        if state._nest_simulation_has_run:
            print(" NEST Reset (Simulation has run)...")
            try:
                nest.ResetKernel()
                state._nest_simulation_has_run = False
                for graph in self.graph_list:
                    for node in graph.node_list:
                        if not hasattr(node, 'positions') or not node.positions: node.build()
                        elif all(len(p) == 0 for p in node.positions if p is not None): node.build()
                        node.populate_node()
                print("  ✓ Reset Done")
            except Exception as e:
                print(f"  Reset failed: {e}")
                return
        
        target = data['target']
        graph_id = target['graph_id']
        node_id = target['node_id']
        pop_id = target['pop_id']
        
        target_graph = next((g for g in self.graph_list if g.graph_id == graph_id), None)
        if not target_graph:
            print(f"Error: Graph {graph_id} not found.")
            return
            
        target_node = next((n for n in target_graph.node_list if n.id == node_id), None)
        if not target_node:
            print(f"Error: Node {node_id} not found.")
            return
        
        conn_params = data.get('conn_params', {})
        
        if not hasattr(target_node, 'devices'): target_node.devices = []
        if 'devices' not in target_node.parameters: target_node.parameters['devices'] = []
        
        existing_devs = target_node.parameters['devices']
        if existing_devs:
            int_ids = [d.get('id', 0) for d in existing_devs if isinstance(d.get('id'), int)]
            if int_ids:
                current_max_id = max(int_ids)
                next_dev_id = current_max_id + 1
            else:
                next_dev_id = 0
        else:
            next_dev_id = 0
            
        device_record = {
            "id": next_dev_id,
            "model": model_name,
            "target_pop_id": pop_id,
            "params": data['params'],
            "conn_params": conn_params,
            "runtime_gid": None
        }
            
        # FIX: node.parameters['devices'] und node.devices teilen sich oft dieselbe
        # Listen-Referenz (shallow copy). Dann appenden beide Aufrufe auf DIESELBE Liste
        # -> Device wird doppelt eingetragen.
        if 'devices' not in target_node.parameters:
            target_node.parameters['devices'] = []
        target_node.parameters['devices'].append(device_record)
        # Nur zusaetzlich appenden, wenn es wirklich separate Listen sind
        if target_node.devices is not target_node.parameters['devices']:
            target_node.devices.append(device_record)
        print(f"  ✓ Saved to Node Parameters (Total: {len(target_node.parameters['devices'])})")

        try:
            nest_device = nest.Create(model_name, params=data['params'])
            device_record['runtime_gid'] = nest_device
            print(f"  ✓ NEST ID: {nest_device}")
            
            if pop_id >= len(target_node.population):
                raise ValueError(f"Population index {pop_id} out of range.")

            pop_nest = target_node.population[pop_id]
            weight = float(conn_params.get('weight', 1.0))
            delay = max(float(conn_params.get('delay', 1.0)), 0.1)
            
            syn_spec = {'synapse_model': 'static_synapse', 'weight': weight, 'delay': delay}
            
            is_source = False
            if "generator" in model_name or "stimulator" in model_name: is_source = True
            elif "meter" in model_name: is_source = True
            
            if is_source:
                nest.Connect(nest_device, pop_nest, syn_spec=syn_spec)
                direction_str = "-> Population (Source)"
            else:
                nest.Connect(pop_nest, nest_device, syn_spec=syn_spec)
                direction_str = "<- Population (Target)"
                
            print(f"  ✓ Connected: {model_name} {direction_str} (W={weight}, D={delay})")
            
            self.reset_view()
            self.deviceAdded.emit()
            
        except Exception as e:
            print(f" Error creating device in NEST: {e}")
            import traceback; traceback.print_exc()
            if device_record in target_node.parameters['devices']: target_node.parameters['devices'].remove(device_record)
            if device_record in target_node.devices: target_node.devices.remove(device_record)
            from PyQt6.QtWidgets import QMessageBox
            QMessageBox.critical(self, "NEST Error", f"Could not create device:\n{str(e)}")


class DeviceHelpWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        
        lbl_icon = QLabel("🛠️")
        lbl_icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lbl_icon.setStyleSheet("font-size: 48px; margin-bottom: 10px;")
        layout.addWidget(lbl_icon)
        
        lbl_title = QLabel("Device Toolbox Guide")
        lbl_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lbl_title.setStyleSheet("color: #FF9800; font-size: 18px; font-weight: bold; letter-spacing: 1px;")
        layout.addWidget(lbl_title)
        
        help_text = QTextEdit()
        help_text.setReadOnly(True)
        help_text.setStyleSheet("""
            QTextEdit {
                background-color: transparent;
                border: none;
                color: #ccc;
                font-size: 13px;
                line-height: 1.4;
            }
        """)
        
        html_content = """
        <div style='font-family: sans-serif;'>
            <p style='text-align: center; color: #888;'>Select a tool from the left menu to configure it.</p>
            
            <h3 style='color: #E91E63;'> Recorders & Meters (Output)</h3>
            <ul>
                <li><b>Spike Recorder:</b> Records firing times (spikes) from neurons. Essential for Raster Plots.</li>
                <li><b>Voltmeter / Multimeter:</b> Records continuous membrane potentials (V_m). connect to neurons to see analog traces.</li>
            </ul>

            <h3 style='color: #FF9800;'>Generators (Input)</h3>
            <ul>
                <li><b>Poisson Generator:</b> Injects random spikes with a specific frequency (Hz). Simulates background activity.</li>
                <li><b>Noise Generator:</b> Injects continuous current noise (Gaussian white noise).</li>
                <li><b>DC Generator:</b> Injects a constant current (pA). Useful for driving neurons to threshold.</li>
                <li><b>Step Current:</b> Injects current pulses at specific times.</li>
                <li><b>Spike Generator:</b> Injects exact spikes at pre-defined timestamps.</li>
            </ul>
            
            <hr style='border-color: #444;'>
            <p style='color: #aaa; font-style: italic; font-size: 11px;'>
                <b>Note:</b> Generators are connected <i>TO</i> the population (Source). 
                Recorders are connected <i>FROM</i> the population (Target).
            </p>
        </div>
        """
        help_text.setHtml(html_content)
        layout.addWidget(help_text)
