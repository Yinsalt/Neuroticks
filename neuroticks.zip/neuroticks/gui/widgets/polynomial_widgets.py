"""Editoren für die Flussfeld-Polynome."""
from PyQt6.QtCore import pyqtSignal, Qt, QTimer
from PyQt6.QtWidgets import (
    QAbstractSpinBox, QComboBox, QDoubleSpinBox, QFrame, QGroupBox, QHBoxLayout, QLabel,
    QPushButton, QScrollArea, QSpinBox, QVBoxLayout, QWidget,
)

class PolynomialTrioWidget(QGroupBox):
    def __init__(self, title):
        super().__init__(title)
        self.setStyleSheet("""
            QGroupBox {
                border: 1px solid #444;
                border-radius: 5px;
                margin-top: 20px;
                font-weight: bold;
                color: #EEE;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px;
                color: #00E5FF; /* Cyan Titel */
            }
        """)
        
        layout = QVBoxLayout(self)
        
        self.builder_x = PolynomialBuilderWidget("dx/dt")
        self.builder_y = PolynomialBuilderWidget("dy/dt")
        self.builder_z = PolynomialBuilderWidget("dz/dt")
        
        layout.addWidget(self.builder_x)
        line1 = QFrame(); line1.setFrameShape(QFrame.Shape.HLine); line1.setStyleSheet("background: #333;")
        layout.addWidget(line1)
        layout.addWidget(self.builder_y)
        line2 = QFrame(); line2.setFrameShape(QFrame.Shape.HLine); line2.setStyleSheet("background: #333;")
        layout.addWidget(line2)
        layout.addWidget(self.builder_z)

    def _convert_to_ui_terms(self, data):
        if isinstance(data, list):
            return data
        
        if isinstance(data, dict) and 'indices' in data and 'coefficients' in data:
            terms = []
            indices = data['indices']
            coeffs = data['coefficients']
            var_map = {0: 'x', 1: 'y', 2: 'z'}
            
            for (var_idx, power), coeff in zip(indices, coeffs):
                term = {
                    'coeff': float(coeff),
                    'var': var_map.get(var_idx, 'x'),
                    'power': int(power)
                }
                terms.append(term)
            return terms
        
        return []

    def _convert_from_ui_terms(self, ui_terms):
        indices = []
        coefficients = []
        var_map = {'x': 0, 'y': 1, 'z': 2}
        
        for t in ui_terms:
            c = t['coeff']
            v = t['var']
            p = t['power']
            
            if v == '1':
                v_idx = 0
                p = 0
            else:
                v_idx = var_map.get(v, 0)
            
            indices.append([v_idx, p])
            coefficients.append(c)
        
        return {
            'indices': indices,
            'coefficients': coefficients,
            'n': 5,
            'decay': 0.5
        }

    def load_polynomials(self, poly_dict):
        if not poly_dict: return
        
        x_terms = self._convert_to_ui_terms(poly_dict.get('x', []))
        y_terms = self._convert_to_ui_terms(poly_dict.get('y', []))
        z_terms = self._convert_to_ui_terms(poly_dict.get('z', []))
        
        for term in x_terms: self.builder_x.add_term(term)
        for term in y_terms: self.builder_y.add_term(term)
        for term in z_terms: self.builder_z.add_term(term)

    def get_polynomials(self):
        return {
            'x': self._convert_from_ui_terms(self.builder_x.get_terms()),
            'y': self._convert_from_ui_terms(self.builder_y.get_terms()),
            'z': self._convert_from_ui_terms(self.builder_z.get_terms())
        }


class PolynomialTermRow(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 2, 0, 2)
        layout.setSpacing(5)

        self.spin_coeff = QDoubleSpinBox()
        self.spin_coeff.setRange(-100.0, 100.0)
        self.spin_coeff.setSingleStep(0.1)
        self.spin_coeff.setValue(1.0)
        self.spin_coeff.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.NoButtons)
        self.spin_coeff.setFixedWidth(60)
        self.spin_coeff.setStyleSheet("""
            background-color: #2b2b2b; color: #00E5FF; font-weight: bold;
            border: 1px solid #444; border-radius: 3px;
        """)
        self.spin_coeff.setToolTip("Coefficient (Multiplikator)")
        layout.addWidget(self.spin_coeff)

        lbl_mult = QLabel("×")
        lbl_mult.setStyleSheet("color: #777; font-weight: bold;")
        layout.addWidget(lbl_mult)

        self.combo_var = QComboBox()
        self.combo_var.addItems(["x", "y", "z", "1"])
        self.combo_var.setFixedWidth(50)
        self.combo_var.setStyleSheet("""
            background-color: #2b2b2b; color: #FFEB3B;
            border: 1px solid #444; border-radius: 3px;
        """)
        layout.addWidget(self.combo_var)

        lbl_pow = QLabel("^")
        lbl_pow.setStyleSheet("color: #777; font-weight: bold;")
        layout.addWidget(lbl_pow)

        self.spin_pow = QSpinBox()
        self.spin_pow.setRange(0, 10)
        self.spin_pow.setFixedWidth(40)
        self.spin_pow.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.NoButtons)
        self.spin_pow.setStyleSheet("""
            background-color: #2b2b2b; color: #FF9800;
            border: 1px solid #444; border-radius: 3px;
        """)
        layout.addWidget(self.spin_pow)

        self.btn_del = QPushButton("×")
        self.btn_del.setFixedSize(20, 20)
        self.btn_del.setStyleSheet("""
            QPushButton { background: transparent; color: #F44336; border: none; font-weight: bold; }
            QPushButton:hover { background: #330000; border-radius: 10px; }
        """)
        layout.addWidget(self.btn_del)

    def get_data(self):
        return {
            "coeff": self.spin_coeff.value(),
            "var": self.combo_var.currentText(),
            "power": self.spin_pow.value()
        }

    def set_data(self, data):
        self.spin_coeff.setValue(data.get("coeff", 1.0))
        idx = self.combo_var.findText(data.get("var", "x"))
        if idx >= 0: self.combo_var.setCurrentIndex(idx)
        self.spin_pow.setValue(data.get("power", 1))


class PolynomialManagerWidget(QWidget):
    polynomialsChanged = pyqtSignal(int, list)
    
    def __init__(self):
        super().__init__()
        self.population_polynomials = {}
        self.current_node_idx = None
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        
        header_bg = QWidget()
        header_bg.setStyleSheet("background-color: #222; border-bottom: 1px solid #444;")
        hb_layout = QVBoxLayout(header_bg)
        
        header = QLabel("FLOW FIELD DEFINITION")
        header.setStyleSheet("font-weight: bold; font-size: 14px; color: #FF9800; letter-spacing: 1px;")
        hb_layout.addWidget(header)
        layout.addWidget(header_bg)
        
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea { border: none; background-color: #1e1e1e; }")
        
        self.content = QWidget()
        self.content.setStyleSheet("background-color: #1e1e1e;")
        self.content_layout = QVBoxLayout(self.content)
        self.content_layout.setSpacing(15)
        
        scroll.setWidget(self.content)
        layout.addWidget(scroll)
        
        self.apply_btn = QPushButton("✓ APPLY FLOW FIELDS")
        self.apply_btn.setMinimumHeight(45)
        self.apply_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.apply_btn.setStyleSheet("""
            QPushButton {
                background-color: #D84315; 
                color: white; 
                font-weight: bold; 
                font-size: 13px;
                border-top: 2px solid #BF360C;
            }
            QPushButton:hover { background-color: #FF5722; }
            QPushButton:pressed { background-color: #BF360C; }
        """)
        self.apply_btn.clicked.connect(self.apply_changes)
        layout.addWidget(self.apply_btn)
    
    def set_populations(self, population_list, node_idx=None):
        self.current_node_idx = node_idx
        
        while self.content_layout.count():
            item = self.content_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        
        self.population_polynomials.clear()
        
        if not population_list:
            placeholder = QLabel("No populations found for this graph node.")
            placeholder.setAlignment(Qt.AlignmentFlag.AlignCenter)
            placeholder.setStyleSheet("color: #666; font-style: italic; margin-top: 50px;")
            self.content_layout.addWidget(placeholder)
            return
        
        for i, pop in enumerate(population_list):
            pop_name = f"POPULATION {i} ({pop.get('model', 'unknown')})"
            
            trio = PolynomialTrioWidget(pop_name)
            
            if 'polynomials' in pop and pop['polynomials']:
                trio.load_polynomials(pop['polynomials'])
            
            self.content_layout.addWidget(trio)
            self.population_polynomials[i] = trio
            
        self.content_layout.addStretch()
    
    def apply_changes(self):
        if self.current_node_idx is None:
            return
        all_polynomials = self.get_all_polynomials()
        self.polynomialsChanged.emit(self.current_node_idx, all_polynomials)
        self.apply_btn.setText("✓ SAVED!")
        QTimer.singleShot(1000, lambda: self.apply_btn.setText("✓ APPLY FLOW FIELDS"))

    def get_all_polynomials(self):
        return [trio.get_polynomials() for trio in self.population_polynomials.values()]




class PolynomialBuilderWidget(QWidget):
    def __init__(self, axis_name="f(x)"):
        super().__init__()
        self.axis_name = axis_name
        self.rows = []
        
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(5, 5, 5, 5)
        self.layout.setSpacing(2)
        
        header_layout = QHBoxLayout()
        self.lbl_title = QLabel(f"{axis_name} =")
        self.lbl_title.setStyleSheet("color: #AAA; font-weight: bold; font-family: Consolas;")
        header_layout.addWidget(self.lbl_title)
        
        btn_add = QPushButton("+ Term")
        btn_add.setFixedSize(60, 20)
        btn_add.setStyleSheet("background: #333; color: #8BC34A; border: 1px solid #444; border-radius: 3px; font-size: 10px;")
        btn_add.clicked.connect(self.add_term)
        header_layout.addWidget(btn_add)
        header_layout.addStretch()
        
        self.layout.addLayout(header_layout)
        
        self.rows_layout = QVBoxLayout()
        self.layout.addLayout(self.rows_layout)
    
    def add_term(self, data=None):
        row = PolynomialTermRow()
        if data:
            row.set_data(data)
        
        row.btn_del.clicked.connect(lambda: self.remove_term(row))
        
        self.rows_layout.addWidget(row)
        self.rows.append(row)

    def remove_term(self, row):
        self.rows_layout.removeWidget(row)
        row.deleteLater()
        if row in self.rows:
            self.rows.remove(row)

    def get_terms(self):
        return [r.get_data() for r in self.rows]
