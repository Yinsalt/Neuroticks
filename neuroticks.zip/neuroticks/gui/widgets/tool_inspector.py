"""Inspektor für Node-Tools."""
from PyQt6.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QPushButton, QTextEdit, QVBoxLayout, QWidget,
)

class ToolInspectorWidget(QWidget):
    def __init__(self, graph_list, parent=None):
        super().__init__(parent)
        self.graph_list = graph_list
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        
        header_frame = QFrame()
        header_frame.setStyleSheet("background-color: #2b2b2b; border: 1px solid #444; border-radius: 4px;")
        header_layout = QHBoxLayout(header_frame)
        
        lbl_title = QLabel("TOOL INSPECTOR (BATCH PROCESSING)")
        lbl_title.setStyleSheet("color: #FFC107; font-weight: bold; font-size: 14px;")
        
        btn_run = QPushButton("▶ Run Processing")
        btn_run.setStyleSheet("background-color: #FFC107; color: black; font-weight: bold; padding: 5px 15px;")
        btn_run.clicked.connect(self.run_inspector)
        
        header_layout.addWidget(lbl_title)
        header_layout.addStretch()
        header_layout.addWidget(btn_run)
        
        layout.addWidget(header_frame)
        
        self.log_output = QTextEdit()
        self.log_output.setReadOnly(True)
        self.log_output.setPlaceholderText("Output log will appear here...")
        self.log_output.setStyleSheet("""
            QTextEdit {
                background-color: #1e1e1e; 
                color: #00E5FF; 
                font-family: Consolas, Monospace; 
                font-size: 12px;
                border: 1px solid #444;
            }
        """)
        layout.addWidget(self.log_output)

    def log(self, message):
        self.log_output.append(message)
        sb = self.log_output.verticalScrollBar()
        sb.setValue(sb.maximum())


    def run_inspector(self):
        self.log_output.clear()
        self.log(">>> Starting Inspector...")
        
        tools_found = 0
        
        for graph in self.graph_list:
            
            for node in graph.node_list:
                
                devices = getattr(node, 'devices', [])
                if not devices and hasattr(node, 'parameters') and 'devices' in node.parameters:
                    devices = node.parameters['devices']
                
                for tool in devices:
                    
                    
                    pass
                    
                    
                    model = tool.get('model', 'unknown')
                    node_name = getattr(node, 'name', f"Node_{node.id}")
                    
                    tools_found += 1

        self.log(f"\n>>> Done. Iterated over {tools_found} tools/devices.")
