"""Baumansicht aller Graphen, Nodes, Populationen, Verbindungen und Devices."""
import random

from PyQt6.QtCore import pyqtSignal, Qt
from PyQt6.QtGui import QAction, QBrush, QColor
from PyQt6.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QLineEdit, QMenu, QPushButton, QTreeWidget,
    QTreeWidgetItem, QVBoxLayout, QWidget,
)

class GraphNameColorWidget(QWidget):
    
    def __init__(self):
        super().__init__()
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout(self)
        
        name_row = QHBoxLayout()
        name_row.addWidget(QLabel("Graph Name:"))
        self.name_input = QLineEdit()
        name_row.addWidget(self.name_input)
        layout.addLayout(name_row)
        
        save_btn = QPushButton("Create Graph")
        save_btn.clicked.connect(self.create_graph)
        layout.addWidget(save_btn)
    
    def generate_random_color(self):
        r = random.randint(0, 255)
        g = random.randint(0, 255)
        b = random.randint(0, 255)
        return f"0x{r:02x}{g:02x}{b:02x}"
    
    def create_graph(self):
        data = {
            'graph_name': self.name_input.text(),
            'color': self.generate_random_color()
        }
        print(data)
        return data


class GraphOverviewWidget(QWidget):

    node_selected = pyqtSignal(int, int)
    population_selected = pyqtSignal(int, int, int)
    connection_selected = pyqtSignal(dict)
    requestConnectionCreation = pyqtSignal(int, int, int)
    requestConnectionDeletion = pyqtSignal(dict)
    device_selected = pyqtSignal(dict)
    itemVisibilityChanged = pyqtSignal(dict, bool)
    requestDeviceDeletion = pyqtSignal(dict)
    requestLiveWeightChange = pyqtSignal(dict, float)
    COLOR_GRAPH_BG = "#000000"; COLOR_GRAPH_FG = "#87CEEB"; COLOR_NODE_BG = "#8B0000"
    COLOR_NODE_FG = "#FFFF00"; COLOR_POP_BG = "#424242"; COLOR_POP_FG = "#FFFFFF"
    COLOR_CONN_BG = "#aaaa00"; COLOR_CONN_FG = "#841414"; COLOR_DEVICE_BG = "#4A148C"; COLOR_DEVICE_FG = "#E0E0E0"
    
    def __init__(self, parent=None, graph_list=None):
        super().__init__(parent)
        self.main_window = parent
        self.graph_list = graph_list if graph_list is not None else []
        self._setup_ui()
    
    def _setup_ui(self):
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(5, 5, 5, 5)
        layout.setSpacing(5)
        
        header = QHBoxLayout()
        title = QLabel("Graph Overview")
        title.setStyleSheet("font-weight: bold; font-size: 14px; color: #FFFF00;")
        header.addWidget(title)
        header.addStretch()
        
        self.refresh_btn = QPushButton("🔄")
        self.refresh_btn.setFixedSize(28, 28)
        self.refresh_btn.clicked.connect(self.update_tree)
        header.addWidget(self.refresh_btn)
        
        self.expand_btn = QPushButton("⊕"); self.expand_btn.setFixedSize(28, 28); self.expand_btn.clicked.connect(self._expand_all)
        header.addWidget(self.expand_btn)
        self.collapse_btn = QPushButton("⊖"); self.collapse_btn.setFixedSize(28, 28); self.collapse_btn.clicked.connect(self._collapse_all)
        header.addWidget(self.collapse_btn)
        layout.addLayout(header)
        
        self.tree = QTreeWidget()
        self.tree.setColumnCount(2)
        self.tree.setHeaderLabels(["Element (Check to Hide/Show)", "Details"])
        self.tree.setColumnWidth(0, 240)
        self.tree.setStyleSheet("background-color: #1e1e1e; color: #e0e0e0; border: 1px solid #444;")
        self.tree.setItemsExpandable(True)
        self.tree.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)

        # Signals nur EINMAL verbinden (vorher war jeder Connect 2x, was doppelte Handler-Aufrufe ausloeste)
        self.tree.itemClicked.connect(self._on_item_clicked)
        self.tree.itemDoubleClicked.connect(self._on_item_double_clicked)
        self.tree.itemChanged.connect(self._on_item_changed)
        self.tree.customContextMenuRequested.connect(self._show_context_menu)

        self.tree.setStyleSheet("""
            QTreeWidget {
                background-color: #1e1e1e;
                color: #e0e0e0;
                border: 1px solid #444444; 
                border-radius: 4px;
                font-family: 'Segoe UI', 'Arial', sans-serif;
                font-size: 12px;
                outline: 0; 
            }
            
            QTreeWidget::item {
                padding: 6px 4px;
                border-bottom: 1px solid #2a2a2a;
                margin: 0px;
            }
            
            QTreeWidget::item:selected {
                background-color: #264f78;
                color: #ffffff;
                border: none;
            }
            
            QTreeWidget::item:hover {
                background-color: #2d2d2d;
            }

            
            QHeaderView {
                background-color: #333333;
                border: none;
                margin: 0px;
                padding: 0px;
            }
            
            QHeaderView::section {
                background-color: #333333;
                color: #ffffff;
                padding: 6px;
                border: none;
                border-bottom: 2px solid #555555;
                border-right: 1px solid #444444; 
                font-weight: bold;
                margin: 0px;
            }
            
            QTableCornerButton::section {
                background-color: #333333;
                border: none;
            }
            
            QScrollBar:vertical {
                border: none;
                background: #2b2b2b;
                width: 10px;
                margin: 0px;
            }
            QScrollBar::handle:vertical {
                background: #555;
                min-height: 20px;
                border-radius: 5px;
            }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                height: 0px;
            }
        """)
        
        self.tree.setFrameShape(QFrame.Shape.NoFrame)
        self.tree.setAttribute(Qt.WidgetAttribute.WA_MacShowFocusRect, False)

        layout.addWidget(self.tree)

        self.status_label = QLabel("No graphs")
        self.status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.status_label.setStyleSheet("color: #aaaaaa; font-size: 11px; padding: 5px;")
        layout.addWidget(self.status_label)

    def _show_context_menu(self, position):
        item = self.tree.itemAt(position)
        if not item: return

        data = item.data(0, Qt.ItemDataRole.UserRole)
        if not data: return

        item_type = data.get('type')
        menu = QMenu(self)

        if item_type in ['node', 'population']:
            pass

        elif item_type == 'connection':
            conn_data = data.get('connection')
            conn_name = conn_data.get('name', 'Connection')

            action_del = QAction(f"Delete (Rebuild)", self)
            action_del.triggered.connect(lambda: self.requestConnectionDeletion.emit(conn_data))
            menu.addAction(action_del)

            action_sever = QAction(f"Sever Connection (Live, w=0)", self)
            action_sever.triggered.connect(lambda: self.requestLiveWeightChange.emit(conn_data, 0.0))
            menu.addAction(action_sever)

            orig_weight = conn_data.get('params', {}).get('weight', 1.0)
            action_restore = QAction(f"Restore Weight (Live, w={orig_weight})", self)
            action_restore.triggered.connect(lambda: self.requestLiveWeightChange.emit(conn_data, float(orig_weight)))
            menu.addAction(action_restore)

        elif item_type == 'device':
            dev_data = data.get('device')
            model = dev_data.get('model', 'Device')
            dev_id = dev_data.get('id', '?')
            
            action_info = QAction(f"ℹ Device: {model}", self)
            action_info.setEnabled(False)
            menu.addAction(action_info)
            
            action_del = QAction(f"🗑️ Delete Device #{dev_id}", self)
            action_del.triggered.connect(lambda: self.requestDeviceDeletion.emit(dev_data))
            menu.addAction(action_del)

        menu.exec(self.tree.viewport().mapToGlobal(position))


    def update_tree(self):
        self.tree.clear()
        
        if not self.graph_list:
            self.status_label.setText("No graphs loaded")
            self.status_label.setVisible(True)
            return
        
        self.status_label.setVisible(False) 
        
        total_nodes = 0
        total_pops = 0
        total_conns = 0
        total_devs = 0
        
        for graph in self.graph_list:
            graph_item = QTreeWidgetItem(self.tree)
            g_name = getattr(graph, 'graph_name', f'Graph_{graph.graph_id}')
            graph_item.setText(0, g_name)
            graph_item.setText(1, f"ID: {graph.graph_id}")
            graph_item.setBackground(0, QBrush(QColor(self.COLOR_GRAPH_BG)))
            graph_item.setForeground(0, QBrush(QColor(self.COLOR_GRAPH_FG)))
            
            graph_item.setData(0, Qt.ItemDataRole.UserRole, {'type': 'graph', 'graph_id': graph.graph_id})
            graph_item.setExpanded(True)
            
            for node in graph.node_list:
                total_nodes += 1
                node_item = self._create_node_item(graph, node, graph_item)
                
                populations = self._get_populations(node)
                for pop_idx, pop_info in enumerate(populations):
                    total_pops += 1
                    pop_item = self._create_population_item(graph, node, pop_idx, pop_info, node_item)
                    
                    connections = self._get_connections_for_pop(node, pop_idx)
                    for conn in connections:
                        total_conns += 1
                        self._create_connection_item(conn, pop_item)
                    
                    devices = self._get_devices_for_pop(node, pop_idx)
                    for dev in devices:
                        total_devs += 1
                        self._create_device_item(dev, pop_item, graph.graph_id, node.id, pop_idx)

        self.status_label.setText(f"{len(self.graph_list)} Graphs | {total_nodes} Nodes | {total_pops} Pops | {total_conns} Conns")
        self.status_label.setVisible(True)
        
    
    def _get_devices_for_pop(self, node, pop_idx):

        # FIX: Dedup per ID, falls im State noch alte Duplikate liegen (z.B. aus
        # gespeicherten Graphen die mit dem frueheren Doppel-Append-Bug erzeugt wurden).
        dev_list = []
        seen_ids = set()
        
        def add_if_new(d):
            dev_id = d.get('id')
            # Fallback-Key wenn keine ID vorhanden ist
            key = dev_id if dev_id is not None else (d.get('model'), d.get('target_pop_id'), id(d))
            if key in seen_ids:
                return
            seen_ids.add(key)
            dev_list.append(d)

        if hasattr(node, 'parameters') and 'devices' in node.parameters:
            for dev in node.parameters['devices']:
                if dev.get('target_pop_id') == pop_idx:
                    add_if_new(dev)
        elif hasattr(node, 'devices'):
            for dev in node.devices:
                if dev.get('target_pop_id') == pop_idx:
                    add_if_new(dev)
                    
        return dev_list

    def _create_device_item(self, dev, parent_item, graph_id, node_id, pop_idx):
        item = QTreeWidgetItem(parent_item)
        
        model = dev.get('model', 'unknown_device')
        dev_id = dev.get('id', '?')
        
        params = dev.get('params', {})
        param_str = ""
        if 'rate' in params: param_str += f"Rate={params['rate']}Hz "
        if 'amplitude' in params: param_str += f"Amp={params['amplitude']}pA "
        if 'mean' in params: param_str += f"Mean={params['mean']} "
        if 'label' in params: param_str += f"File='{params['label']}' "
        if not param_str: param_str = "params..."
        
        item.setText(0, f"       {model}")
        item.setText(1, f"ID: {dev_id} | {param_str}")
        
        self._style_item(item, self.COLOR_DEVICE_BG, self.COLOR_DEVICE_FG, bold=False)
        
        device_data_with_context = dev.copy()
        device_data_with_context['target'] = {
            'graph_id': graph_id,
            'node_id': node_id,
            'pop_id': pop_idx
        }
        
        item.setData(0, Qt.ItemDataRole.UserRole, {
            'type': 'device',
            'device': device_data_with_context
        })
        
        return item


    def _style_item(self, item, bg_color, fg_color, bold=False):
        bg_brush = QBrush(QColor(bg_color))
        fg_brush = QBrush(QColor(fg_color))
        
        for col in range(2):
            item.setBackground(col, bg_brush)
            item.setForeground(col, fg_brush)
        
        if bold:
            font = item.font(0)
            font.setBold(True)
            font.setPointSize(font.pointSize() + 1)
            item.setFont(0, font)
            item.setFont(1, font)
    
    def _create_node_item(self, graph, node, parent):
        item = QTreeWidgetItem(parent)
        item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
        item.setCheckState(0, Qt.CheckState.Checked)
        
        name = getattr(node, 'name', f"Node_{node.id}")
        item.setText(0, f"Node {node.id}: {name}")
        item.setBackground(0, QBrush(QColor(self.COLOR_NODE_BG)))
        item.setForeground(0, QBrush(QColor(self.COLOR_NODE_FG)))
        
        item.setData(0, Qt.ItemDataRole.UserRole, {'type': 'node', 'graph_id': graph.graph_id, 'node_id': node.id})
        item.setExpanded(True)
        return item
    
    def _on_item_changed(self, item, column):
        if column == 0:
            data = item.data(0, Qt.ItemDataRole.UserRole)
            
            if data is None:
                return
            
            visible = (item.checkState(0) == Qt.CheckState.Checked)
            self.itemVisibilityChanged.emit(data, visible)

    def _create_population_item(self, graph, node, pop_idx, pop_info, parent_item):
        item = QTreeWidgetItem(parent_item)
        
        model = pop_info.get('model', 'unknown')
        n_neurons = pop_info.get('n_neurons', '?')
        
        item.setText(0, f"    🟠 Pop {pop_idx}: {model}")
        item.setText(1, f"[{n_neurons} neurons]")
        
        self._style_item(item, self.COLOR_POP_BG, self.COLOR_POP_FG, bold=False)
        
        item.setData(0, Qt.ItemDataRole.UserRole, {
            'type': 'population',
            'graph_id': graph.graph_id,
            'node_id': node.id,
            'pop_id': pop_idx,
            'info': pop_info
        })
        
        item.setExpanded(True)
        
        return item
    
    def _create_connection_item(self, conn, parent_item):
        item = QTreeWidgetItem(parent_item)
        
        source = conn.get('source', {})
        target = conn.get('target', {})
        params = conn.get('params', {})
        
        is_self = (
            source.get('graph_id') == target.get('graph_id') and
            source.get('node_id') == target.get('node_id') and
            source.get('pop_id') == target.get('pop_id')
        )
        
        if is_self:
            icon = "↻"
            target_str = "Self"
        else:
            icon = "→"
            if source.get('graph_id') != target.get('graph_id'):
                target_str = f"G{target.get('graph_id', '?')}N{target.get('node_id', '?')}P{target.get('pop_id', '?')}"
            else:
                target_str = f"N{target.get('node_id', '?')}P{target.get('pop_id', '?')}"
        
        synapse = params.get('synapse_model', 'static')
        if len(synapse) > 15:
            synapse = synapse[:13] + ".."
        
        weight = params.get('weight', '?')
        if isinstance(weight, (int, float)):
            weight_str = f"{weight:.2f}"
        else:
            weight_str = str(weight)
        
        rule = params.get('rule', 'all_to_all')
        if len(rule) > 12:
            rule = rule[:10] + ".."
        
        item.setText(0, f"        {icon} {target_str}")
        item.setText(1, f"{synapse} | w={weight_str} | {rule}")
        
        self._style_item(item, self.COLOR_CONN_BG, self.COLOR_CONN_FG, bold=True)
        
        font = item.font(0)
        font.setPointSize(max(10, font.pointSize()))
        font.setBold(True)
        item.setFont(0, font)
        item.setFont(1, font)
        
        item.setData(0, Qt.ItemDataRole.UserRole, {
            'type': 'connection',
            'connection': conn
        })
        
        return item
    
    def _get_populations(self, node):
        pops = []
        if hasattr(node, 'types'):
            for i, t in enumerate(node.types):
                model = node.neuron_models[i] if hasattr(node, 'neuron_models') and i < len(node.neuron_models) else 'iaf_psc_alpha'
                count = 0
                if hasattr(node, 'population') and i < len(node.population) and node.population[i]:
                    count = len(node.population[i])
                pops.append({'model': model, 'n_neurons': count})
        elif hasattr(node, 'population'):
             for i, p in enumerate(node.population):
                 pops.append({'model': 'unknown', 'n_neurons': len(p) if p else 0})
        return pops
    
    def _get_connections_for_pop(self, node, pop_idx):
        if not hasattr(node, 'connections') or not node.connections:
            return []

        # FIX: Dedup per Connection-ID (schuetzt gegen alte Duplikate in gespeichertem State)
        result = []
        seen_ids = set()
        for conn in node.connections:
            source = conn.get('source', {})
            if source.get('node_id') == node.id and source.get('pop_id') == pop_idx:
                cid = conn.get('id')
                key = cid if cid is not None else id(conn)
                if key in seen_ids:
                    continue
                seen_ids.add(key)
                result.append(conn)
        return result
    
    def _expand_all(self):
        self.tree.expandAll()
    
    def _collapse_all(self):
        self.tree.collapseAll()
        for i in range(self.tree.topLevelItemCount()):
            self.tree.topLevelItem(i).setExpanded(True)
    
    def _on_item_clicked(self, item, column):
        data = item.data(0, Qt.ItemDataRole.UserRole)
        if not data: return
        
        item_type = data.get('type')
        
        if item_type == 'node':
            self.node_selected.emit(data['graph_id'], data['node_id'])
        elif item_type == 'population':
            self.population_selected.emit(data['graph_id'], data['node_id'], data['pop_id'])
        elif item_type == 'connection':
            self.connection_selected.emit(data['connection'])
        elif item_type == 'device':
            self.device_selected.emit(data['device'])
    
    def _on_item_double_clicked(self, item, column):
        pass
