"""Eingebettete Python-Konsole."""
import code
import sys
from io import StringIO

from PyQt6 import QtGui
from PyQt6.QtCore import QEvent, Qt
from PyQt6.QtWidgets import QLineEdit, QTextEdit, QVBoxLayout, QWidget

class PythonConsoleWidget(QWidget):
    def __init__(self, context_vars=None, parent=None):
        super().__init__(parent)
        self.local_vars = context_vars if context_vars is not None else {}
        self.history = []
        self.history_idx = 0
        
        self.init_ui()
        
        self.interpreter = code.InteractiveConsole(self.local_vars)

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        
        self.output_view = QTextEdit()
        self.output_view.setReadOnly(True)
        self.output_view.setStyleSheet("""
            QTextEdit {
                background-color: #1e1e1e;
                color: #00FF00;
                font-family: Consolas, Monospace;
                font-size: 12px;
                border: 1px solid #444;
            }
        """)
        
        self.input_line = QLineEdit()
        self.input_line.setPlaceholderText(">>> Enter Python command...")
        self.input_line.setStyleSheet("""
            QLineEdit {
                background-color: #2b2b2b;
                color: #ffffff;
                font-family: Consolas, Monospace;
                font-size: 12px;
                border: 1px solid #555;
                padding: 4px;
            }
        """)
        self.input_line.returnPressed.connect(self.execute_command)
        self.input_line.installEventFilter(self)

        layout.addWidget(self.output_view)
        layout.addWidget(self.input_line)
        
        self.write_output("Python Console initialized.\nContext available: 'nest', 'graph_list', 'np'\n")

    def write_output(self, text):
        self.output_view.moveCursor(QtGui.QTextCursor.MoveOperation.End)
        self.output_view.insertPlainText(text)
        self.output_view.moveCursor(QtGui.QTextCursor.MoveOperation.End)

    def execute_command(self):
        command = self.input_line.text()
        self.input_line.clear()
        
        if not command.strip():
            return

        self.write_output(f">>> {command}\n")
        self.history.append(command)
        self.history_idx = len(self.history)

        old_stdout = sys.stdout
        old_stderr = sys.stderr
        sys.stdout = mystdout = StringIO()
        sys.stderr = mystderr = StringIO()

        try:
            try:
                result = eval(command, self.local_vars)
                if result is not None:
                    print(repr(result))
            except SyntaxError:
                self.interpreter.runsource(command)
            except Exception:
                self.interpreter.runsource(command)
                
        except Exception:
            self.interpreter.runsource(command)
        
        finally:
            sys.stdout = old_stdout
            sys.stderr = old_stderr

        output = mystdout.getvalue()
        error = mystderr.getvalue()

        if output: self.write_output(output)
        if error: self.write_output(error)

    def eventFilter(self, obj, event):
        if obj == self.input_line and event.type() == QEvent.Type.KeyPress:
            key = event.key()
            if key == Qt.Key.Key_Up:
                if self.history_idx > 0:
                    self.history_idx -= 1
                    self.input_line.setText(self.history[self.history_idx])
                return True
            elif key == Qt.Key.Key_Down:
                if self.history_idx < len(self.history) - 1:
                    self.history_idx += 1
                    self.input_line.setText(self.history[self.history_idx])
                else:
                    self.history_idx = len(self.history)
                    self.input_line.clear()
                return True
        return super().eventFilter(obj, event)
