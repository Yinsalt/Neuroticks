"""EditGraphWidget: bestehende Graphen bearbeiten."""
import nest
import numpy as np
from PyQt6.QtCore import pyqtSignal, Qt
from PyQt6.QtGui import QAction
from PyQt6.QtWidgets import (
    QComboBox, QDoubleSpinBox, QFrame, QHBoxLayout, QLabel, QLineEdit, QMenu, QPushButton,
    QScrollArea, QStackedWidget, QVBoxLayout, QWidget,
)

from neuron_toolbox import distributions, region_names
from neuroticks import state
from neuroticks.constants.node_tools import (
    extract_shape_params, node_parameters1, SHAPE_PARAM_DEFAULTS,
)
from neuroticks.gui.widgets.connection_editor import ConnectionParamWidget
from neuroticks.gui.widgets.dialogs import PositionDialog
from neuroticks.gui.widgets.neuron_parameters import NeuronParametersWidget, NodeParametersWidget
from neuroticks.gui.widgets.polynomial_widgets import PolynomialManagerWidget
from neuroticks.utils.nest_helpers import safe_get_model, safe_get_status
from neuroticks.utils.polynomials import generate_biased_polynomial

class EditGraphWidget(QWidget):
    graphUpdated = pyqtSignal(int)
    
    def __init__(self, graph_list=None):
        super().__init__()
        self.graph_list = graph_list if graph_list is not None else []
        self.current_graph = None
        self.current_graph_id = None
        self.node_list = []
        self.current_node_idx = None
        self.current_pop_idx = None
        self._last_polynomial_node_idx = None
        self._loading = False  # FIX: Prevent saving during load
        self.init_ui()
    
    def init_ui(self):
        import copy
        main_layout = QVBoxLayout(self)
        
        selector_layout = QHBoxLayout()
        selector_layout.addWidget(QLabel("Select Graph to Edit:"))
        
        self.graph_selector = QComboBox()
        self.graph_selector.currentIndexChanged.connect(self.on_graph_selected)
        selector_layout.addWidget(self.graph_selector)
        
        refresh_btn = QPushButton("Refresh List")
        refresh_btn.clicked.connect(self.refresh_graph_list)
        selector_layout.addWidget(refresh_btn)
        
        main_layout.addLayout(selector_layout)
        
        name_disp_layout = QHBoxLayout()
        
        name_disp_layout.addWidget(QLabel("Graph Name:"))
        self.graph_name_input = QLineEdit()
        self.graph_name_input.setPlaceholderText("Edit graph name...")
        name_disp_layout.addWidget(self.graph_name_input, stretch=2)
        
        line = QFrame(); line.setFrameShape(QFrame.Shape.VLine); line.setStyleSheet("color: #555;")
        name_disp_layout.addWidget(line)
        
        name_disp_layout.addWidget(QLabel("Global Offset:"))
        
        self.spin_g_x = QDoubleSpinBox(); self.spin_g_x.setRange(-1e5, 1e5); self.spin_g_x.setPrefix("X: "); self.spin_g_x.setDecimals(1)
        self.spin_g_y = QDoubleSpinBox(); self.spin_g_y.setRange(-1e5, 1e5); self.spin_g_y.setPrefix("Y: "); self.spin_g_y.setDecimals(1)
        self.spin_g_z = QDoubleSpinBox(); self.spin_g_z.setRange(-1e5, 1e5); self.spin_g_z.setPrefix("Z: "); self.spin_g_z.setDecimals(1)
        
        style_disp = "background-color: #222; color: #00E5FF; font-weight: bold; border: 1px solid #444;"
        for s in [self.spin_g_x, self.spin_g_y, self.spin_g_z]:
            s.setStyleSheet(style_disp)
            s.setFixedWidth(80)
            name_disp_layout.addWidget(s)
            
        main_layout.addLayout(name_disp_layout)
        
        content_layout = QHBoxLayout()
        
        node_col = QVBoxLayout()
        node_col.addWidget(QLabel("NODES", alignment=Qt.AlignmentFlag.AlignCenter))
        
        node_scroll = QScrollArea()
        node_scroll.setWidgetResizable(True)
        self.node_list_widget = QWidget()
        self.node_list_layout = QVBoxLayout(self.node_list_widget)
        node_scroll.setWidget(self.node_list_widget)
        node_col.addWidget(node_scroll)
        
        node_buttons_layout = QHBoxLayout()
        
        self.btn_add_node = QPushButton("+ Add")
        self.btn_add_node.clicked.connect(self.add_node)
        self.btn_add_node.setStyleSheet("background-color: #2196F3; color: white; font-weight: bold;")
        
        self.btn_add_node.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.btn_add_node.customContextMenuRequested.connect(self.show_add_node_menu)
        self.btn_add_node.setToolTip("Left-Click: Empty Node\nRight-Click: Structure Patch")

        node_buttons_layout.addWidget(self.btn_add_node)
        
        twin_btn = QPushButton("Twin")
        twin_btn.setToolTip("Clone selected node as a NEW node at new position")
        twin_btn.clicked.connect(self.create_twin_node)
        twin_btn.setStyleSheet("background-color: #9C27B0; color: white; font-weight: bold;")
        node_buttons_layout.addWidget(twin_btn)

        self.remove_node_btn = QPushButton("Remove")
        self.remove_node_btn.clicked.connect(self.remove_node)
        self.remove_node_btn.setEnabled(False)
        self.remove_node_btn.setStyleSheet("background-color: #F44336; color: white; font-weight: bold;")
        node_buttons_layout.addWidget(self.remove_node_btn)
        
        node_col.addLayout(node_buttons_layout)
        
        content_layout.addLayout(node_col, 2)
        
        pop_col = QVBoxLayout()
        pop_scroll = QScrollArea()
        pop_scroll.setWidgetResizable(True)
        self.pop_list_widget = QWidget()
        self.pop_list_layout = QVBoxLayout(self.pop_list_widget)
        pop_scroll.setWidget(self.pop_list_widget)
        pop_col.addWidget(pop_scroll)
        
        pop_btns_layout = QHBoxLayout()
        
        self.add_pop_btn = QPushButton("+ Add Pop")
        self.add_pop_btn.clicked.connect(self.add_population)
        self.add_pop_btn.setEnabled(False)
        self.add_pop_btn.setStyleSheet("background-color: #2196F3; color: white; font-weight: bold;")
        pop_btns_layout.addWidget(self.add_pop_btn)
        
        self.remove_pop_btn = QPushButton("DEL")
        self.remove_pop_btn.setFixedWidth(40)
        self.remove_pop_btn.setToolTip("Remove selected population")
        self.remove_pop_btn.clicked.connect(self.remove_population)
        self.remove_pop_btn.setEnabled(False)
        self.remove_pop_btn.setStyleSheet("background-color: #F44336; color: white; font-weight: bold;")
        pop_btns_layout.addWidget(self.remove_pop_btn)
        
        pop_col.addLayout(pop_btns_layout)
        
        content_layout.addLayout(pop_col, 2)
        
        editor_col = QVBoxLayout()
        
        self.editor_stack = QStackedWidget()
        
        placeholder = QLabel("← Select a Graph to Edit", alignment=Qt.AlignmentFlag.AlignCenter)
        placeholder.setStyleSheet("font-size: 14px; color: #999;")
        self.editor_stack.addWidget(placeholder)
        
        self.node_param_widget = NodeParametersWidget(copy.deepcopy(node_parameters1))
        self.node_param_widget.paramsChanged.connect(self.save_node_params)
        self.editor_stack.addWidget(self.node_param_widget)
        
        self.pop_param_widget = NeuronParametersWidget()
        self.pop_param_widget.parametersSaved.connect(self._on_population_params_saved)  # FIX: Connect signal
        self.editor_stack.addWidget(self.pop_param_widget)
        
        self.polynom_manager = PolynomialManagerWidget()
        self.editor_stack.addWidget(self.polynom_manager)
        self.conn_editor = ConnectionParamWidget()
        self.editor_stack.addWidget(self.conn_editor)
        editor_col.addWidget(self.editor_stack)
        
        content_layout.addLayout(editor_col, 6)
        
        main_layout.addLayout(content_layout)
        
        bottom_layout = QHBoxLayout()
        
        polynom_btn = QPushButton("Edit Polynomial Flow Field")
        polynom_btn.clicked.connect(self.open_polynomial_editor)
        polynom_btn.setMinimumHeight(50)
        polynom_btn.setStyleSheet("background-color: #FF9800; color: white; font-weight: bold;")
        bottom_layout.addWidget(polynom_btn)
        
        delete_btn = QPushButton("Delete Graph")
        delete_btn.setMinimumHeight(50)
        delete_btn.clicked.connect(self.delete_graph)
        delete_btn.setStyleSheet("background-color: #F44336; color: white; font-weight: bold;")
        bottom_layout.addWidget(delete_btn)
        
        save_btn = QPushButton("SAVE CHANGES & REBUILD")
        save_btn.setMinimumHeight(60)
        save_btn.clicked.connect(self.save_changes)
        save_btn.setStyleSheet("background-color: #4CAF50; color: white; font-weight: bold; font-size: 16px;")
        bottom_layout.addWidget(save_btn)
        
        main_layout.addLayout(bottom_layout)
        
        self.refresh_graph_list()

    def select_node_by_id(self, graph_id, node_id):
        index = self.graph_selector.findData(graph_id)
        if index >= 0:
            if self.graph_selector.currentIndex() != index:
                self.graph_selector.setCurrentIndex(index)
        
        target_idx = None
        for i, node_data in enumerate(self.node_list):
            if node_data['params'].get('id') == node_id:
                target_idx = i
                break
        
        if target_idx is not None:
            self.select_node(target_idx, auto_save=False)  # FIX: Don't auto-save when selecting from external
        else:
            print(f"⚠ Node ID {node_id} not found in Editor list.")

    def select_population_by_ids(self, graph_id, node_id, pop_id):
        self.select_node_by_id(graph_id, node_id)
        
        if self.current_node_idx is not None:
            node_data = self.node_list[self.current_node_idx]
            if pop_id < len(node_data['populations']):
                self.select_population(pop_id, auto_save=False)  # FIX: Don't auto-save

    def delete_connection_by_data(self, conn_data):
        src_gid = conn_data['source']['graph_id']
        src_nid = conn_data['source']['node_id']
        conn_id = conn_data.get('id')

        if self.current_graph_id != src_gid:
            idx = self.graph_selector.findData(src_gid)
            if idx >= 0:
                self.graph_selector.setCurrentIndex(idx)
            else:
                print(f"Error: Graph {src_gid} not found for deletion.")
                return

        target_node_idx = None
        for i, node in enumerate(self.node_list):
            if node['params']['id'] == src_nid:
                target_node_idx = i
                break
        
        if target_node_idx is None:
            print(f"Error: Source Node {src_nid} not found in current editor list.")
            return

        node_data_wrapper = self.node_list[target_node_idx]
        connections = node_data_wrapper['params'].get('connections', [])
        new_conns = [c for c in connections if c.get('id') != conn_id]
        # FIX: Alle drei Connection-Referenzen konsistent aktualisieren, damit der
        # Fallback in _build_node_params nicht auf eine alte Liste zurueckfaellt.
        node_data_wrapper['params']['connections'] = new_conns

        if node_data_wrapper.get('original_node'):
            src_node_obj = node_data_wrapper['original_node']
            # 1) Das Attribut
            if hasattr(src_node_obj, 'connections'):
                src_node_obj.connections = [c for c in src_node_obj.connections if c.get('id') != conn_id]
            # 2) Der Parameter-Dict-Eintrag (WAR vorher nicht aktualisiert -> "alle Connections weg"-Bug)
            if hasattr(src_node_obj, 'parameters') and 'connections' in src_node_obj.parameters:
                src_node_obj.parameters['connections'] = [
                    c for c in src_node_obj.parameters['connections'] if c.get('id') != conn_id
                ]

            tgt_gid = conn_data['target']['graph_id']
            tgt_nid = conn_data['target']['node_id']
            tgt_node_obj = None
            target_graph = next((g for g in self.graph_list if g.graph_id == tgt_gid), None)
            
            if target_graph:
                tgt_node_obj = target_graph.get_node(tgt_nid)
            
            if src_node_obj and tgt_node_obj:
                src_node_obj.remove_neighbor_if_isolated(tgt_node_obj)

        self.save_changes()

    def show_add_node_menu(self, pos):
        menu = QMenu(self)
        menu.setStyleSheet("QMenu { background-color: #2b2b2b; color: white; border: 1px solid #555; }")
        
        header = QAction("Add Structure Patch:", self)
        header.setEnabled(False)
        menu.addAction(header)
        menu.addSeparator()

        region_data = {r_key: {} for r_key in region_names.values()}
        for model, region_map in distributions.items():
            for r_key, prob in region_map.items():
                if prob > 0: region_data[r_key][model] = prob

        for display_name, r_key in region_names.items():
            if r_key not in region_data or not region_data[r_key]: continue
            
            models_probs = region_data[r_key]
            model_list = list(models_probs.keys())
            prob_list = list(models_probs.values())
            total = sum(prob_list)
            if total > 0: prob_list = [p/total for p in prob_list]

            action = QAction(display_name, self)
            action.triggered.connect(lambda checked, n=display_name, m=model_list, p=prob_list:
                                   self.add_structure_node(n, m, p))
            menu.addAction(action)

        menu.exec(self.btn_add_node.mapToGlobal(pos))

    def add_structure_node(self, name, models, probs):
        if self.current_graph is None: return

        self.add_node()
        
        node_idx = len(self.node_list) - 1
        node_data = self.node_list[node_idx]
        
        safe_name = name.replace(" ", "_").replace("/", "-")
        node_data['params']['name'] = f"{safe_name}_{node_idx}"
        node_data['params']['grid_size'] = [10, 10, 10]
        node_data['params']['probability_vector'] = probs
        node_data['params']['sparsity_factor'] = 0.85
        
        is_new = node_data.get('original_node') is None
        suffix = " (NEW)" if is_new else ""
        node_data['button'].setText(f"Node {node_idx + 1}{suffix}: {node_data['params']['name']}")
        
        populations = []
        for i, model in enumerate(models):
            default_polynomials = {
                'x': generate_biased_polynomial(axis_idx=0, max_degree=2),
                'y': generate_biased_polynomial(axis_idx=1, max_degree=2),
                'z': generate_biased_polynomial(axis_idx=2, max_degree=2)
            }
            populations.append({
                'model': model,
                'params': {},
                'polynomials': default_polynomials
            })
            
        node_data['populations'] = populations
        self.select_node(node_idx)
        print(f"Added Structure Node to Editor: {name}")

    def load_connection_editor(self, connection_data):
        src_gid = connection_data['source']['graph_id']
        index = self.graph_selector.findData(src_gid)
        if index >= 0 and self.graph_selector.currentIndex() != index:
            self.graph_selector.setCurrentIndex(index)
            
        src_nid = connection_data['source']['node_id']
        target_node_data = None
        for nd in self.node_list:
            if nd['params'].get('id') == src_nid:
                target_node_data = nd
                break
        
        if target_node_data:
            found_conn = None
            original_node = target_node_data.get('original_node')
            if original_node and hasattr(original_node, 'connections'):
                for conn in original_node.connections:
                    if conn.get('id') == connection_data.get('id'):
                        found_conn = conn
                        break
            if not found_conn:
                 conns = target_node_data['params'].get('connections', [])
                 for conn in conns:
                     if conn.get('id') == connection_data.get('id'):
                         found_conn = conn
                         break
            if found_conn:
                self.conn_editor.load_data(found_conn)
                self.editor_stack.setCurrentIndex(4)
                print(f"Editing Connection ID {found_conn.get('id')}")
            else:
                print("Connection reference not found in Editor list (maybe unsaved?). Editing copy.")
                self.conn_editor.load_data(connection_data)
                self.editor_stack.setCurrentIndex(4)
        else:
            print("Source Node for connection not found in Editor.")

    def remove_node(self):
        if self.current_node_idx is None: return
            
        node_data = self.node_list.pop(self.current_node_idx)
        
        if 'button' in node_data:
            self.node_list_layout.removeWidget(node_data['button'])
            node_data['button'].deleteLater()
        
        # Stable ID of the node being removed. Held BEFORE we touch the
        # graph so we can still reference it for the cross-graph sweep
        # below even if the node object gets cleaned out.
        deleted_node_id = node_data['params'].get('id', None)
        deleted_graph_id = self.current_graph_id
            
        if self.current_graph and node_data.get('original_node'):
            original_node = node_data['original_node']
            # Graph.remove_node -> Node.remove() walks self.prev to drop
            # incoming refs from same-graph predecessors. That covers
            # the connected-graph case but not the editor case where
            # `prev` may be incompletely populated (no connect() run yet,
            # cross-graph wiring delayed, etc.). The explicit sweep below
            # is the belt-and-braces version.
            self.current_graph.remove_node(original_node)
        
        # Explicit cross-graph + same-graph sweep: drop ANY connection in
        # ANY graph whose target points at the deleted node. Mirrors the
        # power of the GraphOverview's per-connection deletion path.
        if deleted_node_id is not None:
            self._sweep_incoming_connections(deleted_graph_id, deleted_node_id)
            
        # NO ID-cascading. Keep stable IDs so cross-graph references
        # in OTHER graphs that point at this graph's surviving nodes
        # still resolve correctly. The button label uses LIST POSITION
        # for human readability ("Node 1 of 5"), not ID.
        for i, node in enumerate(self.node_list):
            stable_id = node['params'].get('id', i)
            stable_name = node['params'].get('name', f'Node_{stable_id}')
            node['button'].setText(f"Node {i + 1}: {stable_name}")
            try: node['button'].clicked.disconnect()  # May not be connected
            except RuntimeError: pass  # No connections
            node['button'].clicked.connect(lambda checked=False, idx=i: self.select_node(idx))

        if self.node_list:
            new_idx = max(0, self.current_node_idx - 1)
            self.select_node(new_idx)
        else:
            self.current_node_idx = None
            self.current_pop_idx = None
            self.editor_stack.setCurrentIndex(0)
            self.remove_node_btn.setEnabled(False)
            self.add_pop_btn.setEnabled(False)
            self.remove_pop_btn.setEnabled(False)
            
            while self.pop_list_layout.count():
                item = self.pop_list_layout.takeAt(0)
                widget = item.widget()
                if widget is not None:
                    widget.setParent(None)
                    widget.deleteLater()
    
    def _sweep_incoming_connections(self, deleted_graph_id, deleted_node_id):
        """
        Walks every node in every graph and strips connections whose
        target points at (deleted_graph_id, deleted_node_id). Also
        rewrites the editor-side node_list mirror for the currently-
        loaded graph so a subsequent save_changes can't resurrect the
        old refs.
        
        Why both sides: graph node objects are the source of truth at
        runtime, but `_build_node_params` reads from
        `node_data['params']['connections']` (raw_params) FIRST during
        save (see comment block in _build_node_params). If we only
        clean the graph object and leave the editor mirror dirty,
        the save would re-introduce the dangling refs.
        """
        def _points_at_deleted(conn):
            tgt = conn.get('target', {}) or {}
            return (tgt.get('graph_id') == deleted_graph_id and
                    tgt.get('node_id') == deleted_node_id)
        
        removed_count = 0
        
        for graph in self.graph_list:
            for node in graph.node_list:
                # 1) Strip from the live attribute list
                if hasattr(node, 'connections') and node.connections:
                    before = len(node.connections)
                    node.connections = [c for c in node.connections
                                        if not _points_at_deleted(c)]
                    removed_count += before - len(node.connections)
                
                # 2) Strip from parameters['connections'] mirror
                if (hasattr(node, 'parameters')
                        and isinstance(node.parameters, dict)
                        and 'connections' in node.parameters
                        and node.parameters['connections']):
                    node.parameters['connections'] = [
                        c for c in node.parameters['connections']
                        if not _points_at_deleted(c)
                    ]
                
                # 3) Drop topology backref if isolated now
                if (hasattr(node, 'next') and node.next):
                    for tgt_node in list(node.next):
                        if (getattr(tgt_node, 'graph_id', None) == deleted_graph_id
                                and getattr(tgt_node, 'id', None) == deleted_node_id):
                            try: node.next.remove(tgt_node)
                            except ValueError: pass
        
        # 4) Editor mirror: same-graph node_list dicts. Each holds its
        #    own raw_params['connections']. Rewriting these here means
        #    save_changes won't resurrect the dropped entries.
        for nd in self.node_list:
            params = nd.get('params', {})
            conns = params.get('connections')
            if conns:
                params['connections'] = [c for c in conns
                                          if not _points_at_deleted(c)]
        
        if removed_count:
            print(f"_sweep_incoming_connections: dropped {removed_count} "
                  f"connection(s) targeting (g={deleted_graph_id}, "
                  f"n={deleted_node_id})")

    def remove_population(self):
        if self.current_node_idx is None or self.current_pop_idx is None:
            return
            
        node_wrapper = self.node_list[self.current_node_idx]
        
        # User-Wunsch: letzte Pop darf gelöscht werden, kein Auto-Anlegen.
        
        prob_vec = node_wrapper['params'].get('probability_vector', [])
        deleted_prob = 0.0
        if len(prob_vec) > self.current_pop_idx:
            deleted_prob = prob_vec.pop(self.current_pop_idx)
        
        if prob_vec and deleted_prob > 0:
            add_each = deleted_prob / len(prob_vec)
            node_wrapper['params']['probability_vector'] = [p + add_each for p in prob_vec]
        
        node_wrapper['populations'].pop(self.current_pop_idx)
        
        if node_wrapper.get('original_node'):
            node_obj = node_wrapper['original_node']
            new_conns = []
            targets_to_check = set()
            if hasattr(node_obj, 'connections'):
                for conn in node_obj.connections:
                    if conn['source']['pop_id'] == self.current_pop_idx:
                        tgt_gid = conn['target']['graph_id']
                        tgt_nid = conn['target']['node_id']
                        targets_to_check.add((tgt_gid, tgt_nid))
                        continue
                    if conn['source']['pop_id'] > self.current_pop_idx:
                        conn['source']['pop_id'] -= 1
                    if (conn['target']['graph_id'] == node_obj.graph_id and
                        conn['target']['node_id'] == node_obj.id and
                        conn['target']['pop_id'] > self.current_pop_idx):
                        conn['target']['pop_id'] -= 1
                    new_conns.append(conn)
                
                node_obj.connections = new_conns
                for (gid, nid) in targets_to_check:
                    tgt_graph = next((g for g in self.graph_list if g.graph_id == gid), None)
                    if tgt_graph:
                        tgt_node = tgt_graph.get_node(nid)
                        if tgt_node:
                            node_obj.remove_neighbor_if_isolated(tgt_node)
        
        self.update_population_list()
        
        num_pops = len(node_wrapper['populations'])
        self.node_param_widget.set_population_count(num_pops)
        self.node_param_widget.load_data(node_wrapper['params'])
        
        if num_pops > 0:
            new_idx = max(0, self.current_pop_idx - 1)
            self.select_population(new_idx)
        else:
            self.current_pop_idx = None
            self.remove_pop_btn.setEnabled(False)
            self.editor_stack.setCurrentIndex(1)

    def refresh_graph_list(self):
        current_graph_id = self.graph_selector.currentData()
        self.graph_selector.blockSignals(True)
        self.graph_selector.clear()
        
        if not self.graph_list:
            self.graph_selector.addItem("No graphs available")
            self.graph_selector.setEnabled(False)
        else:
            for graph in self.graph_list:
                name = getattr(graph, 'graph_name', f'Graph {graph.graph_id}')
                self.graph_selector.addItem(f"{name} (ID: {graph.graph_id})", graph.graph_id)
            self.graph_selector.setEnabled(True)
        
        target_index = 0
        if current_graph_id is not None:
            index = self.graph_selector.findData(current_graph_id)
            if index >= 0:
                target_index = index
        
        self.graph_selector.setCurrentIndex(target_index)
        self.graph_selector.blockSignals(False)
        
        if self.graph_selector.count() > 0 and self.graph_list:
            self.on_graph_selected(target_index)
    
    def on_graph_selected(self, index):
        if not self.graph_list or index < 0: return
        
        graph_id = self.graph_selector.currentData()
        if graph_id is None: return
        
        self.current_graph = None
        for graph in self.graph_list:
            if graph.graph_id == graph_id:
                self.current_graph = graph
                break
        
        if not self.current_graph:
            print(f"ERROR: Graph {graph_id} not found!")
            return
        
        self.current_graph_id = graph_id
        self.load_graph_data()
    
    def load_graph_data(self):
        if not self.current_graph: return
        
        self._loading = True  # FIX: Prevent save_current_population_params during load
        
        # FIX: Block signals on the parameter widget to prevent spurious saves
        self.pop_param_widget.blockSignals(True)
        self.pop_param_widget.model_combo.blockSignals(True)
        
        self.current_node_idx = None
        self.current_pop_idx = None
        
        stored_offset = getattr(self.current_graph, 'global_offset', [0.0, 0.0, 0.0])
        self.spin_g_x.setValue(stored_offset[0])
        self.spin_g_y.setValue(stored_offset[1])
        self.spin_g_z.setValue(stored_offset[2])
        
        self.node_list.clear()
        
        while self.node_list_layout.count():
            item = self.node_list_layout.takeAt(0)
            if item.widget(): item.widget().deleteLater()
        
        while self.pop_list_layout.count():
            item = self.pop_list_layout.takeAt(0)
            if item.widget(): item.widget().deleteLater()
        
        graph_name = getattr(self.current_graph, 'graph_name', f'Graph_{self.current_graph_id}')
        self.graph_name_input.setText(graph_name)
        
        for node in self.current_graph.node_list:
            self.load_node_from_graph(node)
        
        # FIX: Re-enable signals before selecting node
        self.pop_param_widget.model_combo.blockSignals(False)
        self.pop_param_widget.blockSignals(False)
        
        if self.node_list:
            self.select_node(0, auto_save=False)  # FIX: Don't save defaults during load
        
        self._loading = False  # FIX: Re-enable saving after load complete
    
    def load_node_from_graph(self, node):
        node_idx = len(self.node_list)
        node_btn = QPushButton(f"Node {node_idx + 1}: {node.name}")
        node_btn.setMinimumHeight(50)
        node_btn.clicked.connect(lambda checked=False, idx=node_idx: self.select_node(idx))
        self.node_list_layout.addWidget(node_btn)
        
        populations = []
        
        # FIX: First try to get params from node.parameters (original source of truth)
        stored_pop_params = []
        stored_shape_params = []
        if hasattr(node, 'parameters'):
            stored_pop_params = node.parameters.get('population_nest_params', [])
            stored_shape_params = node.parameters.get('shape_params_per_pop', [])
        
        node_tool_type = (node.parameters.get('tool_type', 'custom')
                          if hasattr(node, 'parameters') else 'custom')
        
        if hasattr(node, 'population') and node.population:
            for pop_idx, nest_pop in enumerate(node.population):
                if nest_pop is None or len(nest_pop) == 0: continue
                
                model = safe_get_model(nest_pop, 'unknown')
                params = {}
                
                # FIX: Prefer stored params over NEST status (they may have been modified)
                if pop_idx < len(stored_pop_params) and stored_pop_params[pop_idx]:
                    params = stored_pop_params[pop_idx].copy()
                else:
                    # Fallback: read from NEST
                    try:
                        status = safe_get_status(nest_pop)
                        if status:
                            first_neuron = status[0]
                            param_keys = ['V_m', 'E_L', 'tau_m', 'C_m', 'V_th', 't_ref', 'V_reset', 'I_e', 'tau_syn_ex', 'tau_syn_in']
                            for key in param_keys:
                                if key in first_neuron:
                                    params[key] = first_neuron[key]
                    except Exception as e:
                        print(f"Could not extract params from pop {pop_idx}: {e}")
                
                polynomials = {}
                if hasattr(node, 'parameters'):
                    encoded = node.parameters.get('encoded_polynoms_per_type', [])
                    if pop_idx < len(encoded) and encoded[pop_idx]:
                        poly_list = encoded[pop_idx]
                        if len(poly_list) >= 3:
                            polynomials = {'x': poly_list[0], 'y': poly_list[1], 'z': poly_list[2]}
                
                # Pro-Pop shape_params zurück-mappen (Backward-Compat: aus
                # node.parameters globalen Tool-Werten falls fehlend)
                pop_dict = {'model': model, 'params': params, 'polynomials': polynomials}
                if node_tool_type != 'custom':
                    if pop_idx < len(stored_shape_params) and stored_shape_params[pop_idx]:
                        pop_dict['shape_params'] = dict(stored_shape_params[pop_idx])
                    elif hasattr(node, 'parameters'):
                        pop_dict['shape_params'] = extract_shape_params(
                            node_tool_type, node.parameters)
                populations.append(pop_dict)
        
        node_data = {
            'params': node.parameters.copy() if hasattr(node, 'parameters') else {},
            'populations': populations,
            'button': node_btn,
            'original_node': node
        }
        
        node_data['params'].update({
            'id': node.id,
            'name': node.name,
            'center_of_mass': node.center_of_mass.tolist(),
            'm': node.center_of_mass.tolist(),
            'old_center_of_mass': getattr(node, 'old_center_of_mass', node.center_of_mass).tolist() if isinstance(getattr(node, 'old_center_of_mass', None), np.ndarray) else node.parameters.get('old_center_of_mass'),
            'probability_vector': node.parameters.get('probability_vector', [])
        })
        self.node_list.append(node_data)
    
    def add_node(self):
        import copy
        node_idx = len(self.node_list)
        
        # FIX: Stable-ID allocation. List-position is fine for the button
        # label but NOT for params['id'] — if a previous Node_2 was
        # deleted, the gap [0,1,3,4] should be filled with id=2, not
        # id=4. Otherwise we'd have id-collisions or unreachable slots,
        # and Graph.create_node's free-slot search would do the right
        # thing at save time anyway — but doing it here keeps the editor
        # state consistent with what the eventual save will produce.
        used_ids = set()
        for n in self.node_list:
            try:
                nid = int(n['params'].get('id', -1))
                if nid >= 0:
                    used_ids.add(nid)
            except (TypeError, ValueError):
                pass
        new_id = 0
        while new_id in used_ids:
            new_id += 1
        
        node_btn = QPushButton(f"Node {node_idx + 1} (NEW)")
        node_btn.setMinimumHeight(50)
        node_btn.clicked.connect(lambda checked=False, idx=node_idx: self.select_node(idx))
        self.node_list_layout.addWidget(node_btn)
        
        node_params = copy.deepcopy(node_parameters1)
        node_params['id'] = new_id
        node_params['name'] = f"Node_{new_id}"
        node_params['probability_vector'] = []
        node_params['m'] = [0.0, 0.0, 0.0]
        node_params['center_of_mass'] = [0.0, 0.0, 0.0]
        node_params['displacement'] = [0.0, 0.0, 0.0]
        
        self.node_list.append({
            'params': node_params,
            'populations': [],
            'button': node_btn,
            'original_node': None
        })
        self.select_node(node_idx)
    
    def select_node(self, node_idx, auto_save=True):
        if node_idx < 0 or node_idx >= len(self.node_list): return
        
        # FIX: Only save if auto_save is True and we're not loading
        if auto_save and not getattr(self, '_loading', False):
            self.save_current_population_params()
        
        self.current_node_idx = node_idx
        self.current_pop_idx = None
        
        for i, node in enumerate(self.node_list):
            if i == node_idx:
                node['button'].setStyleSheet("background-color: #2196F3; color: white;")
            else:
                node['button'].setStyleSheet("")
        self.remove_node_btn.setEnabled(len(self.node_list) > 1)

        node_data = self.node_list[node_idx]
        tool_type = node_data['params'].get('tool_type', 'custom')
        
        # Konsistent mit GraphCreatorWidget: Auto-add EINE Default-Pop bei
        # leerem Tool-Type-Knoten + prob_vec setzen.
        if tool_type != 'custom' and not node_data['populations']:
            model = node_data['params'].get('tool_neuron_model', 'iaf_psc_alpha')
            shape_params = extract_shape_params(tool_type, node_data['params'])
            node_data['populations'].append({
                'model': model,
                'params': {},
                'shape_params': shape_params,
                'polynomials': {'x': [], 'y': [], 'z': []}
            })
            node_data['params']['probability_vector'] = [1.0]
        
        num_pops = len(node_data['populations'])
        self.node_param_widget.set_population_count(num_pops)
        
        # Tool-Panel mit Shape-Params der ersten Pop mergen, falls Tool-Type
        load_params = dict(node_data['params'])
        if tool_type != 'custom' and num_pops > 0:
            first_pop = node_data['populations'][0]
            shape = first_pop.get('shape_params', {})
            if not shape:
                shape = dict(SHAPE_PARAM_DEFAULTS.get(tool_type, {}))
                first_pop['shape_params'] = shape
            load_params.update(shape)
            load_params['tool_neuron_model'] = first_pop.get(
                'model', load_params.get('tool_neuron_model'))
        
        self.node_param_widget.load_data(load_params)
        self.editor_stack.setCurrentIndex(1)
        
        self.update_population_list()
        self.add_pop_btn.setEnabled(True)
    
    def save_node_params(self, params):
        if self.current_node_idx is not None:
            params['m'] = params['center_of_mass'].copy()
            node = self.node_list[self.current_node_idx]
            num_pops = len(node['populations'])
            if num_pops > 0:
                # Robuste prob_vec Behandlung (kein 0.0-Padding, das zu prob_vec=0 führt)
                current_probs = params.get('probability_vector', [])
                needs_reset = (
                    not current_probs
                    or len(current_probs) != num_pops
                    or sum(current_probs) <= 1e-9
                )
                if needs_reset:
                    current_probs = [1.0 / num_pops] * num_pops
                params['probability_vector'] = current_probs
                
                self.node_param_widget.auto_save = False
                self.node_param_widget.load_data(params)
                self.node_param_widget.auto_save = True
            
            # Tool-Type: Shape-Params auf aktuelle (oder erste) Pop spiegeln
            tool_type = params.get('tool_type', 'custom')
            if tool_type != 'custom' and num_pops > 0:
                target_pop_idx = self.current_pop_idx if self.current_pop_idx is not None else 0
                if 0 <= target_pop_idx < num_pops:
                    target_pop = node['populations'][target_pop_idx]
                    target_pop['shape_params'] = extract_shape_params(tool_type, params)
                    tm = params.get('tool_neuron_model')
                    if tm:
                        target_pop['model'] = tm
                        if 'button' in target_pop:
                            target_pop['button'].setText(
                                f"Pop {target_pop_idx+1}: {tm}")
            
            self.node_list[self.current_node_idx]['params'] = params
    
    def add_population(self):
        if self.current_node_idx is None: return
        self.save_current_population_params()
        node = self.node_list[self.current_node_idx]
        pop_idx = len(node['populations'])
        tool_type = node['params'].get('tool_type', 'custom')
        
        default_polynomials = {
            'x': generate_biased_polynomial(axis_idx=0, max_degree=2),
            'y': generate_biased_polynomial(axis_idx=1, max_degree=2),
            'z': generate_biased_polynomial(axis_idx=2, max_degree=2)
        }
        new_pop = {'model': 'iaf_psc_alpha', 'params': {}, 'polynomials': default_polynomials}
        if tool_type != 'custom':
            current_panel = self.node_param_widget.get_current_params()
            shape_params = extract_shape_params(tool_type, current_panel)
            if not shape_params:
                shape_params = dict(SHAPE_PARAM_DEFAULTS.get(tool_type, {}))
            new_pop['shape_params'] = shape_params
            tool_model = current_panel.get('tool_neuron_model')
            if tool_model:
                new_pop['model'] = tool_model
        node['populations'].append(new_pop)
        
        num_pops = len(node['populations'])
        self.node_param_widget.set_population_count(num_pops)
        node['params']['probability_vector'] = [1.0/num_pops] * num_pops
        self.node_param_widget.load_data(node['params'])
        
        self.update_population_list()
        self.select_population(pop_idx)
    
    def update_population_list(self):
        while self.pop_list_layout.count():
            item = self.pop_list_layout.takeAt(0)
            if item.widget(): item.widget().setParent(None)
        if self.current_node_idx is None: return
        node = self.node_list[self.current_node_idx]
        for i, pop in enumerate(node['populations']):
            pop_btn = QPushButton(f"Pop {i+1}: {pop['model']}")
            pop_btn.setMinimumHeight(40)
            pop_btn.clicked.connect(lambda checked, idx=i: self.select_population(idx))
            self.pop_list_layout.addWidget(pop_btn)
            pop['button'] = pop_btn
    
    def select_population(self, pop_idx, auto_save=True):
        # FIX: Only save if auto_save is True and we're not loading
        if auto_save and not getattr(self, '_loading', False):
            self.save_current_population_params()
        
        self.current_pop_idx = pop_idx
        node = self.node_list[self.current_node_idx]
        for i, pop in enumerate(node['populations']):
            if i == pop_idx:
                pop['button'].setStyleSheet("background-color: #2196F3; color: white;")
            else:
                pop['button'].setStyleSheet("")
        pop = node['populations'][pop_idx]
        
        # Tool-Panel mit pop-spezifischen shape_params syncen
        tool_type = node['params'].get('tool_type', 'custom')
        if tool_type != 'custom':
            merged = dict(node['params'])
            shape = pop.get('shape_params', {})
            if not shape:
                shape = dict(SHAPE_PARAM_DEFAULTS.get(tool_type, {}))
                pop['shape_params'] = shape
            merged.update(shape)
            merged['tool_neuron_model'] = pop.get('model', merged.get('tool_neuron_model'))
            self.node_param_widget.auto_save = False
            self.node_param_widget.load_data(merged)
            self.node_param_widget.auto_save = True
        
        # KRITISCH: NEST-Param-Widget IMMER frisch rebuilden + SYNCHRON
        # load_params (vorher QTimer war race-prone).
        self.pop_param_widget.blockSignals(True)
        self.pop_param_widget.model_combo.blockSignals(True)
        self.pop_param_widget.model_combo.setCurrentText(pop['model'])
        self.pop_param_widget.model_combo.blockSignals(False)
        self.pop_param_widget.on_model_changed(pop['model'])
        if pop.get('params'):
            self.pop_param_widget.load_params(pop['params'])
        self.pop_param_widget.blockSignals(False)
        
        self.editor_stack.setCurrentIndex(2)
        self.remove_pop_btn.setEnabled(True)

    def create_twin_node(self):
        import copy
        if self.current_node_idx is None: return
        self.save_node_params(self.node_param_widget.get_current_params())
        self.save_current_population_params()
        
        source_node = self.node_list[self.current_node_idx]
        clean_populations = []
        if 'populations' in source_node:
            for pop in source_node['populations']:
                clean_pop = {'model': pop.get('model'),
                             'params': pop.get('params', {}),
                             'polynomials': pop.get('polynomials', {})}
                # shape_params (Tool-Geometrie pro Pop) mitkopieren
                if 'shape_params' in pop:
                    clean_pop['shape_params'] = dict(pop['shape_params'])
                clean_populations.append(clean_pop)
        
        data_to_copy = {'params': source_node['params'], 'populations': clean_populations}
        new_node_data = copy.deepcopy(data_to_copy)
        
        current_pos = source_node['params'].get('center_of_mass', [0,0,0])
        old_id = source_node['params'].get('id')
        
        dlg = PositionDialog(current_pos, self)
        if dlg.exec():
            new_pos = dlg.get_position()
            if 'button' in new_node_data: del new_node_data['button']
            new_node_data['original_node'] = None
            new_idx = len(self.node_list)
            old_name = source_node['params'].get('name', 'Node')
            new_name = f"{old_name}_Twin"
            
            new_node_data['params']['id'] = new_idx
            new_node_data['params']['name'] = new_name
            new_node_data['params']['m'] = list(new_pos)
            new_node_data['params']['center_of_mass'] = list(new_pos)
            new_node_data['params']['old_center_of_mass'] = list(new_pos)
            
            source_conns = source_node['params'].get('connections', [])
            twin_conns = []
            max_conn_id = 0
            for node in self.node_list:
                for c in node['params'].get('connections', []):
                    if isinstance(c.get('id'), int): max_conn_id = max(max_conn_id, c.get('id'))
            
            for i, conn in enumerate(source_conns):
                src_id = conn['source'].get('node_id')
                tgt_id = conn['target'].get('node_id')
                if src_id == old_id and tgt_id == old_id:
                    new_conn = copy.deepcopy(conn)
                    new_conn['source']['node_id'] = new_idx
                    new_conn['target']['node_id'] = new_idx
                    max_conn_id += 1
                    new_conn['id'] = max_conn_id
                    new_conn['name'] = f"{conn.get('name', 'conn')}_Twin"
                    if 'error' in new_conn: del new_conn['error']
                    twin_conns.append(new_conn)
            
            new_node_data['params']['connections'] = twin_conns
            node_btn = QPushButton(f"Node {new_idx + 1} (NEW TWIN)")
            node_btn.setMinimumHeight(50)
            node_btn.clicked.connect(lambda checked=False, idx=new_idx: self.select_node(idx))
            self.node_list_layout.addWidget(node_btn)
            new_node_data['button'] = node_btn
            self.node_list.append(new_node_data)
            self.select_node(new_idx)



    def _build_node_params(self, node_idx, node_data):

        import copy
        
        raw_params = node_data['params']
        populations = node_data['populations']
        tool_type = raw_params.get('tool_type', 'custom')

        if tool_type != 'custom' and not populations:
            selected_model = raw_params.get('tool_neuron_model', 'iaf_psc_alpha')
            neuron_models = [selected_model]
            types = [0]
            encoded_polynoms_per_type = [[]]
            prob_vec = [1.0]
            pop_nest_params = [{}]
            shape_params_per_pop = [extract_shape_params(tool_type, raw_params)]
        elif tool_type in ('Blob', 'Cone', 'CCW', 'Grid'):
            # Pro-Pop Modelle erlauben (statt globalem Override)
            fallback_model = raw_params.get('tool_neuron_model', 'iaf_psc_alpha')
            if populations:
                neuron_models = [pop.get('model') or fallback_model for pop in populations]
            else:
                neuron_models = [fallback_model]
            
            # Setze die anderen erforderlichen Variablen
            types = list(range(len(populations))) if populations else [0]
            encoded_polynoms_per_type = []
            for pop in populations:
                poly_dict = pop.get('polynomials', None)
                if poly_dict and all(k in poly_dict for k in ['x', 'y', 'z']):
                    encoded_polynoms_per_type.append([poly_dict['x'], poly_dict['y'], poly_dict['z']])
                else:
                    encoded_polynoms_per_type.append([])
            if not encoded_polynoms_per_type:
                encoded_polynoms_per_type = [[]]
            
            prob_vec = raw_params.get('probability_vector', [])
            if not prob_vec or len(prob_vec) != len(neuron_models):
                prob_vec = [1.0 / len(neuron_models)] * len(neuron_models)
            
            pop_nest_params = ([pop.get('params', {}) for pop in populations]
                                if populations else [{}])
            
            # Pro-Pop Shape-Params (Backward-Compat: falls fehlend, aus Node-Globals)
            shape_params_per_pop = []
            for pop in populations:
                sp = pop.get('shape_params')
                if not sp:
                    sp = extract_shape_params(tool_type, raw_params)
                shape_params_per_pop.append(dict(sp))
            if not shape_params_per_pop:
                shape_params_per_pop = [extract_shape_params(tool_type, raw_params)]
        else:
            neuron_models = [pop['model'] for pop in populations]
            types = list(range(len(populations)))
            
            encoded_polynoms_per_type = []
            for pop in populations:
                poly_dict = pop.get('polynomials', None)
                if poly_dict and all(k in poly_dict for k in ['x', 'y', 'z']):
                    encoded_polynoms_per_type.append([poly_dict['x'], poly_dict['y'], poly_dict['z']])
                else:
                    encoded_polynoms_per_type.append([])
            
            prob_vec = raw_params.get('probability_vector', [])
            if not prob_vec or len(prob_vec) != len(populations):
                if len(populations) > 0:
                    prob_vec = [1.0 / len(populations)] * len(populations)
                else:
                    prob_vec = []
            
            pop_nest_params = [pop.get('params', {}) for pop in populations]
            shape_params_per_pop = [{} for _ in populations]

        old_com = raw_params.get('old_center_of_mass', None)
        if old_com is None and node_data.get('original_node'):
            orig = node_data['original_node']
            if hasattr(orig, 'old_center_of_mass'):
                val = getattr(orig, 'old_center_of_mass', None)
                if isinstance(val, np.ndarray): val = val.tolist()
                old_com = val
            if old_com is None and hasattr(orig, 'center_of_mass'):
                val = orig.center_of_mass
                if isinstance(val, np.ndarray): val = val.tolist()
                old_com = val
        
        if old_com is None:
            old_com = raw_params.get('center_of_mass', [0.0, 0.0, 0.0])

        sx = float(raw_params.get('stretch_x', 1.0))
        sy = float(raw_params.get('stretch_y', 1.0))
        sz = float(raw_params.get('stretch_z', 1.0))
        transform_matrix = [[sx, 0.0, 0.0], [0.0, sy, 0.0], [0.0, 0.0, sz]]

        # FIX: Connections und Devices haben UNTERSCHIEDLICHE Source-of-Truth!
        #
        # - Connections werden ueber den Editor/ConnectionTool verwaltet und
        #   landen in node_data['params']['connections'] (raw_params).
        #   -> raw_params bevorzugen. Nur wenn raw_params keinen Eintrag hat
        #      (z.B. neuer Node, noch nie editiert), auf original_node zurueckfallen.
        #
        # - Devices werden ueber den Device-Manager DIREKT auf dem Node-Objekt
        #   modifiziert (node.devices, node.parameters['devices']), NICHT im
        #   Editor-Dict. Der Editor-State ist deshalb fuer Devices veraltet.
        #   -> original_node bevorzugen. Raw_params nur als Fallback.
        #
        # Vorher (falscher Fix): raw_params fuer BEIDES bevorzugt -> Devices gingen
        # beim Save einer Connection-Aenderung verloren.

        existing_connections = []
        original_node = node_data.get('original_node')

        # Connections: Editor-State ist autoritativ WENN der Key existiert
        # (auch wenn die Liste explizit leer ist - User hat alles geloescht).
        if 'connections' in raw_params:
            existing_connections = [copy.deepcopy(c) for c in raw_params['connections']]
        elif original_node:
            if hasattr(original_node, 'connections') and original_node.connections:
                existing_connections = [copy.deepcopy(c) for c in original_node.connections]
            elif hasattr(original_node, 'parameters') and 'connections' in original_node.parameters:
                existing_connections = [copy.deepcopy(c) for c in original_node.parameters['connections']]

        existing_devices = []
        if original_node:
            source_list = []
            if hasattr(original_node, 'devices') and original_node.devices:
                source_list = original_node.devices
            elif hasattr(original_node, 'parameters') and 'devices' in original_node.parameters:
                source_list = original_node.parameters['devices']

            for d in source_list:
                d_safe = d.copy()
                if 'runtime_gid' in d_safe:
                    d_safe['runtime_gid'] = None
                existing_devices.append(copy.deepcopy(d_safe))

        # Fallback fuer Devices: nur wenn original_node gar keine Devices hat,
        # raw_params konsultieren (betrifft neu angelegte Nodes).
        if not existing_devices:
            raw_devs = raw_params.get('devices', None)
            if raw_devs:
                for d in raw_devs:
                    d_safe = d.copy()
                    if 'runtime_gid' in d_safe:
                        d_safe['runtime_gid'] = None
                    existing_devices.append(copy.deepcopy(d_safe))

        # ID-basierte Deduplication gegen alte Doppelt-Append-Artefakte
        seen_dev_ids = set()
        deduped_devices = []
        for d in existing_devices:
            did = d.get('id')
            key = did if did is not None else id(d)
            if key in seen_dev_ids:
                continue
            seen_dev_ids.add(key)
            deduped_devices.append(d)
        existing_devices = deduped_devices

        for dev in existing_devices:
            if 'runtime_gid' in dev: dev['runtime_gid'] = None

        return {
            'name': raw_params.get('name', f'Node_{node_idx}'),
            # FIX: Preserve the stable ID from raw_params instead of
            # overwriting with list-position node_idx. Without this, every
            # save_changes would compact IDs sequentially (cascade), which
            # silently breaks cross-graph connections that still point at
            # the OLD ID of surviving nodes. node_idx is only the fallback
            # for brand-new nodes whose params dict has no id yet.
            'id': raw_params.get('id', node_idx),
            'graph_id': self.current_graph_id,
            'tool_type': tool_type,
            'neuron_models': neuron_models,
            'types': types,
            'distribution': prob_vec,
            'probability_vector': prob_vec,
            'encoded_polynoms_per_type': encoded_polynoms_per_type,
            'population_nest_params': pop_nest_params,
            'shape_params_per_pop': shape_params_per_pop,  # NEU: pro-Pop Tool-Geometrie
            'auto_spike_recorder': raw_params.get('auto_spike_recorder', False),
            'auto_multimeter': raw_params.get('auto_multimeter', False),
            
            'devices': existing_devices,
            'connections': existing_connections,

            # Top-Level-Tool-Werte als FALLBACK / Default (Backward-Compat)
            'ccw_syn_config': raw_params.get('ccw_syn_config',
                                              {'synapse_model': 'static_synapse', 'extra_params': {}}),
            'ccw_syn_model': raw_params.get('ccw_syn_model', 'static_synapse'),
            'ccw_weight_ex': float(raw_params.get('ccw_weight_ex', 30.0)),
            'ccw_delay_ex': float(raw_params.get('ccw_delay_ex', 1.0)),
            'weight_in_factor': float(raw_params.get('weight_in_factor', 1.0)),
            # CCW/Cone connection-rule Defaults
            'conn_rule': raw_params.get('conn_rule', 'similarity'),
            'conn_p': float(raw_params.get('conn_p', 1.0)),
            'conn_indegree': int(raw_params.get('conn_indegree', 10)),
            'conn_outdegree': int(raw_params.get('conn_outdegree', 10)),
            # Blob synaptic Defaults
            'blob_p_ex': float(raw_params.get('blob_p_ex', 0.8)),
            'blob_p_in': float(raw_params.get('blob_p_in', 0.2)),
            'blob_weight_ex': float(raw_params.get('blob_weight_ex', 2.0)),
            'blob_weight_in': float(raw_params.get('blob_weight_in', -10.0)),
            'blob_delay_ex': float(raw_params.get('blob_delay_ex', 1.0)),
            'blob_delay_in': float(raw_params.get('blob_delay_in', 1.0)),
            'blob_syn_config_ex': raw_params.get('blob_syn_config_ex',
                                                   {'synapse_model': 'static_synapse', 'extra_params': {}}),
            'blob_syn_config_in': raw_params.get('blob_syn_config_in',
                                                   {'synapse_model': 'static_synapse', 'extra_params': {}}),
            'blob_syn_model_ex': raw_params.get('blob_syn_model_ex', 'static_synapse'),
            'blob_syn_model_in': raw_params.get('blob_syn_model_in', 'static_synapse'),
            'blob_allow_autapses': bool(raw_params.get('blob_allow_autapses', False)),
            'k': float(raw_params.get('k', 10.0)),
            'bidirectional': bool(raw_params.get('bidirectional', False)),
            'n_neurons': int(raw_params.get('n_neurons', 100)),
            'radius': float(raw_params.get('radius', 5.0)),
            'radius_top': float(raw_params.get('radius_top', 1.0)),
            'radius_bottom': float(raw_params.get('radius_bottom', 5.0)),
            'height': float(raw_params.get('height', 10.0)),
            'grid_side_length': int(raw_params.get('grid_side_length', 10)),
            'm': raw_params.get('center_of_mass', [0.0, 0.0, 0.0]),
            'center_of_mass': raw_params.get('center_of_mass', [0.0, 0.0, 0.0]),
            'displacement': raw_params.get('displacement', [0.0, 0.0, 0.0]),
            'displacement_factor': float(raw_params.get('displacement_factor', 1.0)),
            'rot_theta': float(raw_params.get('rot_theta', 0.0)),
            'rot_phi': float(raw_params.get('rot_phi', 0.0)),
            'transform_matrix': transform_matrix,
            'stretch_x': sx, 'stretch_y': sy, 'stretch_z': sz,
            'old_center_of_mass': old_com,
            'grid_size': raw_params.get('grid_size', [10, 10, 10]),
            'dt': float(raw_params.get('dt', 0.01)),
            'old': raw_params.get('old', True),
            'num_steps': int(raw_params.get('num_steps', 8)),
            'sparse_holes': int(raw_params.get('sparse_holes', 0)),
            'sparsity_factor': float(raw_params.get('sparsity_factor', 0.9)),
            'polynom_max_power': int(raw_params.get('polynom_max_power', 5)),
            'conn_prob': [],
            'field': None,
            'coefficients': None
        }
    
    
    
    
    def save_current_population_params(self):
        # FIX: Don't save during load - this prevents default values from overwriting loaded data
        if getattr(self, '_loading', False):
            return
            
        if self.current_node_idx is not None and self.current_pop_idx is not None:
            if self.current_node_idx < 0 or self.current_node_idx >= len(self.node_list): return
            node = self.node_list[self.current_node_idx]
            if self.current_pop_idx < 0 or self.current_pop_idx >= len(node['populations']): return
            pop = node['populations'][self.current_pop_idx]
            if self.pop_param_widget.current_model:
                pop['model'] = self.pop_param_widget.current_model
                new_params = {k: w.get_value() for k, w in self.pop_param_widget.parameter_widgets.items()}
                pop['params'] = new_params
                if 'button' in pop: pop['button'].setText(f"Pop {self.current_pop_idx+1}: {pop['model']}")
    
    def _on_population_params_saved(self, model_name, params):
        """FIX: Handler for when 'Save Parameters' button is clicked in NeuronParametersWidget"""
        self.save_current_population_params()

    def open_polynomial_editor(self):
        if self.current_node_idx is None:
            print("Please select a node first!")
            return
        node = self.node_list[self.current_node_idx]
        if not node['populations']:
            print("Please add populations first!")
            return
        self.save_current_population_params()
        if hasattr(self, '_last_polynomial_node_idx') and self._last_polynomial_node_idx is not None:
            last_node = self.node_list[self._last_polynomial_node_idx]
            all_polynomials = self.polynom_manager.get_all_polynomials()
            for i, poly_dict in enumerate(all_polynomials):
                if i < len(last_node['populations']):
                    last_node['populations'][i]['polynomials'] = poly_dict
        self._last_polynomial_node_idx = self.current_node_idx
        self.polynom_manager.set_populations(node['populations'])
        self.editor_stack.setCurrentIndex(3)

    def delete_graph(self):
        if not self.current_graph: return
        from PyQt6.QtWidgets import QMessageBox
        reply = QMessageBox.question(self, 'Delete Graph', f"Really delete '{self.current_graph.graph_name}'?", QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            # WICHTIG: Erst alle Nodes des Graphen einzeln raeumen damit
            # Cross-Graph-Predecessoren in ANDEREN Graphen ihre Connection-
            # Eintraege auf den geloeschten Graph verlieren. Erst danach
            # den Graph selbst aus der Liste werfen.
            try:
                if hasattr(self.current_graph, 'dispose'):
                    self.current_graph.dispose()
                else:
                    # Fallback fuer aeltere neuron_toolbox-Versionen
                    for node in list(self.current_graph.node_list):
                        try:
                            self.current_graph.remove_node(node)
                        except Exception as e:
                            print(f"delete_graph cleanup: {e}")
            except Exception as e:
                print(f"delete_graph dispose error: {e}")
            
            self.graph_list.remove(self.current_graph)
            import nest
            nest.ResetKernel()
            state._nest_simulation_has_run = False
            for graph in self.graph_list:
                for node in graph.node_list: node.populate_node()
            self.current_graph = None
            self.current_graph_id = None
            self.refresh_graph_list()
            self.graphUpdated.emit(-1)
    def _node_was_edited(self, node_data):

        original = node_data.get('original_node')
        
        if not original:
            return True, True, True
        
        any_change = False
        polynomials_changed = False
        structural_changed = False
        
        if not hasattr(original, 'parameters'):
            return True, True, True
        
        old_params = original.parameters
        new_params = node_data['params']
        
        structural_keys = [
            'grid_size', 'num_steps', 'sparsity_factor', 'sparse_holes',
            'dt', 'displacement', 'displacement_factor',
            'rot_theta', 'rot_phi', 'polynom_max_power',
            'stretch_x', 'stretch_y', 'stretch_z',
            'n_neurons', 'radius', 'radius_top', 'radius_bottom', 'height', 'grid_side_length' 
        ]
        
        for key in structural_keys:
            old_val = old_params.get(key)
            new_val = new_params.get(key)
            
            if old_val != new_val:
                any_change = True
                structural_changed = True

        old_com = np.array(original.center_of_mass)
        new_com = np.array(new_params.get('center_of_mass', [0,0,0]))
        if not np.allclose(old_com, new_com, atol=1e-6):
            any_change = True
        
        old_pop_count = len(original.population) if hasattr(original, 'population') and original.population else 0
        new_pop_count = len(node_data['populations'])
        
        if old_pop_count != new_pop_count:
            any_change = True
            structural_changed = True
        
        old_models = original.neuron_models if hasattr(original, 'neuron_models') else []
        new_models = [pop['model'] for pop in node_data['populations']]
        if old_models != new_models:
            any_change = True
            structural_changed = True 

        if 'population_nest_params' in old_params:
            old_nest_params = old_params['population_nest_params']
            new_nest_params = [pop.get('params', {}) for pop in node_data['populations']]
            
            if len(old_nest_params) == len(new_nest_params):
                for i, (old_p, new_p) in enumerate(zip(old_nest_params, new_nest_params)):
                    if old_p != new_p:
                        any_change = True
                        structural_changed = True 

        old_prob = old_params.get('probability_vector', [])
        new_prob = new_params.get('probability_vector', [])
        if old_prob != new_prob:
            any_change = True
            structural_changed = True

        if 'encoded_polynoms_per_type' in old_params:
            old_polys = old_params['encoded_polynoms_per_type']
            new_polys = []
            for pop in node_data['populations']:
                poly_dict = pop.get('polynomials', {})
                if poly_dict and all(k in poly_dict for k in ['x', 'y', 'z']):
                    new_polys.append([poly_dict['x'], poly_dict['y'], poly_dict['z']])
                else:
                    new_polys.append([])
            
            if len(old_polys) != len(new_polys):
                any_change = True
                polynomials_changed = True
                structural_changed = True
            else:
                if old_polys != new_polys:
                    any_change = True
                    polynomials_changed = True
                    structural_changed = True

        return any_change, polynomials_changed, structural_changed
    
    def save_changes(self):
        if not self.current_graph:
            print("ERROR: No graph selected!")
            return
        
        if not self.graph_name_input.text():
            print("ERROR: Graph name required!")
            return

        for i, node in enumerate(self.node_list):
            tool_type = node['params'].get('tool_type', 'custom')
            if tool_type == 'custom' and not node['populations']:
                print(f"ERROR: Node {i+1} (Custom) has no populations! Please add populations.")
                return

        new_name = self.graph_name_input.text()
        self.current_graph.graph_name = new_name
        self.save_current_population_params()
        
        if hasattr(self, '_last_polynomial_node_idx') and self._last_polynomial_node_idx is not None:
            last_node = self.node_list[self._last_polynomial_node_idx]
            all_polynomials = self.polynom_manager.get_all_polynomials()
            for i, poly_dict in enumerate(all_polynomials):
                if i < len(last_node['populations']):
                    last_node['populations'][i]['polynomials'] = poly_dict
        
        gx = self.spin_g_x.value()
        gy = self.spin_g_y.value()
        gz = self.spin_g_z.value()
        graph_global_offset = np.array([gx, gy, gz])
        
        self.current_graph.global_offset = [gx, gy, gz]
        
        print(f"\n=== Saving changes to Graph {self.current_graph_id} (Global Offset: {graph_global_offset}) ===")
        
        edited_analysis = [self._node_was_edited(n) for n in self.node_list]
        nodes_with_structural_changes = [
            (n, i) for i, (n, (_, _, structural)) in enumerate(zip(self.node_list, edited_analysis))
            if structural
        ]
        structural_change_indices = {idx for _, idx in nodes_with_structural_changes}

        nest.ResetKernel()
        state._nest_simulation_has_run = False
        
        self.current_graph.node_list.clear()
        self.current_graph.nodes = 0
        # FIX: Also clear node_dict so stale name/id->node mappings can't
        # block _allocate_node_id from honoring requested IDs from
        # _build_node_params. _next_id no longer needs an explicit reset
        # — Graph._allocate_node_id derives it from used IDs each call.
        self.current_graph.node_dict = {}
        
        for node_idx, node_data in enumerate(self.node_list):
            node_params = self._build_node_params(node_idx, node_data)
            
            local_disp = np.array(node_params.get('displacement', [0.0, 0.0, 0.0]))
            
            total_displacement = local_disp + graph_global_offset
            
            node_params['displacement'] = total_displacement.tolist()
            
            original_node = node_data.get('original_node')
            
            if node_idx == 0:
                new_node = self.current_graph.create_node(
                    parameters=node_params,
                    is_root=True,
                    auto_build=False
                )
            else:
                user_pos = node_params.get('center_of_mass', [0.0, 0.0, 0.0])
                has_explicit_position = not np.allclose(user_pos, [0.0, 0.0, 0.0])
                
                if has_explicit_position:
                    new_node = self.current_graph.create_node(
                        parameters=node_params,
                        auto_build=False
                    )
                else:
                    new_node = self.current_graph.create_node(
                        parameters=node_params,
                        other=self.current_graph.node_list[node_idx - 1],
                        auto_build=False
                    )
            
            has_structural_change = node_idx in structural_change_indices
            
            original_has_points = False
            if original_node and hasattr(original_node, 'positions') and original_node.positions:
                original_has_points = any(len(c) > 0 for c in original_node.positions if c is not None)

            if has_structural_change or not original_has_points:
                reason = "Structural change" if has_structural_change else "Original positions empty/invalid"
                print(f"  Node {node_idx}: REBUILD ({reason})")
                try:
                    new_node.build()
                except Exception as e:
                    print(f"Build failed for Node {node_idx}: {e}")
            
            elif original_node:
                old_com = np.array(original_node.center_of_mass)
                new_com = np.array(node_params['center_of_mass'])

                print(f"  Node {node_idx}: Rebuild due to potential offset shift.")
                new_node.build()
                
            new_node.populate_node()
        
        for graph in self.graph_list:
            if graph.graph_id == self.current_graph_id:
                continue
            for node in graph.node_list:
                node.populate_node()
        
        print(f"Graph '{self.current_graph.graph_name}' updated!")
        
        self.graphUpdated.emit(-1)
        idx = self.graph_selector.currentIndex()
        if idx >= 0:
            new_label = f"{new_name} (ID: {self.current_graph_id})"
            self.graph_selector.setItemText(idx, new_label)
