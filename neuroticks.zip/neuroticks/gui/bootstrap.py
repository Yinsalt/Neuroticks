"""Einmalige GUI-Initialisierung.

Lädt die schweren Bibliotheken in derselben Reihenfolge wie das frühere Main.py
(Qt -> pyqtgraph -> pyvista -> matplotlib/Qt -> vtk -> NEST) und setzt danach die
pyqtgraph-Optionen.  Wird von den GUI-Unterpaketen importiert.
"""
# flake8: noqa
import PyQt6.QtWidgets
import numpy
import pyqtgraph
import pyvista
import scipy.ndimage
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
import matplotlib.pyplot
import pyvistaqt
import pyqtgraph.dockarea
import pyqtgraph.opengl
import vtk
import neuron_toolbox

from neuroticks.gui import pg_config
