"""Eigenständige Tabs des Hauptfensters."""
