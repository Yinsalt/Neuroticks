"""Device-Werkzeug des Sewing-Tabs (hängt Devices nur ans Datenmodell)."""
import numpy as np
from PyQt6.QtWidgets import QComboBox, QFormLayout, QLabel, QPushButton, QWidget

from neuroticks.gui.widgets.device_tools import DeviceConfigPage, ToolsWidget

class SewingDeviceTool(ToolsWidget):
    def __init__(self):
        super().__init__()
        
        self.layout().addWidget(QLabel("----------------"))
        self.btn_delete = QPushButton("🗑 Delete Current Device")
        self.btn_delete.setStyleSheet("background-color: #D32F2F; color: white; font-weight: bold;")
        self.btn_delete.clicked.connect(self.delete_current_device)
        self.layout().addWidget(self.btn_delete)

        for i in range(self.config_stack.count()):
            widget = self.config_stack.widget(i)
            if isinstance(widget, DeviceConfigPage):
                try: widget.deviceCreated.disconnect() 
                except: pass
                try: widget.deviceUpdated.disconnect() 
                except: pass
                
                widget.deviceCreated.connect(self.on_device_created_offline)
                widget.deviceUpdated.connect(self.on_device_updated_offline)
                
                widget.btn_create.setText(f"Attach {widget.device_label}")
                style = widget.btn_create.styleSheet()
                widget.btn_create.setStyleSheet(style.replace("#E91E63", "#00838F").replace("#FF9800", "#00838F"))
                
                old_sel = widget.target_selector
                layout = old_sel.parentWidget().layout()
                layout.removeWidget(old_sel); old_sel.deleteLater()
                
                new_sel = SewingDeviceTargetSelector(self.graph_list)
                layout.insertWidget(0, new_sel)
                widget.target_selector = new_sel

    def set_selection(self, graph_id, node_id):
        for i in range(self.config_stack.count()):
            widget = self.config_stack.widget(i)
            if isinstance(widget, DeviceConfigPage):
                widget.target_selector.set_selection(graph_id, node_id)

    def update_graphs(self, graph_list):
        self.graph_list = graph_list
        for i in range(self.config_stack.count()):
            widget = self.config_stack.widget(i)
            if isinstance(widget, DeviceConfigPage):
                widget.target_selector.graph_list = graph_list
                widget.target_selector.refresh()

    def on_device_created_offline(self, data):
        self._save_device(data, is_update=False)

    def on_device_updated_offline(self, old_data, new_data):
        dev_id = old_data.get('id')
        new_data['id'] = dev_id
        self._save_device(new_data, is_update=True)

    def _save_device(self, data, is_update=False):
        target = data['target']
        graph_id = target['graph_id']
        node_id = target['node_id']
        
        graph = next((g for g in self.graph_list if g.graph_id == graph_id), None)
        if not graph: return
        node = graph.get_node(node_id)
        if not node: return
        
        if not hasattr(node, 'devices') or node.devices is None: 
            node.devices = node.parameters.get('devices', [])
        if 'devices' not in node.parameters: node.parameters['devices'] = []
        
        device_entry = {
            "id": data.get('id') if is_update else np.random.randint(10000, 99999),
            "model": data['model'],
            "target_pop_id": target['pop_id'],
            "params": data['params'],
            "conn_params": data.get('conn_params', {}),
            "runtime_gid": None
        }
        
        if is_update:
            found = False
            for i, d in enumerate(node.devices):
                if str(d.get('id')) == str(device_entry['id']):
                    node.devices[i] = device_entry
                    found = True
                    break
            if not found: node.devices.append(device_entry)
            
            node.parameters['devices'] = node.devices
            print(f"[Sewing] Updated {data['model']} (ID {device_entry['id']})")
        else:
            node.devices.append(device_entry)
            node.parameters['devices'] = node.devices
            print(f"[Sewing] Attached {data['model']} to G{graph_id} N{node_id}")
            
        self.deviceAdded.emit(); self.reset_view()

    def delete_current_device(self):
        current_page = self.config_stack.currentWidget()
        if isinstance(current_page, DeviceConfigPage) and current_page.current_edit_device:
            dev_data = current_page.current_edit_device
            dev_id = dev_data.get('id')
            target = dev_data.get('target', {})
            graph = next((g for g in self.graph_list if g.graph_id == target.get('graph_id')), None)
            if graph:
                node = graph.get_node(target.get('node_id'))
                if node:
                    node.devices = [d for d in node.devices if str(d.get('id')) != str(dev_id)]
                    node.parameters['devices'] = node.devices
                    
            print(f"[Sewing] Deleted device {dev_id}")
            self.deviceAdded.emit()
            self.reset_view()

class SewingDeviceTargetSelector(QWidget):
    def __init__(self, graph_list, parent=None):
        super().__init__(parent)
        self.graph_list = graph_list
        layout = QFormLayout(self)
        self.combo_graph = QComboBox()
        self.combo_node = QComboBox()
        self.combo_pop = QComboBox()
        layout.addRow("Graph:", self.combo_graph)
        layout.addRow("Node:", self.combo_node)
        layout.addRow("Population:", self.combo_pop)
        self.combo_graph.currentIndexChanged.connect(self.on_graph_changed)
        self.combo_node.currentIndexChanged.connect(self.on_node_changed)
        self.refresh()

    def refresh(self):
        self.combo_graph.blockSignals(True); self.combo_graph.clear()
        for g in self.graph_list: self.combo_graph.addItem(f"{getattr(g,'graph_name','G')} ({g.graph_id})", g.graph_id)
        self.combo_graph.blockSignals(False); self.on_graph_changed()

    def on_graph_changed(self):
        self.combo_node.blockSignals(True); self.combo_node.clear()
        gid = self.combo_graph.currentData()
        g = next((x for x in self.graph_list if x.graph_id==gid), None)
        if g: 
            for n in g.node_list: self.combo_node.addItem(f"{n.name} ({n.id})", n.id)
        self.combo_node.blockSignals(False); self.on_node_changed()

    def on_node_changed(self):
        self.combo_pop.clear()
        gid = self.combo_graph.currentData(); nid = self.combo_node.currentData()
        g = next((x for x in self.graph_list if x.graph_id==gid), None)
        if g:
            n = g.get_node(nid)
            if n:
                mods = getattr(n, 'neuron_models', [])
                if not mods and hasattr(n,'types'): mods = ["unk"]*len(n.types)
                for i, m in enumerate(mods): self.combo_pop.addItem(f"Pop {i}: {m}", i)

    def get_selection(self):
        return {'graph_id': self.combo_graph.currentData(), 'node_id': self.combo_node.currentData(), 'pop_id': self.combo_pop.currentData()}

    def set_selection(self, graph_id, node_id):
        idx_g = self.combo_graph.findData(graph_id)
        if idx_g >= 0:
            self.combo_graph.setCurrentIndex(idx_g)
            self.on_graph_changed()
            
            idx_n = self.combo_node.findData(node_id)
            if idx_n >= 0:
                self.combo_node.setCurrentIndex(idx_n)
                self.on_node_changed()
