"""SewingInspector: Detailanzeige für den ausgewählten Graphen oder Node."""
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QFrame, QGridLayout, QLabel, QScrollArea, QVBoxLayout, QWidget

class SewingInspector(QWidget):
    def __init__(self):
        super().__init__()
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.scroll.setStyleSheet("background-color: #1e1e1e; border: none;")
        
        self.content_widget = QWidget()
        self.content_widget.setStyleSheet("background-color: #1e1e1e;")
        self.content_layout = QVBoxLayout(self.content_widget)
        self.content_layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.content_layout.setSpacing(10)
        
        self.lbl_placeholder = QLabel("Select a Graph or Node to inspect.")
        self.lbl_placeholder.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lbl_placeholder.setStyleSheet("color: #555; font-style: italic; font-size: 14px; margin-top: 50px;")
        self.content_layout.addWidget(self.lbl_placeholder)
        
        self.scroll.setWidget(self.content_widget)
        layout.addWidget(self.scroll)

    def clear_content(self):
        while self.content_layout.count():
            item = self.content_layout.takeAt(0)
            if item.widget(): item.widget().deleteLater()

    def inspect_graph(self, graph):
        self.clear_content()
        title = QLabel(f"GRAPH: {getattr(graph, 'graph_name', 'Unnamed')}")
        title.setStyleSheet("color: #00E5FF; font-size: 18px; font-weight: bold; border-bottom: 2px solid #00E5FF; padding-bottom: 5px;")
        self.content_layout.addWidget(title)
        
        n_nodes = len(graph.node_list)
        n_conns = sum(len(getattr(n, 'connections', [])) for n in graph.node_list)
        
        stats_grid = QGridLayout()
        stats_grid.addWidget(QLabel("Graph ID:"), 0, 0)
        stats_grid.addWidget(QLabel(str(graph.graph_id), styleSheet="color: white; font-weight: bold;"), 0, 1)
        stats_grid.addWidget(QLabel("Total Nodes:"), 1, 0)
        stats_grid.addWidget(QLabel(str(n_nodes), styleSheet="color: white; font-weight: bold;"), 1, 1)
        stats_grid.addWidget(QLabel("Total Connections:"), 2, 0)
        stats_grid.addWidget(QLabel(str(n_conns), styleSheet="color: white; font-weight: bold;"), 2, 1)
        
        stats_box = QFrame()
        stats_box.setStyleSheet("background-color: #2b2b2b; border-radius: 5px; padding: 10px;")
        stats_box.setLayout(stats_grid)
        self.content_layout.addWidget(stats_box)
        self.content_layout.addStretch()

    def inspect_node(self, node):
        self.clear_content()
        title = QLabel(f"NODE: {node.name}")
        title.setStyleSheet("color: #E040FB; font-size: 18px; font-weight: bold; border-bottom: 2px solid #E040FB; padding-bottom: 5px;")
        self.content_layout.addWidget(title)
        
        self.content_layout.addWidget(QLabel("Populations:", styleSheet="color: #FF9800; font-weight: bold; margin-top: 10px;"))
        models = getattr(node, 'neuron_models', [])
        for i, m in enumerate(models):
            lbl = QLabel(f"  Pop {i}: {m}")
            lbl.setStyleSheet("color: white; background-color: #333; padding: 5px; border-radius: 3px;")
            self.content_layout.addWidget(lbl)
            
        conns = getattr(node, 'connections', [])
        self.content_layout.addWidget(QLabel(f"Connections (Source): {len(conns)}", styleSheet="color: #4CAF50; font-weight: bold; margin-top: 10px;"))
        for c in conns:
            tgt = c.get('target', {})
            name = c.get('name', 'conn')
            lbl = QLabel(f"  → G{tgt.get('graph_id')} N{tgt.get('node_id')} P{tgt.get('pop_id')} ({name})")
            lbl.setStyleSheet("color: #ccc;")
            self.content_layout.addWidget(lbl)
            
        devs = getattr(node, 'devices', [])
        self.content_layout.addWidget(QLabel(f"Devices: {len(devs)}", styleSheet="color: #E91E63; font-weight: bold; margin-top: 10px;"))
        for d in devs:
            lbl = QLabel(f"  🛠 {d.get('model')} (#{d.get('id')})")
            lbl.setStyleSheet("color: #ccc;")
            self.content_layout.addWidget(lbl)
            
        self.content_layout.addStretch()
