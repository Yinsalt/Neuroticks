"""ExtraTabWidget: der Sewing-Arbeitsbereich."""
import json

import numpy as np
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QDoubleSpinBox, QFileDialog, QFrame, QHBoxLayout, QLabel, QMenu, QMessageBox,
    QPushButton, QSplitter, QVBoxLayout, QWidget,
)

from neuron_toolbox import Graph
from neuroticks.gui.tabs.sewing.graph_view import SewingGraphView
from neuroticks.gui.tabs.sewing.tools_panel import SewingToolsPanel
from neuroticks.gui.widgets.graph_overview import GraphOverviewWidget
from neuroticks.utils.serialization import NumpyEncoder

# Helper für da_source.graph_id-Remapping beim Load — sitzt im
# graph_factory, weil server.py das beim Multi-Agent-Load auch braucht.
# Wir nutzen die selbe Funktion, damit beide Code-Pfade konsistent bleiben.
try:
    from neuroticks.core.graph_factory import _remap_da_source_in_blueprint
except ImportError:
    # Fallback wenn graph_factory nicht verfügbar (sollte nie passieren
    # in einem laufenden Neuroticks-Setup).
    def _remap_da_source_in_blueprint(blueprint_data, id_offset, file_graph_ids):
        if id_offset == 0:
            return 0
        n = 0
        for g in blueprint_data.get('graphs', []):
            for nd in g.get('nodes', []):
                for storage in (nd.get('connections', []) or [],
                                 nd.get('parameters', {}).get('connections', []) or []):
                    for conn in storage:
                        da = conn.get('da_source')
                        if not isinstance(da, dict): continue
                        gid = da.get('graph_id')
                        if gid is None: continue
                        try: gid_i = int(gid)
                        except (TypeError, ValueError): continue
                        if gid_i in file_graph_ids:
                            da['graph_id'] = gid_i + id_offset
                            n += 1
        return n


class ExtraTabWidget(QWidget):
    def __init__(self, main_graph_list, parent=None):
        super().__init__(parent)
        self.main_simulation_graphs = main_graph_list 
        self.left_graphs = []; self.right_graphs = []
        self.init_ui()

    def init_ui(self):
        main_layout = QHBoxLayout(self); main_layout.setContentsMargins(0, 0, 0, 0); main_layout.setSpacing(2)
        
        left_container = QWidget(); left_container.setStyleSheet("background-color: #232323; border-right: 1px solid #444;")
        self.left_layout = QVBoxLayout(left_container); self.left_layout.setContentsMargins(5, 5, 5, 5)
        self.left_layout.addWidget(self._create_header("SOURCE A (CYAN)"))
        btn_load_left = QPushButton("Load A"); btn_load_left.setStyleSheet(self._get_btn_style("#00838F"))
        btn_load_left.clicked.connect(lambda: self.load_graph_file(self.left_graphs, self.left_overview, "A"))
        self.left_layout.addWidget(btn_load_left)
        self.left_overview = GraphOverviewWidget(parent=self, graph_list=self.left_graphs)
        self.left_layout.addWidget(self.left_overview)
        
        center_container = QWidget(); center_container.setStyleSheet("background-color: #1e1e1e;")
        center_layout = QVBoxLayout(center_container)
        canvas_header = QFrame(); canvas_header.setStyleSheet("background-color: #2b2b2b; border-bottom: 1px solid #444;")
        ch_layout = QHBoxLayout(canvas_header); ch_lbl = QLabel("SEWING CANVAS"); ch_lbl.setStyleSheet("color: #ccc; font-weight: bold;")
        ch_layout.addWidget(ch_lbl); center_layout.addWidget(canvas_header)
        
        self.canvas = SewingGraphView(self)
        self.tools_panel = SewingToolsPanel(self)
        

        self.tools_panel.connector.connectionsCreated.connect(self.refresh_all_views)
        self.tools_panel.editor.connectionUpdated.connect(self.refresh_all_views)
        self.tools_panel.devices.deviceAdded.connect(self.refresh_all_views)
        
        splitter = QSplitter(Qt.Orientation.Vertical)
        splitter.setHandleWidth(2)
        splitter.setStyleSheet("QSplitter::handle { background-color: #444; }")
        
        splitter.addWidget(self.canvas)
        splitter.addWidget(self.tools_panel)
        splitter.setStretchFactor(0, 1) 
        splitter.setStretchFactor(1, 0)
        splitter.setSizes([700, 300]) 
        
        center_layout.addWidget(splitter)
        
        disp_frame = QFrame(); disp_layout = QHBoxLayout(disp_frame); disp_layout.setContentsMargins(5,5,5,5)
        disp_layout.addWidget(QLabel("Disp B (X/Y/Z):", styleSheet="color: #E040FB; font-weight:bold;"))
        self.spin_disp_x = QDoubleSpinBox(); self.spin_disp_x.setRange(-1e6, 1e6); self.spin_disp_x.setValue(0.0); self.spin_disp_x.setDecimals(1)
        self.spin_disp_y = QDoubleSpinBox(); self.spin_disp_y.setRange(-1e6, 1e6); self.spin_disp_y.setValue(0.0)
        self.spin_disp_z = QDoubleSpinBox(); self.spin_disp_z.setRange(-1e6, 1e6); self.spin_disp_z.setValue(0.0)
        disp_layout.addWidget(self.spin_disp_x); disp_layout.addWidget(self.spin_disp_y); disp_layout.addWidget(self.spin_disp_z)
        center_layout.addWidget(disp_frame)

        self.btn_merge = QPushButton("MERGE & SAVE PROJECT")
        self.btn_merge.setMinimumHeight(50)
        self.btn_merge.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_merge.setStyleSheet("background-color: #6A1B9A; color: white; font-weight: bold; font-size: 16px; border-top: 2px solid #8E24AA;")
        self.btn_merge.clicked.connect(self.merge_and_save_project)
        center_layout.addWidget(self.btn_merge)

        right_container = QWidget(); right_container.setStyleSheet("background-color: #232323; border-left: 1px solid #444;")
        self.right_layout = QVBoxLayout(right_container); self.right_layout.setContentsMargins(5, 5, 5, 5)
        self.right_layout.addWidget(self._create_header("SOURCE B (MAGENTA)"))
        btn_load_right = QPushButton("Load B"); btn_load_right.setStyleSheet(self._get_btn_style("#AD1457"))
        btn_load_right.clicked.connect(lambda: self.load_graph_file(self.right_graphs, self.right_overview, "B"))
        self.right_layout.addWidget(btn_load_right)
        self.right_overview = GraphOverviewWidget(parent=self, graph_list=self.right_graphs)
        self.right_layout.addWidget(self.right_overview)

        main_layout.addWidget(left_container, 15); main_layout.addWidget(center_container, 70); main_layout.addWidget(right_container, 15)

        self.left_overview.tree.itemClicked.connect(self._on_tree_clicked)
        self.right_overview.tree.itemClicked.connect(self._on_tree_clicked)

        # Right-Click Context-Menu für Use-as-Source / Add-as-Target.
        # Tree-Click selbst füllt das Connect-Panel NICHT mehr (entkoppelt) —
        # der Connect-Tool ist immer unabhängig vom Tree bedienbar.
        for tree in (self.left_overview.tree, self.right_overview.tree):
            tree.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
            tree.customContextMenuRequested.connect(
                lambda pos, t=tree: self._on_tree_context_menu(t, pos)
            )

        self.left_overview.requestDeviceDeletion.connect(self.delete_device_from_overview)
        self.right_overview.requestDeviceDeletion.connect(self.delete_device_from_overview)
        self.left_overview.requestConnectionDeletion.connect(self.delete_connection_from_overview)
        self.right_overview.requestConnectionDeletion.connect(self.delete_connection_from_overview)

    def refresh_all_views(self):
        self.left_overview.update_tree()
        self.right_overview.update_tree()
        self.canvas.update_data(self.left_graphs, self.right_graphs)

    def delete_device_from_overview(self, device_data):
        try:
            dev_id = device_data.get('id')
            target = device_data.get('target', {})
            gid = target.get('graph_id')
            nid = target.get('node_id')
            
            all_graphs = self.left_graphs + self.right_graphs
            graph = next((g for g in all_graphs if g.graph_id == gid), None)
            if graph:
                node = graph.get_node(nid)
                if node:
                    node.devices = [d for d in node.devices if str(d.get('id')) != str(dev_id)]
                    node.parameters['devices'] = node.devices
                    
            self.refresh_all_views()
            
        except Exception as e:
            print(f"Delete Error: {e}")

    def delete_connection_from_overview(self, conn_data):
        try:
            conn_id = conn_data.get('id')
            src = conn_data.get('source', {})
            gid = src.get('graph_id')
            nid = src.get('node_id')
            
            all_graphs = self.left_graphs + self.right_graphs
            graph = next((g for g in all_graphs if g.graph_id == gid), None)
            if graph:
                node = graph.get_node(nid)
                if node:
                    conns = getattr(node, 'connections', [])
                    node.connections = [c for c in conns if c.get('id') != conn_id]
                    node.parameters['connections'] = node.connections
                    
            self.refresh_all_views()
            
        except Exception as e:
            print(f"Delete Error: {e}")

    def _on_tree_clicked(self, item, column):
        data = item.data(0, Qt.ItemDataRole.UserRole)
        if data: self.tools_panel.handle_selection(data)

    def _on_tree_context_menu(self, tree, pos):
        """Right-Click auf einem Tree-Item → Kontextmenü mit Aktionen
        die in den Connect-Tab durchschlagen. Entkoppelt vom normalen
        Click damit der Connect-Tool unabhängig vom Tree bedient werden
        kann.
        """
        item = tree.itemAt(pos)
        if item is None:
            return
        data = item.data(0, Qt.ItemDataRole.UserRole)
        if not data:
            return

        dtype = data.get('type')
        gid = data.get('graph_id')
        nid = data.get('node_id')

        # Kontextmenü hat nur Sinn für Node und Population. Connection und
        # Device haben eigene Edit-Wege, Graph-Item hat nichts zum Verbinden.
        if dtype not in ('node', 'population') or gid is None or nid is None:
            return

        # Pop-Item: pop_id steht im data-dict.
        # Node-Item: pop_id default 0 (User kann's danach im Combo ändern).
        pid = data.get('pop_id', 0) if dtype == 'population' else 0
        try:
            pid = int(pid)
        except (TypeError, ValueError):
            pid = 0

        # Label: bei population zeigen wir Pop-Index, bei Node nicht.
        label_target = (f"G{gid}.N{nid}.P{pid}" if dtype == 'population'
                        else f"G{gid}.N{nid} (Pop 0)")

        menu = QMenu(self)
        menu.setStyleSheet(
            "QMenu { background-color: #2b2b2b; color: #ddd; border: 1px solid #555; }"
            "QMenu::item:selected { background-color: #1976D2; color: white; }"
        )
        act_src = menu.addAction(f"Use as Source  →  {label_target}")
        act_tgt = menu.addAction(f"Add as Target  →  {label_target}")
        menu.addSeparator()
        act_inspect = menu.addAction("Inspect")

        chosen = menu.exec(tree.viewport().mapToGlobal(pos))
        if chosen is act_src:
            self.tools_panel.use_as_source(gid, nid, pid)
        elif chosen is act_tgt:
            self.tools_panel.add_as_target(gid, nid, pid)
        elif chosen is act_inspect:
            self.tools_panel.handle_selection(data)

    def _create_header(self, text):
        lbl = QLabel(text); lbl.setAlignment(Qt.AlignmentFlag.AlignCenter); lbl.setStyleSheet("color: #bbb; font-weight: bold; font-size: 11px; letter-spacing: 1px; padding: 5px;")
        return lbl

    def _get_btn_style(self, color):
        return f"QPushButton {{ background-color: {color}; color: white; font-weight: bold; border: none; border-radius: 4px; padding: 8px; }} QPushButton:hover {{ background-color: white; color: {color}; }}"

    def load_graph_file(self, target_list, overview_widget, source_name):
        filepath, _ = QFileDialog.getOpenFileName(
            self, f"Load into {source_name}", "",
            "JSON Files (*.json);;All Files (*)"
        )
        if not filepath:
            return
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                data = json.load(f)

            # Single-graph Files in das 'graphs'-Format wrappen, damit der
            # universelle Loader sie verarbeiten kann.
            if 'graphs' in data:
                blueprint = data
            elif 'graph' in data:
                blueprint = {
                    'graphs': [{
                        **data['graph'],
                        'nodes': data.get('nodes', []),
                    }]
                }
            else:
                QMessageBox.warning(self, "Error", "Unknown JSON format.")
                return

            # ID-Offset wählen: max(existing_graph_ids) + 1.
            #
            # Damit kollidieren neu geladene Graphen weder mit den schon-
            # geladenen aus der anderen Source noch mit Re-Loads in dieselbe
            # Source. Das Format passt zur angepassten Graph-Klasse —
            # Graph.load_all_from_json(id_offset=N) addiert N auf jede
            # graph_id im File und remappt source/target.graph_id in den
            # Connections automatisch mit. Wir ergänzen das durch
            # _remap_da_source_in_blueprint für die top-level da_source-
            # Felder der Dopa-Synapsen, die der Loader nicht kennt.
            existing_gids = [
                g.graph_id for g in (self.left_graphs + self.right_graphs)
            ]
            off = (max(existing_gids) + 1) if existing_gids else 0

            # Vor dem Load: da_source.graph_id mit demselben Offset remappen.
            # Graph.load_all_from_json kümmert sich um source/target.graph_id,
            # nicht aber um da_source — das muss extern gemacht werden, sonst
            # zeigen Dopa-Synapsen nach dem Sewing auf falsche/inexistente
            # Pops.
            file_graph_ids = {
                int(g.get('graph_id', 0)) for g in blueprint.get('graphs', [])
            }
            n_da = _remap_da_source_in_blueprint(blueprint, off, file_graph_ids)

            # Kanonischer Loader — populate=False weil wir nur die
            # Datenstruktur brauchen (kein NEST-Build), build_connections=False
            # weil wir nicht in NEST verkabeln. Funktioniert mit thin
            # (positions=[]) und fat (positions vorhanden) Format gleich.
            loaded = Graph.load_all_from_json(
                blueprint,
                populate=False,
                build_connections=False,
                id_offset=off,
                verbose=False,
            )

            if not loaded:
                QMessageBox.warning(self, "Error", "Loader returned no graphs.")
                return

            target_list.extend(loaded)
            overview_widget.update_tree()
            self.canvas.update_data(self.left_graphs, self.right_graphs)
            self.tools_panel.update_all_graphs(self.left_graphs, self.right_graphs)

            n_conns = sum(
                len(getattr(n, 'connections', []) or [])
                for g in loaded for n in g.node_list
            )
            print(f"[Sewing] Loaded {len(loaded)} graphs into {source_name}  "
                  f"(id_offset={off}, {n_conns} connections, {n_da} da_source remapped).")

        except Exception as e:
            print(f"Load Error: {e}")
            import traceback
            traceback.print_exc()
            QMessageBox.critical(self, "Load Error", str(e))

    def merge_and_save_project(self):
        """Speichert beide Source-Listen in EIN merged thin-1.0 Projekt.

        Wichtige Eigenschaften:
          - graph_ids werden auf 0..N-1 kompaktiert (sonst sähen sie nach
            den Sewing-Offsets aus: 1_000_000+).
          - source/target/da_source.graph_id werden konsistent mit-remappt
            damit Cross-Graph-Connections und VT-Bindings nach dem Reload
            stimmen.
          - next_ids/prev_ids werden via Graph._serialize_node deduplictiert
            (gleicher Code wie der Main-Save-Pfad → keine Drift).
          - B-Graphen kriegen Displacement-Offset auf init_position +
            center_of_mass + parameters['m']. Positions werden nicht
            gespeichert (Thin/NO) — der Loader baut sie via populate_node()
            beim nächsten Open neu.
        """
        all_graphs = self.left_graphs + self.right_graphs
        if not all_graphs:
            QMessageBox.warning(self, "Error", "No graphs to save.")
            return

        filepath, _ = QFileDialog.getSaveFileName(
            self, "Save Merged Project", "", "JSON Files (*.json)"
        )
        if not filepath:
            return
        if not filepath.endswith('.json'):
            filepath += '.json'

        # Compact final IDs: 0..N-1 (Sewing-Offsets verschwinden im File).
        id_map = {g.graph_id: i for i, g in enumerate(all_graphs)}

        disp_vec = np.array([
            self.spin_disp_x.value(),
            self.spin_disp_y.value(),
            self.spin_disp_z.value(),
        ], dtype=float)
        has_disp = bool(np.any(disp_vec != 0.0))

        project_data = {
            'meta': {
                'version': 'thin-1.0',
                'type': 'neuroticks_thin_project',
                'include_positions': False,
                'source': 'sewing_tool',
            },
            'graphs': [],
        }

        n_dopa_total = 0

        for g in all_graphs:
            new_gid = id_map[g.graph_id]
            is_from_b = (g in self.right_graphs)

            # Graph-Header analog zu Graph.to_json()
            init_pos = (
                g.init_position.tolist() if isinstance(g.init_position, np.ndarray)
                else list(g.init_position) if hasattr(g, 'init_position') else [0.0, 0.0, 0.0]
            )
            if is_from_b and has_disp:
                init_pos = (np.array(init_pos, dtype=float) + disp_vec).tolist()

            g_data = {
                'graph_id': new_gid,
                'graph_name': g.graph_name,
                'max_nodes': int(g.max_nodes) if g.max_nodes else len(g.node_list),
                'init_position': init_pos,
                'polynom_max_power': int(g.polynom_max_power),
                'polynom_decay': float(getattr(g, 'polynom_decay', 0.8)),
                'nodes': [],
            }

            for node in g.node_list:
                # ★ Kanonische Serialisierung — selbe Funktion wie Main-Save.
                # Schreibt da_source mit, deduplictiert next_ids/prev_ids,
                # macht numpy→python Konvertierung sauber.
                nd = g._serialize_node(
                    node,
                    include_positions=False,   # Thin/NO
                    include_devices=True,
                    include_connections=True,
                )

                # graph_id im Node + parameters auf neue ID
                nd['graph_id'] = new_gid
                params = nd.get('parameters', {})
                if isinstance(params, dict):
                    params['graph_id'] = new_gid

                # source/target/da_source.graph_id in Connections remappen
                for c in nd.get('connections', []) or []:
                    if not isinstance(c, dict):
                        continue
                    src = c.get('source')
                    tgt = c.get('target')
                    if isinstance(src, dict) and src.get('graph_id') in id_map:
                        src['graph_id'] = id_map[src['graph_id']]
                    if isinstance(tgt, dict) and tgt.get('graph_id') in id_map:
                        tgt['graph_id'] = id_map[tgt['graph_id']]
                    da = c.get('da_source')
                    if isinstance(da, dict):
                        if da.get('graph_id') in id_map:
                            da['graph_id'] = id_map[da['graph_id']]
                        n_dopa_total += 1

                # B-side Displacement
                if is_from_b and has_disp:
                    com = nd.get('center_of_mass')
                    if com is not None:
                        nd['center_of_mass'] = (np.array(com, dtype=float) + disp_vec).tolist()
                    if isinstance(params, dict):
                        m_val = params.get('m')
                        if m_val is not None:
                            params['m'] = (np.array(m_val, dtype=float) + disp_vec).tolist()

                g_data['nodes'].append(nd)

            project_data['graphs'].append(g_data)

        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(project_data, f, cls=NumpyEncoder, indent=2)
            n_nodes = sum(len(g['nodes']) for g in project_data['graphs'])
            n_conns = sum(
                len(nd.get('connections', []) or [])
                for g in project_data['graphs']
                for nd in g['nodes']
            )
            QMessageBox.information(
                self, "Success",
                f"Merged project saved.\n\n"
                f"Graphs:  {len(all_graphs)}\n"
                f"Nodes:   {n_nodes}\n"
                f"Connections:  {n_conns}\n"
                f"Dopamine connections (da_source preserved):  {n_dopa_total}"
            )
            print(f"[Sewing] Saved {filepath}: {len(all_graphs)} graphs, "
                  f"{n_nodes} nodes, {n_conns} conns, {n_dopa_total} dopa.")
        except Exception as e:
            import traceback
            traceback.print_exc()
            QMessageBox.critical(self, "Error", str(e))

    def on_tab_active(self): pass
