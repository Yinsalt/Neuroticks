"""Offline-Varianten des ConnectionTools (ohne NEST-Verkabelung)."""
import copy

from PyQt6.QtCore import QTimer

from neuroticks.gui.widgets.connection_tool import ConnectionTargetRow, ConnectionTool

class OfflineConnectionTargetRow(ConnectionTargetRow):
    """ConnectionTargetRow für offline geladene Graphen.

    Der echte ConnectionTargetRow iteriert für die Pop-Combo über
    node.population — was bei populate=False eine leere Liste ist.
    Hier nehmen wir stattdessen node.types / node.neuron_models als
    Quelle, weil die im thin-JSON immer mitgespeichert sind.
    """

    def on_node_changed(self):
        self.combo_pop.clear()
        graph_id = self.combo_graph.currentData()
        node_id = self.combo_node.currentData()

        graph = next((g for g in self.graph_list if g.graph_id == graph_id), None)
        if graph is None:
            return
        node = next((n for n in graph.node_list if n.id == node_id), None)
        if node is None:
            return

        types = list(getattr(node, 'types', []) or [])
        models = list(getattr(node, 'neuron_models', []) or [])
        live_pops = list(getattr(node, 'population', []) or [])
        n_pops = max(len(types), len(models), len(live_pops))
        for i in range(n_pops):
            m = models[i] if i < len(models) else 'unknown'
            self.combo_pop.addItem(f"Pop {i}: {m}", i)


class OfflineConnectionTool(ConnectionTool):
    """ConnectionTool für offline-Graphen (Sewing/Fusion).

    Im Sewing-Tool sind die Graphen reine Datenobjekte ohne NEST-Build —
    populate=False, build_connections=False beim Load. Der Apply-Button
    vom echten ConnectionTool versucht über ConnectionExecutor in NEST
    zu verkabeln, was hier zwangsläufig fehlschlägt (keine NEST-Pops
    vorhanden). Diese Subklasse persistiert die queue'ten Connections
    nur ans Datenmodell (node.connections + node.parameters['connections']),
    ohne NEST anzufassen.

    Außerdem werden die Pop-Combos (Source + Targets) aus types/
    neuron_models gefüllt statt aus node.population — letzteres ist bei
    populate=False leer.

    Alle anderen Features — Spatial-Modes, Topological-Rules, DA-Source
    Editor, STDP-Synapsenparameter — kommen 1:1 aus der Parent-Klasse.
    """

    # ─── Pop-Combos: Source ───────────────────────────────────────────
    def on_source_node_changed(self, index):
        self.source_pop_combo.clear()
        if index < 0:
            return
        graph_id = self.source_graph_combo.currentData()
        node_id = self.source_node_combo.currentData()
        graph = next((g for g in self.graph_list if g.graph_id == graph_id), None)
        if graph is None:
            return
        node = next((n for n in graph.node_list if n.id == node_id), None)
        if node is None:
            return
        types = list(getattr(node, 'types', []) or [])
        models = list(getattr(node, 'neuron_models', []) or [])
        live_pops = list(getattr(node, 'population', []) or [])
        n_pops = max(len(types), len(models), len(live_pops))
        for i in range(n_pops):
            m = models[i] if i < len(models) else 'unknown'
            self.source_pop_combo.addItem(f"Pop {i}: {m}", i)

    # ─── Target-Rows nutzen die Offline-Subklasse ─────────────────────
    def add_target_row(self):
        idx = len(self.target_rows)
        row = OfflineConnectionTargetRow(self.graph_list, idx, self)
        row.removeClicked.connect(self.remove_target_row)
        self.target_rows.append(row)
        self.targets_layout.insertWidget(idx, row)
        QTimer.singleShot(100, lambda: self.scroll_targets.verticalScrollBar().setValue(
            self.scroll_targets.verticalScrollBar().maximum()
        ))

    # ─── Apply: persistiert offline statt NEST-Verkabelung ────────────
    def create_all_connections(self):
        if not self.connections:
            return
        graphs_dict = {g.graph_id: g for g in self.graph_list}
        success = 0
        failed = 0
        for conn in list(self.connections):
            s = conn.get('source', {}) or {}
            graph = graphs_dict.get(s.get('graph_id'))
            if graph is None:
                failed += 1
                continue
            node = graph.get_node(s.get('node_id'))
            if node is None:
                failed += 1
                continue
            if not hasattr(node, 'connections') or node.connections is None:
                node.connections = []
            # deepcopy damit die Queue im Tool unabhängig vom persistierten
            # State bleibt — sonst würde späteres Editing der Queue rückwirkend
            # das gespeicherte Connection-Dict mutieren.
            conn_copy = copy.deepcopy(conn)
            node.connections.append(conn_copy)
            # Beide Storages syncen (parameters['connections'] wird vom
            # Loader und vom Save-Pfad parallel benutzt).
            if hasattr(node, 'parameters') and node.parameters is not None:
                node.parameters['connections'] = node.connections
            success += 1

        # Erfolgreich persistierte Connections aus der Queue entfernen.
        self.connections = []
        self.update_connection_list()
        if failed > 0:
            self.status_label.setText(
                f"Persisted {success} connections.  {failed} failed (graph/node not found)."
            )
        else:
            self.status_label.setText(f"Persisted {success} connections to graph data.")

        if success > 0:
            self.connectionsCreated.emit()
