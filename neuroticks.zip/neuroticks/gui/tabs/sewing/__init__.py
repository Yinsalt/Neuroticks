"""Sewing-Tab: zwei Projekte laden, verbinden und zu einem Projekt zusammenführen."""
from neuroticks.gui import bootstrap  # noqa: F401
import pyqtgraph as pg

pg.setConfigOption('background', '#151515')
pg.setConfigOption('foreground', '#d0d0d0')
pg.setConfigOptions(antialias=True)

from neuroticks.gui.tabs.sewing.tab import ExtraTabWidget  # noqa: E402,F401
