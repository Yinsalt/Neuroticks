"""SewingToolsPanel: Inspector, Connect, Edit und Instruments als Tabs."""
from PyQt6.QtWidgets import QTabWidget

from neuroticks.gui.tabs.sewing.device_tool import SewingDeviceTool
from neuroticks.gui.tabs.sewing.inspector import SewingInspector
from neuroticks.gui.tabs.sewing.offline_connection import OfflineConnectionTool
from neuroticks.gui.widgets.connection_editor import ConnectionEditorWidget

class SewingToolsPanel(QTabWidget):
    """Tools-Panel im Sewing-Workspace.

    Nutzt jetzt die echten WidgetLib-Klassen:
      - OfflineConnectionTool (= echter ConnectionTool, persistiert offline)
      - ConnectionEditorWidget (existing-connection editor, identisch zum
        Main-Tool)
    Damit kriegt das Sewing-Tool automatisch alle Verbindungsregeln,
    DA-Source-Bindings, Spatial-Modes und STDP-Parameter, die der echte
    Connection-Workflow auch hat — kein Drift mehr zwischen den beiden UIs.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet("""
            QTabWidget::pane { border: 1px solid #444; background-color: #222; }
            QTabBar::tab { background: #333; color: #aaa; padding: 8px 15px; }
            QTabBar::tab:selected { background: #444; color: white; border-top: 2px solid #00E5FF; }
        """)

        self.combined_list = []

        self.inspector = SewingInspector()
        self.addTab(self.inspector, "Inspector")

        # Echter ConnectionTool (mit Spatial-Modes, DA-source, STDP-Editor).
        # Offline-Variante persistiert nur in node.connections, kein NEST.
        self.connector = OfflineConnectionTool(graph_list=self.combined_list)
        self.addTab(self.connector, "Connect")

        # Bearbeitungs-Tab — derselbe Editor wie im Hauptprogramm.
        self.editor = ConnectionEditorWidget(graph_list=self.combined_list)
        self.addTab(self.editor, "Edit")

        self.devices = SewingDeviceTool()
        self.addTab(self.devices, "Instruments")

    def update_all_graphs(self, left_list, right_list):
        self.combined_list = left_list + right_list
        # In-place graph_list assignment auf den Tools — sie haben die
        # Liste als Reference, also reicht Re-Bind + Refresh.
        self.connector.graph_list = self.combined_list
        self.connector.refresh_graph_list()
        self.editor.graph_list = self.combined_list
        # Wenn der Editor gerade eine Connection geöffnet hat, Re-Resolve
        # auf den neuen graph_list damit der live_ref nicht stale wird.
        if getattr(self.editor, 'current_conn_ref', None) is not None:
            try:
                self.editor.load_connection(self.editor.current_conn_ref)
            except Exception:
                self.editor.clear()
        self.devices.update_graphs(self.combined_list)

    def handle_selection(self, data):
        """Tree-Click — NUR Inspector-Update.

        Das Connect-Panel bleibt bewusst unangetastet, damit der User
        unabhängig von der Tree-Selektion an Verbindungen arbeiten kann.
        Source/Target werden nur auf Right-Click → Context-Menu gesetzt
        (siehe ExtraTabWidget._on_tree_context_menu).
        """
        dtype = data.get('type')
        gid = data.get('graph_id')
        nid = data.get('node_id')

        graph = next((g for g in self.combined_list if g.graph_id == gid), None)

        if dtype == 'graph' and graph:
            self.setCurrentIndex(0)
            self.inspector.inspect_graph(graph)

        elif dtype == 'node' and graph:
            node = graph.get_node(nid)
            if node:
                self.setCurrentIndex(0)
                self.inspector.inspect_node(node)
                # Devices-Tab kriegt weiterhin die Selection — sonst weiß
                # er nicht wo das nächste Device hin soll.
                self.devices.set_selection(gid, nid)

        elif dtype == 'population' and graph:
            # Pop-Click → Inspector-Update auf Node-Ebene
            node = graph.get_node(nid)
            if node:
                self.setCurrentIndex(0)
                self.inspector.inspect_node(node)
                self.devices.set_selection(gid, nid)

        elif dtype == 'connection' and graph:
            conn_data = data.get('connection')
            if conn_data:
                # Existierende Connection → in den Edit-Tab laden.
                self.setCurrentIndex(2)
                self.editor.load_connection(conn_data)

        elif dtype == 'device':
            device_data = data.get('device')
            if device_data:
                self.setCurrentIndex(3)
                self.devices.open_device_editor(device_data)

    # ─── Programmatic API für Right-Click → Source/Target ─────────────
    def use_as_source(self, gid, nid, pid):
        """Vom Tree-Context-Menu: setzt Source des Connect-Tools."""
        self.setCurrentIndex(1)
        try:
            self.connector.set_source(gid, nid, pid)
        except Exception as e:
            print(f"[Sewing] use_as_source({gid},{nid},{pid}): {e}")

    def add_as_target(self, gid, nid, pid):
        """Vom Tree-Context-Menu: hängt Target an die nächste freie Row.
        Wenn alle bestehenden Rows belegt sind, wird eine neue erstellt."""
        self.setCurrentIndex(1)
        rows = self.connector.target_rows
        target_row = None
        for r in rows:
            try:
                g, n, p = r.get_selection()
            except Exception:
                continue
            if None in (g, n, p):
                target_row = r
                break
        if target_row is None:
            # Alle Rows belegt → neue erzeugen
            self.connector.add_target_row()
            target_row = self.connector.target_rows[-1]

        # Combos in der Reihenfolge G → N → P setzen (Cascade über
        # currentIndexChanged füllt das jeweils nächste Combo).
        idx_g = target_row.combo_graph.findData(gid)
        if idx_g >= 0:
            target_row.combo_graph.setCurrentIndex(idx_g)
        idx_n = target_row.combo_node.findData(nid)
        if idx_n >= 0:
            target_row.combo_node.setCurrentIndex(idx_n)
        idx_p = target_row.combo_pop.findData(pid)
        if idx_p >= 0:
            target_row.combo_pop.setCurrentIndex(idx_p)
