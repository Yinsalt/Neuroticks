"""SewingGraphView: 2D-Graphansicht mit kraftbasiertem Layout."""
import numpy as np
import pyqtgraph as pg
from PyQt6.QtCore import QTimer
from PyQt6.QtWidgets import QCheckBox, QHBoxLayout, QPushButton, QSizePolicy, QVBoxLayout, QWidget

class SewingGraphView(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setMinimumHeight(300) 
        
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(0, 0, 0, 0)
        
        toolbar = QHBoxLayout()
        self.btn_relayout = QPushButton("⟳ Reset Layout")
        self.btn_relayout.setStyleSheet("background-color: #333; color: white; border: 1px solid #555; padding: 4px;")
        self.btn_relayout.clicked.connect(self.reset_and_start_animation)
        toolbar.addWidget(self.btn_relayout)
        
        self.chk_physics = QCheckBox("Physics Active")
        self.chk_physics.setChecked(True); self.chk_physics.toggled.connect(self.toggle_physics)
        toolbar.addWidget(self.chk_physics); toolbar.addStretch()
        self.layout.addLayout(toolbar)

        self.view = pg.GraphicsLayoutWidget()
        self.view.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.view.setBackground('#121212')
        
        self.layout.addWidget(self.view)
        self.plot = self.view.addPlot(); self.plot.setAspectLocked(); self.plot.hideAxis('left'); self.plot.hideAxis('bottom')
        self.graph_item = pg.GraphItem(); self.plot.addItem(self.graph_item)
        
        self.nodes_pos = np.array([]); self.nodes_adj = np.array([]); self.node_colors = []; self.node_symbols = []; self.node_groups = np.array([]) 
        self.node_map = {}; self.timer = QTimer(); self.timer.timeout.connect(self.step_layout); self.steps_remaining = 0

    def toggle_physics(self, active):
        if active:
            if self.steps_remaining <= 0: self.steps_remaining = 100 
            self.timer.start(20)
        else: self.timer.stop()

    def update_data(self, left_list, right_list):
        self.timer.stop(); self.node_map = {}; positions = []; colors = []; symbols = []; adjacency = []; groups = []; current_idx = 0
        
        def add_nodes(g_list, brush, sym, grp, x_off):
            nonlocal current_idx
            for graph in g_list:
                for node in graph.node_list:
                    self.node_map[(graph.graph_id, node.id)] = current_idx
                    pos = np.array([node.center_of_mass[0], node.center_of_mass[1]]) if hasattr(node, 'center_of_mass') else np.array([0.0,0.0])
                    pos += np.random.normal(scale=10.0, size=2) + [x_off, 0]
                    positions.append(pos); colors.append(brush); symbols.append(sym); groups.append(grp); current_idx += 1

        add_nodes(left_list, pg.mkBrush('#00E5FF'), 'o', 0, -300.0)
        add_nodes(right_list, pg.mkBrush('#E040FB'), 's', 1, +300.0)
        
        if not positions: self.graph_item.setData(pos=np.array([]), adj=np.array([])); return
        
        self.nodes_pos = np.array(positions, dtype=float); self.node_colors = colors; self.node_symbols = symbols; self.node_groups = np.array(groups, dtype=int)
        
        all_graphs = left_list + right_list
        for graph in all_graphs:
            for node in graph.node_list:
                src_idx = self.node_map.get((graph.graph_id, node.id))
                if src_idx is None: continue
                conns = getattr(node, 'connections', [])
                if not conns and hasattr(node, 'parameters'): conns = node.parameters.get('connections', [])
                for c in conns:
                    tgt = c.get('target', {})
                    t_gid = int(tgt.get('graph_id')) if tgt.get('graph_id') is not None else -1
                    t_nid = int(tgt.get('node_id')) if tgt.get('node_id') is not None else -1
                    tgt_idx = self.node_map.get((t_gid, t_nid))
                    if tgt_idx is not None: adjacency.append([src_idx, tgt_idx])

        self.nodes_adj = np.array(adjacency, dtype=int) if adjacency else np.array([], dtype=int).reshape(0, 2)
        self.update_view()
        if self.chk_physics.isChecked(): self.start_layout_animation()

    def update_view(self):
        try: self.graph_item.setData(pos=self.nodes_pos, adj=self.nodes_adj, pen=pg.mkPen(color=(255, 255, 255, 40), width=1), size=12, symbol=self.node_symbols, symbolBrush=self.node_colors, pxMode=True)
        except: pass

    def start_layout_animation(self): self.steps_remaining = 100; self.timer.start(20)
    def reset_and_start_animation(self):
        if len(self.nodes_pos) == 0: return
        for i, group in enumerate(self.node_groups):
            base_x = -300.0 if group == 0 else 300.0
            self.nodes_pos[i] = [base_x + np.random.uniform(-50, 50), np.random.uniform(-50, 50)]
        self.start_layout_animation()

    def step_layout(self):
        if self.steps_remaining <= 0 or len(self.nodes_pos) == 0: self.timer.stop(); return
        if np.any(np.isnan(self.nodes_pos)): self.nodes_pos = np.nan_to_num(self.nodes_pos); self.timer.stop(); return
        
        pos = self.nodes_pos
        k = 40.0
        force_rep = 3000.0
        force_att = 0.05 
        gravity = 0.05
        dt = 0.4
        max_speed = 40.0
        
        targets = np.zeros_like(pos)
        targets[self.node_groups == 0] = [-300.0, 0.0]
        targets[self.node_groups == 1] = [+300.0, 0.0]
        
        disp = (targets - pos) * gravity
        delta = pos[:, np.newaxis, :] - pos[np.newaxis, :, :]
        dist = np.sqrt(np.sum(delta**2, axis=2)) + 1.0
        
        repulsion = np.minimum(force_rep / (dist**2), 100.0)
        disp += np.sum((delta / dist[:, :, np.newaxis]) * repulsion[:, :, np.newaxis], axis=1)
        
        if len(self.nodes_adj) > 0:
            for i, j in self.nodes_adj:
                delta_vec = pos[i] - pos[j]
                dist_val = np.linalg.norm(delta_vec)
                if dist_val > 0.1:
                    d_vec = (delta_vec / dist_val) * ((dist_val**2 / k) * force_att)
                    disp[i] -= d_vec
                    disp[j] += d_vec
                    
        lengths = np.linalg.norm(disp, axis=1)
        mask = lengths > max_speed
        if np.any(mask): disp[mask] *= (max_speed / lengths[mask])[:, np.newaxis]
        
        self.nodes_pos += disp * dt * 0.9
        self.update_view()
        
        if np.max(lengths) < 0.2: self.steps_remaining = 0
        else: self.steps_remaining -= 1
