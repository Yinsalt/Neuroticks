"""Interaktive 3D-Simulationsansicht mit Injektoren und Elektroden."""
import matplotlib.colors as mcolors
import nest
import numpy as np
import pyqtgraph.opengl as gl
from PyQt6.QtCore import pyqtSignal, QSize, Qt, QTimer
from PyQt6.QtGui import QVector3D
from PyQt6.QtWidgets import (
    QCheckBox, QComboBox, QDoubleSpinBox, QFormLayout, QFrame, QGridLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QScrollArea, QSlider, QSpinBox, QStackedWidget,
    QVBoxLayout, QWidget,
)

from neuron_toolbox import neuron_colors
from neuroticks.utils.nest_helpers import get_receptor_type_for_model

class SafeGLViewWidget(gl.GLViewWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.opts['antialias'] = True
        self.opts['viewport'] = None
    
    def paintGL(self, *args, **kwargs):
        if not self.isVisible() or not self.isValid():
            return
        try:
            self.makeCurrent()
            super().paintGL(*args, **kwargs)
        except Exception:
            pass

class SimulationViewWidget(QWidget):
    sigSpeedChanged = pyqtSignal(int)

    def __init__(self, graph_list, parent=None):
        super().__init__(parent)
        self.graph_list = graph_list
        
        self.scene_loaded = False
        self.active_tool = None
        self.is_paused = True
        
        self.all_points = None
        self.base_colors = None
        self.current_colors = None
        self.global_ids = None
        self.gid_to_idx = {}
        
        self.anim_rg = None
        self.anim_b = None
        self.heat = None
        
        self.electrodes = {}
        self.next_electrode_id = 1
        
        self.stim_params = {'radius': 5.0, 'weight': 1000.0, 'delay': 1.0}
        self.conn_params = {
            'weight': 50.0, 'delay': 1.0, 'radius': 5.0,
            'rule': 'all_to_all', 'p': 0.1, 'indegree': 10,
            'outdegree': 10, 'N': 100,
            'synapse_model': 'static_synapse',
            'allow_autapses': False, 'allow_multapses': True
        }
        
        self.conn_source_gids = []
        self.conn_source_indices = []
        self.temp_connections = []

        self.point_size = 8.0
        self.decay_flash = 0.60
        self.decay_tail = 0.90
        self.decay_heat = 0.80
        
        self.view = None
        self.scatter_item = None
        
        self.render_timer = QTimer()
        self.render_timer.timeout.connect(self.update_animation)
        
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        self.view = SafeGLViewWidget()
        self.view.opts['distance'] = 40
        self.view.setBackgroundColor('#050505')
        gz = gl.GLGridItem(); gz.translate(0, 0, -10); self.view.addItem(gz)
        
        self._original_mouse_press = self.view.mousePressEvent
        self.view.mousePressEvent = self.on_mouse_press
        
        layout.addWidget(self.view, 85)

        self.toolbar_container = QWidget()
        self.toolbar_container.setStyleSheet("background-color: #232323; border-top: 2px solid #444;")
        
        self.toolbar_layout = QHBoxLayout(self.toolbar_container)
        self.toolbar_layout.setContentsMargins(5, 5, 5, 5)
        self.toolbar_layout.setSpacing(10)
        
        left_panel = QWidget()
        left_panel.setStyleSheet("background-color: transparent;")
        left_layout = QVBoxLayout(left_panel)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(5)
        
        row1 = QHBoxLayout()
        self.btn_load = QPushButton("LOAD")
        self.btn_load.clicked.connect(self.load_scene)
        self.btn_load.setStyleSheet("background-color: #1565C0; color: white; font-weight: bold; border-radius: 4px; padding: 4px;")
        
        self.chk_visual_only = QCheckBox("Visual Only")
        self.chk_visual_only.setToolTip("Disables Data Tab updates for maximum performance")
        self.chk_visual_only.setStyleSheet("color: #FFD700; font-weight: bold; margin-left: 5px;")
        self.chk_visual_only.setChecked(False)

        self.btn_clear = QPushButton("✕")
        self.btn_clear.setFixedWidth(30)
        self.btn_clear.clicked.connect(self.unload_scene)
        self.btn_clear.setStyleSheet("background-color: #444; color: white; border-radius: 4px;")
        
        self.slider_speed = QSlider(Qt.Orientation.Horizontal)
        self.slider_speed.setToolTip("Animation Delay (ms zwischen Sim-Ticks). "
                                     "0 = max speed (Bio-Time rast). "
                                     "16 ≈ 60Hz, default — macht 0.1ms-Steps "
                                     "visuell nachvollziehbar.")
        self.slider_speed.setRange(0, 200); self.slider_speed.setValue(16)
        self.slider_speed.valueChanged.connect(self.sigSpeedChanged.emit)
        
        row1.addWidget(self.btn_load)
        row1.addWidget(self.chk_visual_only)
        row1.addWidget(self.btn_clear)
        row1.addWidget(self.slider_speed)
        left_layout.addLayout(row1)
        
        style_tool = """
            QPushButton {
                background-color: #333; color: #bbb; font-weight: bold; font-size: 11px;
                border: 1px solid #555; border-radius: 4px; padding: 6px;
            }
            QPushButton:checked {
                background-color: #FFEB3B; color: black; border: 1px solid #FBC02D;
            }
            QPushButton:hover { background-color: #444; }
        """
        style_conn = style_tool.replace("#FFEB3B", "#FF9800").replace("#FBC02D", "#F57C00")
        
        tools_row = QHBoxLayout()
        self.btn_tool_inject = QPushButton("ELECTRODE")
        self.btn_tool_inject.setCheckable(True)
        self.btn_tool_inject.clicked.connect(lambda: self.set_active_tool('injector'))
        self.btn_tool_inject.setStyleSheet(style_tool)
        
        self.btn_tool_connect = QPushButton("CONNECT")
        self.btn_tool_connect.setCheckable(True)
        self.btn_tool_connect.clicked.connect(lambda: self.set_active_tool('connector'))
        self.btn_tool_connect.setStyleSheet(style_conn)
        
        self.btn_tool_monitor = QPushButton(" ")
        self.btn_tool_monitor.setCheckable(True)
        self.btn_tool_monitor.clicked.connect(lambda: self.set_active_tool('monitor'))
        self.btn_tool_monitor.setStyleSheet(style_tool)
        
        tools_row.addWidget(self.btn_tool_inject)
        tools_row.addWidget(self.btn_tool_connect)
        tools_row.addWidget(self.btn_tool_monitor)
        left_layout.addLayout(tools_row)
        
        self.lbl_tool_status = QLabel("Mode: View Only")
        self.lbl_tool_status.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lbl_tool_status.setStyleSheet("color: #777; font-size: 10px; font-style: italic;")
        left_layout.addWidget(self.lbl_tool_status)
        left_layout.addStretch()
        
        self.toolbar_layout.addWidget(left_panel, 20)

        center_panel = QWidget()
        center_panel.setStyleSheet("background-color: #2a2a2a; border-radius: 4px; border: 1px solid #333;")
        center_layout = QVBoxLayout(center_panel)
        center_layout.setContentsMargins(5, 5, 5, 5)
        
        self.settings_stack = QStackedWidget()
        
        self.settings_stack.addWidget(QLabel("Select a tool...", alignment=Qt.AlignmentFlag.AlignCenter))
        
        self.injector_settings = QWidget()
        self.settings_stack.addWidget(self.injector_settings)

        self.connector_settings = QWidget()
        cl = QGridLayout(self.connector_settings)
        cl.setContentsMargins(2, 2, 2, 2); cl.setSpacing(5)
        
        self.lbl_conn_radius = QLabel(f"Rad: {self.conn_params['radius']:.1f}")
        self.lbl_conn_radius.setStyleSheet("color: #FF9800; font-weight:bold;")
        
        self.slider_conn_radius = QSlider(Qt.Orientation.Horizontal)
        self.slider_conn_radius.setRange(1, 200)
        self.slider_conn_radius.setValue(int(self.conn_params['radius'] * 10))
        
        self.slider_conn_radius.valueChanged.connect(self._update_global_radius)
        
        self.combo_conn_rule = QComboBox(); self.combo_conn_rule.addItems(["all_to_all", "pairwise_bernoulli"])
        self.combo_conn_rule.currentTextChanged.connect(self._on_conn_rule_changed)
        
        cl.addWidget(self.lbl_conn_radius, 0, 0)
        cl.addWidget(self.slider_conn_radius, 0, 1)
        cl.addWidget(self.combo_conn_rule, 0, 2)
        
        self.spin_conn_weight = QDoubleSpinBox(); self.spin_conn_weight.setRange(-1e4, 1e4); self.spin_conn_weight.setValue(50.0); self.spin_conn_weight.setPrefix("W: ")
        self.spin_conn_delay = QDoubleSpinBox(); self.spin_conn_delay.setRange(0.1, 1e3); self.spin_conn_delay.setValue(1.0); self.spin_conn_delay.setPrefix("D: ")
        
        self.conn_rule_params_widget = QWidget()
        self.conn_rule_params_layout = QFormLayout(self.conn_rule_params_widget)
        self.conn_rule_params_layout.setContentsMargins(0,0,0,0)
        self.spin_conn_indegree = QSpinBox(); self.spin_conn_outdegree = QSpinBox(); self.spin_conn_N = QSpinBox(); self.spin_conn_p = QDoubleSpinBox()

        cl.addWidget(self.spin_conn_weight, 1, 0)
        cl.addWidget(self.spin_conn_delay, 1, 1)
        cl.addWidget(self.conn_rule_params_widget, 1, 2)
        
        self.chk_autapses = QCheckBox("Aut"); self.chk_multapses = QCheckBox("Mult"); self.chk_multapses.setChecked(True)
        self.lbl_conn_status = QLabel(""); self.lbl_conn_status.setStyleSheet("color: #4CAF50;")
        
        chk_box = QHBoxLayout(); chk_box.setContentsMargins(0,0,0,0)
        chk_box.addWidget(self.chk_autapses); chk_box.addWidget(self.chk_multapses)
        
        cl.addLayout(chk_box, 2, 0, 1, 2)
        cl.addWidget(self.lbl_conn_status, 2, 2)
        
        self.settings_stack.addWidget(self.connector_settings)
        center_layout.addWidget(self.settings_stack)
        
        self.toolbar_layout.addWidget(center_panel, 30)

        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        right_layout.setContentsMargins(0, 0, 0, 0)
        
        lbl_elec = QLabel("ACTIVE ELECTRODES")
        lbl_elec.setStyleSheet("color: #666; font-weight: bold; font-size: 10px; margin-bottom: 2px;")
        right_layout.addWidget(lbl_elec)
        
        self.elec_scroll = QScrollArea()
        self.elec_scroll.setWidgetResizable(True)
        self.elec_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.elec_scroll.setStyleSheet("""
            QScrollArea { background-color: #1a1a1a; border-radius: 4px; border: 1px solid #333; }
            QScrollBar:vertical { width: 8px; background: #1a1a1a; }
            QScrollBar::handle:vertical { background: #444; border-radius: 4px; }
        """)

        self.elec_container = QWidget()
        self.elec_container.setStyleSheet("background-color: transparent;")
        self.elec_grid = QGridLayout(self.elec_container)
        self.elec_grid.setContentsMargins(5, 5, 5, 5)
        self.elec_grid.setSpacing(5)
        self.elec_grid.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft)
        
        self._electrode_widgets = []

        self.elec_scroll.setWidget(self.elec_container)
        self.elec_scroll.resizeEvent = self._on_elec_scroll_resize
        
        right_layout.addWidget(self.elec_scroll)
        
        btn_clear_all = QPushButton("Clear All Electrodes")
        btn_clear_all.clicked.connect(self.restore_injectors)
        btn_clear_all.setStyleSheet("background: transparent; color: #555; font-size: 9px; text-align: right; padding-right: 5px;")
        right_layout.addWidget(btn_clear_all)

        self.toolbar_layout.addWidget(right_panel, 50)

        layout.addWidget(self.toolbar_container, 15)
        
        self.create_injector_ui(self.injector_settings, self.elec_scroll)

    def update_time_display(self, t): pass
    def update_button_styles(self): pass
    def _update_global_radius(self, value):
        r = value / 10.0
        
        self.stim_params['radius'] = r
        self.conn_params['radius'] = r
        
        if hasattr(self, 'lbl_radius'):
            self.lbl_radius.setText(f"Radius: {r:.1f} mm")
            
        if hasattr(self, 'lbl_conn_radius'):
            self.lbl_conn_radius.setText(f"Rad: {r:.1f}")
            
        
        if hasattr(self, 'slider_radius') and self.slider_radius.value() != value:
            self.slider_radius.blockSignals(True)
            self.slider_radius.setValue(value)
            self.slider_radius.blockSignals(False)
            
        if hasattr(self, 'slider_conn_radius') and self.slider_conn_radius.value() != value:
            self.slider_conn_radius.blockSignals(True)
            self.slider_conn_radius.setValue(value)
            self.slider_conn_radius.blockSignals(False)

    def start_rendering(self):
        if not self.scene_loaded: return
        self.is_paused = False
        if not self.render_timer.isActive():
            self.render_timer.start(30)

    def stop_rendering_safe(self):
        self.is_paused = True
        self.render_timer.stop()

    def update_animation(self):
        if not self.isVisible() or not self.scene_loaded or not self.scatter_item:
            return
            
        try:
            self.anim_rg *= self.decay_tail; self.anim_b *= self.decay_flash; self.heat *= self.decay_heat
            if np.max(self.anim_rg) < 0.05 and np.max(self.anim_b) < 0.05: return
            
            new_c = self.base_colors.copy()
            
            mask = self.anim_rg > 0.05
            if np.any(mask):
                val = self.anim_rg[mask, np.newaxis]
                new_c[mask, 0:3] = np.minimum(1.0, new_c[mask, 0:3] + val)
                new_c[mask, 3] = np.minimum(1.0, 0.4 + val.flatten())
            
            mask_b = self.anim_b > 0.05
            if np.any(mask_b):
                val_b = self.anim_b[mask_b, np.newaxis]
                new_c[mask_b, 2] = np.minimum(1.0, new_c[mask_b, 2] + val_b.flatten())
                new_c[mask_b, 0:2] *= 0.5
                new_c[mask_b, 3] = 1.0
                
            self.scatter_item.setData(color=new_c)
            
        except Exception:
            pass

    def load_scene(self):
        if self.scene_loaded: self.unload_scene()
        points = []; colors = []; gids = []
        
        for graph in self.graph_list:
            for node in graph.node_list:
                if hasattr(node, 'positions') and node.positions:
                    for i, clust in enumerate(node.positions):
                        if clust is None or len(clust) == 0: continue
                        
                        model = node.neuron_models[i] if hasattr(node, 'neuron_models') and i < len(node.neuron_models) else "unknown"
                        rgb = mcolors.to_rgba(neuron_colors.get(model, "#ffffff"), alpha=0.6)
                        
                        points.append(clust)
                        colors.append(np.tile(rgb, (len(clust), 1)))
                        
                        ids_found = False
                        if hasattr(node, 'population') and len(node.population) > i and node.population[i]:
                            try:
                                ids = nest.GetStatus(node.population[i], 'global_id')
                                
                                if len(ids) == len(clust):
                                    gids.append(np.array(ids))
                                    ids_found = True
                                else:
                                    pass
                                    
                            except Exception:
                                pass

                        if not ids_found:
                            gids.append(np.zeros(len(clust), dtype=int))

        if not points: return
        
        self.all_points = np.vstack(points)
        self.base_colors = np.vstack(colors)
        self.current_colors = self.base_colors.copy()
        self.global_ids = np.concatenate(gids)
        self.gid_to_idx = {gid: i for i, gid in enumerate(self.global_ids) if gid > 0}
        
        N = len(self.all_points)
        self.anim_rg = np.zeros(N); self.anim_b = np.zeros(N); self.heat = np.zeros(N)
        
        try:
            self.scatter_item = gl.GLScatterPlotItem(pos=self.all_points, color=self.current_colors, size=self.point_size, pxMode=True)
            self.scatter_item.setGLOptions('translucent')
            
            if self.view.isValid():
                self.view.makeCurrent()
                self.view.addItem(self.scatter_item)
                self.scene_loaded = True
                self.start_rendering()
                print(f"Scene Loaded: {N} neurons.")
            else:
                print("GL View not ready.")
        except Exception as e:
            print(f"OpenGL Init Error: {e}")
            self.scatter_item = None

    def unload_scene(self):
        self.stop_rendering_safe()
        if self.scatter_item:
            try:
                if self.view.isValid():
                    self.view.makeCurrent()
                    self.view.removeItem(self.scatter_item)
            except Exception: pass  # Item may already be removed
        self.scatter_item = None; self.scene_loaded = False

    def feed_spikes(self, gids):
        if not self.scene_loaded or not gids: return
        indices = [self.gid_to_idx[gid] for gid in gids if gid in self.gid_to_idx]
        if indices:
            self.anim_rg[indices] = 1.0;
            self.heat[indices] += 1.0

    def _update_speed_label(self, value): pass
    def _update_radius(self, value):
        r = value / 10.0
        self.stim_params['radius'] = r
        self.lbl_radius.setText(f"Radius: {r:.1f} mm")
    
    def _update_conn_radius(self, value):
        r = value / 10.0
        self.conn_params['radius'] = r
        self.lbl_conn_radius.setText(f"Radius: {r:.1f} mm")
        
    def _update_gen_type_ui(self, index):
        if not hasattr(self, 'combo_gen_type'): return
        
        gen_type = self.combo_gen_type.currentData()
        is_poisson = (gen_type == 'poisson_generator')
        is_spike = (gen_type == 'spike_generator')
        
        if hasattr(self, 'lbl_rate'): self.lbl_rate.setVisible(is_poisson)
        if hasattr(self, 'spin_inj_rate'): self.spin_inj_rate.setVisible(is_poisson)
        
        if hasattr(self, 'spike_gen_container'): 
            self.spike_gen_container.setVisible(is_spike)
            if is_spike:
                self._update_spike_mode_ui(self.combo_spike_mode.currentIndex())
        
    def _on_conn_rule_changed(self, rule):
        while self.conn_rule_params_layout.count():
            item = self.conn_rule_params_layout.takeAt(0)
            if item.widget(): item.widget().setParent(None)
        self.conn_params['rule'] = rule
        if rule == "fixed_indegree": self.conn_rule_params_layout.addRow("Indegree:", self.spin_conn_indegree)
        elif rule == "fixed_outdegree": self.conn_rule_params_layout.addRow("Outdegree:", self.spin_conn_outdegree)
        elif rule == "fixed_total_number": self.conn_rule_params_layout.addRow("Total N:", self.spin_conn_N)
        elif rule == "pairwise_bernoulli": self.conn_rule_params_layout.addRow("Probability:", self.spin_conn_p)
    
    def _get_neurons_in_radius(self, center_idx):
        center_pos = self.all_points[center_idx]
        radius = self.conn_params['radius']
        dists = np.linalg.norm(self.all_points - center_pos, axis=1)
        neighbor_indices = np.where(dists <= radius)[0]
        raw_gids = self.global_ids[neighbor_indices]
        valid_mask = raw_gids > 0
        return neighbor_indices[valid_mask], raw_gids[valid_mask]

    def set_active_tool(self, tool_name):
        if self.active_tool == tool_name:
            self.active_tool = None
            self.btn_tool_inject.setChecked(False)
            self.btn_tool_connect.setChecked(False)
            self.btn_tool_monitor.setChecked(False)
            
            self.settings_stack.setCurrentIndex(0)
            self.lbl_tool_status.setText("Mode: View Only")
        else:
            self.active_tool = tool_name
            self.btn_tool_inject.setChecked(tool_name == 'injector')
            self.btn_tool_connect.setChecked(tool_name == 'connector')
            self.btn_tool_monitor.setChecked(tool_name == 'monitor')
            
            if tool_name == 'injector':
                self.settings_stack.setCurrentIndex(1)
                self.lbl_tool_status.setText("Click in 3D View to ADD Injector")
            elif tool_name == 'connector':
                self.settings_stack.setCurrentIndex(2)
                self.lbl_tool_status.setText("Click Source -> Click Target")
            elif tool_name == 'monitor':
                self.settings_stack.setCurrentIndex(1)
                self.lbl_tool_status.setText("Click to RECORD Spikes")
            
            self.conn_source_gids = []
            self.lbl_conn_status.setText("")

    def project_point_to_screen(self, vec3):
        view_matrix = self.view.viewMatrix()
        w = self.view.width()
        h = self.view.height()
        # Fallunterscheidung für verschiedene PyQtGraph-Versionen
        try:
            # Neue pyqtgraph API (>=0.13.4): region und viewport sind Pflicht
            region = (0, 0, w, h)
            proj_matrix = self.view.projectionMatrix(region=region, viewport=(0, 0, w, h))
        except TypeError:
            # Alte pyqtgraph API: keine Argumente nötig
            proj_matrix = self.view.projectionMatrix()
        mvp = proj_matrix * view_matrix
        screen_vec = mvp.map(QVector3D(vec3[0], vec3[1], vec3[2]))
        x = (screen_vec.x() + 1.0) * w / 2.0
        y = (1.0 - screen_vec.y()) * h / 2.0
        return x, y

    def on_mouse_press(self, event):
        if not self.active_tool or not self.scene_loaded or self.all_points is None:
            self._original_mouse_press(event)
            return

        mx, my = event.pos().x(), event.pos().y()
        min_dist = 30.0
        hit_gid = None; hit_idx = None
        
        for i, pt in enumerate(self.all_points):
            sx, sy = self.project_point_to_screen(pt)
            dist = np.sqrt((sx - mx)**2 + (sy - my)**2)
            if dist < min_dist:
                min_dist = dist
                hit_gid = self.global_ids[i]
                hit_idx = i
                break
        
        if hit_gid is not None:
            self.handle_tool_click(hit_gid, hit_idx)
            self.view.mousePos = event.position() if hasattr(event, 'position') else event.pos()
            event.accept()
        else:
            self._original_mouse_press(event)

    def create_injector_at(self, center_pos, target_gids, neighbor_indices):
        try:
            gen_type = self.combo_gen_type.currentData()
            w = self.stim_params['weight']; d = self.stim_params['delay']
            
            if gen_type == 'poisson_generator':
                sg = nest.Create('poisson_generator', params={'rate': 0.0})
            else:
                sg = nest.Create('spike_generator')
            
            targets_sorted = sorted(target_gids.tolist())
            target_nc = nest.NodeCollection(targets_sorted)
            
            # Group targets by model to handle MC models correctly
            model_groups = {}
            for gid in targets_sorted:
                try:
                    model = nest.GetStatus(nest.NodeCollection([gid]), 'model')[0]
                    if model not in model_groups:
                        model_groups[model] = []
                    model_groups[model].append(gid)
                except Exception:
                    if 'unknown' not in model_groups:
                        model_groups['unknown'] = []
                    model_groups['unknown'].append(gid)
            
            # Connect each group with appropriate receptor_type
            total_connected = 0
            for model, gids in model_groups.items():
                syn_spec = {'weight': w, 'delay': d}
                receptor = get_receptor_type_for_model(model, excitatory=(w >= 0))
                if receptor > 0:
                    syn_spec['receptor_type'] = receptor
                
                try:
                    nest.Connect(sg, nest.NodeCollection(gids), conn_spec={'rule': 'all_to_all'}, syn_spec=syn_spec)
                    total_connected += len(gids)
                except Exception as e:
                    print(f"  Skipping {len(gids)} {model} neurons: {e}")
            
            gen_gid = sg.tolist()[0]
            elec_id = self.next_electrode_id; self.next_electrode_id += 1
            letter = InjectorButton.get_next_letter()
            
            item = InjectorButton(elec_id, gen_gid, len(target_gids), letter, gen_type)
            item.triggerClicked.connect(self.trigger_electrode)
            item.removeClicked.connect(self.remove_electrode)
            
            self._add_electrode_widget(item)
            
            self.electrodes[elec_id] = {
                'gid': gen_gid,
                'widget': item,
                'targets': neighbor_indices,
                'center': center_pos.tolist(),
                'gen_type': gen_type,
                'letter': letter
            }
            self.lbl_tool_status.setText(f"Injector {letter} added!")
            print(f"Created {gen_type} {letter} connected to {total_connected}/{len(target_gids)} neurons.")
            
        except Exception as e:
            print(f"Injection err: {e}")
            import traceback
            traceback.print_exc()

    def handle_tool_click(self, center_gid, center_idx):
        print(f"Interaction at GID: {center_gid}")
        
        if self.active_tool == 'injector':
            center_pos = self.all_points[center_idx]
            radius = self.stim_params['radius']
            dists = np.linalg.norm(self.all_points - center_pos, axis=1)
            neighbor_indices = np.where(dists <= radius)[0]
            raw_target_gids = self.global_ids[neighbor_indices]
            if len(raw_target_gids) == 0: return
            self.create_injector_at(center_pos, raw_target_gids, neighbor_indices)

        elif self.active_tool == 'connector':
            neighbor_indices, neighbor_gids = self._get_neurons_in_radius(center_idx)
            if len(neighbor_gids) == 0:
                self.lbl_tool_status.setText("No neurons in radius!")
                return
            
            if len(self.conn_source_gids) == 0:
                self.conn_source_gids = neighbor_gids.tolist()
                self.conn_source_indices = neighbor_indices.tolist()
                
                self.anim_b[neighbor_indices] = 3.0
                
                self.lbl_tool_status.setText(f"Source: {len(self.conn_source_gids)} neurons. Click Target.")
                self.lbl_conn_status.setText(f"✓ {len(self.conn_source_gids)} source neurons selected")
            else:
                target_gids = neighbor_gids.tolist()
                target_indices = neighbor_indices.tolist()
                try:
                    src_sorted = sorted(self.conn_source_gids)
                    tgt_sorted = sorted(target_gids)
                    
                    src_collection = nest.NodeCollection(src_sorted)
                    
                    conn_spec = self._build_conn_spec()
                    base_syn_spec = self._build_syn_spec()
                    weight = base_syn_spec.get('weight', 1.0)
                    
                    # Group targets by model
                    model_groups = {}
                    for gid in tgt_sorted:
                        try:
                            model = nest.GetStatus(nest.NodeCollection([gid]), 'model')[0]
                            if model not in model_groups:
                                model_groups[model] = []
                            model_groups[model].append(gid)
                        except Exception:
                            if 'unknown' not in model_groups:
                                model_groups['unknown'] = []
                            model_groups['unknown'].append(gid)
                    
                    # Connect to each model group with appropriate receptor_type
                    total_connected = 0
                    for model, gids in model_groups.items():
                        syn_spec = base_syn_spec.copy()
                        receptor = get_receptor_type_for_model(model, excitatory=(weight >= 0))
                        if receptor > 0:
                            syn_spec['receptor_type'] = receptor
                        
                        try:
                            nest.Connect(src_collection, nest.NodeCollection(gids), conn_spec, syn_spec)
                            total_connected += len(gids)
                        except Exception as e:
                            print(f"  Skipping {len(gids)} {model} targets: {e}")
                    
                    self.anim_rg[target_indices] = 5.0
                    
                    n_src = len(self.conn_source_gids)
                    n_tgt = len(target_gids)
                    print(f"🔗 Connected {n_src} -> {total_connected}/{n_tgt} neurons")
                    self.lbl_tool_status.setText(f"Connected {n_src}→{total_connected}! Next Source?")
                    self.lbl_conn_status.setText(f"✓ {n_src} → {total_connected}")
                    
                except Exception as e:
                    print(f"Connection Error: {e}")
                    self.lbl_conn_status.setText(f"✗ {e}")
                
                self.conn_source_gids = []
                self.conn_source_indices = []
             
        elif self.active_tool == 'monitor':
             center_pos = self.all_points[center_idx]
             radius = self.stim_params['radius']
             dists = np.linalg.norm(self.all_points - center_pos, axis=1)
             neighbor_indices = np.where(dists <= radius)[0]
             raw_target_gids = self.global_ids[neighbor_indices]
             
             if len(raw_target_gids) == 0: return
             
             try:
                 target_node = None
                 target_pop_idx = 0
                 
                 found = False
                 curr_idx = 0
                 for graph in self.graph_list:
                     for node in graph.node_list:
                         if hasattr(node, 'positions'):
                             for pop_i, pos in enumerate(node.positions):
                                 if pos is None: continue
                                 size = len(pos)
                                 if curr_idx <= center_idx < curr_idx + size:
                                     target_node = node
                                     target_pop_idx = pop_i
                                     found = True
                                     break
                                 curr_idx += size
                         if found: break
                     if found: break
                 
                 if not target_node:
                     print("Error: Could not identify source node for monitor.")
                     return

                 rec = nest.Create("spike_recorder")
                 nest.SetStatus(rec, {"label": "manual_monitor", "record_to": "memory"})
                 
                 targets_sorted = sorted(raw_target_gids.tolist())
                 nest.Connect(nest.NodeCollection(targets_sorted), rec)
                 
                 rec_gid = rec.tolist()[0]
                 
                 if not hasattr(target_node, 'devices'): target_node.devices = []
                 if 'devices' not in target_node.parameters: target_node.parameters['devices'] = []
                 
                 existing = target_node.parameters['devices']
                 next_dev_id = (max([d.get('id', 0) for d in existing]) + 1) if existing else 9900
                 
                 device_record = {
                    "id": next_dev_id,
                    "model": "spike_recorder",
                    "target_pop_id": target_pop_idx,
                    "params": {"label": "manual_monitor"},
                    "conn_params": {"weight": 1.0, "delay": 1.0},
                    "runtime_gid": rec,
                    "is_manual_monitor": True
                 }
                 
                 # FIX: Doppel-Append vermeiden (siehe oben)
                 if 'devices' not in target_node.parameters:
                     target_node.parameters['devices'] = []
                 target_node.parameters['devices'].append(device_record)
                 if target_node.devices is not target_node.parameters['devices']:
                     target_node.devices.append(device_record)
                 
                 elec_id = self.next_electrode_id; self.next_electrode_id += 1
                 letter = f"M{elec_id}"
                 
                 item = InjectorButton(elec_id, rec_gid, len(targets_sorted), letter, "recorder")
                 item.set_active(True)
                 item.removeClicked.connect(self.remove_electrode)
                 
                 self._add_electrode_widget(item)
                 self.electrodes[elec_id] = {'gid': rec_gid, 'widget': item, 'targets': neighbor_indices, 'gen_type': 'recorder', 'letter': letter}
                 
                 self.lbl_tool_status.setText(f"Monitor {letter} added. Check Data Tab!")
                 print(f"Manual Monitor added to Node {target_node.id}. Please Refresh Data Tab.")
                 
             except Exception as e:
                 print(f"Monitor Error: {e}")


    def create_injector_ui(self, settings_widget, grid_area_widget=None):
        if isinstance(settings_widget, QVBoxLayout): il = settings_widget
        else:
            if settings_widget.layout() is None: il = QVBoxLayout(settings_widget)
            else: il = settings_widget.layout()
                
        il.setContentsMargins(5, 5, 5, 5); il.setSpacing(6)

        type_row = QHBoxLayout()
        type_row.addWidget(QLabel("Typ:", styleSheet="color: #aaa;"))
        self.combo_gen_type = QComboBox()
        self.combo_gen_type.addItems(["Spike Generator", "Poisson Generator"])
        self.combo_gen_type.setItemData(0, "spike_generator")
        self.combo_gen_type.setItemData(1, "poisson_generator")
        self.combo_gen_type.setStyleSheet("background-color: #333; color: white; padding: 3px;")
        self.combo_gen_type.currentIndexChanged.connect(self._update_gen_type_ui)
        type_row.addWidget(self.combo_gen_type)
        il.addLayout(type_row)

        self.lbl_radius = QLabel(f"Radius: {self.stim_params['radius']:.1f} mm")
        self.lbl_radius.setStyleSheet("color: #FF9800; font-weight:bold;")
        
        self.slider_radius = QSlider(Qt.Orientation.Horizontal)
        self.slider_radius.setRange(1, 200)
        self.slider_radius.setValue(int(self.stim_params['radius'] * 10))
        
        self.slider_radius.valueChanged.connect(self._update_global_radius)
        
        il.addWidget(self.lbl_radius)
        il.addWidget(self.slider_radius)

        param_grid = QGridLayout()
        
        param_grid.addWidget(QLabel("Weight:"), 0, 0)
        self.spin_inj_weight = QDoubleSpinBox()
        self.spin_inj_weight.setRange(-1e5, 1e5); self.spin_inj_weight.setValue(self.stim_params['weight'])
        self.spin_inj_weight.setSuffix(" pA")
        self.spin_inj_weight.valueChanged.connect(lambda v: self.stim_params.update({'weight': v}))
        param_grid.addWidget(self.spin_inj_weight, 0, 1)

        param_grid.addWidget(QLabel("Delay:"), 1, 0)
        self.spin_inj_delay = QDoubleSpinBox()
        self.spin_inj_delay.setRange(0.1, 1e3); self.spin_inj_delay.setValue(self.stim_params['delay'])
        self.spin_inj_delay.setSuffix(" ms")
        self.spin_inj_delay.valueChanged.connect(lambda v: self.stim_params.update({'delay': v}))
        param_grid.addWidget(self.spin_inj_delay, 1, 1)

        self.lbl_rate = QLabel("Rate:")
        self.spin_inj_rate = QDoubleSpinBox()
        self.spin_inj_rate.setRange(0.1, 1e4); self.spin_inj_rate.setValue(100.0); self.spin_inj_rate.setSuffix(" Hz")
        
        param_grid.addWidget(self.lbl_rate, 2, 0)
        param_grid.addWidget(self.spin_inj_rate, 2, 1)
        
        il.addLayout(param_grid)
        
        self.spike_gen_container = QWidget()
        self.spike_gen_container.setStyleSheet("background-color: #2a2a2a; border-radius: 4px; padding: 5px;")
        spike_layout = QVBoxLayout(self.spike_gen_container)
        spike_layout.setContentsMargins(5, 5, 5, 5)
        spike_layout.setSpacing(4)
        
        mode_row = QHBoxLayout()
        mode_row.addWidget(QLabel("Mode:", styleSheet="color: #FF9800; font-weight: bold;"))
        self.combo_spike_mode = QComboBox()
        self.combo_spike_mode.addItems(["Single Shot", "Regular Train", "Burst", "Custom Times"])
        self.combo_spike_mode.setStyleSheet("background-color: #333; color: white;")
        self.combo_spike_mode.currentIndexChanged.connect(self._update_spike_mode_ui)
        mode_row.addWidget(self.combo_spike_mode)
        spike_layout.addLayout(mode_row)
        
        self.spike_train_params = QWidget()
        train_grid = QGridLayout(self.spike_train_params)
        train_grid.setContentsMargins(0, 5, 0, 0)
        train_grid.setSpacing(3)
        
        self.lbl_spike_start = QLabel("Start:")
        self.spin_spike_start = QDoubleSpinBox()
        self.spin_spike_start.setRange(0.0, 1e6)
        self.spin_spike_start.setValue(10.0)
        self.spin_spike_start.setSuffix(" ms")
        self.spin_spike_start.setToolTip("First spike time (relative to current sim time)")
        train_grid.addWidget(self.lbl_spike_start, 0, 0)
        train_grid.addWidget(self.spin_spike_start, 0, 1)
        
        self.lbl_spike_interval = QLabel("Interval:")
        self.spin_spike_interval = QDoubleSpinBox()
        self.spin_spike_interval.setRange(0.1, 1e4)
        self.spin_spike_interval.setValue(10.0)
        self.spin_spike_interval.setSuffix(" ms")
        self.spin_spike_interval.setToolTip("Inter-spike interval")
        train_grid.addWidget(self.lbl_spike_interval, 1, 0)
        train_grid.addWidget(self.spin_spike_interval, 1, 1)
        
        self.lbl_spike_count = QLabel("Count:")
        self.spin_spike_count = QSpinBox()
        self.spin_spike_count.setRange(1, 1000)
        self.spin_spike_count.setValue(10)
        self.spin_spike_count.setToolTip("Number of spikes")
        train_grid.addWidget(self.lbl_spike_count, 2, 0)
        train_grid.addWidget(self.spin_spike_count, 2, 1)
        
        self.lbl_burst_spikes = QLabel("Spikes/Burst:")
        self.spin_burst_spikes = QSpinBox()
        self.spin_burst_spikes.setRange(2, 50)
        self.spin_burst_spikes.setValue(5)
        self.spin_burst_spikes.setToolTip("Number of spikes per burst")
        train_grid.addWidget(self.lbl_burst_spikes, 3, 0)
        train_grid.addWidget(self.spin_burst_spikes, 3, 1)
        
        self.lbl_burst_isi = QLabel("Burst ISI:")
        self.spin_burst_isi = QDoubleSpinBox()
        self.spin_burst_isi.setRange(0.5, 100.0)
        self.spin_burst_isi.setValue(2.0)
        self.spin_burst_isi.setSuffix(" ms")
        self.spin_burst_isi.setToolTip("Inter-spike interval within burst")
        train_grid.addWidget(self.lbl_burst_isi, 4, 0)
        train_grid.addWidget(self.spin_burst_isi, 4, 1)
        
        spike_layout.addWidget(self.spike_train_params)
        
        self.custom_times_container = QWidget()
        custom_layout = QVBoxLayout(self.custom_times_container)
        custom_layout.setContentsMargins(0, 5, 0, 0)
        custom_layout.addWidget(QLabel("Spike Times (comma-separated):", styleSheet="color: #aaa; font-size: 10px;"))
        self.txt_custom_times = QLineEdit()
        self.txt_custom_times.setPlaceholderText("e.g. 10, 20, 30, 50, 100")
        self.txt_custom_times.setStyleSheet("background-color: #333; color: white; padding: 4px;")
        custom_layout.addWidget(self.txt_custom_times)
        spike_layout.addWidget(self.custom_times_container)
        
        self.lbl_spike_preview = QLabel("Preview: --")
        self.lbl_spike_preview.setStyleSheet("color: #888; font-size: 9px; font-style: italic;")
        self.lbl_spike_preview.setWordWrap(True)
        spike_layout.addWidget(self.lbl_spike_preview)
        
        self.spin_spike_start.valueChanged.connect(self._update_spike_preview)
        self.spin_spike_interval.valueChanged.connect(self._update_spike_preview)
        self.spin_spike_count.valueChanged.connect(self._update_spike_preview)
        self.spin_burst_spikes.valueChanged.connect(self._update_spike_preview)
        self.spin_burst_isi.valueChanged.connect(self._update_spike_preview)
        self.txt_custom_times.textChanged.connect(self._update_spike_preview)
        self.combo_spike_mode.currentIndexChanged.connect(self._update_spike_preview)
        
        il.addWidget(self.spike_gen_container)
        il.addStretch()

        self._update_gen_type_ui(0)
        self._update_spike_mode_ui(0)
    
    def _update_spike_mode_ui(self, index):
        mode = self.combo_spike_mode.currentText()
        
        self.lbl_spike_start.setVisible(True)
        self.spin_spike_start.setVisible(True)
        
        is_single = (mode == "Single Shot")
        is_train = (mode == "Regular Train")
        is_burst = (mode == "Burst")
        is_custom = (mode == "Custom Times")
        
        self.lbl_spike_interval.setVisible(is_train or is_burst)
        self.spin_spike_interval.setVisible(is_train or is_burst)
        self.lbl_spike_count.setVisible(is_train or is_burst)
        self.spin_spike_count.setVisible(is_train or is_burst)
        
        self.lbl_burst_spikes.setVisible(is_burst)
        self.spin_burst_spikes.setVisible(is_burst)
        self.lbl_burst_isi.setVisible(is_burst)
        self.spin_burst_isi.setVisible(is_burst)
        
        self.custom_times_container.setVisible(is_custom)
        self.spike_train_params.setVisible(not is_custom)
        
        self.lbl_spike_start.setVisible(not is_custom)
        self.spin_spike_start.setVisible(not is_custom)
        
        self._update_spike_preview()
    
    def _update_spike_preview(self):
        times = self._calculate_spike_times(preview=True)
        if times:
            if len(times) > 8:
                preview = ", ".join(f"{t:.1f}" for t in times[:4]) + f" ... ({len(times)} spikes)"
            else:
                preview = ", ".join(f"{t:.1f}" for t in times)
            self.lbl_spike_preview.setText(f"Preview: {preview} ms")
        else:
            self.lbl_spike_preview.setText("Preview: --")
    
    def _calculate_spike_times(self, preview=False):
        mode = self.combo_spike_mode.currentText()
        
        if preview:
            base_time = 0.0
        else:
            try:
                base_time = nest.GetKernelStatus().get('time', 0.0)
            except Exception:
                base_time = 0.0
        
        start = self.spin_spike_start.value()
        
        if mode == "Single Shot":
            return [base_time + start]
        
        elif mode == "Regular Train":
            interval = self.spin_spike_interval.value()
            count = self.spin_spike_count.value()
            return [base_time + start + i * interval for i in range(count)]
        
        elif mode == "Burst":
            interval = self.spin_spike_interval.value()
            count = self.spin_spike_count.value()
            spikes_per_burst = self.spin_burst_spikes.value()
            burst_isi = self.spin_burst_isi.value()
            
            times = []
            for burst_idx in range(count):
                burst_start = base_time + start + burst_idx * interval
                for spike_idx in range(spikes_per_burst):
                    times.append(burst_start + spike_idx * burst_isi)
            return times
        
        elif mode == "Custom Times":
            try:
                text = self.txt_custom_times.text().strip()
                if not text:
                    return []
                times = [base_time + float(t.strip()) for t in text.split(",") if t.strip()]
                return sorted(times)
            except (ValueError, TypeError): return []
        
        return []

    def trigger_electrode(self, gid):
        try:
            elec_data = None
            for e in self.electrodes.values():
                if e['gid'] == gid: 
                    elec_data = e
                    break
            
            if not elec_data:
                print(f"Electrode with GID {gid} not found")
                return
                
            gen_type = elec_data.get('gen_type', 'spike_generator')
            letter = elec_data.get('letter', '?')
            widget = elec_data.get('widget')
            sg_node = nest.NodeCollection([gid])
            
            if gen_type == 'poisson_generator':
                current_rate = nest.GetStatus(sg_node, 'rate')[0]
                if current_rate > 0:
                    nest.SetStatus(sg_node, {'rate': 0.0})
                    if widget:
                        widget.set_active(False)
                    print(f"Injector {letter}: OFF")
                else:
                    r = self.spin_inj_rate.value()
                    nest.SetStatus(sg_node, {'rate': r})
                    if widget:
                        widget.set_active(True)
                    print(f"Injector {letter}: ON ({r} Hz)")
            else:
                spike_times = self._calculate_spike_times(preview=False)
                
                if not spike_times:
                    print(f"Injector {letter}: No spike times defined!")
                    return
                
                current_time = nest.GetKernelStatus().get('time', 0.0)
                future_times = [t for t in spike_times if t > current_time]
                
                if not future_times:
                    min_time = current_time + 1.0
                    future_times = [min_time + (t - min(spike_times)) for t in spike_times]
                
                nest.SetStatus(sg_node, {'spike_times': future_times})
                
                if widget:
                    widget.set_active(True)
                    duration = min(500, 100 + len(future_times) * 20)
                    QTimer.singleShot(duration, lambda: widget.set_active(False))
                
                mode = self.combo_spike_mode.currentText()
                print(f"⚡ Injector {letter} [{mode}]: {len(future_times)} spikes scheduled")
                print(f"   Times: {future_times[:5]}{'...' if len(future_times) > 5 else ''}")
                
        except Exception as e: 
            print(f"Fire Error: {e}")
            import traceback
            traceback.print_exc()

    def _add_electrode_widget(self, widget):
        self._electrode_widgets.append(widget)
        self._rearrange_electrode_grid()
    
    def _remove_electrode_widget(self, widget):
        if widget in self._electrode_widgets:
            self._electrode_widgets.remove(widget)
        self._rearrange_electrode_grid()
    
    def _rearrange_electrode_grid(self):
        while self.elec_grid.count():
            item = self.elec_grid.takeAt(0)
        
        if not self._electrode_widgets:
            return
        
        container_width = self.elec_scroll.viewport().width() - 20  
        button_width = 65  
        cols = max(1, container_width // button_width)
        
        for i, widget in enumerate(self._electrode_widgets):
            row = i // cols
            col = i % cols
            self.elec_grid.addWidget(widget, row, col)
        
        rows = (len(self._electrode_widgets) + cols - 1) // cols
        min_height = rows * 80 + 10
        self.elec_container.setMinimumHeight(min_height)
    
    def _on_elec_scroll_resize(self, event):
        QScrollArea.resizeEvent(self.elec_scroll, event)
        self._rearrange_electrode_grid()

    def remove_electrode(self, elec_id):
        if elec_id in self.electrodes:
            data = self.electrodes.pop(elec_id)
            widget = data['widget']
            self._remove_electrode_widget(widget)
            widget.deleteLater()

    def restore_injectors(self):
        self.electrodes.clear()
        for widget in self._electrode_widgets:
            widget.deleteLater()
        self._electrode_widgets.clear()
        
        while self.elec_grid.count():
            item = self.elec_grid.takeAt(0)
        
        self.next_electrode_id = 1
        InjectorButton.reset_counter()
        self.conn_source_gids = []
        if hasattr(self, 'lbl_conn_status'): self.lbl_conn_status.setText("")

    def _build_conn_spec(self):
        rule = self.combo_conn_rule.currentText()
        spec = {'rule': rule, 'allow_autapses': self.chk_autapses.isChecked(), 'allow_multapses': self.chk_multapses.isChecked()}
        if rule == "fixed_indegree": spec['indegree'] = self.spin_conn_indegree.value()
        elif rule == "fixed_outdegree": spec['outdegree'] = self.spin_conn_outdegree.value()
        elif rule == "fixed_total_number": spec['N'] = self.spin_conn_N.value()
        elif rule == "pairwise_bernoulli": spec['p'] = self.spin_conn_p.value()
        return spec
    
    def _build_syn_spec(self):
        return {'synapse_model': 'static_synapse', 'weight': self.spin_conn_weight.value(), 'delay': max(self.spin_conn_delay.value(), 0.1)}


class InjectorButton(QWidget):
    triggerClicked = pyqtSignal(int)
    removeClicked = pyqtSignal(int)
    
    _letter_counter = 0
    
    COLOR_OFF = "#1565C0"       
    COLOR_OFF_BORDER = "#64B5F6"
    COLOR_ON = "#FDD835"       
    COLOR_ON_BORDER = "#FBC02D"
    
    @staticmethod
    def get_next_letter():
        idx = InjectorButton._letter_counter
        InjectorButton._letter_counter += 1
        result = ""
        while True:
            result = chr(65 + (idx % 26)) + result
            idx = idx // 26 - 1
            if idx < 0: break
        return result
    
    @staticmethod
    def reset_counter():
        InjectorButton._letter_counter = 0

    def __init__(self, electrode_id, generator_gid, target_count, letter, gen_type, parent=None):
        super().__init__(parent)
        self.electrode_id = electrode_id
        self.generator_gid = generator_gid
        self.letter = letter
        self.gen_type = gen_type
        self.is_active = False  
        self.setFixedSize(60, 75)
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(2, 2, 2, 2)
        layout.setSpacing(2)
        
        self.btn = QPushButton(self.letter)
        self.btn.setFixedSize(50, 50)
        self.btn.setCursor(Qt.CursorShape.PointingHandCursor)
        
        if gen_type == 'poisson_generator':
            self.btn.setToolTip(f"Poisson Generator (Toggle ON/OFF)\nTargets: {target_count}\nRight-click to remove")
        elif gen_type == 'recorder':
            self.btn.setToolTip(f"Spike Recorder\nTargets: {target_count}\nRight-click to remove")
        else:
            self.btn.setToolTip(f"Spike Generator (Single Shot)\nTargets: {target_count}\nRight-click to remove")
        
        self._apply_style()
        
        self.btn.clicked.connect(self._on_click)
        self.btn.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.btn.customContextMenuRequested.connect(self._on_right_click)
        
        layout.addWidget(self.btn, alignment=Qt.AlignmentFlag.AlignCenter)
        
        lbl = QLabel(f"{target_count}n")
        lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lbl.setStyleSheet("color: #888; font-size: 9px;")
        layout.addWidget(lbl)
    
    def _apply_style(self):
        if self.is_active:
            bg = self.COLOR_ON
            border = self.COLOR_ON_BORDER
            text_color = "black"
        else:
            bg = self.COLOR_OFF
            border = self.COLOR_OFF_BORDER
            text_color = "white"
        
        self.btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {bg};
                color: {text_color};
                font-weight: bold; 
                font-size: 18px;
                border: 2px solid {border};
                border-radius: 8px;
            }}
            QPushButton:hover {{ 
                background-color: {border}; 
                color: black; 
            }}
            QPushButton:pressed {{ 
                background-color: white; 
            }}
        """)
    
    def set_active(self, active):
        self.is_active = active
        self._apply_style()
    
    def toggle(self):
        self.is_active = not self.is_active
        self._apply_style()
        return self.is_active
    
    def _on_click(self):
        self.triggerClicked.emit(self.generator_gid)
    
    def _on_right_click(self, pos):
        self.removeClicked.emit(self.electrode_id)
    
    def sizeHint(self):
        return QSize(60, 75)


class ElectrodeItem(QWidget):
    triggerClicked = pyqtSignal(int)
    removeClicked = pyqtSignal(int)
    paramsChanged = pyqtSignal(int, float, float)

    def __init__(self, electrode_id, generator_gid, target_count, init_weight=1000.0, init_delay=1.0, parent=None):
        super().__init__(parent)
        self.electrode_id = electrode_id
        self.generator_gid = generator_gid
        
        self.setStyleSheet("""
            QFrame#MainFrame {
                background-color: #2b2b2b; 
                border: 1px solid #444; 
                border-radius: 4px;
            }
            QLabel { color: #ddd; font-size: 11px; }
            QDoubleSpinBox {
                background-color: #1e1e1e; color: #00E5FF;
                border: 1px solid #555; border-radius: 2px;
                padding: 1px;
            }
        """)
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 2, 0, 2)
        
        self.frame = QFrame()
        self.frame.setObjectName("MainFrame")
        fl = QVBoxLayout(self.frame)
        fl.setContentsMargins(6, 6, 6, 6)
        fl.setSpacing(4)
        
        header = QHBoxLayout()
        lbl_id = QLabel(f"<b style='color:#FF9800'>#{electrode_id}</b> <span style='color:#777'>({target_count} targets)</span>")
        header.addWidget(lbl_id)
        header.addStretch()
        
        btn_del = QPushButton("×")
        btn_del.setFixedSize(16, 16)
        btn_del.setCursor(Qt.CursorShape.PointingHandCursor)
        btn_del.setStyleSheet("color: #F44336; border: none; font-weight: bold;")
        btn_del.clicked.connect(lambda: self.removeClicked.emit(self.electrode_id))
        header.addWidget(btn_del)
        fl.addLayout(header)
        
        param_layout = QHBoxLayout()
        
        self.spin_w = QDoubleSpinBox()
        self.spin_w.setRange(-10000, 10000)
        self.spin_w.setValue(init_weight)
        self.spin_w.setDecimals(1)
        self.spin_w.setSuffix(" pA")
        self.spin_w.setToolTip("Synaptic Weight")
        self.spin_w.setFixedWidth(70)
        self.spin_w.valueChanged.connect(self.on_params_changed)
        
        self.spin_d = QDoubleSpinBox()
        self.spin_d.setRange(0.1, 1000)
        self.spin_d.setValue(init_delay)
        self.spin_d.setDecimals(1)
        self.spin_d.setSuffix(" ms")
        self.spin_d.setToolTip("Delay")
        self.spin_d.setFixedWidth(60)
        self.spin_d.valueChanged.connect(self.on_params_changed)
        
        param_layout.addWidget(QLabel("W:"))
        param_layout.addWidget(self.spin_w)
        param_layout.addWidget(QLabel("D:"))
        param_layout.addWidget(self.spin_d)
        fl.addLayout(param_layout)
        
        self.btn_fire = QPushButton("⚡ FIRE (1ms)")
        self.btn_fire.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_fire.setStyleSheet("""
            QPushButton {
                background-color: #E65100; color: white; font-weight: bold;
                border: 1px solid #FF9800; border-radius: 3px; padding: 4px;
            }
            QPushButton:hover { background-color: #FF9800; color: black; }
            QPushButton:pressed { background-color: #FFF; border: none; }
        """)
        self.btn_fire.clicked.connect(lambda: self.triggerClicked.emit(self.generator_gid))
        fl.addWidget(self.btn_fire)
        
        layout.addWidget(self.frame)

    def on_params_changed(self):
        self.paramsChanged.emit(self.electrode_id, self.spin_w.value(), self.spin_d.value())
