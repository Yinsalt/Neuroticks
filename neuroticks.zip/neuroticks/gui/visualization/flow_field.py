"""FlowFieldWidget: 3D-Ansicht der Flussfelder."""
import numpy as np
import pyvista as pv
import vtk
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QDoubleSpinBox, QHBoxLayout, QLabel, QPushButton, QVBoxLayout, QWidget
from pyvistaqt import QtInteractor

from neuron_toolbox import PolynomGenerator

class FlowFieldWidget(QWidget):
    def __init__(self, graph_list, parent=None):
        super().__init__(parent)
        self.graph_list = graph_list
        self.target_graph_id = None
        self.target_node_id = None
        
        self.dt = 0.05
        self.current_step = 0
        self.active_populations_data = []
        
        self.init_ui()

    def init_ui(self):
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(0, 0, 0, 0)
        
        toolbar = QHBoxLayout()
        toolbar.setContentsMargins(5, 5, 5, 5)
        toolbar.setSpacing(5)
        
        btn_reset = QPushButton("↺ Reset")
        btn_reset.setStyleSheet("background-color: #2196F3; color: white; padding: 5px;")
        btn_reset.clicked.connect(self.reset_positions)
        toolbar.addWidget(btn_reset)
        
        btn_prev10 = QPushButton("<< -10")
        btn_prev10.setStyleSheet("background-color: #5D4037; color: white; font-weight: bold; padding: 5px;")
        btn_prev10.clicked.connect(lambda: self.perform_step(-10))
        toolbar.addWidget(btn_prev10)

        btn_prev = QPushButton("< -1")
        btn_prev.setStyleSheet("background-color: #444; color: white; font-weight: bold; padding: 5px;")
        btn_prev.clicked.connect(lambda: self.perform_step(-1))
        toolbar.addWidget(btn_prev)
        
        self.lbl_step = QLabel("Step: 0")
        self.lbl_step.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lbl_step.setFixedWidth(80)
        self.lbl_step.setStyleSheet("color: #00E5FF; font-weight: bold; font-size: 12px; border: 1px solid #444; border-radius: 4px; padding: 2px;")
        toolbar.addWidget(self.lbl_step)
        
        btn_next = QPushButton("+1 >")
        btn_next.setStyleSheet("background-color: #4CAF50; color: white; font-weight: bold; padding: 5px;")
        btn_next.clicked.connect(lambda: self.perform_step(1))
        toolbar.addWidget(btn_next)

        btn_next10 = QPushButton(">> +10")
        btn_next10.setStyleSheet("background-color: #2E7D32; color: white; font-weight: bold; padding: 5px;")
        btn_next10.clicked.connect(lambda: self.perform_step(10))
        toolbar.addWidget(btn_next10)
        
        self.dt_spin = QDoubleSpinBox()
        self.dt_spin.setRange(0.001, 1.0)
        self.dt_spin.setSingleStep(0.01)
        self.dt_spin.setValue(0.05)
        self.dt_spin.setPrefix("dt: ")
        self.dt_spin.setDecimals(3)
        self.dt_spin.valueChanged.connect(self.update_dt)
        toolbar.addWidget(self.dt_spin)
        
        self.layout.addLayout(toolbar)
        
        self.plotter = QtInteractor(self)
        self.plotter.set_background("black")
        self.plotter.add_axes()
        
        self.layout.addWidget(self.plotter)
        
        self.text_actor = vtk.vtkTextActor()
        self.text_actor.GetTextProperty().SetFontSize(14)
        self.text_actor.GetTextProperty().SetColor(1.0, 1.0, 1.0)
        self.text_actor.SetPosition(10, 10)
        self.plotter.renderer.AddViewProp(self.text_actor)
        
        self.build_scene()

    def update_dt(self, val):
        self.dt = val

    def set_target_node(self, graph_id, node_id):
        if self.target_graph_id == graph_id and self.target_node_id == node_id:
            return
        self.target_graph_id = graph_id
        self.target_node_id = node_id
        if self.isVisible():
            self.build_scene()

    def build_scene(self):
        self.plotter.clear()
        self.plotter.renderer.AddViewProp(self.text_actor)
        self.active_populations_data = []
        self.current_step = 0
        self.lbl_step.setText("Step: 0")
        
        if not self.graph_list:
            self.text_actor.SetInput("No graphs available.")
            self.plotter.render()
            return

        if self.target_graph_id is None or self.target_node_id is None:
            self.text_actor.SetInput("Select a node to inspect Flow Field.")
            self.plotter.render()
            return

        target_graph = next((g for g in self.graph_list if g.graph_id == self.target_graph_id), None)
        if not target_graph: return
        target_node = next((n for n in target_graph.node_list if n.id == self.target_node_id), None)
        if not target_node: return

        self.text_actor.SetInput(f"Flow Field: {target_node.name} (Graph {target_graph.graph_id})")

        if not hasattr(target_node, 'positions') or not target_node.positions:
            return

        params = target_node.parameters
        encoded_per_type = params.get("encoded_polynoms_per_type", [])
        
        poly_gen = PolynomGenerator(n=params.get('polynom_max_power', 5))

        show_legend = True
        has_valid_flow = False

        for pop_idx, positions in enumerate(target_node.positions):
            if positions is None or len(positions) == 0:
                continue
            
            funcs = []
            
            if pop_idx < len(encoded_per_type):
                data_block = encoded_per_type[pop_idx]
                
                if isinstance(data_block, (list, tuple)) and len(data_block) == 3:
                    try:
                        funcs = poly_gen.decode_multiple(data_block)
                    except Exception as e:
                        print(f"Error decoding polys for pop {pop_idx}: {e}")
                        funcs = []
            
            if not funcs or len(funcs) != 3:
                continue
            
            f1, f2, f3 = funcs
            if not (callable(f1) and callable(f2) and callable(f3)):
                continue
                
            has_valid_flow = True

            current_pos = positions.copy()
            
            points_mesh = pv.PolyData(current_pos)
            self.plotter.add_mesh(
                points_mesh,
                color="#aaaaaa",
                point_size=5,
                render_points_as_spheres=True
            )
            
            vectors_mesh = pv.PolyData(current_pos)
            self._update_vectors(vectors_mesh, current_pos, f1, f2, f3)
            
            glyph = vectors_mesh.glyph(orient='vectors', scale='scale', factor=0.8)
            
            actor_arrows = self.plotter.add_mesh(
                glyph,
                scalars='mag',
                cmap='jet',
                opacity=0.8,
                show_scalar_bar=show_legend,
                scalar_bar_args={'title': 'Flow Magnitude', 'color': 'white'}
            )
            show_legend = False
            
            self.active_populations_data.append({
                'points_mesh': points_mesh,
                'vectors_mesh': vectors_mesh,
                'arrow_actor': actor_arrows,
                'original_pos': positions.copy(),
                'current_pos': current_pos,
                'funcs': (f1, f2, f3)
            })

        if not has_valid_flow:
            self.text_actor.SetInput(f"{target_node.name}: No Flow Field Data (Static Structure)")

        self.plotter.reset_camera()
        self.plotter.update()

    def _update_vectors(self, mesh, positions, f1, f2, f3):
        x = positions[:, 0]
        y = positions[:, 1]
        z = positions[:, 2]
        
        u = f1(x, y, z)
        v = f2(x, y, z)
        w = f3(x, y, z)
        
        vectors = np.column_stack((u, v, w))
        magnitudes = np.linalg.norm(vectors, axis=1)
        safe_mags = np.where(magnitudes == 0, 1, magnitudes)
        
        mesh.points = positions
        mesh['vectors'] = vectors / safe_mags[:, None]
        mesh['mag'] = magnitudes
        mesh['scale'] = np.clip(magnitudes, 0, 2.0)

    def perform_step(self, n_steps):
        if not self.active_populations_data:
            return

        direction = 1 if n_steps > 0 else -1
        iterations = abs(n_steps)

        
        for data in self.active_populations_data:
            pos = data['current_pos']
            f1, f2, f3 = data['funcs']
            
            for _ in range(iterations):
                x, y, z = pos[:, 0], pos[:, 1], pos[:, 2]
                u = f1(x, y, z)
                v = f2(x, y, z)
                w = f3(x, y, z)
                
                velocity = np.column_stack((u, v, w))
                
                pos = pos + (direction * velocity * self.dt)
            
            data['current_pos'] = pos
            
            data['points_mesh'].points = pos
            
            self._update_vectors(data['vectors_mesh'], pos, f1, f2, f3)
            
            self.plotter.remove_actor(data['arrow_actor'])
            glyph = data['vectors_mesh'].glyph(orient='vectors', scale='scale', factor=0.8)
            new_actor = self.plotter.add_mesh(
                glyph,
                scalars='mag',
                cmap='jet',
                opacity=0.8,
                show_scalar_bar=False
            )
            data['arrow_actor'] = new_actor

        self.current_step += n_steps
        self.lbl_step.setText(f"Step: {self.current_step}")
        self.plotter.update()

    def reset_positions(self):
        if not self.active_populations_data: return
        
        self.current_step = 0
        self.lbl_step.setText("Step: 0")
        
        for data in self.active_populations_data:
            data['current_pos'] = data['original_pos'].copy()
            
            f1, f2, f3 = data['funcs']
            data['points_mesh'].points = data['current_pos']
            
            self._update_vectors(data['vectors_mesh'], data['current_pos'], f1, f2, f3)
            
            self.plotter.remove_actor(data['arrow_actor'])
            glyph = data['vectors_mesh'].glyph(orient='vectors', scale='scale', factor=0.8)
            data['arrow_actor'] = self.plotter.add_mesh(
                glyph, scalars='mag', cmap='jet', opacity=0.8, show_scalar_bar=False
            )
            
        self.plotter.update()
