"""BlinkingNetworkWidget: animierte Netzwerk-Vorschau."""
import matplotlib.colors as mcolors
import numpy as np
import pyvista as pv
from PyQt6.QtCore import QTimer
from PyQt6.QtWidgets import QVBoxLayout, QWidget
from pyvistaqt import QtInteractor

from neuron_toolbox import neuron_colors

class BlinkingNetworkWidget(QWidget):
    def __init__(self, graph_list, parent=None):
        super().__init__(parent)
        self.graph_list = graph_list
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(0, 0, 0, 0)
        
        self.plotter = QtInteractor(self)
        self.plotter.set_background("black")
        self.plotter.enable_anti_aliasing()
        self.layout.addWidget(self.plotter)
        
        self.neuron_mesh = None
        self.edge_mesh = None
        
        self.activity = None
        self.edge_intensities = None
        self.base_colors = None
        
        self.connected_mask = None
        
        self.base_opacity = 0.2
        
        self.connectivity_map = []
        self.population_ranges = {}
        
        self.simulation_running = False
        self.is_active = True
        
        self.timer = QTimer()
        self.timer.timeout.connect(self.animate)
        
        self.build_scene()
        self.timer.start(30)

    def set_base_opacity(self, value):
        """Updates the resting opacity of all edges. Called by the opacity
        slider. Range 0.0..1.0. Pumps the new value into the edge_intensities
        array (which the animate-loop dampens toward base_opacity each tick),
        and refreshes the cell_data so PyVista picks up the change live."""
        try:
            self.base_opacity = float(value)
        except (TypeError, ValueError):
            return
        # Push to the live edge mesh so the change is visible without
        # having to wait for a flash to fade.
        if self.edge_intensities is not None:
            self.edge_intensities = np.full_like(self.edge_intensities, self.base_opacity)
            if self.edge_mesh is not None:
                self.edge_mesh.cell_data["glow"] = self.edge_intensities
                if hasattr(self, 'plotter'):
                    try:
                        self.plotter.update()
                    except Exception:
                        pass

    def build_scene(self):
        self.plotter.clear()
        self.connectivity_map = []
        self.population_ranges = {}
        
        if not self.graph_list: return
        
        all_points = []
        all_colors = []
        current_idx = 0
        
        for graph in self.graph_list:
            for node in graph.node_list:
                if not hasattr(node, 'positions') or not node.positions: continue
                for pop_idx, cluster in enumerate(node.positions):
                    if cluster is None or len(cluster) == 0: continue
                    
                    start = current_idx
                    end = current_idx + len(cluster)
                    self.population_ranges[(graph.graph_id, node.id, pop_idx)] = (start, end)
                    current_idx = end
                    
                    model = node.neuron_models[pop_idx] if pop_idx < len(node.neuron_models) else "unknown"
                    hex_c = neuron_colors.get(model, "#ffffff")
                    rgb = mcolors.to_rgb(hex_c)
                    
                    all_points.append(cluster)
                    all_colors.extend([rgb] * len(cluster))
        
        if not all_points: return

        points = np.vstack(all_points)
        n_points = len(points)
        self.base_colors = np.array(all_colors)
        self.activity = np.zeros(n_points)
        self.connected_mask = np.zeros(n_points, dtype=bool)
        
        self.neuron_mesh = pv.PolyData(points)
        self.neuron_mesh.point_data["display_color"] = self.base_colors
        
        self.plotter.add_mesh(
            self.neuron_mesh, scalars="display_color", rgb=True,
            point_size=6, render_points_as_spheres=True,
            ambient=0.3, diffuse=0.8
        )
        
        lines_data = []
        current_edge_idx = 0
        VISUAL_EDGE_LIMIT = 200
        
        for graph in self.graph_list:
            for node in graph.node_list:
                if not hasattr(node, 'connections'): continue
                for conn in node.connections:
                    src = conn.get('source', {})
                    tgt = conn.get('target', {})
                    params = conn.get('params', {})
                    
                    s_key = (src.get('graph_id'), src.get('node_id'), src.get('pop_id'))
                    t_key = (tgt.get('graph_id'), tgt.get('node_id'), tgt.get('pop_id'))
                    
                    if s_key in self.population_ranges and t_key in self.population_ranges:
                        s_start, s_end = self.population_ranges[s_key]
                        t_start, t_end = self.population_ranges[t_key]
                        
                        self.connected_mask[s_start:s_end] = True
                        self.connected_mask[t_start:t_end] = True
                        
                        n_possible = (s_end-s_start) * (t_end-t_start)
                        n_show = min(VISUAL_EDGE_LIMIT, int(np.sqrt(n_possible)))
                        n_show = max(1, n_show)
                        
                        edge_slice = slice(current_edge_idx, current_edge_idx + n_show)
                        current_edge_idx += n_show
                        
                        self.connectivity_map.append({
                            'src_slice': slice(s_start, s_end),
                            'tgt_indices': np.arange(t_start, t_end),
                            'weight': params.get('weight', 1.0),
                            'edge_slice': edge_slice
                        })
                        
                        p1s = np.random.randint(s_start, s_end, n_show)
                        p2s = np.random.randint(t_start, t_end, n_show)
                        for p1, p2 in zip(p1s, p2s):
                            lines_data.extend([2, p1, p2])

        if lines_data:
            self.edge_mesh = pv.PolyData(points, lines=np.array(lines_data))
            
            self.edge_intensities = np.full(self.edge_mesh.n_cells, self.base_opacity)
            self.edge_mesh.cell_data["glow"] = self.edge_intensities
            
            colors = ["#333333", "#555555", "#FFD700", "#FFFFFF"]
            gold_cmap = mcolors.LinearSegmentedColormap.from_list("gold", colors, N=256)
            
            self.plotter.add_mesh(
                self.edge_mesh,
                scalars="glow",
                cmap=gold_cmap,
                clim=[0.0, 1.0],
                opacity="linear",
                render_lines_as_tubes=True,
                line_width=1.5,
                use_transparency=True,
                show_scalar_bar=False
            )
            
        self.plotter.reset_camera()

    def start_simulation(self):
        self.simulation_running = True

    def stop_simulation(self):
        self.simulation_running = False

    def animate(self):
        if (not self.isVisible() or not self.is_active or
            self.neuron_mesh is None or not hasattr(self, 'plotter')):
            return
        
        try:
            self.activity *= 0.92
            
            if self.edge_intensities is not None:
                diff = self.edge_intensities - self.base_opacity
                self.edge_intensities = self.base_opacity + (diff * 0.88)

            
            if len(self.connectivity_map) > 0:
                import random
                n_flash = max(1, int(len(self.connectivity_map) * 0.05))
                flash_conns = random.sample(self.connectivity_map, n_flash)
                
                for conn in flash_conns:
                    self.edge_intensities[conn['edge_slice']] = 1.0
                    
                    targets = conn['tgt_indices']
                    if len(targets) > 0:
                        n_hits = max(1, int(len(targets) * 0.2))
                        hit_idx = targets[np.random.choice(len(targets), size=n_hits)]
                        self.activity[hit_idx] += 0.3

            self.activity = np.clip(self.activity, 0, 1.2)
            
            act_norm = np.clip(self.activity, 0, 1)[:, None]
            target_color = np.array([1.0, 1.0, 1.0])
            display_colors = self.base_colors * (1.0 - act_norm * 0.6) + target_color * (act_norm * 0.6)
            
            self.neuron_mesh.point_data["display_color"] = display_colors
            
            if self.edge_mesh:
                self.edge_mesh.cell_data["glow"] = self.edge_intensities

            if self.plotter.render_window:
                self.plotter.update()
            
        except Exception:
            pass

    def closeEvent(self, event):
        self.is_active = False
        self.simulation_running = False
        if hasattr(self, 'timer'): self.timer.stop()
        if hasattr(self, 'plotter'): self.plotter.close()
        super().closeEvent(event)
