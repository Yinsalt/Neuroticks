"""Qt-Oberfläche von Neuroticks."""
