"""Globale pyqtgraph-Einstellungen (wird beim Import der GUI-Pakete gesetzt)."""
import pyqtgraph as pg

pg.setConfigOption('background', '#1e1e1e')
pg.setConfigOption('foreground', 'd')
pg.setConfigOption('antialias', True)
