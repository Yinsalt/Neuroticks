"""Live-Plots während der laufenden Simulation."""
import nest
import numpy as np
import pyqtgraph as pg
from PyQt6.QtCore import pyqtSignal, Qt
from PyQt6.QtGui import QBrush, QColor
from PyQt6.QtWidgets import (
    QCheckBox, QDoubleSpinBox, QFormLayout, QFrame, QGroupBox, QHBoxLayout, QLabel,
    QPushButton, QScrollArea, QSpinBox, QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget,
)

from neuron_toolbox import neuron_colors

class NodeLiveGroup(QGroupBox):
    def __init__(self, graph_id, node_id, node_name, model_name, color_hex, parent=None):
        super().__init__(parent)
        
        self.setStyleSheet(f"""
            QGroupBox {{
                border: 1px solid #333;
                border-radius: 4px;
                margin-top: 1.2em;
                background-color: #181818;
            }}
            QGroupBox::title {{
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px;
                color: {color_hex};
                font-weight: bold;
            }}
        """)
        self.setTitle(f"{node_name} (ID:{node_id}) - {model_name}")
        
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(4, 15, 4, 4)
        self.layout.setSpacing(2)
        
        self.rate_plot = pg.PlotWidget()
        self.rate_plot.setBackground(None)
        self.rate_plot.setMaximumHeight(50)
        self.rate_plot.hideAxis('left')
        self.rate_plot.hideAxis('bottom')
        
        c = QColor(color_hex)
        self.rate_curve = self.rate_plot.plot(pen=pg.mkPen(c, width=2), fillLevel=0, brush=pg.mkBrush(c.red(), c.green(), c.blue(), 40))
        self.layout.addWidget(self.rate_plot)
        
        self.btn_toggle = QPushButton("▼ Details")
        self.btn_toggle.setCheckable(True)
        self.btn_toggle.setChecked(False)
        self.btn_toggle.setStyleSheet("text-align: left; color: #666; background: transparent; border: none; font-size: 10px;")
        self.btn_toggle.toggled.connect(self._toggle)
        self.layout.addWidget(self.btn_toggle)
        
        self.details = QWidget()
        self.details.setVisible(False)
        self.details_layout = QVBoxLayout(self.details)
        self.details_layout.setContentsMargins(10,0,0,0)
        self.layout.addWidget(self.details)
        
        self.plots = []

    def add_plot(self, widget):
        self.details_layout.addWidget(widget)
        self.plots.append(widget)
        self.btn_toggle.setText(f"▶ Details ({len(self.plots)} Devices)")

    def _toggle(self, checked):
        self.details.setVisible(checked)
        arrow = "▼" if checked else "▶"
        self.btn_toggle.setText(f"{arrow} Details ({len(self.plots)} Devices)")
        
    def update_summary(self):
        pass


class NodeLiveGroup(QGroupBox):
    def __init__(self, graph_id, node_id, node_name, model_name, color, parent=None):
        super().__init__(parent)
        self.graph_id = graph_id
        self.node_id = node_id
        self.node_name = node_name
        
        self.setStyleSheet(f"""
            QGroupBox {{
                border: 1px solid #444;
                border-radius: 6px;
                margin-top: 24px;
                background-color: #1a1a1a;
            }}
            QGroupBox::title {{
                subcontrol-origin: margin;
                subcontrol-position: top left;
                padding: 0 5px;
                color: {color};
                font-weight: bold;
                font-size: 13px;
            }}
        """)
        self.setTitle(f"Graph {graph_id} | {node_name} ({model_name})")
        
        self.layout = QVBoxLayout(self)
        self.layout.setSpacing(2)
        self.layout.setContentsMargins(5, 15, 5, 5)
        
        self.sum_plot = pg.PlotWidget()
        self.sum_plot.setBackground('#121212')
        self.sum_plot.setMaximumHeight(80)
        self.sum_plot.hideAxis('left')
        self.sum_plot.setLabel('bottom', 'Spike Rate (Population)', units='')
        self.sum_plot.getAxis('bottom').setHeight(15)
        
        self.rate_curve = self.sum_plot.plot(pen=pg.mkPen(color, width=2, fillLevel=0, brush=(50,50,50,100)))
        self.layout.addWidget(self.sum_plot)
        
        self.btn_toggle = QPushButton("▼ Show 0 Devices")
        self.btn_toggle.setCheckable(True)
        self.btn_toggle.setChecked(True)
        self.btn_toggle.setStyleSheet("""
            QPushButton {
                text-align: left; background: #222; color: #888; border: none; padding: 4px;
            }
            QPushButton:hover { background: #333; color: white; }
            QPushButton:checked { color: #00E5FF; }
        """)
        self.btn_toggle.toggled.connect(self.toggle_details)
        self.layout.addWidget(self.btn_toggle)
        
        self.details_container = QWidget()
        self.details_layout = QVBoxLayout(self.details_container)
        self.details_layout.setContentsMargins(0,0,0,0)
        self.details_layout.setSpacing(5)
        self.layout.addWidget(self.details_container)
        
        self.spike_times_buffer = []
        self.plot_widgets = []

    def add_device_widget(self, widget):
        self.details_layout.addWidget(widget)
        self.plot_widgets.append(widget)
        self.btn_toggle.setText(f"▼ Show {len(self.plot_widgets)} Devices")

    def toggle_details(self, checked):
        self.details_container.setVisible(checked)
        arrow = "▼" if checked else "▶"
        self.btn_toggle.setText(f"{arrow} Show {len(self.plot_widgets)} Devices")

    def update_sum_plot(self, time_window=100.0):
        new_spikes = []
        for w in self.plot_widgets:
            if "spike_recorder" in w.device_type:
                if w.times:
                    last_t = w.times[-1]
                    cutoff = last_t - time_window
                    
                    
                    # TODO
                    y, x = np.histogram(w.times, bins=50)
                    pass
        
        self.sum_plot.setTitle("Aggregate Activity (ToDo)", size='8pt')



class LivePlotWidget(QWidget):
    closed = pyqtSignal()

    def __init__(self, unique_key, device_type, params, node_info, view_window=1000.0, buffer_window=5000.0, parent=None):
        super().__init__(parent)
        self.unique_key = unique_key
        self.nest_gid = None
        self.device_type = device_type
        self.node_color = QColor(node_info.get('color', '#FFFFFF'))
        
        self.view_window = view_window      
        self.buffer_window = buffer_window  
        
        self.downsample_step = 10 
        self.max_traces = 5
        
        self.data_x = np.array([]) 
        self.data_y = np.array([])
        
        self.traces = {} 
        
        self._init_ui(params, node_info)

    def set_view_window(self, window_ms):
        self.view_window = float(window_ms)
        if self.buffer_window < self.view_window:
            self.buffer_window = self.view_window

    def set_buffer_window(self, window_ms):
        self.buffer_window = float(window_ms)
        if self.view_window > self.buffer_window:
            self.view_window = self.buffer_window

    def _init_ui(self, params, node_info):
        self.setStyleSheet(f"background-color: #1e1e1e; border: 1px solid #333; border-left: 4px solid {self.node_color.name()}; border-radius: 4px;")
        l = QVBoxLayout(self); l.setContentsMargins(0,0,0,0); l.setSpacing(0)
        
        h = QWidget(); h.setStyleSheet("background-color: #252525; border-bottom: 1px solid #333;")
        hl = QHBoxLayout(h); hl.setContentsMargins(5,2,5,2)
        
        dev_label = params.get('label', self.device_type)
        title_str = f"<b>{node_info.get('name')}</b>: {dev_label}"
        
        hl.addWidget(QLabel(title_str, styleSheet=f"color: #eee;"))
        hl.addStretch()
        
        self.step_spin = QSpinBox()
        self.step_spin.setRange(1, 100); self.step_spin.setValue(10)
        self.step_spin.setToolTip("Downsampling Step")
        self.step_spin.setFixedWidth(40)
        self.step_spin.setStyleSheet("background: #333; color: #00E5FF; border: none;")
        
        if "spike" not in self.device_type:
            hl.addWidget(QLabel("Step:", styleSheet="color:#888; font-size:10px;"))
            hl.addWidget(self.step_spin)
        
        b = QPushButton("×"); b.setFixedSize(20,20)
        b.setStyleSheet("background: transparent; color: #888; border: none; font-weight: bold;")
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        b.clicked.connect(self.close_and_flush)
        hl.addWidget(b); l.addWidget(h)
        
        self.pw = pg.PlotWidget()
        self.pw.setBackground('#121212')
        self.pw.showGrid(x=True, y=True, alpha=0.2)
        self.pw.setMouseEnabled(x=True, y=True)
        self.pw.getAxis('bottom').setLabel('Time', units='ms')
        self.pw.setDownsampling(mode='peak') 
        self.pw.setClipToView(True)
        l.addWidget(self.pw)
        
        if "spike" in self.device_type:
            self.pw.setLabel('left', 'Neuron ID')
            self.scatter = pg.ScatterPlotItem(size=3, pen=None, brush=pg.mkBrush(self.node_color), symbol='s', pxMode=True)
            self.pw.addItem(self.scatter)
            self.is_analog = False
        else:
            record_from = params.get('record_from', ['V_m'])
            if isinstance(record_from, str): record_from = [record_from]
            self.value_key = record_from[0] if record_from else 'V_m'
            self.pw.setLabel('left', self.value_key)
            self.is_analog = True

    def update_data(self, events, current_time=None):
        if not events: return
        
        new_times = events.get('times', [])
        new_senders = events.get('senders', [])
        
        if not hasattr(new_times, '__len__') or len(new_times) == 0: return

        arr_new_times = np.array(new_times) if isinstance(new_times, list) else new_times
        arr_new_senders = np.array(new_senders) if isinstance(new_senders, list) else new_senders


        cutoff_time = 0.0
        if current_time is not None:
            cutoff_time = current_time - self.buffer_window

        if not self.is_analog:
            self.data_x = np.append(self.data_x, arr_new_times)
            self.data_y = np.append(self.data_y, arr_new_senders)
            
            if len(self.data_x) > 0 and self.data_x[0] < cutoff_time:
                cut_idx = np.searchsorted(self.data_x, cutoff_time)
                if cut_idx > 0:
                    self.data_x = self.data_x[cut_idx:]
                    self.data_y = self.data_y[cut_idx:]
            
            self.scatter.setData(x=self.data_x, y=self.data_y)

        else:
            values = events.get(self.value_key, [])
            arr_new_values = np.array(values) if isinstance(values, list) else values
            
            if len(arr_new_values) != len(arr_new_times): return
            
            step = self.step_spin.value()
            unique_senders = np.unique(arr_new_senders)
            active_traces = 0
            
            for sender in unique_senders:
                if sender not in self.traces and len(self.traces) >= self.max_traces:
                    continue
                
                mask = (arr_new_senders == sender)
                t_chunk = arr_new_times[mask][::step]
                v_chunk = arr_new_values[mask][::step]
                
                if len(t_chunk) == 0: continue

                if sender not in self.traces:
                    c = self.node_color
                    import random
                    noise = random.randint(-30, 30)
                    r = max(0, min(255, c.red() + noise))
                    g = max(0, min(255, c.green() + noise))
                    b = max(0, min(255, c.blue() + noise))
                    curve = self.pw.plot(pen=pg.mkPen(QColor(r,g,b), width=1.5), name=f"N{sender}")
                    self.traces[sender] = {'x': np.array([]), 'y': np.array([]), 'curve': curve}
                
                trace = self.traces[sender]
                trace['x'] = np.append(trace['x'], t_chunk)
                trace['y'] = np.append(trace['y'], v_chunk)
                
                if len(trace['x']) > 0 and trace['x'][0] < cutoff_time:
                    cut_idx = np.searchsorted(trace['x'], cutoff_time)
                    if cut_idx > 0:
                        trace['x'] = trace['x'][cut_idx:]
                        trace['y'] = trace['y'][cut_idx:]
                
                trace['curve'].setData(trace['x'], trace['y'])
                active_traces += 1
                if active_traces >= self.max_traces: break

    def set_view_range_to_window(self, current_time):
        min_t = max(0, current_time - self.view_window)
        self.pw.setXRange(min_t, current_time, padding=0)

    def close_and_flush(self):
        self.clear_data()
        self.closed.emit()

    def clear_data(self):
        self.data_x = np.array([])
        self.data_y = np.array([])
        if hasattr(self, 'scatter') and self.scatter: 
            self.scatter.clear()
        if hasattr(self, 'traces'):
            for t in self.traces.values():
                t['x'] = np.array([]); t['y'] = np.array([]); t['curve'].clear()
            self.traces.clear()

class LiveDataDashboard(QWidget):
    MODE_POP_ACTIVITY = 0
    MODE_DEVICE_DETAIL = 1
    
    def __init__(self, graph_list, parent=None):
        super().__init__(parent)
        self.graph_list = graph_list
        self.active_plots_map = {}
        self.current_view_mode = self.MODE_POP_ACTIVITY
        self.data_cache = {}
        
        self.view_window = 1000.0 
        self.buffer_window = 5000.0 
        
        self.init_ui()

    def init_ui(self):
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        
        left_container = QWidget()
        left_container.setFixedWidth(280)
        left_container.setStyleSheet("background-color: #232323; border-right: 1px solid #444;")
        left_layout = QVBoxLayout(left_container)
        
        left_layout.addWidget(QLabel("DATA SOURCE & MODE", styleSheet="color:#00E5FF; font-weight:bold; margin-top:5px;"))

        mode_group = QFrame()
        mode_group.setStyleSheet("background-color: #1a1a1a; border-radius: 4px; padding: 2px;")
        mode_l = QHBoxLayout(mode_group); mode_l.setSpacing(1); mode_l.setContentsMargins(0,0,0,0)
        
        self.btn_mode_pop = QPushButton("Rate (Pop)")
        self.btn_mode_detail = QPushButton("Detail (Device)")
        self.mode_btns = [self.btn_mode_pop, self.btn_mode_detail]
        
        for i, btn in enumerate(self.mode_btns):
            btn.setCheckable(True)
            btn.setFixedHeight(30)
            btn.clicked.connect(lambda checked, idx=i: self.set_view_mode(idx))
        
        mode_l.addWidget(self.btn_mode_pop)
        mode_l.addWidget(self.btn_mode_detail)
        left_layout.addWidget(mode_group)
        
        win_group = QGroupBox("Time Windows")
        win_l = QFormLayout(win_group)
        
        self.chk_scroll = QCheckBox("Auto-Scroll"); self.chk_scroll.setChecked(True)
        win_l.addRow(self.chk_scroll)
        
        self.spin_view = QDoubleSpinBox()
        self.spin_view.setRange(10, 1e6); self.spin_view.setValue(self.view_window)
        self.spin_view.setSuffix(" ms")
        self.spin_view.setToolTip("Zoom: How much time is visible on screen.")
        self.spin_view.valueChanged.connect(self._on_view_changed)
        win_l.addRow("View (Zoom):", self.spin_view)
        
        self.spin_buffer = QDoubleSpinBox()
        self.spin_buffer.setRange(10, 1e6); self.spin_buffer.setValue(self.buffer_window)
        self.spin_buffer.setSuffix(" ms")
        self.spin_buffer.setStyleSheet("color: #FF9800;")
        self.spin_buffer.setToolTip("Buffer: How long data is kept in memory before deleting.")
        self.spin_buffer.valueChanged.connect(self._on_buffer_changed)
        win_l.addRow("History (RAM):", self.spin_buffer)
        
        left_layout.addWidget(win_group)
        
        self.tree = QTreeWidget()
        self.tree.setHeaderHidden(True)
        self.tree.setStyleSheet("background-color: #1e1e1e; border: 1px solid #444;")
        self.tree.itemClicked.connect(self.on_tree_item_clicked)
        left_layout.addWidget(self.tree)
        
        btn_scan = QPushButton("↻ Refresh List"); btn_scan.clicked.connect(self.scan_for_devices)
        left_layout.addWidget(btn_scan)
        btn_clear = QPushButton("🗑 Close All Plots"); btn_clear.clicked.connect(self.close_all_plots)
        left_layout.addWidget(btn_clear)
        
        layout.addWidget(left_container)
        
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setStyleSheet("border: none; background-color: #121212;")
        
        self.plot_container = QWidget()
        self.plot_container.setStyleSheet("background-color: #121212;")
        self.plot_layout = QVBoxLayout(self.plot_container)
        self.plot_layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.plot_layout.setSpacing(10)
        
        self.scroll.setWidget(self.plot_container)
        layout.addWidget(self.scroll)
        
        self.set_view_mode(0)

    def _on_view_changed(self, val):
        self.view_window = val
        if self.view_window > self.buffer_window:
            self.spin_buffer.setValue(self.view_window) 
        for w in self.active_plots_map.values():
            if hasattr(w, 'set_view_window'): w.set_view_window(val)

    def _on_buffer_changed(self, val):
        self.buffer_window = val
        if self.buffer_window < self.view_window:
            self.spin_view.setValue(self.buffer_window) 
        for w in self.active_plots_map.values():
            if hasattr(w, 'set_buffer_window'): w.set_buffer_window(val)

    def scan_for_devices(self):
        self.tree.clear()
        
        active_gid_map = {}
        
        for graph in self.graph_list:
            g_item = QTreeWidgetItem(self.tree)
            g_item.setText(0, getattr(graph, 'graph_name', f"Graph {graph.graph_id}"))
            g_item.setExpanded(True)
            
            for node in graph.node_list:
                devs = getattr(node, 'devices', [])
                if not devs and hasattr(node, 'parameters') and 'devices' in node.parameters: 
                    devs = node.parameters['devices']
                
                relevant_devs = [d for d in devs if any(x in d.get('model', '') for x in ['recorder', 'meter'])]
                if not relevant_devs: continue
                
                n_item = QTreeWidgetItem(g_item)
                n_item.setText(0, node.name)
                n_item.setExpanded(True)
                
                pop_map = {}
                for d in relevant_devs:
                    pid = d.get('target_pop_id', 0)
                    if pid not in pop_map: pop_map[pid] = []
                    pop_map[pid].append(d)
                    
                for pid, d_list in pop_map.items():
                    model = node.neuron_models[pid] if hasattr(node, 'neuron_models') and pid < len(node.neuron_models) else 'unknown'
                    
                    neuron_count = 0
                    if hasattr(node, 'positions') and node.positions and pid < len(node.positions):
                        if node.positions[pid] is not None:
                            neuron_count = len(node.positions[pid])
                    
                    p_item = QTreeWidgetItem(n_item)
                    p_item.setText(0, f"Pop {pid}: {model}")
                    p_item.setForeground(0, QBrush(QColor("#FFD700")))
                    
                    pop_key = (graph.graph_id, node.id, pid)
                    pop_info = {
                        'type': 'pop', 
                        'key': pop_key, 
                        'info': {'name': f"{node.name}_P{pid}", 'color': neuron_colors.get(model, '#fff')}, 
                        'neuron_count': neuron_count,
                        'recorders': []
                    }
                    
                    for dev in d_list:
                        dev_model = dev.get('model','')
                        dev_id = dev.get('id', '?')
                        
                        gid = dev.get('runtime_gid')
                        if hasattr(gid, 'tolist'): gid = gid.tolist()[0] if gid else None
                        elif isinstance(gid, list): gid = gid[0] if gid else None
                        
                        dev_unique_key = (graph.graph_id, node.id, dev_id)
                        active_gid_map[dev_unique_key] = gid
                        
                        dev_data = {
                            'type': 'dev', 
                            'key': dev_unique_key, 
                            'nest_gid': gid, 
                            'params': dev.get('params',{}), 
                            'model': dev_model, 
                            'info': {'name': f"{node.name} #{dev_id}", 'color': neuron_colors.get(model, '#fff')}
                        }
                        
                        if "spike" in dev_model: 
                            pop_info['recorders'].append(dev_data)
                            
                        d_item = QTreeWidgetItem(p_item)
                        d_item.setText(0, f"{'⚡' if 'spike' in dev_model else 'DATA'} {dev_model} #{dev_id}")
                        d_item.setData(0, Qt.ItemDataRole.UserRole, dev_data)
                        
                        if "meter" in dev_model: d_item.setForeground(0, QBrush(QColor("#00E5FF")))
                        else: d_item.setForeground(0, QBrush(QColor("#FFEB3B")))
                        
                    p_item.setData(0, Qt.ItemDataRole.UserRole, pop_info)

        for ukey, widget in self.active_plots_map.items():
            
            if isinstance(widget, LivePlotWidget):
                dev_lookup_key = ukey[:3]
                
                if dev_lookup_key in active_gid_map:
                    new_gid = active_gid_map[dev_lookup_key]
                    if new_gid is not None:
                        widget.nest_gid = new_gid

            elif isinstance(widget, PopulationRatePlot):
                for rec_data in widget.recorders_data:
                    d_key = rec_data.get('key')
                    if d_key in active_gid_map:
                        rec_data['nest_gid'] = active_gid_map[d_key]
                        
    def on_tree_item_clicked(self, item, col):
        data = item.data(0, Qt.ItemDataRole.UserRole)
        if not data: return
        dtype = data.get('type'); base_key = data.get('key')
        if self.current_view_mode == self.MODE_POP_ACTIVITY:
            target_pop_data = None
            if dtype == 'pop': target_pop_data = data
            elif dtype == 'dev' and "spike" in data.get('model',''):
                parent = item.parent()
                if parent: target_pop_data = parent.data(0, Qt.ItemDataRole.UserRole)
            if target_pop_data:
                ukey = (*target_pop_data['key'], 'rate')
                if ukey not in self.active_plots_map: self._add_pop_rate_plot(target_pop_data, ukey)
        else:
            if dtype == 'dev':
                ukey = (*base_key, 'detail')
                if ukey not in self.active_plots_map: self._add_dev_plot(data, ukey)

    def _add_pop_rate_plot(self, data, ukey):
        recorders = data.get('recorders', [])
        if not recorders: return
        info = data['info']
        neuron_count = data.get('neuron_count', 100)
        w = PopulationRatePlot(str(ukey), info['name'], neuron_count, info['color'], view_window=self.view_window, buffer_window=self.buffer_window, parent=self.plot_container)
        w.recorders_data = recorders
        w.closed.connect(lambda: self._on_widget_closed(ukey))
        self.plot_layout.addWidget(w); self.active_plots_map[ukey] = w; self.plot_container.adjustSize()

    def _add_dev_plot(self, data, ukey):
        gid = data.get('nest_gid')
        if gid is None: return
        w = LivePlotWidget(ukey, data['model'], data['params'], data['info'], view_window=self.view_window, buffer_window=self.buffer_window, parent=self.plot_container)
        w.setMinimumHeight(200); w.nest_gid = gid
        if gid in self.data_cache:
            cache = self.data_cache[gid]
            hist = {'times': cache['times'], 'senders': cache['senders']}
            for k,v in cache['values'].items(): hist[k] = v
            w.update_data(hist)
        w.closed.connect(lambda: self._on_widget_closed(ukey))
        self.plot_layout.addWidget(w); self.active_plots_map[ukey] = w

    def _on_widget_closed(self, key):
        if key in self.active_plots_map:
            w = self.active_plots_map.pop(key); w.setParent(None); w.deleteLater()

    def process_incoming_data(self, data_snapshot, current_time):
        
        for gid, events in data_snapshot.items():
            if gid not in self.data_cache: 
                self.data_cache[gid] = {'times':[], 'senders':[], 'values':{}}
            if 'times' in events: 
                self.data_cache[gid]['times'].extend(events['times'])
            if 'senders' in events: 
                self.data_cache[gid]['senders'].extend(events['senders'])
            for k,v in events.items():
                if k not in ['times','senders']:
                    if k not in self.data_cache[gid]['values']: 
                        self.data_cache[gid]['values'][k] = []
                    self.data_cache[gid]['values'][k].extend(v)
        
        if not self.isVisible():
            return
            
        for ukey, w in self.active_plots_map.items():
            target_gids = []
            if isinstance(w, PopulationRatePlot):
                for d in w.recorders_data: 
                    if d['nest_gid']: target_gids.append(d['nest_gid'])
            elif isinstance(w, LivePlotWidget):
                if w.nest_gid: target_gids.append(w.nest_gid)
            
            events_list = []
            for gid in target_gids:
                if gid in data_snapshot: events_list.append(data_snapshot[gid])
            
            if events_list:
                if isinstance(w, PopulationRatePlot): w.update_from_recorders(events_list, current_time)
                else: w.update_data(events_list[0], current_time)
            
            if self.chk_scroll.isChecked():
                if hasattr(w, 'set_view_range_to_window'):
                    w.set_view_range_to_window(current_time)

    def close_all_plots(self):
        for k in list(self.active_plots_map.keys()): self._on_widget_closed(k)
    def clear_all_data(self):
        self.data_cache.clear()
        for w in self.active_plots_map.values(): w.clear_data()
    def get_all_data(self): return self.data_cache
    def reload_and_center(self): self.scan_for_devices()
    def set_view_mode(self, idx):
        self.current_view_mode = idx
        for i, btn in enumerate(self.mode_btns):
            btn.setChecked(i == idx)
            style = "background-color: #2196F3; color: white; border: none; font-weight: bold;" if i == idx else "background-color: #333; color: #888; border: none;"
            btn.setStyleSheet(style)
    def _get_mode_btn_style(self, active):
        return f"background-color: {'#2196F3' if active else '#333'}; color: {'white' if active else '#888'}; font-weight: bold; border: none;"


class PopulationRatePlot(QWidget):
    closed = pyqtSignal()

    def __init__(self, plot_key, title, neuron_count, color_hex, view_window=1000.0, buffer_window=5000.0, resolution=None, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(200)
        
        self.plot_key = plot_key
        self.neuron_count = max(1, neuron_count)
        
        self.view_window = view_window
        self.buffer_window = buffer_window
        
        if resolution is None:
            try:
                self.resolution = nest.resolution
            except Exception:
                self.resolution = 0.1
        else:
            self.resolution = resolution
        
        self.view_window = view_window
        self.buffer_window = buffer_window
        
        self.time_bins = []
        self.rate_values = []
        self.recorders_data = [] 
        
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(0,0,0,0); self.layout.setSpacing(0)
        self.setStyleSheet(f"border: 1px solid #444; border-left: 4px solid {color_hex}; background-color: #121212; border-radius: 4px;")
        
        header = QWidget(); header.setStyleSheet("background-color: #222; border-bottom: 1px solid #333;")
        hl = QHBoxLayout(header); hl.setContentsMargins(5,2,5,2)
        lbl = QLabel(f"{title} (Rate)"); lbl.setStyleSheet("color: white; font-weight: bold;")
        hl.addWidget(lbl); hl.addStretch()
        btn_close = QPushButton("×"); btn_close.setFixedSize(20,20)
        btn_close.setStyleSheet("background: transparent; color: #888; border: none; font-weight: bold;")
        btn_close.clicked.connect(self.closed.emit)
        hl.addWidget(btn_close)
        self.layout.addWidget(header)
        
        self.pw = pg.PlotWidget()
        self.pw.setBackground(None)
        self.pw.showGrid(x=True, y=True, alpha=0.3)
        self.pw.setLabel('left', 'Firing Rate', units='Hz')
        self.pw.setLabel('bottom', 'Time', units='ms')
        self.pw.setMouseEnabled(x=True, y=True)
        
        c = QColor(color_hex)
        self.curve = self.pw.plot(pen=pg.mkPen(c, width=2), fillLevel=0, brush=pg.mkBrush(c.red(), c.green(), c.blue(), 50))
        self.layout.addWidget(self.pw)

    def set_view_window(self, ms):
        self.view_window = float(ms)
        if self.buffer_window < self.view_window: self.buffer_window = self.view_window

    def set_buffer_window(self, ms):
        self.buffer_window = float(ms)
        if self.view_window > self.buffer_window: self.view_window = self.buffer_window

    def update_from_recorders(self, events_list, current_time):
        total_spikes = 0
        for ev in events_list:
            if 'times' in ev: total_spikes += len(ev['times'])
        
        hz = total_spikes / (self.neuron_count * self.resolution)
        
        self.time_bins.append(current_time)
        self.rate_values.append(hz)
        
        cutoff = current_time - self.buffer_window
        while len(self.time_bins) > 0 and self.time_bins[0] < cutoff:
            self.time_bins.pop(0)
            self.rate_values.pop(0)
            
        self.curve.setData(self.time_bins, self.rate_values)

    def set_view_range_to_window(self, current_time):
        min_t = max(0, current_time - self.view_window)
        self.pw.setXRange(min_t, current_time, padding=0)
        
    def clear_data(self):
        self.time_bins = []; self.rate_values = []; self.curve.clear()
