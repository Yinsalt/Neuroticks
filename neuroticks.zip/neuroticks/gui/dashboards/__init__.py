"""Dashboards für Live- und Offline-Auswertung."""
from neuroticks.gui import bootstrap  # noqa: F401
