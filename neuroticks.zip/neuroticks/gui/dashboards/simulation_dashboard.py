"""SimulationDashboardWidget: Steuerung von Headless-Läufen und Export."""
import os
from datetime import datetime

from PyQt6.QtCore import pyqtSignal, Qt
from PyQt6.QtWidgets import (
    QDoubleSpinBox, QFileDialog, QFormLayout, QGroupBox, QHBoxLayout, QInputDialog, QLabel,
    QLineEdit, QMessageBox, QPushButton, QVBoxLayout, QWidget,
)
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

from neuron_toolbox import neuron_colors
from neuroticks.core.script_exporter import ScriptExporter

class SimulationDashboardWidget(QWidget):
    requestStartSimulation = pyqtSignal(float)
    requestStopSimulation = pyqtSignal()
    sigDurationChanged = pyqtSignal(float)
    requestResetKernel = pyqtSignal()

    def __init__(self, graph_list):
        super().__init__()
        self.graph_list = graph_list
        self.init_ui()

    def init_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setSpacing(20)
        main_layout.setContentsMargins(20, 20, 20, 20)

        header = QLabel("HEADLESS SIMULATION DASHBOARD")
        header.setStyleSheet("font-size: 18px; font-weight: bold; color: #FF9800; letter-spacing: 2px;")
        header.setAlignment(Qt.AlignmentFlag.AlignCenter)
        main_layout.addWidget(header)

        content_layout = QHBoxLayout()
        
        left_col = QVBoxLayout()
        
        config_group = QGroupBox("Configuration")
        config_layout = QFormLayout(config_group)
        
        self.duration_spin = QDoubleSpinBox()
        self.duration_spin.setRange(0.1, 10000000.0)
        self.duration_spin.setValue(1000.0)
        self.duration_spin.setSuffix(" ms")
        self.duration_spin.setStyleSheet("font-size: 14px; padding: 5px; color: #00E5FF; font-weight: bold;")
        self.duration_spin.valueChanged.connect(self.sigDurationChanged.emit)
        self.input_placeholder = QLineEdit("No external input file selected")
        self.input_placeholder.setReadOnly(True)
        self.input_placeholder.setStyleSheet("color: #888; font-style: italic;")
        
        config_layout.addRow("Duration:", self.duration_spin)
        config_layout.addRow("Input:", self.input_placeholder)
        
        left_col.addWidget(config_group)
        
        stats_group = QGroupBox("Network Status")
        self.stats_layout = QFormLayout(stats_group)
        self.lbl_nodes = QLabel("0"); self.lbl_nodes.setStyleSheet("color: #00E5FF; font-weight:bold;")
        self.lbl_neurons = QLabel("0"); self.lbl_neurons.setStyleSheet("color: #00E5FF; font-weight:bold;")
        self.lbl_conns = QLabel("0"); self.lbl_conns.setStyleSheet("color: #00E5FF; font-weight:bold;")
        
        self.stats_layout.addRow("Nodes:", self.lbl_nodes)
        self.stats_layout.addRow("Total Neurons:", self.lbl_neurons)
        self.stats_layout.addRow("Connections:", self.lbl_conns)
        
        left_col.addWidget(stats_group)
        left_col.addStretch()
        content_layout.addLayout(left_col, 1)

        right_col = QVBoxLayout()
        chart_group = QGroupBox("Model Distribution")
        chart_layout = QVBoxLayout(chart_group)
        
        self.figure = Figure(figsize=(4, 4), facecolor='#2b2b2b')
        self.canvas = FigureCanvas(self.figure)
        self.canvas.setStyleSheet("background-color: #2b2b2b;")
        chart_layout.addWidget(self.canvas)
        
        right_col.addWidget(chart_group)
        content_layout.addLayout(right_col, 1)

        main_layout.addLayout(content_layout)

        action_container = QWidget()
        action_layout = QHBoxLayout(action_container)
        action_layout.setSpacing(15)
        
        self.btn_start = QPushButton("RUN HEADLESS")
        self.btn_start.setMinimumHeight(60)
        self.btn_start.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_start.setStyleSheet("""
            QPushButton {
                background-color: #2E7D32; color: white; font-weight: bold; font-size: 16px; 
                border-radius: 8px; border-bottom: 4px solid #1B5E20;
            }
            QPushButton:hover { background-color: #388E3C; margin-top: 2px; border-bottom: 2px solid #1B5E20; }
            QPushButton:pressed { background-color: #1B5E20; margin-top: 4px; border-bottom: none; }
            QPushButton:disabled { background-color: #444; border: 1px solid #555; color: #888; }
        """)
        self.btn_start.clicked.connect(self._on_start_clicked)
        self.btn_export = QPushButton("EXPORT TO PYTHON")
        self.btn_export.setStyleSheet("background-color: #009688; color: white; font-weight: bold; padding: 10px;")
        self.btn_export.clicked.connect(self.export_script_dialog)
        self.btn_stop = QPushButton("STOP")
        self.btn_stop.setMinimumHeight(60)
        self.btn_stop.setEnabled(False)
        self.btn_stop.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_stop.setStyleSheet("""
            QPushButton {
                background-color: #C62828; color: white; font-weight: bold; font-size: 16px; 
                border-radius: 8px; border-bottom: 4px solid #B71C1C;
            }
            QPushButton:hover { background-color: #D32F2F; margin-top: 2px; border-bottom: 2px solid #B71C1C; }
            QPushButton:pressed { background-color: #B71C1C; margin-top: 4px; border-bottom: none; }
            QPushButton:disabled { background-color: #444; border: 1px solid #555; color: #888; }
        """)
        self.btn_stop.clicked.connect(self.requestStopSimulation.emit)
        
        self.btn_reset = QPushButton("RESET KERNEL")
        self.btn_reset.setMinimumHeight(60)
        self.btn_reset.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_reset.setStyleSheet("""
            QPushButton {
                background-color: #E65100; color: white; font-weight: bold; font-size: 16px; 
                border-radius: 8px; border-bottom: 4px solid #BF360C;
            }
            QPushButton:hover { background-color: #EF6C00; margin-top: 2px; border-bottom: 2px solid #BF360C; }
            QPushButton:pressed { background-color: #BF360C; margin-top: 4px; border-bottom: none; }
            QPushButton:disabled { background-color: #444; border: 1px solid #555; color: #888; }
        """)
        self.btn_reset.clicked.connect(self.requestResetKernel.emit)
        self.btn_export = QPushButton("EXPORT")
        self.btn_export.setMinimumHeight(60)
        self.btn_export.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_export.setStyleSheet("""
            QPushButton {
                background-color: #009688; color: white; font-weight: bold; font-size: 16px; 
                border-radius: 8px; border-bottom: 4px solid #00695C;
            }
            QPushButton:hover { background-color: #26A69A; margin-top: 2px; border-bottom: 2px solid #00695C; }
            QPushButton:pressed { background-color: #00695C; margin-top: 4px; border-bottom: none; }
        """)
        self.btn_export.clicked.connect(self.export_script_dialog)
        # ----------------------------------------

        action_layout.addWidget(self.btn_start, 2)
        action_layout.addWidget(self.btn_stop, 1)
        action_layout.addWidget(self.btn_reset, 1)
        action_layout.addWidget(self.btn_export, 1) 
        main_layout.addWidget(action_container)

        

    def _on_start_clicked(self):
        duration = self.duration_spin.value()
        self.requestStartSimulation.emit(duration)
    def export_script_dialog(self):
        parent_dir = QFileDialog.getExistingDirectory(
            self, "Select Destination Folder for Export"
        )
        
        if not parent_dir:
            return

        default_name = f"Neuroticks_Project_{datetime.now().strftime('%Y%m%d_%H%M')}"
        project_name, ok = QInputDialog.getText(
            self, "Project Name", "Enter name for the export folder:", text=default_name
        )
        
        if ok and project_name:
            safe_name = "".join(c for c in project_name if c.isalnum() or c in (' ', '_', '-')).strip()
            if not safe_name:
                safe_name = "Unnamed_Project"

            exporter = ScriptExporter(self.graph_list)
            duration = self.duration_spin.value()
            
            success = exporter.export_project(parent_dir, safe_name, duration=duration)
            
            if success:
                full_path = os.path.join(parent_dir, safe_name)
                QMessageBox.information(self, "Export Successful", 
                    f"Project exported successfully to:\n{full_path}\n\n"
                    "Files created:\n"
                    "- run.py\n"
                    "- graphs.json\n"
                    "- neuron_toolbox.py")
            else:
                QMessageBox.critical(self, "Export Failed", 
                    "Could not export the project. Check console for errors.")
    def set_ui_locked(self, locked):
        self.btn_start.setEnabled(not locked)
        self.btn_reset.setEnabled(not locked)
        self.duration_spin.setEnabled(not locked)
        
        self.btn_stop.setEnabled(locked)
        
        if locked:
            self.btn_start.setText("Running...")
            self.btn_start.setStyleSheet("background-color: #444; color: #888; border: 1px solid #555; border-radius: 8px;")
        else:
            self.btn_start.setText("▶ RUN HEADLESS")
            self.btn_start.setStyleSheet("""
                QPushButton {
                    background-color: #2E7D32; color: white; font-weight: bold; font-size: 16px; 
                    border-radius: 8px; border-bottom: 4px solid #1B5E20;
                }
                QPushButton:hover { background-color: #388E3C; margin-top: 2px; border-bottom: 2px solid #1B5E20; }
                QPushButton:pressed { background-color: #1B5E20; margin-top: 4px; border-bottom: none; }
            """)

    def refresh_data(self):
        total_nodes = 0
        total_neurons = 0
        total_conns = 0
        model_counts = {}

        for graph in self.graph_list:
            total_nodes += len(graph.node_list)
            for node in graph.node_list:
                if hasattr(node, 'connections'): total_conns += len(node.connections)
                if hasattr(node, 'population') and node.population:
                    for i, nest_pop in enumerate(node.population):
                        if nest_pop:
                            count = len(nest_pop)
                            total_neurons += count
                            model_name = node.neuron_models[i] if hasattr(node, 'neuron_models') and i < len(node.neuron_models) else "unknown"
                            model_counts[model_name] = model_counts.get(model_name, 0) + count

        self.lbl_nodes.setText(str(total_nodes))
        self.lbl_neurons.setText(str(total_neurons))
        self.lbl_conns.setText(str(total_conns))
        self._plot_pie_chart(model_counts)


    def update_duration_from_external(self, val):
        self.duration_spin.blockSignals(True)
        self.duration_spin.setValue(val)
        self.duration_spin.blockSignals(False)


    def _plot_pie_chart(self, counts):
        self.figure.clear()
        if not counts:
            ax = self.figure.add_subplot(111); ax.text(0.5, 0.5, "No Data", ha='center', color='white'); ax.axis('off')
            self.canvas.draw(); return

        labels = list(counts.keys()); sizes = list(counts.values())
        colors = [neuron_colors.get(l, "#888") for l in labels]
        ax = self.figure.add_subplot(111)
        wedges, texts, autotexts = ax.pie(sizes, labels=None, autopct='%1.1f%%', startangle=90, colors=colors, textprops=dict(color="white"), pctdistance=0.85)
        for t in autotexts: t.set_color("black"); t.set_weight("bold")
        ax.legend(wedges, labels, title="Models", loc="center left", bbox_to_anchor=(0.9, 0, 0.5, 1), frameon=False, labelcolor='#ccc')
        self.figure.patch.set_facecolor('#2b2b2b'); self.figure.subplots_adjust(left=0, bottom=0, right=0.75, top=1)
        self.canvas.draw()
