"""Ändert Gewichte bestehender Verbindungen während der Simulation."""
import nest

class LiveConnectionController:
    @staticmethod
    def set_weight(graph_list, conn_data, new_weight):
        try:
            src_info = conn_data.get('source', {})
            tgt_info = conn_data.get('target', {})
            
            src_pop = LiveConnectionController._find_population(graph_list, src_info)
            tgt_pop = LiveConnectionController._find_population(graph_list, tgt_info)
            
            if src_pop is None or tgt_pop is None:
                print("⚠ Live Update Failed: Source or Target population not found.")
                return False

            conns = nest.GetConnections(src_pop, tgt_pop)
            
            if not conns:
                print("⚠ Live Update: No active NEST connections found between these populations.")
                return False
            
            nest.SetStatus(conns, {'weight': float(new_weight)})
            print(f"⚡ Live Update: Set weight to {new_weight} for {len(conns)} connections.")
            return True
            
        except Exception as e:
            print(f"Live Update Error: {e}")
            import traceback
            traceback.print_exc()
            return False

    @staticmethod
    def _find_population(graph_list, info):
        gid = info.get('graph_id')
        nid = info.get('node_id')
        pid = info.get('pop_id')
        
        graph = next((g for g in graph_list if g.graph_id == gid), None)
        if not graph: return None
        
        node = graph.get_node(nid)
        if not node or not hasattr(node, 'population'): return None
        
        if pid < len(node.population):
            return node.population[pid]
        return None
