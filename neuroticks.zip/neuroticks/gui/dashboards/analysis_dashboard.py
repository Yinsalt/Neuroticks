"""AnalysisDashboard: Auswertung gespeicherter Simulationsdaten."""
import nest
import numpy as np
from PyQt6.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QPushButton, QStackedWidget, QVBoxLayout, QWidget,
)

from neuroticks.gui.dashboards.time_series import TimeSeriesPlotWidget
from neuroticks.gui.widgets.graph_info import GraphInfoWidget
from neuroticks.gui.widgets.python_console import PythonConsoleWidget
from neuroticks.gui.widgets.tool_inspector import ToolInspectorWidget

class AnalysisDashboard(QWidget):
    def __init__(self, graph_list, parent=None):
        super().__init__(parent)
        self.graph_list = graph_list
        self.init_ui()

    def init_ui(self):
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        
        menu_frame = QFrame()
        menu_frame.setFixedWidth(200)
        menu_frame.setStyleSheet("background-color: #232323; border-right: 1px solid #444;")
        menu_layout = QVBoxLayout(menu_frame)
        menu_layout.setContentsMargins(10, 20, 10, 10)
        menu_layout.setSpacing(10)
        
        lbl_title = QLabel("DATA ANALYSIS")
        lbl_title.setStyleSheet("color: #bbb; font-weight: bold; font-size: 12px; letter-spacing: 1px; border-bottom: 1px solid #444; padding-bottom: 5px;")
        menu_layout.addWidget(lbl_title)
        
        self.btn_graph_info = QPushButton("Graph Info")
        self.btn_time_series = QPushButton("Time Series")
        self.btn_tool_inspector = QPushButton("Tool Inspector")
        self.btn_terminal = QPushButton("Terminal")
        
        self.buttons = [
            self.btn_graph_info,
            self.btn_time_series,
            self.btn_tool_inspector,
            self.btn_terminal
        ]
        
        for i, btn in enumerate(self.buttons):
            btn.setCheckable(True)
            btn.setStyleSheet(self._get_btn_style())
            btn.clicked.connect(lambda checked, idx=i: self.switch_view(idx))
            menu_layout.addWidget(btn)
        
        menu_layout.addStretch()
        
        self.content_stack = QStackedWidget()
        
        self.graph_info = GraphInfoWidget(self.graph_list)
        self.content_stack.addWidget(self.graph_info)
        
        self.time_series = TimeSeriesPlotWidget(self.graph_list)
        self.content_stack.addWidget(self.time_series)
        
        self.tool_inspector = ToolInspectorWidget(self.graph_list)
        self.content_stack.addWidget(self.tool_inspector)

        context = {
            'graph_list': self.graph_list,
            'nest': nest,
            'np': np,
            'self': self
        }
        self.terminal_widget = PythonConsoleWidget(context_vars=context)
        self.content_stack.addWidget(self.terminal_widget)
        
        layout.addWidget(menu_frame)
        layout.addWidget(self.content_stack)
        
        self.switch_view(0)

    def refresh_all_tabs(self):
        if hasattr(self, 'graph_info'):
            self.graph_info.refresh_combo()
            
        if hasattr(self, 'time_series'):
            self.time_series.refresh_graphs()
            
        
    def switch_view(self, index):
        self.content_stack.setCurrentIndex(index)
        
        for i, btn in enumerate(self.buttons):
            btn.setChecked(i == index)
            
        if index == 0:
            self.graph_info.refresh_combo()
        elif index == 1:
            self.time_series.refresh_graphs()

    def _get_btn_style(self):
        return """
            QPushButton {
                text-align: left; padding: 10px; border: none;
                background-color: transparent; color: #aaa; font-weight: bold;
            }
            QPushButton:hover { background-color: #2c2c2c; color: white; }
            QPushButton:checked { background-color: #1976D2; color: white; border-left: 4px solid #64B5F6; }
        """
