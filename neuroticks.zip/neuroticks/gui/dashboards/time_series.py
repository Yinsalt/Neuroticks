"""TimeSeriesPlotWidget: Zeitreihen aufgezeichneter Devices."""
import numpy as np
import pyqtgraph as pg
import pyqtgraph.opengl as gl
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QComboBox, QFrame, QHBoxLayout, QLabel, QPushButton, QStackedWidget, QVBoxLayout,
    QWidget,
)
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

from neuroticks.gui.visualization.simulation_view import SafeGLViewWidget

class TimeSeriesPlotWidget(QWidget):
    def __init__(self, graph_list):
        super().__init__()
        self.graph_list = graph_list
        self.current_data = {}
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        
        ctrl_frame = QFrame()
        ctrl_frame.setStyleSheet("background-color: #2b2b2b; border: 1px solid #444; border-radius: 4px;")
        ctrl_layout = QHBoxLayout(ctrl_frame)
        
        style_combo = "background-color: #1e1e1e; color: white; border: 1px solid #555; padding: 4px;"
        style_lbl = "color: #ddd; font-weight: bold;"
        
        self.combo_graph = QComboBox(); self.combo_graph.setStyleSheet(style_combo)
        self.combo_node = QComboBox(); self.combo_node.setStyleSheet(style_combo)
        self.combo_device = QComboBox(); self.combo_device.setStyleSheet(style_combo)
        
        self.combo_analysis = QComboBox()
        self.combo_analysis.setStyleSheet("background-color: #004d40; color: white; border: 1px solid #00695c; padding: 4px; font-weight: bold;")
        
        self.btn_plot = QPushButton("ANALYZE")
        self.btn_plot.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_plot.setStyleSheet("background-color: #2196F3; color: white; font-weight: bold; border-radius: 3px; padding: 6px 20px;")
        
        ctrl_layout.addWidget(QLabel("Graph:", styleSheet=style_lbl))
        ctrl_layout.addWidget(self.combo_graph)
        ctrl_layout.addWidget(QLabel("Node:", styleSheet=style_lbl))
        ctrl_layout.addWidget(self.combo_node)
        ctrl_layout.addWidget(QLabel("Device:", styleSheet=style_lbl))
        ctrl_layout.addWidget(self.combo_device, 1)
        ctrl_layout.addWidget(QLabel("Tool:", styleSheet=style_lbl))
        ctrl_layout.addWidget(self.combo_analysis, 1)
        ctrl_layout.addWidget(self.btn_plot)
        
        layout.addWidget(ctrl_frame)
        
        self.stack = QStackedWidget()
        
        self.pg_view = pg.GraphicsLayoutWidget()
        self.pg_view.setBackground('w')
        self.stack.addWidget(self.pg_view)
        
        self.gl_view = SafeGLViewWidget()
        self.gl_view.opts['distance'] = 200
        self.gl_view.setBackgroundColor('k')
        self.stack.addWidget(self.gl_view)
        
        self.fig = Figure(figsize=(5, 4), facecolor='white')
        self.mpl_canvas = FigureCanvas(self.fig)
        self.stack.addWidget(self.mpl_canvas)
        
        layout.addWidget(self.stack)
        
        self.combo_graph.currentIndexChanged.connect(self.on_graph_changed)
        self.combo_node.currentIndexChanged.connect(self.on_node_changed)
        self.combo_device.currentIndexChanged.connect(self.on_device_changed)
        self.btn_plot.clicked.connect(self.run_analysis)
        
        self.refresh_graphs()


    def refresh_graphs(self):
        self.combo_graph.blockSignals(True)
        self.combo_graph.clear()
        for g in self.graph_list:
            name = getattr(g, 'graph_name', f"Graph {g.graph_id}")
            self.combo_graph.addItem(f"{name} (ID: {g.graph_id})", g.graph_id)
        self.combo_graph.blockSignals(False)
        self.on_graph_changed()

    def on_graph_changed(self):
        self.combo_node.blockSignals(True)
        self.combo_node.clear()
        gid = self.combo_graph.currentData()
        graph = next((g for g in self.graph_list if g.graph_id == gid), None)
        if graph:
            for node in graph.node_list:
                self.combo_node.addItem(f"{node.name} (ID: {node.id})", node)
        self.combo_node.blockSignals(False)
        self.on_node_changed()

    def on_node_changed(self):
        self.combo_device.blockSignals(True)
        self.combo_device.clear()
        node = self.combo_node.currentData()
        if not node: return
        
        known_devices = {}
        
        if hasattr(node, 'devices'):
            for d in node.devices:
                known_devices[d.get('id')] = d.get('model', 'unknown')
                
        if hasattr(node, 'results') and 'history' in node.results:
            for entry in node.results['history']:
                if 'devices' in entry:
                    for did_str, info in entry['devices'].items():
                        try:
                            did = int(did_str)
                            if did not in known_devices:
                                known_devices[did] = info.get('model', 'unknown')
                        except (ValueError, TypeError): pass
        
        def safe_sort_key(k):
            try:
                return (0, int(k))
            except (ValueError, TypeError):
                return (1, str(k))

        for did in sorted(list(known_devices.keys()), key=safe_sort_key):
            model = known_devices[did]
            if "recorder" in model or "meter" in model:
                self.combo_device.addItem(f"#{did}: {model}", (did, model))
                
        self.combo_device.blockSignals(False)
        self.on_device_changed()

    def on_device_changed(self):
        self.combo_analysis.clear()
        data = self.combo_device.currentData()
        if not data: return
        
        did, model = data
        
        if "spike_recorder" in model:
            self.combo_analysis.addItems([
                "Raster Plot (2D)",
                "Population Activity (Histogram)",
                "Firing Rate (Line)",
                "ISI Distribution (Histogram)",
                "Spike Matrix (Heatmap)"
            ])
        elif "meter" in model or "multimeter" in model:
            self.combo_analysis.addItems([
                "Membrane Potential (Traces)",
                "V_m Heatmap"
            ])

    def _fetch_data(self):
        node = self.combo_node.currentData()
        dev_data_raw = self.combo_device.currentData()
        if not node or not dev_data_raw: return None
        
        dev_id, model = dev_data_raw
        
        if not hasattr(node, 'results') or 'history' not in node.results:
            return None
            
        merged = {'times': [], 'senders': [], 'V_m': [], 'model': model, 'dev_id': dev_id}
        
        for run in node.results['history']:
            if 'devices' not in run: continue
            
            dev_entry = run['devices'].get(dev_id) or run['devices'].get(str(dev_id))
            if not dev_entry or 'data' not in dev_entry: continue
            
            d = dev_entry['data']
            
            if 'times' in d: merged['times'].extend(d['times'])
            if 'senders' in d: merged['senders'].extend(d['senders'])
            if 'V_m' in d: merged['V_m'].extend(d['V_m'])
            
        if merged['times']: merged['times'] = np.array(merged['times'])
        if merged['senders']: merged['senders'] = np.array(merged['senders'])
        if merged['V_m']: merged['V_m'] = np.array(merged['V_m'])
        
        return merged

    def run_analysis(self):
        data = self._fetch_data()
        if not data or len(data['times']) == 0:
            print("No data found for this device.")
            return

        mode = self.combo_analysis.currentText()
        
        self.pg_view.clear()
        self.gl_view.items = []
        self.fig.clear()
        
        if "3D" in mode:
            self.stack.setCurrentIndex(1)
            self._plot_3d(data, mode)
        elif "Matplotlib" in mode:
            self.stack.setCurrentIndex(2)
            self._plot_mpl(data, mode)
        else:
            self.stack.setCurrentIndex(0)
            self._plot_2d(data, mode)

    
    def _plot_2d(self, data, mode):
        times = data['times']
        
        sort_idx = np.argsort(times)
        times = times[sort_idx]
        
        if mode == "Raster Plot (2D)":
            senders = data['senders'][sort_idx]
            p = self.pg_view.addPlot(title=f"Spike Raster (#{data['dev_id']})")
            scatter = pg.ScatterPlotItem(x=times, y=senders, size=3, pen=None, brush='k')
            p.addItem(scatter)
            p.setLabel('bottom', 'Time', 'ms')
            p.setLabel('left', 'Neuron ID')

        elif mode == "Population Activity (Histogram)":
            p = self.pg_view.addPlot(title="Population Activity (PSTH)")
            y, x = np.histogram(times, bins=100)
            curve = pg.BarGraphItem(x=x[:-1], height=y, width=(x[1]-x[0]), brush='b')
            p.addItem(curve)
            p.setLabel('bottom', 'Time', 'ms')
            p.setLabel('left', 'Spike Count')

        elif mode == "Firing Rate (Line)":
            bin_size = 10.0
            bins = np.arange(times.min(), times.max() + bin_size, bin_size)
            counts, _ = np.histogram(times, bins=bins)
            
            unique_senders = len(np.unique(data['senders'])) if len(data['senders']) > 0 else 1
            rate = counts / (bin_size / 1000.0) / unique_senders
            
            p = self.pg_view.addPlot(title="Population Firing Rate")
            p.plot(bins[:-1], rate, pen=pg.mkPen('r', width=2))
            p.setLabel('bottom', 'Time', 'ms')
            p.setLabel('left', 'Rate', 'Hz')

        elif mode == "ISI Distribution (Histogram)":
            senders = data['senders']
            isis = []
            for nid in np.unique(senders):
                st = np.sort(times[senders == nid])
                if len(st) > 1:
                    isis.extend(np.diff(st))
            
            if isis:
                p = self.pg_view.addPlot(title="Inter-Spike Intervals (ISI)")
                y, x = np.histogram(isis, bins=50)
                bg = pg.BarGraphItem(x=x[:-1], height=y, width=(x[1]-x[0]), brush='g')
                p.addItem(bg)
                p.setLabel('bottom', 'ISI', 'ms')
            else:
                self.pg_view.addLabel("Not enough spikes for ISI")

        elif mode == "Membrane Potential (Traces)":
            vals = data['V_m'][sort_idx]
            
            senders = data.get('senders')
            if senders is not None:
                senders = senders[sort_idx]
                unique_ids = np.unique(senders)[:10]
                
                p = self.pg_view.addPlot(title="Membrane Potential (First 10 Neurons)")
                p.addLegend()
                
                colors = ['r', 'g', 'b', 'c', 'm', 'y', 'k', 'orange', 'purple', 'brown']
                for i, uid in enumerate(unique_ids):
                    mask = senders == uid
                    t_u = times[mask]
                    v_u = vals[mask]
                    p.plot(t_u, v_u, pen=pg.mkPen(colors[i%len(colors)], width=1.5), name=f"N{uid}")
                
                p.setLabel('bottom', 'Time', 'ms')
                p.setLabel('left', 'Voltage', 'mV')

        elif "Heatmap" in mode:
            self._plot_heatmap_2d(data, mode)

    def _plot_heatmap_2d(self, data, mode):
        times = data['times']
        
        if "Spike" in mode:
            senders = data['senders']
            t_bins = 50
            n_bins = max(10, len(np.unique(senders)))
            
            hist, x_edges, y_edges = np.histogram2d(times, senders, bins=[t_bins, n_bins])
            
            p = self.pg_view.addPlot(title="Spike Density Heatmap")
            img = pg.ImageItem(hist)
            img.setLookupTable(pg.colormap.get('inferno').getLookupTable())
            p.addItem(img)
            p.setLabel('bottom', 'Time Bin')
            p.setLabel('left', 'Neuron Bin')
            
            bar = pg.ColorBarItem(values=(0, np.max(hist)), colorMap='inferno')
            bar.setImageItem(img)
            
        elif "V_m" in mode:
            senders = data['senders']
            vals = data['V_m']
            
            u_ids = np.unique(senders)
            u_ids.sort()
            
            common_time = np.linspace(times.min(), times.max(), 200)
            matrix = np.zeros((len(u_ids), len(common_time)))
            
            for i, uid in enumerate(u_ids):
                mask = senders == uid
                t_n = times[mask]
                v_n = vals[mask]
                s = np.argsort(t_n)
                if len(s) > 1:
                    matrix[i, :] = np.interp(common_time, t_n[s], v_n[s])
            
            p = self.pg_view.addPlot(title="Membrane Potential Heatmap")
            img = pg.ImageItem(matrix)
            img.setLookupTable(pg.colormap.get('viridis').getLookupTable())
            p.addItem(img)
            p.setLabel('bottom', 'Time')
            p.setLabel('left', 'Neuron Index')


    def _plot_3d(self, data, mode):
        times = data['times']
        
        self.gl_view.setCameraPosition(distance=100, elevation=30, azimuth=45)
        
        g = gl.GLGridItem()
        g.scale(10, 10, 1)
        self.gl_view.addItem(g)
        
        if mode == "3D Spike Cloud":
            senders = data['senders']
            x = (times - times.min()) / (np.ptp(times) + 1e-6) * 100 - 50
            y = (senders - senders.min()) / (np.ptp(senders) + 1e-6) * 100 - 50
            z = np.zeros_like(x)
            
            pos = np.column_stack((x, y, z))
            
            colors = np.zeros((len(pos), 4))
            colors[:, 0] = (x + 50) / 100.0
            colors[:, 2] = 1.0 - ((x + 50) / 100.0)
            colors[:, 1] = 0.5
            colors[:, 3] = 0.8
            
            sp = gl.GLScatterPlotItem(pos=pos, color=colors, size=5, pxMode=True)
            self.gl_view.addItem(sp)
            
        elif mode == "3D Activity Surface" or "3D V_m" in mode:
            senders = data['senders']
            vals = data['V_m'] if "V_m" in mode else np.ones_like(times)
            
            t_bins = 50
            n_bins = 50
            
            if "V_m" in mode:
                 pass
                 self._plot_3d(data, "3D Spike Cloud")
                 return
            else:
                hist, _, _ = np.histogram2d(times, senders, bins=[t_bins, n_bins])
                
                z = hist * 5.0
                
                surface = gl.GLSurfacePlotItem(z=z, shader='heightColor', computeNormals=False, smooth=False)
                surface.shader()['colorMap'] = np.array([0,0,1,1, 0,1,0,1, 1,1,0,1, 1,0,0,1])
                surface.translate(-t_bins/2, -n_bins/2, 0)
                surface.scale(2, 2, 1)
                self.gl_view.addItem(surface)
