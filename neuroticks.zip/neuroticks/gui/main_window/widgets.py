"""Hilfs-Widgets des Hauptfensters (Viewport, Vorschau, Statusleiste)."""
from PyQt6.QtCore import pyqtSignal, QSize, Qt
from PyQt6.QtGui import QColor, QPalette
from PyQt6.QtWidgets import QHBoxLayout, QLabel, QProgressBar, QPushButton, QVBoxLayout, QWidget

class MaximizableViewport(QWidget):
    """Wrapper-Container für ein Viz-Widget, das einen kleinen Maximize/
    Minimize-Button als Overlay rechts unten anbietet.

    Rendering-Plumbing: das eigentliche Viz-Widget liegt in einem
    QVBoxLayout, der Button ist ein Child mit absoluten Koordinaten
    (per resizeEvent positioniert) — damit kann er weder Layout noch
    Aspect-Ratio des Viz beeinflussen.

    Den Mode-Switch macht NICHT diese Klasse selber, sondern die
    sigToggleMaximize-Signal-Connection im Editor-Widget. Grund: das
    Maximieren bedeutet auf Editor-Ebene "Sidebar weg, anderes Layout
    aktiv" — das kann nur der Editor entscheiden.
    """
    sigToggleMaximize = pyqtSignal(object)  # emits self

    def __init__(self, inner_widget, parent=None):
        super().__init__(parent)
        self._inner = inner_widget
        self._is_maximized = False

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addWidget(inner_widget)

        # Overlay-Button: Child von self (nicht im Layout!), wird in
        # resizeEvent positioniert. Stylesheet ahmt typische OS-Window-
        # Buttons nach: dezenter Hintergrund, prägnante Glyphe.
        self.btn_max = QPushButton("⛶", self)  # U+26F6 Square Four
        self.btn_max.setToolTip("Maximize / Minimize")
        self.btn_max.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_max.setFixedSize(28, 28)
        self.btn_max.setStyleSheet("""
            QPushButton {
                background-color: rgba(40, 40, 40, 200);
                color: #DDD;
                border: 1px solid #555;
                border-radius: 4px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: rgba(80, 80, 80, 230);
                color: #FFF;
                border: 1px solid #2196F3;
            }
            QPushButton:pressed {
                background-color: rgba(20, 20, 20, 230);
            }
        """)
        self.btn_max.clicked.connect(
            lambda: self.sigToggleMaximize.emit(self))
        # Über alle Geschwister-Widgets (3D-Viewer etc.).
        self.btn_max.raise_()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        # Button rechts unten mit 8 px Margin platzieren.
        margin = 8
        self.btn_max.move(
            self.width() - self.btn_max.width() - margin,
            self.height() - self.btn_max.height() - margin,
        )
        self.btn_max.raise_()

    def set_maximized_state(self, is_max: bool):
        """Setzt nur die Glyphe + State-Flag. Das eigentliche
        Reparenting läuft im Editor."""
        self._is_maximized = is_max
        # ⛶ = maximize-Hint (vier Ecken nach außen)
        # 🗗 würde "restore" sein, ist aber nicht zuverlässig in jedem
        # Qt-Font; daher ⛶ auch im max-Zustand, mit anderem Tooltip.
        # Alternative: Char "−" (Minus) wenn max-Glyphe nicht mag.
        if is_max:
            self.btn_max.setText("🗗")
            self.btn_max.setToolTip("Restore")
        else:
            self.btn_max.setText("⛶")
            self.btn_max.setToolTip("Maximize")


class PreviewWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet("""
            background-color: #000000; 
            border: 1px solid #333;
        """)
        self.setMinimumSize(80, 80)
        self._updating = False
        
    def resizeEvent(self, event):
        if self._updating:
            return super().resizeEvent(event)
        
        self._updating = True
        width = event.size().width()
        if self.height() != width:
            self.setFixedHeight(width)
        self._updating = False
        super().resizeEvent(event)
    
    def sizeHint(self):
        return QSize(150, 150)
    
    def minimumSizeHint(self):
        return QSize(80, 80)


class Color(QWidget):
    def __init__(self, color):
        super().__init__()
        self.setAutoFillBackground(True)
        palette = self.palette()
        palette.setColor(QPalette.ColorRole.Window, QColor(color))
        self.setPalette(palette)


class StatusBarWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.setup_ui()
    
    def setup_ui(self):
        layout = QHBoxLayout(self)
        layout.setContentsMargins(5, 2, 5, 2)
        
        self.status_label = QLabel("Ready")
        self.status_label.setStyleSheet("""
            QLabel {
                color: #2E7D32;
                font-weight: bold;
                padding: 2px 5px;
            }
        """)
        
        self.progress_bar = QProgressBar()
        self.progress_bar.setMaximumWidth(200)
        self.progress_bar.setMaximumHeight(20)
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                border: 1px solid #555;     
                border-radius: 3px;
                text-align: center;
                background-color: #333;     
                color: white;               
            }
            QProgressBar::chunk {
                background-color: #4CAF50; 
                border-radius: 2px;
            }
        """)
        self.progress_bar.setVisible(False)
        
        layout.addWidget(self.status_label, 8)
        layout.addWidget(self.progress_bar, 2)
    
    def set_status(self, message, color="#2E7D32"):
        self.status_label.setText(message)
        self.status_label.setStyleSheet(f"""
            QLabel {{
                color: {color};
                font-weight: bold;
                padding: 2px 5px;
            }}
        """)
    
    def set_progress(self, value, maximum=100, show=True):
        if show:
            self.progress_bar.setVisible(True)
            self.progress_bar.setMaximum(maximum)
            self.progress_bar.setValue(value)
        else:
            self.progress_bar.setVisible(False)
    
    def reset(self):
        self.status_label.setText("Ready")
        self.status_label.setStyleSheet("""
            QLabel {
                color: #2E7D32;
                font-weight: bold;
                padding: 2px 5px;
            }
        """)
        self.progress_bar.setVisible(False)
        self.progress_bar.setValue(0)
    
    def show_error(self, message):
        self.set_status(f"{message}", color="#D32F2F")
        self.progress_bar.setVisible(False)
    
    def show_success(self, message):
        self.set_status(f"{message}", color="#2E7D32")
        self.progress_bar.setVisible(False)
