"""Seite 'Population Examples': Browser für den Examples/-Ordner."""
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QPushButton, QScrollArea, QVBoxLayout, QWidget,
)

class _ExamplesPage(QWidget):
    """
    The "Population Examples" tab: lists every *.json file inside the
    Examples/ folder. Each file is a button — clicking opens a sub-list
    of all graphs the file contains, then a displacement dialog, then
    the import.
    
    The actual scanning and importing logic lives on MainWindow
    (_scan_examples, _import_example_file). This widget is just the UI.
    """
    
    def __init__(self, main_window, parent=None):
        super().__init__(parent)
        self.main = main_window
        self._build_ui()
        self.rebuild()
    
    def _build_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        
        # Header
        header_frame = QFrame()
        header_frame.setStyleSheet("background-color: #2b2b2b; border-bottom: 1px solid #444;")
        hl = QVBoxLayout(header_frame)
        hl.setContentsMargins(10, 10, 10, 10)
        title = QLabel("EXAMPLES")
        title.setStyleSheet("font-weight: bold; font-size: 14px; color: #66BB6A;")
        hl.addWidget(title)
        info = QLabel(
            "Click a file to import its graphs into the current scene. "
            "You'll be asked for a 3D displacement so the new graph "
            "doesn't overlap existing ones."
        )
        info.setStyleSheet("color: #888; font-style: italic;")
        info.setWordWrap(True)
        hl.addWidget(info)
        # Folder path + rescan button
        bottom_row = QHBoxLayout()
        self._path_label = QLabel("")
        self._path_label.setStyleSheet("color: #666; font-size: 10px; font-family: monospace;")
        bottom_row.addWidget(self._path_label, 1)
        rescan_btn = QPushButton("⟳ Rescan")
        rescan_btn.setFixedHeight(24)
        rescan_btn.setStyleSheet("""
            QPushButton { background: #263238; color: #ECEFF1;
                          border: 1px solid #455A64; border-radius: 4px;
                          padding: 2px 10px; font-size: 11px; }
            QPushButton:hover { background: #37474F; border: 1px solid #607D8B; }
        """)
        rescan_btn.clicked.connect(self.rebuild)
        bottom_row.addWidget(rescan_btn)
        hl.addLayout(bottom_row)
        outer.addWidget(header_frame)
        
        # Scrollable list of example files
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("border: none; background-color: #1e1e1e;")
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self._container = QWidget()
        self._container.setStyleSheet("background-color: #1e1e1e;")
        self._inner_layout = QVBoxLayout(self._container)
        self._inner_layout.setSpacing(4)
        self._inner_layout.setContentsMargins(10, 10, 10, 10)
        self._inner_layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        scroll.setWidget(self._container)
        outer.addWidget(scroll, 1)
    
    def rebuild(self):
        """Re-scans the folder and rebuilds the file-button list."""
        # Wipe
        while self._inner_layout.count():
            item = self._inner_layout.takeAt(0)
            w = item.widget()
            if w:
                w.setParent(None)
                w.deleteLater()
        
        try:
            self._path_label.setText(str(self.main._examples_dir()))
        except Exception:
            self._path_label.setText("Examples/")
        
        entries = self.main._scan_examples()
        if not entries:
            hint = QLabel(
                f"<i>No example files yet.</i><br><br>"
                f"Drop <code>*.json</code> files into:<br>"
                f"<b>{self.main._examples_dir()}</b><br><br>"
                f"Each file imports as a complete bundle (all graphs + connections)."
            )
            hint.setTextFormat(Qt.TextFormat.RichText)
            hint.setWordWrap(True)
            hint.setStyleSheet("color: #888; font-size: 12px; padding: 20px;")
            hint.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft)
            self._inner_layout.addWidget(hint)
            return
        
        # One button per file. The whole file is imported as a bundle so
        # cross-graph connections between graphs in the same file stay
        # intact. Files that contain a single graph still work.
        import os
        for fp, label, count in entries:
            btn = QPushButton(label)
            btn.setMinimumHeight(48)
            btn.setMinimumWidth(220)
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.setStyleSheet("""
                QPushButton {
                    background-color: #1B5E20; color: #C8E6C9;
                    border: 1px solid #2E7D32; border-radius: 6px;
                    padding: 8px 14px; font-weight: bold; font-size: 13px;
                    text-align: left;
                }
                QPushButton:hover {
                    background-color: #2E7D32; border: 1px solid #66BB6A;
                    color: white;
                }
            """)
            count_word = "graph" if count == 1 else "graphs"
            btn.setToolTip(
                f"Import {os.path.basename(fp)} ({count} {count_word}) "
                f"as a complete bundle."
            )
            # Show the count subtly inside the button text
            btn.setText(f"{label}    [{count} {count_word}]")
            btn.clicked.connect(
                lambda checked, p=fp, lab=label, c=count:
                self.main._on_example_clicked(p, lab, c)
            )
            self._inner_layout.addWidget(btn)
        
        self._inner_layout.addStretch()
