"""Dialoge des Hauptfensters."""
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QDialog, QDialogButtonBox, QDoubleSpinBox, QHBoxLayout, QLabel, QVBoxLayout,
)

class _DisplacementDialog(QDialog):
    """Tiny modal dialog: asks the user for a 3D offset (dx, dy, dz)
    before importing an example graph. Returns (dx, dy, dz) on accept."""
    
    def __init__(self, graph_name, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Import: {graph_name}")
        self.setModal(True)
        self.setMinimumWidth(360)
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(15, 12, 15, 12)
        layout.setSpacing(10)
        
        info = QLabel(
            f"Where to place <b>{graph_name}</b>?<br>"
            "<i style='color:#888'>The graph will be shifted by this offset "
            "so it doesn't overlap existing graphs.</i>"
        )
        info.setTextFormat(Qt.TextFormat.RichText)
        info.setWordWrap(True)
        layout.addWidget(info)
        
        # Three spinboxes
        self.dx = QDoubleSpinBox(); self.dx.setRange(-1e6, 1e6); self.dx.setDecimals(3); self.dx.setSingleStep(1.0); self.dx.setPrefix("dx = ")
        self.dy = QDoubleSpinBox(); self.dy.setRange(-1e6, 1e6); self.dy.setDecimals(3); self.dy.setSingleStep(1.0); self.dy.setPrefix("dy = ")
        self.dz = QDoubleSpinBox(); self.dz.setRange(-1e6, 1e6); self.dz.setDecimals(3); self.dz.setSingleStep(1.0); self.dz.setPrefix("dz = ")
        for w in (self.dx, self.dy, self.dz):
            w.setFixedHeight(28)
        row = QHBoxLayout()
        row.addWidget(self.dx); row.addWidget(self.dy); row.addWidget(self.dz)
        layout.addLayout(row)
        
        # Buttons
        btn_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        btn_box.accepted.connect(self.accept)
        btn_box.rejected.connect(self.reject)
        layout.addWidget(btn_box)
    
    def get_displacement(self):
        return self.dx.value(), self.dy.value(), self.dz.value()
