"""MainWindow: setzt die Mixins zusammen und hält die Qt-Event-Handler."""
import nest
import vtk
from PyQt6.QtWidgets import QMainWindow, QSizePolicy

from neuroticks.gui.main_window.mixins.examples import ExamplesMixin
from neuroticks.gui.main_window.mixins.graph_events import GraphEventsMixin
from neuroticks.gui.main_window.mixins.headless import HeadlessMixin
from neuroticks.gui.main_window.mixins.layout import LayoutMixin
from neuroticks.gui.main_window.mixins.nest_kernel import NestKernelMixin
from neuroticks.gui.main_window.mixins.persistence import PersistenceMixin
from neuroticks.gui.main_window.mixins.project import ProjectMixin
from neuroticks.gui.main_window.mixins.simulation import SimulationMixin
from neuroticks.gui.main_window.mixins.visualization import VisualizationMixin

nest.EnableStructuralPlasticity()
nest.set_verbosity("M_ERROR")


class MainWindow(
    LayoutMixin,
    ProjectMixin,
    NestKernelMixin,
    GraphEventsMixin,
    VisualizationMixin,
    SimulationMixin,
    HeadlessMixin,
    PersistenceMixin,
    ExamplesMixin,
    QMainWindow,
):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Neuroticks")
        self.setMinimumSize(1280, 720)
        self.resize(1920, 1080)
        
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.active_graphs = {}
        self.graphs = self.active_graphs
        self.structural_plasticity_enabled = True
        self.hidden_nodes = set()
        self.hidden_graphs = set()
        self.create_menubar()
        self.setup_ui()
        self.graph_builder.polynom_manager.polynomialsChanged.connect(self.rebuild_node_with_new_polynomials)
    


    def closeEvent(self, event):
        try:
            vtk.vtkObject.GlobalWarningDisplayOff()
            
            if hasattr(self, 'simulation_view') and self.simulation_view:
                self.simulation_view.sim_running = False
                if hasattr(self.simulation_view, 'timer'):
                    self.simulation_view.timer.stop()
            
            if hasattr(self, 'blink_widget') and self.blink_widget:
                self.blink_widget.is_active = False
                self.blink_widget.simulation_running = False
                if hasattr(self.blink_widget, 'timer'):
                    self.blink_widget.timer.stop()
            
            if hasattr(self, 'vis_stack'):
                for i in range(self.vis_stack.count()):
                    widget = self.vis_stack.widget(i)
                    if widget:
                        if hasattr(widget, 'timer'):
                            widget.timer.stop()
                        if hasattr(widget, 'plotter'):
                            try:
                                widget.plotter.close()
                            except:
                                pass

            for plotter_name in ['neuron_plotter', 'graph_plotter']:
                if hasattr(self, plotter_name):
                    plotter = getattr(self, plotter_name)
                    if plotter:
                        try:
                            plotter.close()
                        except:
                            pass
            
            if hasattr(self, 'blink_widget') and self.blink_widget:
                if hasattr(self.blink_widget, 'plotter'):
                    try:
                        self.blink_widget.plotter.close()
                    except:
                        pass
                        
        except Exception as e:
            print(f"Cleanup error (harmless on exit): {e}")
        
        event.accept()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        
        from PyQt6.QtCore import QTimer
        QTimer.singleShot(50, self._update_plotters_after_resize)
