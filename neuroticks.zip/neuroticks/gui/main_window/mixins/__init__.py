"""Thematische Mixins, aus denen MainWindow zusammengesetzt ist."""
