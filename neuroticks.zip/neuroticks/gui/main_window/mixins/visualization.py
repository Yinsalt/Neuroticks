"""3D-Darstellung: Neuronenpunkte, Graph-Skelett, Hover und Detail-Panel."""
import numpy as np
import pyvista as pv
import vtk
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QFrame, QHBoxLayout, QLabel, QPushButton, QVBoxLayout, QWidget
from pyvistaqt import QtInteractor

from neuroticks.constants.colors import get_neuron_color
from neuroticks.state import graph_list


class VisualizationMixin:
    """PyVista-Darstellung der Graphen."""

    def _on_retina_viz_refresh(self):
        """Triggert Redraw der Live-Viz nach Retina-Build oder Frame-Tick.

        Die BlinkingNetworkWidget aktualisiert sich selbst via Timer, aber bei
        strukturellen Aenderungen (Retina neu gebaut / zerstoert) muss build_scene()
        erneut laufen, damit die virtual_graph-Nodes mitgerendert werden.
        """
        try:
            if hasattr(self, 'blink_widget') and self.blink_widget is not None:
                # Nur bei strukturellen Aenderungen rebuild - nicht bei jedem Frame-Tick
                # Der Caller (retinaBuilt/Destroyed) signalisiert das.
                if self.sender() is not None and self.sender().__class__.__name__ == 'RetinaTestTabWidget':
                    # Signal name checken via sender()... einfacher: immer rebuild
                    pass
                self.blink_widget.build_scene()
            # Neuron- und Graph-Plotter ebenfalls aktualisieren wenn gerade sichtbar
            if self.vis_stack.currentIndex() == 0:
                self.plot_neuron_points()
            elif self.vis_stack.currentIndex() == 1:
                self.plot_graph_skeleton()
        except Exception as e:
            print(f"viz refresh error: {e}")

    def create_neuron_visualization(self):
        plotter = QtInteractor(self)
        plotter.set_background('black')
        plotter.add_axes()
        return plotter
    
    def _on_opacity_changed(self, value):
        opacity = value / 100.0
        if hasattr(self, 'blink_widget'):
            self.blink_widget.set_base_opacity(opacity)

    def create_graph_visualization(self):
        """Returns a wrapper widget: graph plotter with a top header bar
        (label-toggle) and an overlay detail-panel. The actual plotter
        sits at self.graph_plotter; helpers below access it directly."""
        wrapper = QWidget()
        v = QVBoxLayout(wrapper)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(0)

        # Header bar with the label-toggle
        header = QWidget()
        header.setStyleSheet("background: #1a1a1a; border-bottom: 1px solid #444;")
        header.setFixedHeight(34)
        h = QHBoxLayout(header)
        h.setContentsMargins(8, 4, 8, 4)
        h.setSpacing(8)

        title = QLabel("Graph Skeleton")
        title.setStyleSheet("color: #FFD700; font-weight: bold;")
        h.addWidget(title)
        h.addStretch()

        self.graph_label_toggle = QPushButton("Labels: OFF")
        self.graph_label_toggle.setCheckable(True)
        self.graph_label_toggle.setChecked(False)
        self.graph_label_toggle.setFixedWidth(110)
        self.graph_label_toggle.setStyleSheet("""
            QPushButton { background: #333; color: #ccc; border: 1px solid #555;
                          border-radius: 3px; padding: 3px 8px; font-size: 11px; }
            QPushButton:checked { background: #2E7D32; color: white;
                                  border: 1px solid #4CAF50; }
        """)
        self.graph_label_toggle.toggled.connect(self._on_graph_labels_toggled)
        h.addWidget(self.graph_label_toggle)

        v.addWidget(header)

        # The actual PyVista plotter
        self.graph_plotter = QtInteractor(wrapper)
        self.graph_plotter.set_background('black')
        self.graph_plotter.add_axes()
        v.addWidget(self.graph_plotter, 1)

        # Floating detail panel — sits on top of the plotter, hidden until
        # a node/connection is clicked. Click-outside closes it.
        self.graph_detail_panel = QFrame(wrapper)
        self.graph_detail_panel.setStyleSheet("""
            QFrame {
                background: rgba(20, 20, 20, 235);
                border: 2px solid #FFD700;
                border-radius: 6px;
            }
            QLabel { color: #eee; }
        """)
        self.graph_detail_panel.setMinimumWidth(320)
        self.graph_detail_panel.setMaximumWidth(420)
        dp_layout = QVBoxLayout(self.graph_detail_panel)
        dp_layout.setContentsMargins(12, 10, 12, 10)
        dp_layout.setSpacing(6)

        dp_header = QHBoxLayout()
        self.graph_detail_title = QLabel("Details")
        self.graph_detail_title.setStyleSheet(
            "font-weight: bold; font-size: 13px; color: #FFD700;"
        )
        dp_header.addWidget(self.graph_detail_title)
        dp_header.addStretch()
        close_btn = QPushButton("×")
        close_btn.setFixedSize(22, 22)
        close_btn.setStyleSheet(
            "QPushButton { background: transparent; color: #ccc; "
            "border: none; font-size: 16px; font-weight: bold; } "
            "QPushButton:hover { color: #FF3333; }"
        )
        close_btn.clicked.connect(self._hide_graph_detail_panel)
        dp_header.addWidget(close_btn)
        dp_layout.addLayout(dp_header)

        self.graph_detail_text = QLabel("")
        self.graph_detail_text.setWordWrap(True)
        self.graph_detail_text.setTextFormat(Qt.TextFormat.RichText)
        self.graph_detail_text.setStyleSheet(
            "font-family: Consolas, monospace; font-size: 11px; color: #ddd;"
        )
        self.graph_detail_text.setAlignment(
            Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft
        )
        dp_layout.addWidget(self.graph_detail_text)

        self.graph_detail_panel.hide()
        # Make wrapper own the panel so we can position it absolutely later
        self._graph_skeleton_wrapper = wrapper

        return wrapper
    def on_visibility_changed(self, data, visible):
        dtype = data.get('type')
        
        if dtype == 'node':
            key = (data['graph_id'], data['node_id'])
            if visible:
                if key in self.hidden_nodes: self.hidden_nodes.remove(key)
            else:
                self.hidden_nodes.add(key)
                
        elif dtype == 'graph':
            gid = data['graph_id']
            if visible:
                if gid in self.hidden_graphs: self.hidden_graphs.remove(gid)
            else:
                self.hidden_graphs.add(gid)
        
        self.plot_neuron_points()
        self.plot_graph_skeleton()


    def plot_neuron_points(self):
        self.neuron_plotter.clear()
        legend_entries = []
        used_types = set()
        
        for graph in graph_list:
            if graph.graph_id in self.hidden_graphs:
                continue
                
            for node in graph.node_list:
                if (graph.graph_id, node.id) in self.hidden_nodes:
                    continue
                
                for i, pts in enumerate(node.positions):
                    if pts is None or len(pts) == 0: continue
                    neuron_type = node.neuron_models[i] if i < len(node.neuron_models) else "unknown"
                    color = get_neuron_color(neuron_type)
                    
                    if neuron_type not in used_types:
                        legend_entries.append([neuron_type, color])
                        used_types.add(neuron_type)
                        
                    point_cloud = pv.PolyData(pts)
                    self.neuron_plotter.add_mesh(point_cloud, color=color, point_size=10)
                    
        if legend_entries:
            self.neuron_plotter.add_legend(legend_entries, size=(0.12, 0.12), loc='upper right')
        self.neuron_plotter.update()
        
   

    def plot_graph_skeleton(self):

        self.graph_plotter.clear()
        
        self.skeleton_info_map = {}
        self.skeleton_label_actors = []  # actors that toggle with the label button
        self.highlighted_actor = None
        self.original_color = None
        self.original_opacity = None
        
        self.tooltip_actor = vtk.vtkTextActor()
        self.tooltip_actor.GetTextProperty().SetFontSize(14)
        self.tooltip_actor.GetTextProperty().SetColor(1.0, 1.0, 1.0) 
        self.tooltip_actor.GetTextProperty().SetBackgroundColor(0.0, 0.0, 0.0) 
        self.tooltip_actor.GetTextProperty().SetBackgroundOpacity(0.7)
        self.tooltip_actor.GetTextProperty().SetFontFamilyToArial()
        self.tooltip_actor.GetTextProperty().BoldOn()
        self.tooltip_actor.SetVisibility(False)
        self.graph_plotter.renderer.AddViewProp(self.tooltip_actor)
        
        node_map = {}
        for graph in graph_list:
            if graph.graph_id in self.hidden_graphs: continue
            for node in graph.node_list:
                node_map[(graph.graph_id, node.id)] = node

        import random
        import matplotlib.pyplot as plt

        labels_visible = (
            self.graph_label_toggle.isChecked()
            if hasattr(self, 'graph_label_toggle') else False
        )

        for graph in graph_list:
            if graph.graph_id in self.hidden_graphs: continue

            cmap = plt.get_cmap("tab20")
            rgba = cmap(graph.graph_id % 20)
            graph_node_color = rgba[:3] 

            # Optional: graph-name label, placed above the highest node of
            # the graph. Only added when label-toggle is on.
            if labels_visible and graph.node_list:
                node_centers = np.array([
                    nd.center_of_mass for nd in graph.node_list
                    if (graph.graph_id, nd.id) not in self.hidden_nodes
                ])
                if len(node_centers) > 0:
                    top_pt = node_centers.mean(axis=0).copy()
                    top_pt[2] = node_centers[:, 2].max() + 1.6
                    g_name = getattr(graph, 'graph_name', f'Graph_{graph.graph_id}')
                    try:
                        actor = self.graph_plotter.add_point_labels(
                            np.array([top_pt]),
                            [g_name],
                            font_size=14,
                            text_color="#FFD700",
                            point_color=None, point_size=0,
                            shape=None, shape_opacity=0.0,
                            show_points=False, always_visible=True,
                            pickable=False,
                            name=f"glabel_g{graph.graph_id}"
                        )
                        self.skeleton_label_actors.append(actor)
                    except Exception:
                        pass
            
            for node in graph.node_list:
                if (graph.graph_id, node.id) in self.hidden_nodes: continue

                center = np.array(node.center_of_mass)
                
                sphere = pv.Sphere(radius=0.6, center=center)
                node_actor = self.graph_plotter.add_mesh(
                    sphere,
                    color=graph_node_color,
                    opacity=0.9,
                    smooth_shading=True,
                    pickable=True
                )
                
                n_pops = len(node.population) if hasattr(node, 'population') and node.population else 0
                dev_count = len(node.devices) if hasattr(node, 'devices') else 0
                if not dev_count and 'devices' in node.parameters: dev_count = len(node.parameters['devices'])

                # Sum neuron count from populations (also if some are None)
                total_neurons = 0
                if hasattr(node, 'population') and node.population:
                    for pop in node.population:
                        if pop is not None:
                            try:
                                total_neurons += len(pop)
                            except (TypeError, AttributeError):
                                pass

                info_text = (f"NODE: {node.name}\n"
                             f"ID: {node.id} (Graph {graph.graph_id})\n"
                             f"Populations: {n_pops}\n"
                             f"Neurons: {total_neurons}\n"
                             f"Devices: {dev_count}\n"
                             f"Pos: {center.round(2)}")
                # Build a richer info dict for click-panel + plain text for hover
                self.skeleton_info_map[node_actor] = {
                    'kind': 'node',
                    'short': info_text,
                    'detail_html': self._format_node_detail_html(
                        graph, node, n_pops, total_neurons, dev_count, center
                    ),
                    'title': f"Node: {node.name}",
                }

                # Permanent label only when toggle is on. When off, no label
                # actor is created at all (cleaner than visibility hacks).
                if labels_visible:
                    label_text = f"{node.name}\n({total_neurons}n)"
                    label_pos = center + np.array([0.0, 0.0, 0.85])
                    try:
                        lbl_actor = self.graph_plotter.add_point_labels(
                            np.array([label_pos]), [label_text],
                            font_size=11,
                            text_color="white",
                            point_color=None,
                            point_size=0,
                            shape=None,
                            shape_opacity=0.0,
                            show_points=False,
                            always_visible=True,
                            pickable=False,
                            name=f"label_g{graph.graph_id}_n{node.id}"
                        )
                        self.skeleton_label_actors.append(lbl_actor)
                    except Exception:
                        try:
                            lbl_actor = self.graph_plotter.add_point_labels(
                                np.array([label_pos]), [label_text],
                                font_size=11, text_color="white",
                                show_points=False, always_visible=True
                            )
                            self.skeleton_label_actors.append(lbl_actor)
                        except Exception:
                            pass

                if dev_count > 0:
                    aura = pv.Sphere(radius=0.9, center=center)
                    self.graph_plotter.add_mesh(aura, color="#FFD700", opacity=0.15, pickable=False)

                if hasattr(node, 'connections') and node.connections:
                    # Group connections by (target_graph, target_node) so we
                    # can fan multiple connections out across distinct
                    # control-points instead of overlapping a single spline.
                    pair_buckets = {}
                    for conn in node.connections:
                        tgt_id = (
                            int(conn.get('target', {}).get('graph_id', -1)),
                            int(conn.get('target', {}).get('node_id', -1)),
                        )
                        pair_buckets.setdefault(tgt_id, []).append(conn)

                    for (tgt_gid, tgt_nid), conns_to_pair in pair_buckets.items():
                        if (tgt_gid, tgt_nid) not in node_map: continue
                        if tgt_gid in self.hidden_graphs: continue
                        if (tgt_gid, tgt_nid) in self.hidden_nodes: continue
                        target_node = node_map[(tgt_gid, tgt_nid)]

                        for conn_idx, conn in enumerate(conns_to_pair):
                            try:
                                self._draw_single_connection(
                                    graph, node, target_node, conn,
                                    conn_idx, len(conns_to_pair),
                                    tgt_gid, tgt_nid,
                                )
                            except Exception as e:
                                print(f"Error plotting connection: {e}")

        try:
            self.graph_plotter.iren.remove_observer(self._observer_tag)
        except: pass
        
        self._observer_tag = self.graph_plotter.iren.add_observer(
            "MouseMoveEvent", self._on_skeleton_hover
        )
        # Click handler for the detail panel
        try:
            self.graph_plotter.iren.remove_observer(self._click_observer_tag)
        except: pass
        self._click_observer_tag = self.graph_plotter.iren.add_observer(
            "LeftButtonPressEvent", self._on_skeleton_click
        )

        self.graph_plotter.reset_camera()
        self.graph_plotter.update()

    def _draw_single_connection(self, graph, node, target_node, conn,
                                 conn_idx, total_for_pair, tgt_gid, tgt_nid):
        """Draws ONE connection as its own spline+arrowhead. Multiple
        connections between the same node pair fan out across distinct
        control-points so they don't overlap. Each gets its own pickable
        hitbox so hover/click identifies that specific connection."""
        params = conn.get('params', {})
        weight = float(params.get('weight', 1.0))
        conn_name = conn.get('name', 'Connection')

        if weight > 0:
            edge_color = "#FF3333"
            conn_type = "Excitatory (+)"
        elif weight < 0:
            edge_color = "#3366FF"
            conn_type = "Inhibitory (-)"
        else:
            edge_color = "#888888"
            conn_type = "Silent (0)"

        start = np.array(node.center_of_mass)
        end = np.array(target_node.center_of_mass)

        delay_val = params.get('delay', '?')
        rule = params.get('rule', '?')
        p_val = params.get('p', None)
        src_pop = conn.get('source', {}).get('pop_id', '?')
        tgt_pop = conn.get('target', {}).get('pop_id', '?')
        synapse_model = params.get('synapse_model', '?')

        conn_short = (f"CONNECTION: {conn_name}\n"
                      f"Type: {conn_type}\n"
                      f"From: {node.name} (G{graph.graph_id} N{node.id} P{src_pop})\n"
                      f"To:   {target_node.name} (G{tgt_gid} N{tgt_nid} P{tgt_pop})\n"
                      f"Weight: {weight}\n"
                      f"Delay:  {delay_val} ms\n"
                      f"Model: {synapse_model}\n"
                      f"Rule:  {rule}" + (f" (p={p_val})" if p_val is not None else ""))

        conn_detail_html = self._format_connection_detail_html(
            conn_name, conn_type, edge_color,
            graph, node, src_pop,
            target_node, tgt_gid, tgt_nid, tgt_pop,
            weight, delay_val, synapse_model, rule, p_val,
            params, conn_idx, total_for_pair,
        )
        click_payload = {
            'kind': 'connection',
            'short': conn_short,
            'detail_html': conn_detail_html,
            'title': f"Connection: {conn_name}",
        }

        if node == target_node:
            # Self-loop: ring on top of the node, slight tilt per
            # conn_idx so multiple self-loops are visible.
            tilt_deg = 90 + (conn_idx - (total_for_pair - 1) / 2) * 10
            torus = pv.ParametricTorus(ringradius=0.7, crosssectionradius=0.07)
            try:
                torus.rotate_x(tilt_deg, inplace=True)
                torus.translate(start + np.array([0.0, 0.0, 0.65 + 0.15 * conn_idx]),
                                inplace=True)
            except TypeError:
                torus = torus.rotate_x(tilt_deg)
                torus = torus.translate(
                    start + np.array([0.0, 0.0, 0.65 + 0.15 * conn_idx])
                )
            actor_self = self.graph_plotter.add_mesh(
                torus, color=edge_color, opacity=0.85, pickable=True
            )
            self.skeleton_info_map[actor_self] = click_payload
            return

        # Fan-out: each connection gets a distinct control-point so multiple
        # parallel connections don't overlap. Offset is index-based, not
        # random, so re-renders are stable.
        mid_point = (start + end) / 2.0
        # Build an axis perpendicular to the edge direction to fan along
        edge_dir = end - start
        edge_len = np.linalg.norm(edge_dir)
        if edge_len < 1e-6:
            edge_dir_n = np.array([1.0, 0.0, 0.0])
        else:
            edge_dir_n = edge_dir / edge_len
        # Pick a stable perp axis — cross with world-up, fall back to X
        world_up = np.array([0.0, 0.0, 1.0])
        perp = np.cross(edge_dir_n, world_up)
        if np.linalg.norm(perp) < 1e-6:
            perp = np.cross(edge_dir_n, np.array([1.0, 0.0, 0.0]))
        perp = perp / max(np.linalg.norm(perp), 1e-6)

        # Spread angle around the mid-point, centered around 0
        if total_for_pair == 1:
            spread = np.array([0.0, 0.0, 1.2])  # single conn: small upward bow
        else:
            theta = (conn_idx / max(total_for_pair - 1, 1)) * np.pi - np.pi / 2
            radius_lift = 1.5 + 0.4 * total_for_pair
            spread = perp * np.cos(theta) * radius_lift + world_up * (
                np.sin(theta) * radius_lift * 0.4 + 0.6
            )
        control_point = mid_point + spread

        points = np.array([start, control_point, end])
        spline = pv.Spline(points, n_points=20)

        self.graph_plotter.add_mesh(
            spline, color=edge_color, line_width=2.0,
            render_lines_as_tubes=True, pickable=False
        )

        # Invisible thicker tube for picking
        hitbox = spline.tube(radius=0.25)
        actor_hitbox = self.graph_plotter.add_mesh(
            hitbox, color=edge_color, opacity=0.0, pickable=True
        )
        self.skeleton_info_map[actor_hitbox] = click_payload

        # Arrow head at the target end, offset along spline tangent
        last_pt = spline.points[-1]
        prev_pt = spline.points[-3]
        direction = last_pt - prev_pt
        norm = np.linalg.norm(direction)
        if norm > 0:
            direction /= norm
        cone_pos = end - (direction * 0.8)
        arrow_head = pv.Cone(
            center=cone_pos, direction=direction,
            height=0.5, radius=0.2, resolution=12
        )
        self.graph_plotter.add_mesh(arrow_head, color=edge_color, pickable=False)

    def _format_node_detail_html(self, graph, node, n_pops, total_neurons,
                                  dev_count, center):
        g_name = getattr(graph, 'graph_name', f'Graph_{graph.graph_id}')
        rows = [
            f"<b>Graph:</b> {g_name} (id={graph.graph_id})",
            f"<b>Node:</b> {node.name} (id={node.id})",
            f"<b>Populations:</b> {n_pops}",
            f"<b>Total neurons:</b> {total_neurons}",
            f"<b>Devices:</b> {dev_count}",
            f"<b>Center of mass:</b> [{center[0]:.2f}, {center[1]:.2f}, {center[2]:.2f}]",
        ]
        # Per-pop neuron model + count
        if hasattr(node, 'neuron_models') and node.neuron_models:
            rows.append("<br><b>Per-population:</b>")
            for i, model in enumerate(node.neuron_models):
                pop_n = 0
                if hasattr(node, 'population') and i < len(node.population):
                    p = node.population[i]
                    if p is not None:
                        try:
                            pop_n = len(p)
                        except Exception:
                            pop_n = 0
                rows.append(f"&nbsp;&nbsp;Pop {i}: {model} ({pop_n}n)")
        n_outgoing = len(node.connections) if hasattr(node, 'connections') else 0
        rows.append(f"<br><b>Outgoing connections:</b> {n_outgoing}")
        return "<br>".join(rows)

    def _format_connection_detail_html(self, conn_name, conn_type, edge_color,
                                        graph, src_node, src_pop,
                                        tgt_node, tgt_gid, tgt_nid, tgt_pop,
                                        weight, delay_val, synapse_model, rule,
                                        p_val, params, conn_idx, total_for_pair):
        g_name = getattr(graph, 'graph_name', f'Graph_{graph.graph_id}')
        type_html = f"<span style='color:{edge_color};'>{conn_type}</span>"
        rows = [
            f"<b>Name:</b> {conn_name}",
            f"<b>Type:</b> {type_html}",
            "",
            f"<b>From:</b> {src_node.name} (Pop {src_pop})",
            f"&nbsp;&nbsp;<i>Graph: {g_name} (id={graph.graph_id}), Node id={src_node.id}</i>",
            f"<b>To:</b> {tgt_node.name} (Pop {tgt_pop})",
            f"&nbsp;&nbsp;<i>Graph id={tgt_gid}, Node id={tgt_nid}</i>",
            "",
            f"<b>Weight:</b> {weight}",
            f"<b>Delay:</b> {delay_val} ms",
            f"<b>Synapse model:</b> {synapse_model}",
            f"<b>Rule:</b> {rule}" + (f" (p={p_val})" if p_val is not None else ""),
        ]
        # Append any additional params not covered above
        extras = {
            k: v for k, v in (params or {}).items()
            if k not in ('weight', 'delay', 'synapse_model', 'rule', 'p',
                         'allow_autapses', 'allow_multapses', 'receptor_type',
                         'use_spatial')
        }
        if extras:
            rows.append("")
            rows.append("<b>Extra synapse params:</b>")
            for k, v in extras.items():
                rows.append(f"&nbsp;&nbsp;{k} = {v}")
        if total_for_pair > 1:
            rows.append("")
            rows.append(
                f"<i>Connection {conn_idx + 1} of {total_for_pair} between this pair</i>"
            )
        return "<br>".join(rows)

    def _on_graph_labels_toggled(self, checked):
        """Re-renders the skeleton with or without labels."""
        if hasattr(self, 'graph_label_toggle'):
            self.graph_label_toggle.setText("Labels: ON" if checked else "Labels: OFF")
        # Easiest path: rebuild the skeleton (cheap for normal graph counts).
        if hasattr(self, 'graph_plotter') and hasattr(self, 'plot_graph_skeleton'):
            try:
                self.plot_graph_skeleton()
            except Exception as e:
                print(f"label toggle rebuild error: {e}")

    def _on_skeleton_click(self, interactor, event):
        """Click on a node/connection → show the detail panel. Click on
        empty space → hide it."""
        x, y = interactor.GetEventPosition()
        picker = vtk.vtkPropPicker()
        picker.Pick(x, y, 0, self.graph_plotter.renderer)
        actor = picker.GetActor()
        if actor and actor in self.skeleton_info_map:
            payload = self.skeleton_info_map[actor]
            if isinstance(payload, dict):
                self._show_graph_detail_panel(
                    payload.get('title', 'Details'),
                    payload.get('detail_html', payload.get('short', '')),
                )
            else:
                # Backward-compat: old code stored plain strings
                self._show_graph_detail_panel("Details", str(payload))
        else:
            self._hide_graph_detail_panel()

    def _show_graph_detail_panel(self, title, html_body):
        if not hasattr(self, 'graph_detail_panel'):
            return
        self.graph_detail_title.setText(title)
        self.graph_detail_text.setText(html_body)
        # Position the panel in the top-right corner of the wrapper
        wrapper = self._graph_skeleton_wrapper
        self.graph_detail_panel.adjustSize()
        pw = self.graph_detail_panel.sizeHint().width()
        # Anchor 12px from the right edge, 50px below the header
        x = max(10, wrapper.width() - pw - 12)
        y = 46
        self.graph_detail_panel.setGeometry(x, y, pw, self.graph_detail_panel.sizeHint().height())
        self.graph_detail_panel.raise_()
        self.graph_detail_panel.show()

    def _hide_graph_detail_panel(self):
        if hasattr(self, 'graph_detail_panel'):
            self.graph_detail_panel.hide()
    def _on_skeleton_hover(self, interactor, event):

        x, y = interactor.GetEventPosition()
        
        picker = vtk.vtkPropPicker()
        picker.Pick(x, y, 0, self.graph_plotter.renderer)
        actor = picker.GetActor()
        
        if self.highlighted_actor and self.highlighted_actor != actor:
            try:
                prop = self.highlighted_actor.GetProperty()
                if self.original_color: prop.SetColor(self.original_color)
                if self.original_opacity: prop.SetOpacity(self.original_opacity)
            except AttributeError: pass
            self.highlighted_actor = None
            self.tooltip_actor.SetVisibility(False)

        if actor and actor in self.skeleton_info_map:
            if self.highlighted_actor != actor:
                self.highlighted_actor = actor
                prop = actor.GetProperty()
                
                self.original_color = prop.GetColor()
                self.original_opacity = prop.GetOpacity()
                
                prop.SetColor(1.0, 1.0, 1.0)
                prop.SetOpacity(1.0)
                
                payload = self.skeleton_info_map[actor]
                # Tooltip uses the short plain-text form. Click-panel uses
                # the html form. For backward-compat, accept plain strings.
                if isinstance(payload, dict):
                    text_content = payload.get('short', '')
                else:
                    text_content = str(payload)
                self.tooltip_actor.SetInput(text_content)
                self.tooltip_actor.SetVisibility(True)
            
            self.tooltip_actor.SetPosition(x + 15, y + 10)
            
        else:
            self.tooltip_actor.SetVisibility(False)
        
        interactor.Render()

    def open_live_spectator(self):

        self._switch_main_view(1)
