"""NEST-Kernel: Reset, Neuaufbau und Prüfung der Populationen."""
from typing import Any, Dict

import nest
from PyQt6.QtCore import QTimer
from PyQt6.QtWidgets import QApplication, QMessageBox

from neuron_toolbox import clear_dopa_vt_cache
from neuroticks.core.connection_executor import ConnectionExecutor
from neuroticks.core.connection_store import (
    create_nest_connections_from_stored, safe_nest_reset_and_repopulate,
)
from neuroticks.state import graph_list
from neuroticks.utils.nest_helpers import _invalidate_nest_refs


class NestKernelMixin:
    """Kernel-Reset und Neuaufbau des Netzwerks."""

    def init_connection_system(self):

        self.connection_executor = ConnectionExecutor(self.graphs)
        
        if hasattr(self, 'connection_tool'):
            self.connection_tool.set_graphs(self.graphs)
    def safe_reset_kernel(self, enable_structural_plasticity=False):
         
        if hasattr(self, 'status_bar'):
            self.status_bar.set_status("Resetting NEST kernel...", color="#FF5722")
            QApplication.processEvents()
        
        stats = safe_nest_reset_and_repopulate(
            self.active_graphs,
            enable_structural_plasticity=enable_structural_plasticity,
            verbose=True
        )
        
        msg = (f"Reset complete: {stats['populations_created']} populations, "
               f"{stats['connections_created']} connections")
        
        if hasattr(self, 'status_bar'):
            self.status_bar.show_success(msg)
        
        if hasattr(self, 'update_visualizations'):
            self.update_visualizations()
        
        return stats


    def rebuild_node_with_new_polynomials(self, node_idx, polynomials):
        if not self.active_graphs:
            print("No active graphs to rebuild")
            return
        if hasattr(self, 'sim_timer'):
            self.sim_timer.stop()
        if hasattr(self, 'simulation_view'):
            self.simulation_view.stop_rendering_safe()
        graph = list(self.active_graphs.values())[-1]
        
        if node_idx >= len(graph.node_list):
            print(f"⚠ Node {node_idx} not found in graph")
            return
        
        node = graph.node_list[node_idx]
        
        print(f"Rebuilding Node {node_idx} with new polynomials...")
        
        encoded_polynoms_per_type = []
        for poly_dict in polynomials:
            if poly_dict and all(k in poly_dict for k in ['x', 'y', 'z']):
                encoded_polynoms_per_type.append([poly_dict['x'], poly_dict['y'], poly_dict['z']])
            else:
                encoded_polynoms_per_type.append([])
        
        node.parameters['encoded_polynoms_per_type'] = encoded_polynoms_per_type
        
        node.build()
        
        # Invalidate stale refs before ResetKernel
        if hasattr(self, 'sim_timer'):
            self.sim_timer.stop()
        self.live_recorders = []
        _invalidate_nest_refs(list(self.active_graphs.values()))
        
        nest.ResetKernel()
        
        # Drop dopa-VT cache: GIDs from the previous kernel are dead.
        
        clear_dopa_vt_cache()
        for g in self.active_graphs.values():
            for n in g.node_list:
                n.populate_node()
        
        self.update_visualizations()
        print(f"Node {node_idx} rebuilt successfully!")
    def toggle_structural_plasticity(self, enabled):
                
        if enabled:
            self.safe_reset_kernel(enable_structural_plasticity=True)
        else:
            self.safe_reset_kernel(enable_structural_plasticity=False)
    
    def manual_nest_reset(self):
        from PyQt6.QtWidgets import QMessageBox
        
        reply = QMessageBox.question(
            self,
            'Reset NEST Kernel',
            'This will reset NEST and repopulate all graphs.\n\nContinue?',
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        
        if reply == QMessageBox.StandardButton.Yes:
            self.status_bar.set_status("Resetting NEST...", color="#1976D2")
            self.status_bar.set_progress(0)
            QApplication.processEvents()
            
            print("\nManual NEST Reset...")

            # RetinaTestTab informieren dass seine NodeCollections jetzt tot sind
            # (und den virtual_graph aus graph_list entfernen BEVOR repopulate laeuft).
            if hasattr(self, 'retina_test_tab') and self.retina_test_tab is not None:
                try:
                    self.retina_test_tab.on_nest_kernel_reset()
                except Exception as _e:
                    print(f"retina_test_tab.on_nest_kernel_reset error: {_e}")

            # Invalidate stale NodeCollection refs before ResetKernel
            if hasattr(self, 'sim_timer'):
                self.sim_timer.stop()
            self.live_recorders = []
            _invalidate_nest_refs(graph_list)
            
            nest.ResetKernel()
            
            # Drop dopa-VT cache: GIDs from the previous kernel are dead.
            
            clear_dopa_vt_cache()
            self.status_bar.set_progress(30)
            QApplication.processEvents()
            
            if self.structural_plasticity_enabled:
                nest.EnableStructuralPlasticity()
            else:
                nest.DisableStructuralPlasticity()
            
            if graph_list:
                total_graphs = len(graph_list)
                for i, graph in enumerate(graph_list):
                    self.status_bar.set_status(f"Repopulating graph {i+1}/{total_graphs}...", color="#1976D2")
                    self.status_bar.set_progress(30 + int(50 * (i+1) / total_graphs))
                    QApplication.processEvents()
                    
                    for node in graph.node_list:
                        node.populate_node()
                
                self.status_bar.set_status("Updating visualizations...", color="#1976D2")
                self.status_bar.set_progress(90)
                QApplication.processEvents()
                
                self.update_visualizations()
                self.graph_overview.update_tree()

            if hasattr(self, 'simulation_view'):
                self.simulation_view.restore_injectors()
            
            self.status_bar.show_success("NEST Reset complete!")
    

    def verify_nest_populations(self):
        print("VERIFYING NEST POPULATIONS")
        
        all_ok = True
        
        for graph in graph_list:
            graph_name = getattr(graph, 'graph_name', f'Graph {graph.graph_id}')
            print(f"\n{graph_name} (ID: {graph.graph_id})")
            
            for node in graph.node_list:
                node_name = getattr(node, 'name', 'Unnamed')
                
                if not hasattr(node, 'population') or not node.population:
                    print(f" {node_name}: No NEST population")
                    all_ok = False
                    continue
                
                try:
                    total_neurons = 0
                    for pop_idx, nest_pop in enumerate(node.population):
                        if nest_pop is None or len(nest_pop) == 0:
                            continue
                        
                        actual_pos = nest.GetPosition(nest_pop)
                        neuron_count = len(nest_pop)
                        total_neurons += neuron_count
                        
                        if len(actual_pos) != neuron_count:
                            print(f"{node_name} Pop{pop_idx}: Position mismatch")
                            all_ok = False
                        else:
                            print(f"{node_name} Pop{pop_idx}: {neuron_count} neurons spatial")
                    
                    if total_neurons == 0:
                        print(f"{node_name}: Total 0 neurons")
                        all_ok = False
                        
                except Exception as e:
                    print(f"{node_name}: {type(e).__name__}: {e}")
                    all_ok = False
        
        report = "All verified" if all_ok else "Issues found"
        
        
        return all_ok, report

    def reconnect_network(self):

        if not graph_list:
            self.status_bar.show_error("No graphs to reconnect!")
            return

        reply = QMessageBox.question(
            self,
            'Reconnect Network',
            'Reset NEST kernel and restore all connections?\n\n'
            '• Positions: KEPT (No WFC)\n'
            '• Neurons: Re-created\n'
            '• Connections: Re-connected',
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        
        if reply == QMessageBox.StandardButton.No:
            return


        self.status_bar.set_status("Resetting NEST & Reconnecting...", color="#00BCD4")
        self.status_bar.set_progress(10)
        QApplication.processEvents()

        try:
            graphs_dict = {g.graph_id: g for g in graph_list}

            stats = safe_nest_reset_and_repopulate(
                graphs_dict,
                enable_structural_plasticity=self.structural_plasticity_enabled,
                verbose=True
            )

            self.status_bar.set_status("Refreshing Views...", color="#00BCD4")
            self.status_bar.set_progress(90)
            QApplication.processEvents()

            self.update_visualizations()
            self.connection_tool.refresh()
            
            if hasattr(self, 'simulation_view'):
                self.simulation_view.restore_injectors()

            if hasattr(self, 'blink_widget'):
                self.blink_widget.build_scene()

            msg = (f"Reconnected! Created {stats['populations_created']} populations "
                   f"and {stats['connections_created']} connections.")
            
            if stats['connections_failed'] > 0:
                msg += f" (WARNING: {stats['connections_failed']} connections failed!)"
                self.status_bar.set_status(f"⚠ {msg}", color="#FF9800")
                QMessageBox.warning(self, "Reconnect Warning", msg)
            else:
                self.status_bar.show_success(msg)
            
            print(f"{msg}")

        except Exception as e:
            self.status_bar.show_error(f"Reconnect failed: {e}")
            print(f"Reconnect failed: {e}")
            import traceback
            traceback.print_exc()
            QMessageBox.critical(self, "Reconnect Error", str(e))


    def reset_and_restart(self, duration=None):
        print("\n=== RESETTING SIMULATION ===")
        if hasattr(self, 'sim_timer'):
            self.sim_timer.stop()
        
        self.current_nest_time = 0.0
        self.sim_target_time = 0.0

        
        self.current_nest_time = 0.0
        self.sim_target_time = 0.0
        self.sim_mode = 'step'
        
        try:
            self.status_bar.set_status("Resetting Kernel & Network...", "#E65100")
            QApplication.processEvents()
            
            if hasattr(self, 'simulation_view'):
                if hasattr(self.simulation_view, 'stop_rendering_safe'):
                    self.simulation_view.stop_rendering_safe()
                
                self.simulation_view.update_time_display(0.0)
                self.simulation_view.is_paused = True
                self.simulation_view.update_button_styles()

            # RetinaTestTab informieren BEVOR ResetKernel, damit es seinen State clearen
            # und den virtual_graph aus graph_list entfernen kann.
            if hasattr(self, 'retina_test_tab') and self.retina_test_tab is not None:
                try:
                    self.retina_test_tab.on_nest_kernel_reset()
                except Exception as _e:
                    print(f"retina_test_tab.on_nest_kernel_reset error: {_e}")

            # Invalidate stale NodeCollection refs before ResetKernel
            _invalidate_nest_refs(graph_list)

            nest.ResetKernel()

            # Drop dopa-VT cache: GIDs from the previous kernel are dead.

            clear_dopa_vt_cache()
            if self.structural_plasticity_enabled:
                nest.EnableStructuralPlasticity()
            self.current_nest_time = 0.0
            self.update_global_time_display(0.0)
            self._update_global_button_state('stopped')
            
            print("RESET COMPLETE: TIME 0.0")
            for graph in graph_list:
                for node in graph.node_list:
                    if not hasattr(node, 'positions') or not node.positions:
                        node.build()
                    node.populate_node()
            
            graphs_dict = {g.graph_id: g for g in graph_list}
            create_nest_connections_from_stored(graphs_dict, verbose=False)
            
            if self.main_stack.currentIndex() == 1 and hasattr(self, 'simulation_view'):
                self.simulation_view.load_scene()
                self.simulation_view.restore_injectors()
            
            self.live_recorders = []
            self._ensure_spike_recorders()
            
            if hasattr(self, 'live_dashboard'):
                self.live_dashboard.clear_all_data()
                
                QTimer.singleShot(200, self.live_dashboard.scan_for_devices)
                
            self.update_global_time_display(0.0)
            self._update_global_button_state('stopped')
            print("=== RESET COMPLETE: TIME 0.0 ===")
            
        except Exception as e:
            self.status_bar.show_error(f"Reset Failed: {e}")
            print(f"Reset Error: {e}")
            import traceback; traceback.print_exc()




    def rebuild_all_graphs(
            self,
            target_graphs=None,
            reset_nest: bool = True,
            rebuild_positions: bool = False,
            enable_structural_plasticity: bool = False,
            status_callback=None,
            verbose: bool = True
        ) -> Dict[str, Any]:
            
            graphs_to_process = graph_list
            
            if isinstance(target_graphs, list):
                graphs_to_process = target_graphs
            
            stats = {
                'graphs_rebuilt': 0,
                'nodes_rebuilt': 0,
                'populations_created': 0,
                'errors': []
            }
            
            if not graphs_to_process:
                if verbose:
                    print("No graphs to rebuild")
                return stats
            
            if verbose:

                print("REBUILD ALL GRAPHS")

            
            if reset_nest:
                if verbose:
                    print("\nResetting NEST kernel...")
                
                if hasattr(self, 'status_bar'):
                    self.status_bar.set_status("Resetting NEST kernel...", color="#FF5722")
                    self.status_bar.set_progress(5)
                    QApplication.processEvents()

                # Invalidate stale NodeCollection refs before ResetKernel
                if hasattr(self, 'sim_timer'):
                    self.sim_timer.stop()
                self.live_recorders = []
                _invalidate_nest_refs(graphs_to_process)

                nest.ResetKernel()

                # Drop dopa-VT cache: GIDs from the previous kernel are dead.

                clear_dopa_vt_cache()
                if enable_structural_plasticity:
                    try:
                        nest.EnableStructuralPlasticity()
                        if verbose:
                            print("✓ Structural plasticity enabled")
                    except Exception as e:
                        if verbose:
                            print(f"Could not enable structural plasticity: {e}")
            
            total_graphs = len(graphs_to_process)
            
            for g_idx, graph in enumerate(graphs_to_process):
                graph_name = getattr(graph, 'graph_name', f'Graph_{graph.graph_id}')
                
                if verbose:
                    print(f"\n[{g_idx+1}/{total_graphs}] Rebuilding '{graph_name}' (ID: {graph.graph_id})")
                
                if hasattr(self, 'status_bar'):
                    progress = 10 + int(80 * g_idx / total_graphs)
                    self.status_bar.set_status(f"Rebuilding {graph_name}...", color="#1976D2")
                    self.status_bar.set_progress(progress)
                    QApplication.processEvents()
                
                for n_idx, node in enumerate(graph.node_list):
                    node_name = getattr(node, 'name', f'Node_{node.id}')
                    
                    try:
                        if rebuild_positions:
                            if verbose:
                                print(f"Building Node {node.id}: {node_name}...")
                            node.build()
                        else:
                            if not hasattr(node, 'positions') or not node.positions:
                                node.build()
                            elif all(len(p) == 0 for p in node.positions if p is not None):
                                node.build()
                        
                        if verbose:
                            print(f"Populating Node {node.id}: {node_name}...")
                        node.populate_node()
                        
                        if hasattr(node, 'population') and node.population:
                            n_pops = len([p for p in node.population if p is not None and len(p) > 0])
                            stats['populations_created'] += n_pops
                        
                        stats['nodes_rebuilt'] += 1
                        
                    except Exception as e:
                        error_msg = f"Node {node.id} ({node_name}): {str(e)}"
                        stats['errors'].append(error_msg)
                        if verbose:
                            print(f" Error: {e}")
                
                stats['graphs_rebuilt'] += 1
            
            if verbose:
                print(f"   Rebuild complete!")
                print(f"   Graphs: {stats['graphs_rebuilt']}")
                print(f"   Nodes: {stats['nodes_rebuilt']}")
                print(f"   Populations: {stats['populations_created']}")
            
            if hasattr(self, 'status_bar'):
                self.status_bar.show_success(f"Rebuild complete! ({stats['populations_created']} pops created)")
            
            self.update_visualizations()
        
            if hasattr(self, 'simulation_view'):
                self.simulation_view.restore_injectors()
            return stats
