"""Live-Simulation: Timer, Start/Stop/Step, Recorder und Datenverteilung."""
from datetime import datetime

import nest
import numpy as np
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtWidgets import QApplication

from neuroticks.gui.dashboards.live_connection_controller import LiveConnectionController
from neuroticks.state import graph_list


class SimulationMixin:
    """Steuerung der laufenden NEST-Simulation."""

    def reset_from_live_dashboard(self, keep_data):
        print("Live Dashboard Reset triggered.")
        self.sim_timer.stop()
        
        if self.action_auto_save.isChecked():
            self.archive_live_data()
            
        self.reset_and_restart()
        self.simulation_view.update_time_display(0.0)
    def update_simulation_speed(self, value):
        
        delay = int((100 - value) * 2)
        
        if hasattr(self, 'sim_timer'):
            self.sim_timer.setInterval(delay)
    def update_simulation_target(self, new_duration):
        if hasattr(self, 'sim_timer') and self.sim_timer.isActive():
            self.sim_target_time = self.current_nest_time + new_duration
            print(f"  -> Target updated to {self.sim_target_time}ms")
        else:
            self.sim_target_time = new_duration


    def run_nest_simulation(self, duration):
        print(f"\n>>> STARTING LIVE SIMULATION (Duration: {duration} ms) <<<")
        self.status_bar.set_status("Simulation running...", color="#FF9800")
        
        self._ensure_spike_recorders()
        
        step_size = 25.0
        current_time = 0.0
        
        self._switch_main_view(1)
        
        try:
            while current_time < duration:
                self._simulate_step_and_update(step_size)
                current_time += step_size
                
                
                QApplication.processEvents()
                
                prog = int((current_time / duration) * 100)
                self.status_bar.set_progress(prog)
                
                if hasattr(self.simulation_view, 'is_paused') and self.simulation_view.is_paused:
                    break

            self.collect_simulation_results(duration)
            self.status_bar.show_success("Simulation finished.")
            self.sim_dashboard.btn_results.setEnabled(True)
            
        except Exception as e:
            self.status_bar.show_error(f"Simulation Error: {e}")
            print(f"Error: {e}")
            import traceback; traceback.print_exc()

    def _ensure_spike_recorders(self):
        self.live_recorders = []
        for graph in graph_list:
            # Skip virtuelle Graphs (RetinaTestTab hat eigene Recorder)
            if getattr(graph, 'is_virtual', False):
                continue
            for node in graph.node_list:
                if hasattr(node, 'devices'):
                    for dev in node.devices:
                        model = dev.get('model', '')
                        if 'recorder' in model or 'meter' in model:
                            gid = dev.get('runtime_gid')
                            if gid is not None:
                                # Keep as NodeCollection for nest.GetStatus compatibility
                                if not hasattr(gid, 'tolist') and not isinstance(gid, list):
                                    # It's a raw int - wrap it
                                    try:
                                        gid = nest.NodeCollection([int(gid)])
                                    except Exception:
                                        continue
                                if gid not in self.live_recorders:
                                    self.live_recorders.append(gid)
        non_spiking = [
            'siegert_neuron', 'mcculloch_pitts_neuron',
            'rate_neuron_ipn', 'rate_neuron_opn', 'gif_pop_psc_exp',
            'ht_neuron'
        ]
        
        for graph in graph_list:
            for node in graph.node_list:
                if hasattr(node, 'population'):
                    for pop_idx, pop in enumerate(node.population):
                        if pop is None: continue
                        
                        try:
                            model = nest.GetStatus(pop, 'model')[0]
                            if model in non_spiking:
                                continue
                            

                            if not hasattr(node, 'devices'): node.devices = []
                            if 'devices' not in node.parameters: node.parameters['devices'] = []
                            
                            existing = [d for d in node.devices if d.get('target_pop_id') == pop_idx and d.get('is_auto', False)]
                            
                            if existing:
                                rec_entry = existing[0]
                                rec = rec_entry.get('runtime_gid')

                                try:
                                    nest.GetStatus(rec) 
                                except:
                                    rec = None
                                    rec_entry['runtime_gid'] = None
                                
                                if rec:
                                    self.live_recorders.append(rec)
                                    continue

                            rec = nest.Create("spike_recorder")
                            nest.SetStatus(rec, {"record_to": "memory"})
                            nest.Connect(pop, rec)
                            self.live_recorders.append(rec)
                            
                            auto_device_entry = {
                                "id": f"auto_{graph.graph_id}_{node.id}_{pop_idx}", 
                                "model": "spike_recorder",
                                "target_pop_id": pop_idx,
                                "params": {"label": "auto_visual_recorder"},
                                "conn_params": {},
                                "runtime_gid": rec,
                                "is_auto": True 
                            }
                            
                            # FIX: Doppel-Append vermeiden bei shared list reference
                            if 'devices' not in node.parameters:
                                node.parameters['devices'] = []
                            node.parameters['devices'].append(auto_device_entry)
                            if node.devices is not node.parameters['devices']:
                                node.devices.append(auto_device_entry)
                            
                        except Exception as e:
                            print(f"Warning creating live recorder: {e}")
                            
        if hasattr(self, 'live_dashboard'):
            QTimer.singleShot(100, self.live_dashboard.scan_for_devices)

    def init_simulation_timer(self):
        self.sim_timer = QTimer()
        self.sim_timer.setTimerType(Qt.TimerType.PreciseTimer)
        self.sim_timer.timeout.connect(self.on_sim_timer_timeout)
        
        self.sim_mode = 'continuous'
        self.sim_target_time = 0.0
        self.current_nest_time = 0.0
        
        self.last_ui_update_realtime = 0.0
        
        if hasattr(self, 'simulation_view'):
            self.simulation_view.sigSpeedChanged.connect(self.update_simulation_speed)
        

    def _global_start(self):
        step = self.global_step_spin.value()
        self.start_continuous_simulation(step, max_duration=0)
        self._update_global_button_state('running')
    
    def _global_step(self):
        step = self.global_step_spin.value()
        self.step_simulation(step)
    
    def _global_pause(self):
        self.pause_simulation()
        self._update_global_button_state('paused')
    
    def _global_stop(self):
        self.stop_simulation()
        self._update_global_button_state('stopped')
    
    def _global_reset(self):
        self.reset_and_restart()
        self._update_global_button_state('stopped')
        self.global_time_label.setText("0.0 ms")
    
    def _update_global_button_state(self, state):
        base = "font-weight: bold; border-radius: 3px; padding: 5px 10px;"
        
        if state == 'running':
            self.global_btn_start.setEnabled(False)
            self.global_btn_start.setStyleSheet(f"{base} background-color: #1B5E20; color: #666;")
            self.global_btn_pause.setEnabled(True)
            self.global_btn_pause.setStyleSheet(f"{base} background-color: #FBC02D; color: black;")
        
        elif state == 'paused' or state == 'stopped':
            self.global_btn_start.setEnabled(True)
            self.global_btn_start.setStyleSheet(f"{base} background-color: #2E7D32; color: white;")
            self.global_btn_pause.setEnabled(False)
            self.global_btn_pause.setStyleSheet(f"{base} background-color: #555; color: #888;")
    
    def update_global_time_display(self, time_ms=None):
        if not hasattr(self, 'global_time_label'): return
        
        if time_ms is None:
            time_ms = self._get_nest_time()

        self.global_time_label.setText(f"{float(time_ms):.1f} ms")
        # Forciere UI-Repaint: setText + repaint() reicht in PyQt6 nicht
        # immer wenn der main-thread durch nest.Simulate blockiert wird.
        # processEvents() gibt Qt explizit Zeit zum painten.
        self.global_time_label.update()
        self.global_time_label.repaint()
        QApplication.processEvents()
    
    @staticmethod
    def _get_nest_time():
        """Liest die aktuelle NEST-Simulationszeit. NEST 3.x hat den Wert
        unter 'biological_time'; 'time' ist deprecated/leer und gibt 0.0
        zurück, was den Timer einfrieren ließ."""
        try:
            stat = nest.GetKernelStatus()
            return float(stat.get('biological_time', stat.get('time', 0.0)) or 0.0)
        except Exception:
            return 0.0
    
    def _simulate_step_and_update(self, step):
        """Wrapper um nest.Simulate(step) der den globalen Timer mit der
        akkumulierten Sim-Zeit aktualisiert. Jeder Pfad in Neuroticks der
        NEST live laufen lässt (continuous-loop, live-run, headless) sollte
        diesen Helper benutzen — sonst bleibt das global_time_label hängen
        UND der Eye-Tab bekommt keinen Frame-Takt.
        Reset auf 0 passiert ohnehin in reset_and_restart()."""
        # NEST akzeptiert nur Vielfache der Kernel-Resolution. Den Spinner-
        # Wert darauf snappen, sonst crasht nest.Simulate() z.B. bei 0.15ms
        # auf einem 0.1ms-Kernel ("not a multiple of resolution"). Mindestens
        # 1 Resolution-Step.
        try:
            res = float(nest.GetKernelStatus('resolution')) or 0.1
        except Exception:
            res = 0.1
        snapped = max(1, round(float(step) / res)) * res

        # Eye-Tab VOR dem Simulate: ggf. das nächste Video-Frame in die
        # Retina feeden, damit der Input zum Bio-Zeitfenster dieses Steps
        # passt. No-op wenn kein Tab / kein Video / nicht armed.
        self._drive_retina_tab('on_global_tick', snapped)

        nest.Simulate(snapped)

        # Eye-Tab NACH dem Simulate: Tab-eigene UI (Frame-Index, Preview).
        self._drive_retina_tab('on_after_global_tick')

        # NEST-Zeit auslesen + lokale Akkumulation als Backup. Der Zeitmesser
        # wächst additiv um exakt den (gesnappten) Step pro Simulation-Step.
        local_t = float(getattr(self, 'current_nest_time', 0.0)) + snapped
        nest_t = self._get_nest_time()
        self.current_nest_time = max(local_t, nest_t)
        self.update_global_time_display(self.current_nest_time)
        return self.current_nest_time

    def _drive_retina_tab(self, hook_name, *args):
        """Ruft einen Eye-Tab-Hook (on_global_tick / on_after_global_tick)
        auf, falls der Tab geladen ist und den Hook hat. Fehler im Tab
        dürfen die globale Sim-Loop NICHT killen — nur loggen."""
        tab = getattr(self, 'retina_test_tab', None)
        if tab is None:
            return
        hook = getattr(tab, hook_name, None)
        if hook is None:
            return
        try:
            hook(*args)
        except Exception as e:
            print(f"[retina {hook_name}] {e}")
    def update_simulation_speed(self, slider_value):
        if hasattr(self, 'sim_timer'):
            self.sim_timer.setInterval(slider_value)


    def start_continuous_simulation(self, step_size, max_duration=None):

        step_val = self.global_step_spin.value()
        
        self.sim_mode = 'continuous'
        self.sim_step_size = step_val
        
        self.current_nest_time = self._get_nest_time()
        
        # Initiales Label-Update damit User sieht von wo wir starten
        self.update_global_time_display(self.current_nest_time)
            
        print(f"Starting Continuous Run from {self.current_nest_time} ms")

        self.sim_target_time = float('inf')
        
        if max_duration is not None and max_duration > 0:
             self.sim_target_time = self.current_nest_time + max_duration

        self.status_bar.set_status("Running...", "#2E7D32")
        self._ensure_spike_recorders()

        self.sim_timer.setSingleShot(False)
        
        if hasattr(self, 'simulation_view'):
            self.simulation_view.start_rendering()
            
        self.sim_timer.start(0)


    def step_simulation(self, step_size):
        print(f"Executing Single Step ({step_size}ms)")
        self.sim_mode = 'step'
        self.sim_step_size = step_size
        
        self.sim_timer.setSingleShot(True)
        self._ensure_spike_recorders()
        self.sim_timer.start(0)


    def pause_simulation(self):
        print("Simulation Paused")
        self.sim_timer.stop()
        self.status_bar.set_status("Paused", "#FBC02D")
        
        if hasattr(self, 'simulation_view'):
            self.simulation_view.stop_rendering_safe()
        
        self._update_global_button_state('paused')

    def stop_simulation(self):
        print("Simulation Stopped")
        self.sim_timer.stop()
        self.collect_simulation_results(0)
        self.status_bar.set_status("Stopped", "#D32F2F")
        
        if hasattr(self, 'simulation_view'):
            self.simulation_view.stop_rendering_safe()
            
        self._update_global_button_state('stopped')

    


    def on_live_weight_change(self, conn_data, new_weight):
        success = LiveConnectionController.set_weight(graph_list, conn_data, new_weight)
        
        if success:
            src_gid = conn_data['source']['graph_id']
            src_nid = conn_data['source']['node_id']
            conn_id = conn_data.get('id')
            
            target_graph = next((g for g in graph_list if g.graph_id == src_gid), None)
            if target_graph:
                node = target_graph.get_node(src_nid)
                if node and hasattr(node, 'connections'):
                    for c in node.connections:
                        if c.get('id') == conn_id:
                            c['params']['weight'] = new_weight
                            if new_weight == 0.0:
                                if "(Severed)" not in c.get('name', ''):
                                    c['name'] = f"{c.get('name','Conn')} (Severed)"
                            else:
                                c['name'] = c.get('name', 'Conn').replace(" (Severed)", "")
                            break
            
            self.graph_overview.update_tree()
            self.status_bar.show_success(f"Connection weight set to {new_weight} (Live).")
        else:
            self.status_bar.show_error("Live update failed (Simulation running?)")


    def on_sim_timer_timeout(self):
        try:
            # Step LIVE vom Spinner lesen → Tweaken während des Runs wirkt
            # sofort (vorher wurde sim_step_size nur einmal beim Start
            # gecached, der Slider war damit faktisch tot). Single-Step setzt
            # denselben Spinner-Wert in step_simulation(), bleibt konsistent.
            if hasattr(self, 'global_step_spin'):
                self.sim_step_size = float(self.global_step_spin.value())

            if self.sim_mode == 'continuous' and self.sim_target_time != float('inf'):
                remaining = self.sim_target_time - self.current_nest_time
                if remaining <= 0.0001:
                    self.pause_simulation()
                    self.update_global_time_display(self.current_nest_time)
                    self.status_bar.show_success(f"Target reached ({self.current_nest_time:.1f}ms).")
                    return
                step_to_take = min(self.sim_step_size, remaining)
            else:
                step_to_take = self.sim_step_size

            self._simulate_step_and_update(step_to_take)
            self._distribute_simulation_data()
            QApplication.processEvents()
            
        except Exception as e:
            self.sim_timer.stop()
            self.status_bar.show_error(f"Sim Error: {e}")
            print(f"Sim Error: {e}")
            import traceback; traceback.print_exc()
 




    def _distribute_simulation_data(self):

        try:
            k_stat = nest.GetKernelStatus()
            sim_time = k_stat.get('time', k_stat.get('biological_time', 0.0))
        except:
            sim_time = 0.0

        visual_only = False
        if hasattr(self, 'simulation_view') and self.simulation_view.chk_visual_only.isChecked():
            visual_only = True

        all_events_cache = {}
        recorders_to_clear = []
        
        if hasattr(self, 'live_recorders') and self.live_recorders:
            for rec in self.live_recorders:
                try:
                    status = nest.GetStatus(rec)[0]
                    n_events = status.get('n_events', 0)
                    if n_events > 0:
                        events = status.get('events', {})
                        events_copy = {}
                        for k, v in events.items():
                            if hasattr(v, 'copy'):
                                events_copy[k] = v.copy()
                            elif hasattr(v, 'tolist'):
                                events_copy[k] = np.array(v)  
                            else:
                                events_copy[k] = v
                        
                        nest_id = rec.tolist()[0] if hasattr(rec, 'tolist') else int(rec[0]) if isinstance(rec, list) else int(rec)
                        all_events_cache[nest_id] = events_copy
                        recorders_to_clear.append(rec)
                except Exception:
                    pass

        if hasattr(self, 'simulation_view') and self.simulation_view.isVisible():
            visual_spikes_flat = []
            for nest_id, events in all_events_cache.items():
                if 'senders' in events:
                    senders = events['senders']
                    if hasattr(senders, 'tolist'):
                        visual_spikes_flat.extend(senders.tolist())
                    else:
                        visual_spikes_flat.extend(list(senders))
            
            if visual_spikes_flat:
                self.simulation_view.feed_spikes(visual_spikes_flat)

        QApplication.processEvents()


        for rec in recorders_to_clear:
            try:
                nest.SetStatus(rec, {'n_events': 0})
            except:
                pass

        if visual_only:
            return

        live_data_snapshot = {}
        has_dashboard_data = False
        
        graphs = getattr(self, 'active_graphs', {}).values()
        if not graphs: 
            graphs = graph_list

        process_counter = 0

        for graph in graphs:
            # Skip virtuelle Graphs (RetinaTestTab bewirtschaftet eigene Recorder)
            if getattr(graph, 'is_virtual', False):
                continue
            for node in graph.node_list:
                process_counter += 1
                if process_counter % 10 == 0:
                    QApplication.processEvents()

                if not hasattr(node, 'devices') or not node.devices:
                    continue

                # Safety-Net: results-Attribut sicherstellen
                if not hasattr(node, 'results') or node.results is None:
                    node.results = {}
                if "history" not in node.results:
                    node.results["history"] = []
                
                step_record = {
                    "time": sim_time,
                    "devices": {}
                }
                data_in_step = False

                for dev in node.devices:
                    gid = dev.get('runtime_gid')
                    dev_id = dev.get('id')
                    model = dev.get('model', '')
                    
                    if gid is None: 
                        continue
                    
                    try:
                        nest_id = gid
                        if isinstance(gid, list):
                            nest_id = gid[0]
                        elif hasattr(gid, 'tolist'):
                            nest_id = gid.tolist()[0]
                    except Exception:
                        continue  # Stale NodeCollection → skip

                    if "recorder" in model or "meter" in model:
                        if nest_id in all_events_cache:
                            events = all_events_cache[nest_id]
                            
                            clean_events = {}
                            for k, v in events.items():
                                if hasattr(v, 'tolist'): 
                                    clean_events[k] = v.tolist()
                                else: 
                                    clean_events[k] = list(v) if hasattr(v, '__iter__') else v
                            
                            step_record["devices"][str(dev_id)] = {
                                "type": model,
                                "events": clean_events
                            }
                            data_in_step = True
                            
                            live_data_snapshot[nest_id] = events
                            has_dashboard_data = True
                
                if data_in_step:
                    node.results["history"].append(step_record)

        if has_dashboard_data and hasattr(self, 'live_dashboard'):
            self.live_dashboard.process_incoming_data(live_data_snapshot, sim_time)
    
    def start_simulation(self):
        print("Simulation started (Not implemented yet)")
        self.status_bar.set_status("Simulation running...", color="#4CAF50")

    def stop_simulation(self):
        print("Simulation stopped")
        self.status_bar.set_status("Simulation stopped", color="#F44336")
    
    
    
    def collect_simulation_results(self, duration):
        print(f"\n>>> COLLECTING & FLUSHING DATA <<<")
        timestamp = datetime.now().isoformat()
        
        has_data = False
        
        for graph in graph_list:
            for node in graph.node_list:
                if "history" not in node.results:
                    node.results["history"] = []
                
                run_data = {
                    "timestamp": timestamp,
                    "devices": {}
                }
                
                if not hasattr(node, 'devices') or not node.devices:
                    continue

                for dev in node.devices:
                    gid = dev.get('runtime_gid')
                    dev_id = dev.get('id')
                    model = dev.get('model', '')
                    
                    if gid is None: continue
                    
                    if "recorder" in model or "meter" in model:
                        try:
                            status = nest.GetStatus(gid)[0]
                            events = status.get('events', {})
                            
                            n_events = status.get('n_events', 0)
                            if n_events == 0:
                                continue
                                
                            cleaned_events = {}
                            for k, v in events.items():
                                if isinstance(v, np.ndarray):
                                    cleaned_events[k] = v.tolist()
                                else:
                                    cleaned_events[k] = v
                            
                            run_data["devices"][dev_id] = {
                                "model": model,
                                "type": "recorder",
                                "data": cleaned_events
                            }
                            has_data = True
                            
                            nest.SetStatus(gid, {'n_events': 0})
                            print(f"  -> {model} (ID {dev_id}): Collected & Flushed {n_events} events.")
                            
                        except Exception as e:
                            print(f"Error collecting {model}: {e}")

                if run_data["devices"]:
                    node.results["history"].append(run_data)
        
        if has_data:
            print(">>> Data collection complete.")
            if hasattr(self, 'status_bar'):
                self.status_bar.show_success("Simulation data collected & flushed.")
