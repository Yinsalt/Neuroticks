"""Aufbau der Oberfläche: Menü, Bereiche, Ansichtswechsel."""
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QAction
from PyQt6.QtWidgets import (
    QDoubleSpinBox, QHBoxLayout, QLabel, QPushButton, QSizePolicy, QSlider, QStackedWidget,
    QVBoxLayout, QWidget,
)

from neuroticks.gui.dashboards.analysis_dashboard import AnalysisDashboard
from neuroticks.gui.dashboards.live_dashboard import LiveDataDashboard
from neuroticks.gui.dashboards.simulation_dashboard import SimulationDashboardWidget
from neuroticks.gui.main_window.examples_page import _ExamplesPage
from neuroticks.gui.main_window.widgets import MaximizableViewport, PreviewWidget, StatusBarWidget
from neuroticks.gui.tabs.history_browser import CustomTabWidget
from neuroticks.gui.tabs.sewing.tab import ExtraTabWidget
from neuroticks.gui.visualization.blinking_network import BlinkingNetworkWidget
from neuroticks.gui.visualization.flow_field import FlowFieldWidget
from neuroticks.gui.visualization.simulation_view import SimulationViewWidget
from neuroticks.gui.widgets.connection_editor import ConnectionEditorWidget
from neuroticks.gui.widgets.connection_tool import ConnectionTool
from neuroticks.gui.widgets.device_tools import DeviceConfigPage, ToolsWidget
from neuroticks.gui.widgets.graph_creator import GraphCreatorWidget
from neuroticks.gui.widgets.graph_editor import EditGraphWidget
from neuroticks.gui.widgets.graph_overview import GraphOverviewWidget
from neuroticks.gui.widgets.structures import StructuresWidget
from neuroticks.state import graph_list

# OtherTab is a user-editable sandbox in OtherTab.py. If the file is
# missing or has an error, fall back to a tiny placeholder so the app
# still starts.
try:
    from OtherTab import OtherTabWidget
    _OTHER_TAB_OK = True
except Exception as _other_err:
    print(f"OtherTab.py not loadable ({_other_err}); using placeholder.")
    _OTHER_TAB_OK = False

# Retina-Test-Tab (optional - fails gracefully if retina modules missing)
try:
    from neuroticks.gui.tabs.retina_test import RetinaTestTabWidget
    HAS_RETINA_TEST_TAB = True
except Exception as _retina_tab_err:
    HAS_RETINA_TEST_TAB = False
    print(f"[Main] RetinaTestTab nicht geladen: {_retina_tab_err}")


class LayoutMixin:
    """UI-Aufbau des Hauptfensters."""

    def create_menubar(self):
        menubar = self.menuBar()
        
        file_menu = menubar.addMenu("File")
        
        new_action = QAction("New Project", self)
        new_action.setShortcut("Ctrl+N")
        new_action.triggered.connect(self.new_project_dialog)
        file_menu.addAction(new_action)
        
        file_menu.addSeparator()
        
        # ── LOAD (kernel reset, replaces current session) ───────────
        load_action = QAction("Load Graph", self)
        load_action.setShortcut("Ctrl+O")
        load_action.triggered.connect(self.load_all_graphs_dialog)
        file_menu.addAction(load_action)
        
        file_menu.addSeparator()
        
        # ── SAVE (current session → file) ────────────────────────────
        save_fat_action = QAction("Save as Fat Graph", self)
        save_fat_action.setShortcut("Ctrl+S")
        save_fat_action.setStatusTip(
            "Save with positions. Larger file, exact reproduction."
        )
        save_fat_action.triggered.connect(self.save_all_graphs_dialog)
        file_menu.addAction(save_fat_action)
        
        save_thin_action = QAction("Save as Thin Graph", self)
        save_thin_action.setShortcut("Ctrl+Shift+S")
        save_thin_action.setStatusTip(
            "Save without positions (or WFC-only). Loader regenerates "
            "via build() — frees you from position-constraint editing."
        )
        save_thin_action.triggered.connect(self.save_thin_graphs_dialog)
        file_menu.addAction(save_thin_action)
        
        file_menu.addSeparator()
        
        # ── IMPORT (additive, no kernel reset) ───────────────────────
        import_fat_action = QAction("Import Fat Subgraph…", self)
        import_fat_action.setShortcut("Ctrl+I")
        import_fat_action.setStatusTip(
            "Append a graph file (with positions) to the current session. "
            "Full feature support (anisotropic / spatial / distance-dep). "
            "Auto-shifts graph_ids on collision."
        )
        import_fat_action.triggered.connect(self.merge_graphs_dialog)
        file_menu.addAction(import_fat_action)
        
        import_thin_action = QAction("Import Thin Subgraph…", self)
        import_thin_action.setShortcut("Ctrl+Shift+I")
        import_thin_action.setStatusTip(
            "Append a thin graph file (positions empty → rebuilt via "
            "build()) to the current session. Toolbox-based loader."
        )
        import_thin_action.triggered.connect(self.load_thin_graphs_dialog)
        file_menu.addAction(import_thin_action)
        
        file_menu.addSeparator()
        
        exit_action = QAction("Exit", self)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        settings_menu = menubar.addMenu("Settings")
        nest_menu = menubar.addMenu("NEST Settings")
        self.action_auto_save = QAction("Auto-Save Live History on Reset", self)
        self.action_auto_save.setCheckable(True)
        self.action_auto_save.setChecked(True)
        settings_menu.addAction(self.action_auto_save)
        self.plasticity_action = QAction("Structural Plasticity", self)
        self.plasticity_action.setCheckable(True)
        self.plasticity_action.setChecked(self.structural_plasticity_enabled)
        self.plasticity_action.triggered.connect(self.toggle_structural_plasticity)
        nest_menu.addAction(self.plasticity_action)
        
        nest_menu.addSeparator()
        
        reset_action = QAction("Reset NEST Kernel", self)
        reset_action.triggered.connect(self.manual_nest_reset)
        nest_menu.addAction(reset_action)
        
        view_menu = menubar.addMenu("View")
        refresh_action = QAction("Refresh Visualizations", self)
        refresh_action.triggered.connect(self.update_visualizations)
        view_menu.addAction(refresh_action)


    def setup_ui(self):
        central_widget = QWidget()
        central_widget.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setCentralWidget(central_widget)

        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)
        
        switch_bar = QWidget()
        switch_bar.setStyleSheet("background-color: #1a1a1a; border-bottom: 2px solid #333;")
        switch_bar.setFixedHeight(50)
        switch_layout = QHBoxLayout(switch_bar)
        switch_layout.setContentsMargins(10, 5, 10, 5)
        switch_layout.setSpacing(10)
        
        self.view_switch_style_active = "QPushButton { background-color: #2196F3; color: white; font-weight: bold; border: none; border-radius: 4px; padding: 10px 30px; font-size: 14px; } QPushButton:hover { background-color: #42A5F5; }"
        self.view_switch_style_inactive = "QPushButton { background-color: #333; color: #aaa; font-weight: bold; border: 1px solid #555; border-radius: 4px; padding: 10px 30px; font-size: 14px; } QPushButton:hover { background-color: #444; color: white; }"
        
        self.btn_view_editor = QPushButton("EDITOR")
        self.btn_view_simulation = QPushButton("INTERACTIVE")
        self.btn_view_data = QPushButton("LIVE PLOTS")
        self.btn_view_custom = QPushButton("HISTORY")
        self.btn_view_extra = QPushButton("FUSION TOOL") 
        self.btn_view_eye = QPushButton("EYE")
        for btn in [self.btn_view_editor, self.btn_view_simulation, self.btn_view_data, self.btn_view_custom, self.btn_view_extra, self.btn_view_eye]: 
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.setStyleSheet(self.view_switch_style_inactive)

        self.btn_view_editor.clicked.connect(lambda: self._switch_main_view(0))
        self.btn_view_simulation.clicked.connect(lambda: self._switch_main_view(1))
        self.btn_view_data.clicked.connect(lambda: self._switch_main_view(2))
        self.btn_view_custom.clicked.connect(lambda: self._switch_main_view(3))
        self.btn_view_extra.clicked.connect(lambda: self._switch_main_view(4))
        self.btn_view_eye.clicked.connect(lambda: self._switch_main_view(5))
        
        self.view_buttons = [
            self.btn_view_editor, 
            self.btn_view_simulation, 
            self.btn_view_data, 
            self.btn_view_custom,
            self.btn_view_extra,
            self.btn_view_eye,
        ]
        
        switch_layout.addWidget(self.btn_view_editor)
        switch_layout.addWidget(self.btn_view_simulation)
        switch_layout.addWidget(self.btn_view_data)
        switch_layout.addWidget(self.btn_view_custom)
        switch_layout.addWidget(self.btn_view_extra) 
        switch_layout.addWidget(self.btn_view_eye)

        self.global_sim_control = QWidget()
        self.global_sim_control.setStyleSheet("background-color: transparent;")
        gsc_layout = QHBoxLayout(self.global_sim_control)
        gsc_layout.setContentsMargins(0, 0, 0, 0)
        gsc_layout.setSpacing(8)
        
        self.global_btn_save_data = QPushButton("Save Data")
        self.global_btn_save_data.setCursor(Qt.CursorShape.PointingHandCursor)
        self.global_btn_save_data.setStyleSheet("""
            QPushButton { background-color: #00897B; color: white; font-weight: bold; border: 1px solid #00695C; border-radius: 3px; padding: 5px 10px; }
            QPushButton:hover { background-color: #26A69A; }
        """)
        self.global_btn_save_data.clicked.connect(self.manual_save_data_dialog)
        gsc_layout.addWidget(self.global_btn_save_data)

        lbl_step = QLabel("Res:"); lbl_step.setStyleSheet("color:#888;")
        self.global_step_spin = QDoubleSpinBox()
        self.global_step_spin.setRange(0.1, 1000)
        self.global_step_spin.setDecimals(2)
        self.global_step_spin.setSingleStep(0.1)
        self.global_step_spin.setValue(0.1)          # default = 1 NEST-Resolution-Step (zeitliches Mikroskop, max zoom)
        self.global_step_spin.setKeyboardTracking(True)  # Wert greift sofort beim Tippen, nicht erst bei Enter
        self.global_step_spin.setSuffix(" ms")
        self.global_step_spin.setToolTip(
            "Bio-Zeit pro Simulation-Step.\n"
            "0.10ms = feinste Auflösung (1 Resolution-Step pro Tick).\n"
            "Live tweakbar — wirkt sofort, auch während ein Run läuft."
        )
        self.global_step_spin.setFixedWidth(70); self.global_step_spin.setStyleSheet("background:#333; color:#00E5FF; border:1px solid #555;")
        
        self.global_time_label = QLabel("0.0 ms")
        self.global_time_label.setFixedWidth(180)
        self.global_time_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        self.global_time_label.setStyleSheet("background-color: #000; color: #00FF00; font-family: Consolas; font-size: 14px; font-weight: bold; border: 1px solid #444; padding: 2px;")
        
        btn_style = "font-weight: bold; border-radius: 3px; padding: 5px 10px;"
        
        self.global_btn_start = QPushButton("▶")
        self.global_btn_start.setToolTip("Run Continuous")
        self.global_btn_start.setStyleSheet(f"{btn_style} background-color: #2E7D32; color: white;")
        self.global_btn_start.clicked.connect(self._global_start)
        
        self.global_btn_pause = QPushButton("⏸")
        self.global_btn_pause.setStyleSheet(f"{btn_style} background-color: #FBC02D; color: black;")
        self.global_btn_pause.clicked.connect(self._global_pause)
        
        self.global_btn_reset = QPushButton("↺")
        self.global_btn_reset.setToolTip("Reset Kernel & Visuals")
        self.global_btn_reset.setStyleSheet(f"{btn_style} background-color: #E65100; color: white;")
        self.global_btn_reset.clicked.connect(self._global_reset)
        
        gsc_layout.addWidget(lbl_step)
        gsc_layout.addWidget(self.global_step_spin)
        gsc_layout.addWidget(self.global_time_label)
        gsc_layout.addWidget(self.global_btn_start)
        gsc_layout.addWidget(self.global_btn_pause)
        gsc_layout.addWidget(self.global_btn_reset)
        
        switch_layout.addWidget(self.global_sim_control)
        main_layout.addWidget(switch_bar)
        
        self.main_stack = QStackedWidget()
        self.editor_widget = self._create_editor_widget()
        self.simulation_view = SimulationViewWidget(graph_list, self)
        self.live_dashboard = LiveDataDashboard(graph_list, self)
        self.custom_tab = CustomTabWidget(graph_list, self)
        self.extra_tab = ExtraTabWidget(graph_list, self) 
        self.data_view = self._create_data_view() 
        self.main_stack.addWidget(self.editor_widget)   # Index 0
        self.main_stack.addWidget(self.simulation_view) # Index 1
        self.main_stack.addWidget(self.live_dashboard)  # Index 2
        self.main_stack.addWidget(self.custom_tab)      # Index 3
        self.main_stack.addWidget(self.extra_tab)       # Index 4 

        # Index 5: Retina-Test-Tab (falls ladbar)
        if HAS_RETINA_TEST_TAB:
            self.retina_test_tab = RetinaTestTabWidget(graph_list, main_window=self)
            self.retina_test_tab.requestVizRefresh.connect(self._on_retina_viz_refresh)
            self.retina_test_tab.retinaBuilt.connect(self._on_retina_viz_refresh)
            self.retina_test_tab.retinaDestroyed.connect(self._on_retina_viz_refresh)
            self.retina_test_tab.retinaBuilt.connect(self._on_retina_graphs_changed)
            self.retina_test_tab.retinaDestroyed.connect(self._on_retina_graphs_changed)
            self.main_stack.addWidget(self.retina_test_tab)
        else:
            self.retina_test_tab = None
            # Placeholder falls RetinaTestTab nicht geladen werden konnte
            _placeholder = QLabel("EYE tab unavailable - retina_main.py not found in PYTHONPATH")
            _placeholder.setAlignment(Qt.AlignmentFlag.AlignCenter)
            _placeholder.setStyleSheet("color: #888; font-size: 16px;")
            self.main_stack.addWidget(_placeholder)
        
        main_layout.addWidget(self.main_stack)

        self.update_visualizations()
        self.init_simulation_timer()
        self._update_global_button_state('stopped')  # FIX: Ensure buttons are in stopped state on startup
        self._switch_main_view(0)

    def _create_data_view(self):
        self.data_dashboard = AnalysisDashboard(graph_list)
        return self.data_dashboard
    
    
    
    def _switch_main_view(self, index):
        self.main_stack.setCurrentIndex(index)
        
        for i, btn in enumerate(self.view_buttons):
            if i == index:
                btn.setStyleSheet(self.view_switch_style_active)
            else:
                btn.setStyleSheet(self.view_switch_style_inactive)
        
        if index == 1:
            if hasattr(self, 'simulation_view') and self.simulation_view.scene_loaded:
                self.simulation_view.start_rendering()
        else:
            if hasattr(self, 'simulation_view'):
                self.simulation_view.stop_rendering_safe()
                
        if index == 2:
            if hasattr(self, 'live_dashboard'):
                self.live_dashboard.reload_and_center()
            
            if hasattr(self, 'data_dashboard'):
                self.data_dashboard.refresh_all_tabs()
                
        if index == 3:
            if hasattr(self, 'custom_tab'):
                self.custom_tab.on_tab_active()

        if index == 4:
            if hasattr(self, 'extra_tab'):
                self.extra_tab.on_tab_active()

        if index == 5:
            if hasattr(self, 'retina_test_tab') and self.retina_test_tab is not None:
                try:
                    self.retina_test_tab.on_tab_activated()
                except Exception as e:
                    print(f"retina_test_tab.on_tab_activated error: {e}")


    def _create_editor_widget(self):
        editor = QWidget()
        editor_layout = QVBoxLayout(editor)
        editor_layout.setContentsMargins(0, 0, 0, 0)
        editor_layout.setSpacing(0)

        # ─── Editor-View-Stack ───────────────────────────────────────
        # Slot 0: normales Layout (Sidebar, Top-Right-Panel, Bottom).
        # Slot 1: maximierter Viewport (eines der 4 Viz-Widgets fullscreen,
        #          mit Restore-Button rechts unten).
        # Beim Maximize wird das gewählte Viz-Widget aus self.vis_stack
        # rausgehoben und in Slot 1 reparented; beim Restore wieder
        # zurückgesteckt.
        self.editor_view_stack = QStackedWidget()

        # ── Slot 0: normaler Editor ──
        normal_view = QWidget()
        normal_layout = QVBoxLayout(normal_view)
        normal_layout.setContentsMargins(0, 0, 0, 0)
        normal_layout.setSpacing(0)

        top_layout = QHBoxLayout()
        top_left = self.create_top_left()
        self.graph_overview = GraphOverviewWidget(self, graph_list=graph_list)
        top_layout.addLayout(top_left, 7)
        top_layout.addWidget(self.graph_overview, 3)

        bottom_layout = QHBoxLayout()
        bottom_left = self.create_bottom_left()
        bottom_right = self.create_bottom_right()

        bottom_layout.addLayout(bottom_left, 7)
        bottom_layout.addLayout(bottom_right, 3)

        normal_layout.addLayout(top_layout, 3)
        normal_layout.addLayout(bottom_layout, 2)

        # ── Slot 1: maximierter Viewport (anfangs leer) ──
        # Bekommt beim Maximize das Viz-Widget reingesetzt.
        self.editor_max_slot = QWidget()
        self.editor_max_slot_layout = QVBoxLayout(self.editor_max_slot)
        self.editor_max_slot_layout.setContentsMargins(0, 0, 0, 0)
        self.editor_max_slot_layout.setSpacing(0)

        self.editor_view_stack.addWidget(normal_view)
        self.editor_view_stack.addWidget(self.editor_max_slot)

        editor_layout.addWidget(self.editor_view_stack)

        # State für das aktuell maximierte Viewport (None wenn nichts
        # maximiert).
        self._maximized_viewport = None

        return editor

    def _on_viz_toggle_maximize(self, viewport):
        """Behandelt Klicks auf den Maximize/Minimize-Button eines
        MaximizableViewport.

        Logik:
          - wenn nichts maximiert ist und ein Viewport will maximieren:
            den Viewport aus vis_stack rausnehmen, in den max_slot
            packen, editor_view_stack auf Slot 1 stellen.
          - wenn der gleiche Viewport schon maximiert ist (Klick auf
            Restore): rückwärts. Aus max_slot raus, zurück in vis_stack
            an die richtige Position, editor_view_stack auf Slot 0.
          - wenn ein ANDERER Viewport maximiert war: theoretisch
            unmöglich weil im max-Modus die Sidebar weg ist und kein
            anderer Button erreichbar — aber zur Sicherheit fangen
            wir's: erst alten restoren, dann neuen maximieren.
        """
        if not hasattr(self, 'editor_view_stack'):
            return

        # ── Restore-Pfad ──
        if self._maximized_viewport is viewport:
            self._restore_viewport()
            return

        # ── Falls schon was anderes maximiert ist, erst restoren ──
        if self._maximized_viewport is not None:
            self._restore_viewport()

        # ── Maximize ──
        # Index merken damit wir beim Restore an die richtige Stelle
        # zurückkommen — die Insert-Reihenfolge in vis_stack ist die
        # Index-Quelle für die Sidebar-Buttons (Neurons=0, Graph=1,
        # Firing=2, Flow=3).
        idx = self.vis_stack.indexOf(viewport)
        if idx < 0:
            return  # Viewport gehört nicht zum vis_stack — kein-Op.

        self._maximized_origin_index = idx

        # vis_stack.removeWidget reparented das Widget auf None und
        # markiert es als hidden. Direkt danach in den max_slot-Layout
        # packen UND explizit show() rufen — sonst bleibt das Viewport
        # unsichtbar (Stack-internes Hide-Flag wird durch addWidget
        # nicht zurückgesetzt).
        self.vis_stack.removeWidget(viewport)
        self.editor_max_slot_layout.addWidget(viewport)
        viewport.show()

        viewport.set_maximized_state(True)
        self.editor_view_stack.setCurrentIndex(1)
        self._maximized_viewport = viewport

    def _restore_viewport(self):
        """Hebt den maximierten Zustand auf — Viewport zurück in die
        Sidebar-Position, Editor zurück auf normales Layout."""
        viewport = self._maximized_viewport
        if viewport is None:
            return

        # Aus dem max_slot rausnehmen.
        self.editor_max_slot_layout.removeWidget(viewport)

        # An die ursprüngliche Index-Position zurück. insertWidget
        # akzeptiert auch Indizes am Ende ohne zu meckern, aber wir
        # nutzen den gemerkten Index. show() nochmal explizit, weil
        # removeWidget() oben das Hidden-Flag wieder setzt.
        idx = getattr(self, '_maximized_origin_index', -1)
        if idx < 0 or idx > self.vis_stack.count():
            self.vis_stack.addWidget(viewport)
        else:
            self.vis_stack.insertWidget(idx, viewport)
        viewport.show()

        viewport.set_maximized_state(False)
        self.editor_view_stack.setCurrentIndex(0)
        self._maximized_viewport = None
        self._maximized_origin_index = -1

        # Sidebar-Sync: das Sidebar-Switching benutzt setCurrentIndex
        # auf vis_stack. Wenn der maximiert-zurückgesteckte Viewport
        # nicht zufällig der zuletzt angezeigte war, will der User ihn
        # vermutlich gerade SEHEN (er hat ja gerade auf Restore geklickt).
        # Also bringen wir ihn nach vorne.
        self.vis_stack.setCurrentWidget(viewport)
        # Und passenden Sidebar-Button checken (Neurons=0..Flow=3
        # sind direkt indizes der nav_buttons).
        if hasattr(self, 'nav_buttons') and 0 <= idx < len(self.nav_buttons):
            for i, b in enumerate(self.nav_buttons):
                b.setChecked(i == idx)
  
    


    def create_top_left(self):
        layout = QHBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        scene_menu = QWidget()
        scene_menu.setStyleSheet("background-color: #2b2b2b;")
        
        scene_layout = QVBoxLayout()
        scene_layout.setContentsMargins(0, 0, 0, 0)
        scene_layout.setSpacing(0)
        
        nav_style = """
            QPushButton {
                background-color: #333;
                color: #aaa;
                border: 1px solid #444;
                border-radius: 0px;
                font-weight: bold;
                text-align: center;
                padding: 5px;
            }
            QPushButton:hover { 
                background-color: #444; 
                color: white;
                border: 1px solid #2196F3; 
            }
            QPushButton:checked { 
                background-color: #555; 
                color: white;
                border: 1px solid #2196F3;
                border-left: 4px solid #2196F3; 
            }
        """
        
        btn_neurons = QPushButton("Neurons")
        btn_graph = QPushButton("Graph")
        
        self.firing_patterns_container = QWidget()
        fp_layout = QVBoxLayout(self.firing_patterns_container)
        fp_layout.setContentsMargins(0, 0, 0, 0)
        fp_layout.setSpacing(0)
        
        btn_sim = QPushButton("Firing\nPatterns")
        
        self.slider_wrapper = QWidget()
        self.slider_wrapper.setStyleSheet("background-color: #3a3a3a; border-left: 4px solid #FFD700;")
        self.slider_wrapper.setVisible(False)
        slider_layout = QVBoxLayout(self.slider_wrapper)
        slider_layout.setContentsMargins(10, 5, 10, 10)
        
        lbl_slider = QLabel("Edge Opacity")
        lbl_slider.setStyleSheet("color: #ddd; font-size: 10px; font-weight: normal; border: none;")
        lbl_slider.setAlignment(Qt.AlignmentFlag.AlignLeft)
        
        self.opacity_slider = QSlider(Qt.Orientation.Horizontal)
        self.opacity_slider.setRange(0, 100)
        self.opacity_slider.setValue(30)
        self.opacity_slider.setStyleSheet("""
            QSlider::groove:horizontal {
                height: 4px;
                background: #555;
                border-radius: 2px;
            }
            QSlider::handle:horizontal {
                background: #FFD700;
                width: 12px;
                height: 12px;
                margin: -4px 0;
                border-radius: 6px;
            }
        """)
        self.opacity_slider.valueChanged.connect(self._on_opacity_changed)
        
        slider_layout.addWidget(lbl_slider)
        slider_layout.addWidget(self.opacity_slider)
        
        fp_layout.addWidget(btn_sim)
        fp_layout.addWidget(self.slider_wrapper)
        
        btn_flow = QPushButton("Positional\nFlowfield")
        btn_simulation = QPushButton("Simulation")
        btn_other = QPushButton("Other")
        
        all_nav_buttons = [btn_neurons, btn_graph, btn_sim, btn_flow, btn_simulation, btn_other]
        for btn in all_nav_buttons:
            btn.setStyleSheet(nav_style)
            btn.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
            btn.setCheckable(True)
        
        buttons_container = QWidget()
        buttons_layout = QVBoxLayout(buttons_container)
        buttons_layout.setContentsMargins(0, 0, 0, 0)
        buttons_layout.setSpacing(1)
        
        buttons_layout.addWidget(btn_neurons, 1)
        buttons_layout.addWidget(btn_graph, 1)
        buttons_layout.addWidget(self.firing_patterns_container, 1)
        buttons_layout.addWidget(btn_flow, 1)
        buttons_layout.addWidget(btn_simulation, 1)
        buttons_layout.addWidget(btn_other, 1)
        
        self.preview_widget = PreviewWidget()
        
        scene_layout.addWidget(buttons_container, 1)
        scene_layout.addWidget(self.preview_widget, 0)
        
        scene_menu.setLayout(scene_layout)
        
        self.vis_stack = QStackedWidget()
        
        self.neuron_plotter = self.create_neuron_visualization()
        # create_graph_visualization() sets self.graph_plotter (the
        # QtInteractor) internally and returns the wrapper widget that
        # contains the header + plotter + detail panel. We store the
        # wrapper separately so we don't overwrite self.graph_plotter.
        self.graph_skeleton_wrapper = self.create_graph_visualization()
        self.blink_widget = BlinkingNetworkWidget(graph_list)
        self.flow_widget = FlowFieldWidget(graph_list)

        # Die ersten vier Visualisierungen kriegen einen Maximize-
        # Wrapper. Die Sim-Dashboard- und Other-Tab-Slots nicht (kein
        # Bedarf, das sind Steuerflächen, kein Live-Viewport).
        self.viz_neurons    = MaximizableViewport(self.neuron_plotter)
        self.viz_graph      = MaximizableViewport(self.graph_skeleton_wrapper)
        self.viz_firing     = MaximizableViewport(self.blink_widget)
        self.viz_flow       = MaximizableViewport(self.flow_widget)

        for v in (self.viz_neurons, self.viz_graph,
                  self.viz_firing, self.viz_flow):
            v.sigToggleMaximize.connect(self._on_viz_toggle_maximize)

        self.vis_stack.addWidget(self.viz_neurons)
        self.vis_stack.addWidget(self.viz_graph)
        self.vis_stack.addWidget(self.viz_firing)
        self.vis_stack.addWidget(self.viz_flow)
        self.sim_dashboard = SimulationDashboardWidget(graph_list)
        
        self.sim_dashboard.requestStartSimulation.connect(self.start_headless_simulation)
        self.sim_dashboard.requestStopSimulation.connect(self.stop_headless_simulation)
        self.sim_dashboard.requestResetKernel.connect(self.manual_nest_reset)
        
        self.vis_stack.addWidget(self.sim_dashboard)
        if _OTHER_TAB_OK:
            self.other_tab = OtherTabWidget(graph_list=graph_list)
        else:
            self.other_tab = QLabel(
                "OtherTab.py konnte nicht geladen werden — "
                "siehe Konsole für Details."
            )
            self.other_tab.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self.other_tab.setStyleSheet(
                "background: #2a1a1a; color: #ff8888; font-size: 14px;"
            )
        self.vis_stack.addWidget(self.other_tab)
        
        self.nav_buttons = [btn_neurons, btn_graph, btn_sim, btn_flow, btn_simulation, btn_other]
        
        btn_neurons.clicked.connect(lambda: self._switch_view(0))
        btn_graph.clicked.connect(lambda: self._switch_view(1))
        btn_sim.clicked.connect(lambda: self._switch_view(2, sim_mode=True))
        btn_flow.clicked.connect(lambda: self._switch_view(3))
        btn_simulation.clicked.connect(lambda: self._switch_view(4))
        btn_other.clicked.connect(lambda: self._switch_view(5))
        
        btn_neurons.setChecked(True)
        
        layout.addWidget(scene_menu, 1)
        layout.addWidget(self.vis_stack, 9)
        
        return layout


    

    
        
    def _switch_view(self, index, sim_mode=False):
        # Wenn ein Viewport maximiert ist und der User über die Sidebar
        # auf einen anderen Viewport klickt: erst restoren, sonst zeigt
        # vis_stack den maximierten gar nicht (er hängt im max_slot).
        if (self._maximized_viewport is not None
                and getattr(self, '_maximized_origin_index', -1) != index):
            self._restore_viewport()

        self.vis_stack.setCurrentIndex(index)
        
        if index == 2:
            self.slider_wrapper.setVisible(True)
        else:
            self.slider_wrapper.setVisible(False)
            
        for i, btn in enumerate(self.nav_buttons):
            btn.setChecked(i == index)
        
        if index == 2:
            self.blink_widget.build_scene()
            if sim_mode:
                self.blink_widget.start_simulation()
            else:
                self.blink_widget.stop_simulation()
        else:
            self.blink_widget.stop_simulation()
            
        if index == 3:
            if hasattr(self, 'flow_widget'):
                if self.flow_widget.target_node_id is None and graph_list:
                    first_graph = graph_list[0]
                    if first_graph.node_list:
                        first_node = first_graph.node_list[0]
                        self.flow_widget.set_target_node(first_graph.graph_id, first_node.id)
                
                self.flow_widget.build_scene()
        if index == 4:
            self.sim_dashboard.refresh_data()

    def create_bottom_left(self):
        layout = QVBoxLayout()
        
        self.tool_stack = QStackedWidget()

        self.graph_builder = GraphCreatorWidget()
        self.graph_builder.graphCreated.connect(self.on_graph_created)
        self.tool_stack.addWidget(self.graph_builder)
        
        self.graph_editor = EditGraphWidget(graph_list=graph_list)
        self.graph_editor.graphUpdated.connect(self.on_graph_updated)
        self.tool_stack.addWidget(self.graph_editor)
        
        self.connection_tool = ConnectionTool(graph_list)
        
        self.connection_tool.connectionsCreated.connect(self.graph_overview.update_tree)
        self.connection_tool.connectionsCreated.connect(self.update_visualizations)
        
        self.tool_stack.addWidget(self.connection_tool)
        
        # Connection Editor — separate page for editing existing connections.
        # Routed to from the graph-overview when the user clicks an arrow.
        # Trigger network rebuild on update so NEST-side reflects the
        # changed synapse model / weight / spatial spec.
        self.connection_editor = ConnectionEditorWidget(graph_list=graph_list)
        self.connection_editor.connectionUpdated.connect(self._on_connection_edited)
        self.tool_stack.addWidget(self.connection_editor)
        
        # The "Population Examples" tab now hosts an Examples-folder browser.
        # The old StructuresWidget (cortical regions) is still instantiated
        # for backward compat (callers might use it via self.structures_widget)
        # but is not added to the tool_stack — its slot belongs to examples.
        self.structures_widget = StructuresWidget()
        self.structures_widget.structureSelected.connect(self.on_structure_selected)
        self.examples_widget = _ExamplesPage(main_window=self)
        self.tool_stack.addWidget(self.examples_widget)
        
        self.tools_widget = ToolsWidget()
        self.tools_widget.update_graphs(graph_list)
        self.tools_widget.deviceAdded.connect(self.graph_overview.update_tree)
        self.tools_widget.deviceAdded.connect(self.update_visualizations)
        
        for i in range(self.tools_widget.config_stack.count()):
            widget = self.tools_widget.config_stack.widget(i)
            if isinstance(widget, DeviceConfigPage):
                widget.deviceUpdated.connect(self.handle_device_update)

        self.tool_stack.addWidget(self.tools_widget)
        self.status_bar = StatusBarWidget()
        
        layout.addWidget(self.tool_stack, 9)
        layout.addWidget(self.status_bar, 1)
        
        self.graph_overview.node_selected.connect(self._on_overview_node_selected)
        self.graph_overview.device_selected.connect(self.on_device_tree_click)
        self.graph_overview.population_selected.connect(self._on_overview_pop_selected)
        self.graph_overview.connection_selected.connect(self._on_overview_conn_selected)
        self.graph_overview.requestConnectionCreation.connect(self.open_connection_tool_for_node)
        self.graph_overview.requestConnectionDeletion.connect(self.delete_connection_wrapper)
        
        self.graph_overview.requestDeviceDeletion.connect(self.delete_device_wrapper)
        self.graph_overview.requestLiveWeightChange.connect(self.on_live_weight_change)

        return layout

    def set_tool_page(self, index):
        """Zentrale Methode zum Wechseln der Tool-Seite mit Navigation-Sync."""
        self.tool_stack.setCurrentIndex(index)
        
        # Synchronisiere Navigation-Buttons
        if hasattr(self, 'nav_btns') and self.nav_btns:
            for i, btn in enumerate(self.nav_btns):
                if i == index:
                    btn.setStyleSheet(self.nav_active_style)
                else:
                    btn.setStyleSheet(self.nav_base_style)
    
    def _update_plotters_after_resize(self):
        try:
            for plotter_name in ['neuron_plotter', 'graph_plotter']:
                if hasattr(self, plotter_name):
                    plotter = getattr(self, plotter_name)
                    if plotter and hasattr(plotter, 'render_window') and plotter.render_window:
                        plotter.update()
            
            if hasattr(self, 'blink_widget') and self.blink_widget:
                if hasattr(self.blink_widget, 'plotter'):
                    if self.blink_widget.plotter and self.blink_widget.plotter.render_window:
                        self.blink_widget.plotter.update()
        except:
            pass

    def create_bottom_right(self):
        main_container = QWidget()
        main_container.setStyleSheet("background-color: #232323; border-left: 1px solid #444;")
        
        main_layout = QHBoxLayout(main_container)
        main_layout.setContentsMargins(15, 15, 15, 15)
        main_layout.setSpacing(15)

        self.nav_base_style = """
            QPushButton {
                background-color: #2b2b2b;
                color: #B0BEC5;
                border: 1px solid #37474F;
                border-radius: 6px;
                font-weight: bold;
                font-size: 13px;
                text-align: center;
                margin: 2px;
            }
            QPushButton:hover {
                background-color: #37474F;
                color: white;
            }
            QPushButton:pressed {
                background-color: #102027;
            }
        """

        self.nav_active_style = """
            QPushButton {
                background-color: #1c242b;
                color: #00E5FF;
                border: 2px solid #00E5FF; /* Neon Rand */
                border-radius: 6px;
                font-weight: bold;
                font-size: 13px;
                text-align: center;
                margin: 2px;
            }
        """

        action_btn_style = """
            QPushButton {
                background-color: #3E2723; color: #D7CCC8;
                border: 1px solid #5D4037; border-radius: 6px; font-weight: bold;
            }
            QPushButton:hover { background-color: #4E342E; border: 1px solid #8D6E63; color: white; }
        """
        
        io_btn_style = """
            QPushButton {
                background-color: #263238; color: #ECEFF1;
                border: 1px solid #455A64; border-radius: 6px; font-weight: bold;
            }
            QPushButton:hover { background-color: #37474F; border: 1px solid #607D8B; color: white; }
        """

        def create_header(text):
            lbl = QLabel(text)
            lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            lbl.setStyleSheet("color: #757575; font-weight: bold; font-size: 11px; letter-spacing: 2px; margin-bottom: 5px;")
            lbl.setFixedHeight(20)
            return lbl

        col1_layout = QVBoxLayout()
        col1_layout.setSpacing(5)
        col1_layout.addWidget(create_header("NAVIGATION"))
        
        self.nav_btns = []
        
        nav_items = [
            ("Network Builder", 0),
            ("Graph Inspector", 1),
            ("Connection Creator", 2),
            ("Connection Editor", 3),
            ("Population Examples", 4),
            ("Instrumentation", 5)
        ]

        for label, idx in nav_items:
            btn = QPushButton(label)
            btn.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
            
            btn.setStyleSheet(self.nav_base_style)
            
            btn.clicked.connect(lambda checked, i=idx: self.set_tool_page(i))
            
            self.nav_btns.append(btn)
            col1_layout.addWidget(btn)

        if self.nav_btns:
            self.nav_btns[0].setStyleSheet(self.nav_active_style)

        col2_layout = QVBoxLayout()
        col2_layout.setSpacing(5)
        col2_layout.addWidget(create_header("KERNEL"))
        
        ops_items = [
            ("Refresh Connectivity", self.reconnect_network),
            ("Reinstantiate Network", self.rebuild_all_graphs)
        ]
        
        for label, func in ops_items:
            btn = QPushButton(label)
            btn.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
            btn.setStyleSheet(action_btn_style)
            btn.clicked.connect(func)
            col2_layout.addWidget(btn)

        # ── GRAPH I/O column ─────────────────────────────────────────
        # Aufgespalten in 5 explizite Aktionen damit der Mental Model
        # klar ist:
        #   IMPORT (additiv)    : append an laufende Session, kein
        #                         Kernel-Reset, IDs werden automatisch
        #                         geshiftet wenn Kollision droht.
        #   LOAD                : ersetzt Session komplett (Kernel-Reset).
        #   SAVE THIN/FAT       : aktuelle Session → Datei.
        # Thin = ohne (oder nur WFC) Positionen, build() rekonstruiert.
        # Fat  = mit Positionen, exakte Reproduktion.
        col3_layout = QVBoxLayout()
        col3_layout.setSpacing(5)
        col3_layout.addWidget(create_header("GRAPH I/O"))
        
        # Distinct styles damit der User die drei Aktionsklassen optisch
        # unterscheidet (Import = additiv, Load = destruktiv, Save = output)
        import_btn_style = """
            QPushButton {
                background-color: #1B5E20; color: #C8E6C9;
                border: 1px solid #2E7D32; border-radius: 6px; font-weight: bold;
            }
            QPushButton:hover { background-color: #2E7D32; border: 1px solid #66BB6A; color: white; }
        """
        load_btn_style = """
            QPushButton {
                background-color: #4A148C; color: #E1BEE7;
                border: 1px solid #6A1B9A; border-radius: 6px; font-weight: bold;
            }
            QPushButton:hover { background-color: #6A1B9A; border: 1px solid #BA68C8; color: white; }
        """
        # io_btn_style is already defined above (used for Save buttons here)
        
        graph_io_items = [
            # (label, callback, style, tooltip)
            ("Import Thin Subgraph", self.load_thin_graphs_dialog, import_btn_style,
             "Append a thin graph (positions empty → rebuilt). Toolbox loader."),
            ("Import Fat Subgraph",  self.merge_graphs_dialog,      import_btn_style,
             "Append a fat graph (with positions). Full feature support."),
            ("Load Graph",           self.load_all_graphs_dialog,   load_btn_style,
             "Replace current session with a project file (kernel reset)."),
            ("Save as Thin Graph",   self.save_thin_graphs_dialog,  io_btn_style,
             "Save current session without positions (or WFC-only auto)."),
            ("Save as Fat Graph",    self.save_all_graphs_dialog,   io_btn_style,
             "Save current session with positions."),
        ]
        
        for label, func, style, tip in graph_io_items:
            btn = QPushButton(label)
            btn.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
            btn.setStyleSheet(style)
            btn.setToolTip(tip)
            btn.clicked.connect(func)
            col3_layout.addWidget(btn)

        # Stretch-Faktoren angepasst: GRAPH I/O hat jetzt 5 Buttons,
        # bekommt etwas mehr Platz.
        main_layout.addLayout(col1_layout, 4)
        main_layout.addLayout(col2_layout, 2)
        main_layout.addLayout(col3_layout, 4)

        wrapper_layout = QHBoxLayout()
        wrapper_layout.setContentsMargins(0,0,0,0)
        wrapper_layout.addWidget(main_container)
        
        return wrapper_layout
