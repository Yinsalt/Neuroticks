"""Projekt anlegen und Anwendung zurücksetzen."""
import nest
from PyQt6.QtWidgets import QApplication, QMessageBox

from neuron_toolbox import clear_dopa_vt_cache
from neuroticks import state
from neuroticks.state import graph_list


class ProjectMixin:
    """Neues Projekt / kompletter Reset."""

    def new_project_dialog(self):

        if graph_list:
            reply = QMessageBox.question(
                self,
                "New Project",
                "Do you want to save your changes before starting a new project?\n\n"
                "If you choose 'Discard', all current graphs and settings will be lost.",
                QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Discard | QMessageBox.StandardButton.Cancel
            )
            
            if reply == QMessageBox.StandardButton.Cancel:
                return
            
            if reply == QMessageBox.StandardButton.Save:
                self.save_all_graphs_dialog()
        
        self.reset_application()

    def reset_application(self):
        self.status_bar.set_status("Cleaning up for new project...", color="#FF5722")
        QApplication.processEvents()
        if hasattr(self, 'sim_timer'):
            self.sim_timer.stop()
        if hasattr(self, 'simulation_view'):
            self.simulation_view.stop_rendering_safe()
        
        try:
            global graph_list
            graph_list.clear()
            
            state.next_graph_id = 0
            state.graph_parameters.clear()
            if hasattr(self, 'tools_widget'):
                self.tools_widget.update_graphs(graph_list)
  
            
            print("Resetting NEST Kernel...")
            self.live_recorders = []
            nest.ResetKernel()
            # Drop dopa-VT cache: GIDs from the previous kernel are dead.
            clear_dopa_vt_cache()
            if self.structural_plasticity_enabled:
                nest.EnableStructuralPlasticity()
            
            self.active_graphs.clear()
            if hasattr(self, 'simulation_view') and self.simulation_view:
                self.simulation_view._initialized = False
            if hasattr(self, 'graph_builder'):
                self.graph_builder.reset()
            
            if hasattr(self, 'graph_editor'):
                self.graph_editor.current_graph = None
                self.graph_editor.current_graph_id = None
                self.graph_editor.node_list.clear()

                self.graph_editor.graph_name_input.clear()
                self.graph_editor.refresh_graph_list()
                
                while self.graph_editor.node_list_layout.count():
                    item = self.graph_editor.node_list_layout.takeAt(0)
                    if item.widget(): item.widget().deleteLater()
                while self.graph_editor.pop_list_layout.count():
                    item = self.graph_editor.pop_list_layout.takeAt(0)
                    if item.widget(): item.widget().deleteLater()
            
            if hasattr(self, 'connection_tool'):
                self.connection_tool.connections.clear()
                self.connection_tool.next_conn_id = 0
                self.connection_tool.update_connection_list()
                self.connection_tool.refresh()
            
            self.update_visualizations()
            
            if hasattr(self, 'graph_overview'):
                self.graph_overview.update_tree()
                
            if hasattr(self, 'blink_widget'):
                self.blink_widget.build_scene()
            
            self.status_bar.show_success("New Project created!")
            print("Application reset successful.")
            
        except Exception as e:
            self.status_bar.show_error(f"Error during reset: {e}")
            print(f"Reset Error: {e}")
            import traceback
            traceback.print_exc()
