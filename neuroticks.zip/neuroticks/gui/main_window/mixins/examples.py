"""Examples/-Ordner: scannen und Beispiele ins Projekt importieren."""
import copy

import numpy as np
from PyQt6.QtWidgets import QApplication

from neuron_toolbox import Graph
from neuroticks import state
from neuroticks.core.connection_executor import ConnectionExecutor
from neuroticks.gui.main_window.dialogs import _DisplacementDialog
from neuroticks.paths import PROJECT_ROOT
from neuroticks.state import graph_list


class ExamplesMixin:
    """Import von Beispiel-Projekten."""

    # ═══════════════════════════════════════════════════════════════
    #  EXAMPLES — Examples/ folder browser
    # ═══════════════════════════════════════════════════════════════

    def _examples_dir(self):
        """Return Path to the Examples/ folder. Create it if missing."""
        import os
        from pathlib import Path
        # Sit next to Main.py so it's portable across installs
        here = Path(PROJECT_ROOT)
        d = here / "Examples"
        try:
            d.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            print(f"Examples dir create failed: {e}")
        return d
    
    def _scan_examples(self):
        """
        Scan Examples/ for *.json files. Returns one entry per file:
            (filepath, display_label, graph_count)
        Files that don't parse or contain no graphs are skipped.
        Multi-graph files import as a bundle so cross-graph connections
        between them stay intact.
        """
        import json
        from pathlib import Path
        d = self._examples_dir()
        results = []
        if not d.exists():
            return results
        for fp in sorted(d.glob("*.json")):
            try:
                with open(fp, 'r', encoding='utf-8') as f:
                    data = json.load(f)
            except Exception:
                continue
            if not isinstance(data, dict):
                continue
            graphs = data.get('graphs')
            if isinstance(graphs, list) and graphs:
                results.append((str(fp), fp.stem, len(graphs)))
            elif 'graph' in data:
                # Single-graph format
                results.append((str(fp), fp.stem, 1))
        return results
    
    def _refresh_examples_buttons(self):
        """Tells the Examples page to re-scan the folder and rebuild buttons."""
        if hasattr(self, 'examples_widget') and self.examples_widget is not None:
            self.examples_widget.rebuild()
    
    def _on_example_clicked(self, filepath, display_label, graph_count):
        """Ask for a displacement, then import the entire file (all graphs
        with their cross-graph connections preserved) into the scene."""
        import os
        title = os.path.basename(filepath)
        dlg = _DisplacementDialog(
            f"{title} — {graph_count} graph(s)",
            parent=self,
        )
        if dlg.exec() != dlg.DialogCode.Accepted:
            return
        dx, dy, dz = dlg.get_displacement()
        try:
            self._import_example_file(filepath, np.array([dx, dy, dz], dtype=float))
        except Exception as e:
            self.status_bar.show_error(f"Example import failed: {e}")
            print(f"Example import failed: {e}")
            import traceback; traceback.print_exc()
    
    def _import_example_file(self, filepath, displacement):
        """
        Import ALL graphs in a file as a bundle, shifted by `displacement`.
        Cross-graph connections between graphs in the same file stay intact
        because every old graph_id is rewritten consistently to its new id.
        Cross-graph connections that pointed at IDs not contained in the
        file are left as-is (they would be dangling anyway and get pruned
        on reset).
        """
        import json
        import os
        with open(filepath, 'r', encoding='utf-8') as f:
            project_data = json.load(f)
        
        graphs_to_load = project_data.get('graphs', [])
        if not graphs_to_load and 'graph' in project_data:
            g_only = project_data['graph'].copy()
            g_only['nodes'] = project_data.get('nodes', [])
            graphs_to_load = [g_only]
        if not graphs_to_load:
            raise ValueError(f"No graphs in {os.path.basename(filepath)}")
        
        # Allocate consecutive new IDs for every graph in the file
        next_id = max((g.graph_id for g in graph_list), default=-1) + 1
        id_mapping = {}
        for i, g_data in enumerate(graphs_to_load):
            old_id = int(g_data.get('graph_id', i))
            id_mapping[old_id] = next_id + i
        
        self.status_bar.set_status(
            f"Importing {len(graphs_to_load)} graph(s) from "
            f"{os.path.basename(filepath)}...",
            color="#2E7D32",
        )
        QApplication.processEvents()
        
        new_graphs = []
        for g_data in graphs_to_load:
            old_id = int(g_data.get('graph_id', 0))
            new_graph_id = id_mapping[old_id]
            graph_name = g_data.get('graph_name', f'Imported_{new_graph_id}')
            
            # Shifted init position
            init_pos = np.array(g_data.get('init_position', [0, 0, 0]), dtype=float) + displacement
            
            graph = Graph(
                graph_name=graph_name,
                graph_id=new_graph_id,
                parameter_list=[],
                polynom_max_power=g_data.get('polynom_max_power', 5),
                polynom_decay=g_data.get('polynom_decay', 0.8),
                position=init_pos.tolist(),
                max_nodes=g_data.get('max_nodes', 100),
            )
            
            nodes_data = sorted(g_data.get('nodes', []), key=lambda x: x.get('id', 0))
            
            for nd in nodes_data:
                params = nd.get('parameters', {}).copy()
                params['id'] = nd.get('id', 0)
                params['name'] = nd.get('name', f"Node_{params['id']}")
                params['graph_id'] = new_graph_id
                
                if 'center_of_mass' in nd:
                    params['center_of_mass'] = (
                        np.array(nd['center_of_mass'], dtype=float) + displacement
                    )
                elif 'center_of_mass' in params:
                    params['center_of_mass'] = (
                        np.array(params['center_of_mass'], dtype=float) + displacement
                    )
                
                shifted_positions = None
                if nd.get('positions'):
                    shifted_positions = [
                        np.array(p, dtype=float) + displacement
                        for p in nd['positions']
                    ]
                
                # Rewrite graph_ids in connection source/target via id_mapping.
                # IDs not in the mapping (refs to graphs outside the file)
                # are kept as-is — they may be dangling and prune_dangling
                # will catch them on next reset.
                adjusted_connections = []
                for conn in nd.get('connections', []):
                    new_conn = copy.deepcopy(conn)
                    if 'source' in new_conn and new_conn['source']:
                        old_src = new_conn['source'].get('graph_id')
                        if old_src in id_mapping:
                            new_conn['source']['graph_id'] = id_mapping[old_src]
                    if 'target' in new_conn and new_conn['target']:
                        old_tgt = new_conn['target'].get('graph_id')
                        if old_tgt in id_mapping:
                            new_conn['target']['graph_id'] = id_mapping[old_tgt]
                    adjusted_connections.append(new_conn)
                params['connections'] = adjusted_connections
                
                cleaned_devices = []
                for dev in nd.get('devices', []):
                    d_copy = copy.deepcopy(dev)
                    d_copy['runtime_gid'] = None
                    cleaned_devices.append(d_copy)
                params['devices'] = cleaned_devices
                
                is_root = (nd.get('id', 0) == 0)
                parent_id = nd.get('parent_id')
                parent = graph.get_node(parent_id) if parent_id is not None else None
                
                new_node = graph.create_node(
                    parameters=params,
                    other=parent,
                    is_root=is_root,
                    auto_build=False,
                )
                
                if shifted_positions is not None:
                    new_node.positions = shifted_positions
                    if 'center_of_mass' in params:
                        new_node.center_of_mass = np.array(params['center_of_mass'], dtype=float)
                
                new_node.devices = cleaned_devices
                new_node.connections = adjusted_connections
                
                if 'neuron_models' in nd:
                    new_node.neuron_models = nd['neuron_models']
                if 'types' in nd:
                    new_node.types = nd['types']
                    new_node.population = [None] * len(nd['types'])
            
            # Intra-graph prev/next
            for nd in nodes_data:
                node = graph.get_node(nd.get('id'))
                if not node: continue
                for nid in nd.get('next_ids', []):
                    nxt = graph.get_node(nid)
                    if nxt and nxt not in node.next: node.next.append(nxt)
                for pid in nd.get('prev_ids', []):
                    prv = graph.get_node(pid)
                    if prv and prv not in node.prev: node.prev.append(prv)
            
            # Populate NEST
            for node in graph.node_list:
                if not hasattr(node, 'positions') or not node.positions:
                    node.build()
                elif all(len(p) == 0 for p in node.positions if p is not None):
                    node.build()
                node.populate_node()
            
            graph_list.append(graph)
            new_graphs.append(graph)
        
        state.next_graph_id = max(g.graph_id for g in graph_list) + 1
        
        # Cross-graph backref pass over EVERY graph (so backrefs work
        # both within the imported bundle and to existing graphs).
        global_lookup = {(g.graph_id, n.id): n for g in graph_list for n in g.node_list}
        for g in new_graphs:
            for node in g.node_list:
                for conn in node.connections or []:
                    tgt = conn.get('target', {}) or {}
                    tn = global_lookup.get((tgt.get('graph_id'), tgt.get('node_id')))
                    if tn is not None:
                        node.add_neighbor(tn)
        
        # Build NEST connections for all newly imported graphs
        graphs_dict = {g.graph_id: g for g in graph_list}
        executor = ConnectionExecutor(graphs_dict)
        all_new_conns = []
        for g in new_graphs:
            for n in g.node_list:
                if hasattr(n, 'connections'):
                    all_new_conns.extend(n.connections)
        success, fail, _ = executor.execute_all(all_new_conns)
        
        # Refresh UI
        if hasattr(self, 'tools_widget'):
            self.tools_widget.update_graphs(graph_list)
        self.update_visualizations()
        self.graph_overview.update_tree()
        if hasattr(self, 'connection_tool'):
            self.connection_tool.refresh()
        if hasattr(self, 'graph_editor'):
            self.graph_editor.refresh_graph_list()
        if hasattr(self, 'blink_widget'):
            self.blink_widget.build_scene()
        
        graph_names = ", ".join(g.graph_name for g in new_graphs)
        self.status_bar.show_success(
            f"Imported {len(new_graphs)} graph(s) [{graph_names}] — "
            f"{success} conns, {fail} failed"
        )
