"""Reaktionen auf Änderungen an Graphen, Verbindungen und Devices."""
import nest
from PyQt6.QtWidgets import QApplication

from neuron_toolbox import clear_dopa_vt_cache
from neuroticks.core.connection_store import (
    export_connections_to_dict, get_all_connections_summary, import_connections_from_dict,
)
from neuroticks.core.graph_builders import create_graph_from_widget
from neuroticks.state import graph_list
from neuroticks.utils.nest_helpers import _invalidate_nest_refs


class GraphEventsMixin:
    """Signal-Handler für Graph-, Verbindungs- und Device-Änderungen."""

    def on_graph_created(self, graph):

        self.graphs[graph.graph_id] = graph
        
        if hasattr(self, 'connection_tool'):
            self.connection_tool.set_graphs(self.graphs)
    
    def on_graph_deleted(self, graph_id):
        if graph_id in self.graphs:
            del self.graphs[graph_id]
        
        if hasattr(self, 'connection_tool'):
            self.connection_tool.set_graphs(self.graphs)
    
    def get_connection_summary(self):
        return get_all_connections_summary(self.graphs)
    
    def export_connections(self, filepath):
        import json
        
        connections = export_connections_to_dict(self.graphs)
        with open(filepath, 'w') as f:
            json.dump(connections, f, indent=2)
        
        return len(connections)
    
    def import_connections(self, filepath, clear_existing=True):
        import json
        
        with open(filepath, 'r') as f:
            connections = json.load(f)
        
        return import_connections_from_dict(self.graphs, connections, clear_existing)
    
    
    def update_visualizations(self):
        success, report = self.verify_nest_populations()
        
        if not success:
            print("\nWARNING: Some nodes have issues with NEST populations!")
        else:
            print("\nAll NEST populations verified successfully!")
        
        self.plot_neuron_points()
        self.plot_graph_skeleton()
        
        if hasattr(self, 'blink_widget'):
            print("Rebuilding Simulation Scene...")
            self.blink_widget.build_scene()
    def on_graph_updated(self, graph_id):
        if graph_id == -1:
            self.status_bar.set_status("Graph deleted, refreshing...", color="#1976D2")
            if hasattr(self, 'tools_widget'):
                self.tools_widget.update_graphs(graph_list)
        else:
            print(f"Graph {graph_id} updated, refreshing...")
            self.status_bar.set_status(f"Graph {graph_id} updated, refreshing...", color="#1976D2")
        
        self.status_bar.set_progress(50)
        QApplication.processEvents()
        
        self.update_visualizations()
        self.graph_overview.update_tree()
        self.connection_tool.refresh()
        self.status_bar.show_success("Changes saved!")

        QApplication.processEvents()
    
    def on_device_tree_click(self, device_data):
        self.set_tool_page(5)
        self.tools_widget.open_device_editor(device_data)
        self.status_bar.set_status(f"Editing Device: {device_data.get('model')}", "#FF9800")

    def handle_device_update(self, old_data, new_data):
        print("\n=== UPDATING DEVICE (In-Place) ===")
        
        if hasattr(self, 'sim_timer'):
            self.sim_timer.stop()
        self.live_recorders = []

        self.status_bar.set_status("Updating Device Params & Rebuilding...", "#FF5722")
        QApplication.processEvents()

        target = old_data.get('target', {})
        gid = target.get('graph_id')
        nid = target.get('node_id')
        old_id = old_data.get('id')
        
        target_graph = next((g for g in graph_list if g.graph_id == gid), None)
        
        updated = False
        
        if target_graph:
            node = target_graph.get_node(nid)
            if node:
                if hasattr(node, 'parameters') and 'devices' in node.parameters:
                    for dev_conf in node.parameters['devices']:
                        if str(dev_conf.get('id')) == str(old_id):
                            dev_conf['params'] = new_data['params']
                            dev_conf['conn_params'] = new_data.get('conn_params', {})
                            dev_conf['model'] = new_data.get('model', dev_conf['model'])
                            
                            dev_conf['runtime_gid'] = None
                            updated = True
                            print(f"  ✓ Device config {old_id} updated in-place.")
                            break
        
        if not updated:
            print("Error: Could not find device to update in parameters.")
            self.status_bar.show_error("Update failed: Device not found.")
            return

        print("Resetting Kernel...")
        # Invalidate stale refs before ResetKernel
        _invalidate_nest_refs(graph_list)
        
        nest.ResetKernel()
        
        # Drop dopa-VT cache: GIDs from the previous kernel are dead.
        
        clear_dopa_vt_cache()
        if self.structural_plasticity_enabled:
            nest.EnableStructuralPlasticity()
            
        self.rebuild_all_graphs(reset_nest=False, verbose=False)
        
        self.update_visualizations()
        self.graph_overview.update_tree()
        self.status_bar.show_success("Device updated successfully!")


    def delete_connection_wrapper(self, conn_data):
        from PyQt6.QtWidgets import QMessageBox
        
        name = conn_data.get('name', 'Connection')
        reply = QMessageBox.question(
            self,
            "Delete Connection",
            f"Are you sure you want to delete '{name}'?\n\nThis will trigger a graph rebuild.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        
        if reply == QMessageBox.StandardButton.Yes:
            self.set_tool_page(1)
            self.graph_editor.delete_connection_by_data(conn_data)
            self.status_bar.show_success(f"Connection '{name}' deleted.")
            self.update_visualizations()

    def _on_overview_node_selected(self, graph_id, node_id):
        
        self.set_tool_page(1)
        self.graph_editor.select_node_by_id(graph_id, node_id)
        
        if hasattr(self, 'flow_widget'):
            self.flow_widget.set_target_node(graph_id, node_id)
    def open_connection_tool_for_node(self, graph_id, node_id, pop_id=0):

        print(f"Context Menu Action: Setting Source to Graph {graph_id}, Node {node_id}, Pop {pop_id}")
        
        self.set_tool_page(2)
        
        self.connection_tool.refresh()
        
        self.connection_tool.set_source(graph_id, node_id, pop_id)
        
        self.status_bar.set_status(f"Source preset: G{graph_id} N{node_id} P{pop_id}", color="#2196F3")


    def _on_overview_pop_selected(self, graph_id, node_id, pop_id):
        self.set_tool_page(1)
        self.graph_editor.select_population_by_ids(graph_id, node_id, pop_id)


    def _on_overview_conn_selected(self, connection_data):
        # Open the standalone Connection Editor on tool-page 3.
        # Used to dispatch into Graph Inspector — that path got too crowded
        # so editing existing connections lives on its own page now.
        self.set_tool_page(3)
        self.connection_editor.load_connection(connection_data)
    
    def _on_connection_edited(self, conn_data):
        """Called when ConnectionEditor.apply_changes runs. Triggers a
        rebuild so NEST reflects the new synapse model / weight / spatial
        spec. Connection data is already mutated in place — we just need
        to invalidate the existing NEST projections and recreate them."""
        try:
            self.status_bar.set_status(
                f"Rebuilding network after connection edit: {conn_data.get('name','?')}",
                color="#673AB7",
            )
            QApplication.processEvents()
            # Full rebuild path — same one used after device updates.
            _invalidate_nest_refs(graph_list)
            nest.ResetKernel()
            # Drop dopa-VT cache: GIDs from the previous kernel are dead.
            clear_dopa_vt_cache()
            if getattr(self, 'structural_plasticity_enabled', False):
                try: nest.EnableStructuralPlasticity()
                except Exception: pass
            self.rebuild_all_graphs(reset_nest=False, verbose=False)
            self.update_visualizations()
            self.graph_overview.update_tree()
            self.status_bar.show_success("Connection updated.")
        except Exception as e:
            print(f"Rebuild after connection edit failed: {e}")
            self.status_bar.show_error("Rebuild failed; see console.")


    
    def on_structure_selected(self, name, models, probs):
        
        self.set_tool_page(0)
        
        self.graph_builder.load_structure_preset(name, models, probs, grid_size=[10, 10, 10])
        
        self.status_bar.show_success(f"Preset '{name}' loaded into Graph Creator.")
        print(f"Loaded Structure: {name} with {len(models)} populations.")






    def delete_device_wrapper(self, device_data):
        from PyQt6.QtWidgets import QMessageBox
        
        model = device_data.get('model', 'Device')
        dev_id = device_data.get('id')
        
        reply = QMessageBox.question(
            self,
            "Delete Device",
            f"Really delete {model} (ID: {dev_id})?\n\nThis will reset the kernel.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        
        if reply == QMessageBox.StandardButton.Yes:
            self.status_bar.set_status("Deleting device & Resetting...", "#FF5722")
            QApplication.processEvents()
            
            target = device_data.get('target', {})
            gid = target.get('graph_id')
            nid = target.get('node_id')
            
            target_graph = next((g for g in graph_list if g.graph_id == gid), None)
            if target_graph:
                node = target_graph.get_node(nid)
                if node:
                    if hasattr(node, 'devices'):
                        node.devices = [d for d in node.devices if str(d.get('id')) != str(dev_id)]
                    
                    if hasattr(node, 'parameters') and 'devices' in node.parameters:
                        node.parameters['devices'] = [d for d in node.parameters['devices'] if str(d.get('id')) != str(dev_id)]

            # FIX: Auch den Editor-State aktualisieren, sonst kommt das Device beim naechsten
            # save_changes zurueck (_build_node_params bevorzugt raw_params)
            if hasattr(self, 'graph_editor') and self.graph_editor.current_graph_id == gid:
                for nd in self.graph_editor.node_list:
                    if nd['params'].get('id') == nid:
                        devs = nd['params'].get('devices', [])
                        nd['params']['devices'] = [d for d in devs if str(d.get('id')) != str(dev_id)]
                        break

            self.manual_nest_reset()
            
            self.graph_overview.update_tree()
            self.status_bar.show_success(f"Device {dev_id} deleted.")
    
    def on_graph_created(self, graph_id):
        try:
            self.status_bar.set_status("Creating graph...", color="#1976D2")
            self.status_bar.set_progress(0, maximum=100)
            QApplication.processEvents()
        
            graph = create_graph_from_widget(graph_id)
            self.active_graphs[graph_id] = graph
            self.status_bar.set_progress(30)
            QApplication.processEvents()

            total_nodes = len(graph.node_list)
            for i, node in enumerate(graph.node_list):
                self.status_bar.set_status(f"Building node {i+1}/{total_nodes}...", color="#1976D2")
                self.status_bar.set_progress(30 + int(30 * (i+1) / total_nodes))
                QApplication.processEvents()
                
                if not hasattr(node, 'positions') or node.positions is None:
                    node.build()
                node.populate_node()

            self.status_bar.set_status("Updating visualizations...", color="#1976D2")
            self.status_bar.set_progress(80)
            QApplication.processEvents()
            
            self.update_visualizations()
            self.graph_overview.update_tree()
            
            self.connection_tool.refresh()
            
            self.graph_editor.refresh_graph_list()
            if hasattr(self, 'tools_widget'):
                self.tools_widget.update_graphs(graph_list)

            self.status_bar.show_success(f"Graph '{graph.graph_name}' created!")
            QApplication.processEvents()
            
        except Exception as e:
            self.status_bar.show_error(f"Failed to create graph: {e}")
            print(f"Error creating graph: {e}")
            import traceback
            traceback.print_exc()

    def _on_retina_graphs_changed(self):
        if hasattr(self, 'connection_tool'):
            self.connection_tool.refresh()                # Retina-Graph in Source/Target-Auswahl aufnehmen bzw. entfernen
