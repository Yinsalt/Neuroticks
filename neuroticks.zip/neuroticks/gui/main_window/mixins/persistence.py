"""Speichern, Laden und Zusammenführen von Projekten sowie Archivieren von Live-Daten."""
import copy
import json
from datetime import datetime
from pathlib import Path

import nest
import numpy as np
from PyQt6.QtWidgets import QApplication, QFileDialog, QInputDialog, QMessageBox

from neuron_toolbox import clear_dopa_vt_cache, Graph
from neuroticks import state
from neuroticks.core.connection_executor import ConnectionExecutor
from neuroticks.core.connection_store import create_nest_connections_from_stored
from neuroticks.gui.main_window.json_encoder import NumpyEncoder
from neuroticks.state import graph_list
from neuroticks.utils.nest_helpers import _invalidate_nest_refs
from neuroticks.utils.serialization import _clean_params, _serialize_connections


class PersistenceMixin:
    """Datei-Dialoge für Projekte und Simulationsdaten."""

    def manual_save_data_dialog(self):
        default_name = f"run_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        filename, ok = QInputDialog.getText(self, "Save Data", "Filename (without .json):", text=default_name)
        
        if ok and filename:
            if not filename.endswith('.json'):
                filename += ".json"
            self.archive_live_data(filename)





    def archive_live_data(self, custom_filename=None):

        print("Archiving Simulation Data...")
        try:
            raw_live_data = self.live_dashboard.get_all_data()
            
            if not raw_live_data:
                self.status_bar.show_error("No live data found to save.")
                return

            if custom_filename:
                filename = custom_filename
            else:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                filename = f"history_live_{timestamp}.json"
            
            if not filename.endswith('.json'):
                filename += '.json'
            
            output_dir = Path("Simulation_History")
            output_dir.mkdir(parents=True, exist_ok=True)
            filepath = output_dir / filename

            history_data = {
                'meta': {
                    'version': '3.0',
                    'type': 'neuroticks_history',
                    'timestamp': str(datetime.now()),
                },
                'graphs': []
            }

            total_measurements = 0

            for graph in graph_list:
                # Skip virtuelle Graphen (RetinaTestTab) im History-Export
                if getattr(graph, 'is_virtual', False):
                    continue
                g_data = {
                    'graph_id': graph.graph_id,
                    'graph_name': getattr(graph, 'graph_name', f'Graph_{graph.graph_id}'),
                    'nodes': []
                }

                for node in graph.node_list:
                    n_data = {
                        'id': node.id,
                        'name': node.name,
                        'neuron_models': getattr(node, 'neuron_models', []),
                        'types': getattr(node, 'types', []),
                        'devices': [],
                        'results': {
                            'history': []
                        }
                    }
                    
                    all_devices = getattr(node, 'devices', [])
                    if not all_devices and hasattr(node, 'parameters') and 'devices' in node.parameters:
                        all_devices = node.parameters['devices']
                    
                    run_entry = {'devices': {}}
                    
                    for dev in all_devices:
                        dev_id = dev.get('id', 0)
                        dev_model = dev.get('model', 'unknown')
                        runtime_gid = dev.get('runtime_gid')
                        
                        dev_config = dev.copy()
                        if 'runtime_gid' in dev_config:
                            del dev_config['runtime_gid']
                        if 'params' in dev_config:
                            dev_config['params'] = _clean_params(dev_config['params'])
                        n_data['devices'].append(dev_config)
                        
                        search_gid = None
                        if runtime_gid is not None:
                            try:
                                if hasattr(runtime_gid, 'tolist'):
                                    search_gid = runtime_gid.tolist()[0]
                                elif isinstance(runtime_gid, list):
                                    search_gid = runtime_gid[0]
                                else:
                                    search_gid = int(runtime_gid)
                            except:
                                pass
                        
                        if search_gid is not None and search_gid in raw_live_data:
                            rec_data = raw_live_data[search_gid]
                            
                            clean_data = {}
                            for k, v in rec_data.items():
                                if k == 'values' and isinstance(v, dict):
                                    for vk, vv in v.items():
                                        clean_data[vk] = vv.tolist() if hasattr(vv, 'tolist') else list(vv) if hasattr(vv, '__iter__') and not isinstance(vv, str) else vv
                                else:
                                    clean_data[k] = v.tolist() if hasattr(v, 'tolist') else v
                            
                            run_entry['devices'][str(dev_id)] = {
                                'model': dev_model,
                                'data': clean_data
                            }
                            total_measurements += 1
                    
                    if run_entry['devices']:
                        n_data['results']['history'].append(run_entry)
                    
                    g_data['nodes'].append(n_data)
                
                history_data['graphs'].append(g_data)

            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(history_data, f, cls=NumpyEncoder, indent=2)
                
            self.status_bar.show_success(f"Saved {total_measurements} device recordings to {filename}")
            print(f"Saved history with {total_measurements} device recordings.")
            
            if hasattr(self, 'custom_tab'):
                self.custom_tab.refresh_history_list()
            
        except Exception as e:
            print(f"Error archiving data: {e}")
            import traceback
            traceback.print_exc()
            self.status_bar.show_error(f"Save Error: {e}")
    


    def save_all_graphs_dialog(self):
        if not graph_list:
            QMessageBox.warning(self, "Save Error", "No graphs to save!")
            return

        filepath, _ = QFileDialog.getSaveFileName(
            self, "Save as Fat Graph", "", "JSON Files (*.json);;All Files (*)"
        )

        if filepath:
            if not filepath.endswith('.json'):
                filepath += '.json'
            
            try:
                project_data = {
                    'meta': {
                        'version': '2.1',
                        'type': 'neuroticks_project',
                        'timestamp': str(np.datetime64('now'))
                    },
                    'graphs': []
                }

                for graph in graph_list:
                    # Skip virtuelle Graphen (z.B. RetinaTestTab): nicht exportieren
                    if getattr(graph, 'is_virtual', False):
                        continue
                    nodes_data = []
                    for node in graph.node_list:
                        
                        cleaned_devices = []
                        source_devices = getattr(node, 'devices', [])
                        if not source_devices and 'devices' in node.parameters:
                            source_devices = node.parameters['devices']

                        for dev in source_devices:
                            dev_copy = dev.copy()
                            if 'runtime_gid' in dev_copy: del dev_copy['runtime_gid']
                            if 'params' in dev_copy: dev_copy['params'] = _clean_params(dev_copy['params'])
                            cleaned_devices.append(dev_copy)

                        safe_params = node.parameters.copy() if hasattr(node, 'parameters') else {}
                        if 'devices' in safe_params: del safe_params['devices']

                        parent_id = None
                        if hasattr(node, 'parent') and node.parent is not None:
                            parent_id = node.parent.id

                        node_data = {
                            'id': node.id,
                            'name': node.name,
                            'graph_id': graph.graph_id,
                            'parameters': _clean_params(safe_params),
                            
                            'positions': [pos.tolist() if isinstance(pos, np.ndarray) else list(pos)
                                          for pos in node.positions] if hasattr(node, 'positions') and node.positions else [],
                            'center_of_mass': list(node.center_of_mass) if hasattr(node, 'center_of_mass') else [0,0,0],
                            
                            'connections': _serialize_connections(node.connections) if hasattr(node, 'connections') else [],
                            'devices': cleaned_devices,
                            
                            'types': node.types if hasattr(node, 'types') else [],
                            'neuron_models': node.neuron_models if hasattr(node, 'neuron_models') else [],
                            'distribution': list(node.distribution) if hasattr(node, 'distribution') and node.distribution else [],
                            
                            'parent_id': parent_id,
                            'next_ids': [n.id for n in node.next] if hasattr(node, 'next') else [],
                            'prev_ids': [n.id for n in node.prev] if hasattr(node, 'prev') else [],
                        }
                        nodes_data.append(node_data)

                    graph_data = {
                        'graph_id': graph.graph_id,
                        'graph_name': getattr(graph, 'graph_name', f'Graph_{graph.graph_id}'),
                        'max_nodes': graph.max_nodes,
                        'init_position': list(graph.init_position) if hasattr(graph, 'init_position') else [0,0,0],
                        'polynom_max_power': graph.polynom_max_power if hasattr(graph, 'polynom_max_power') else 5,
                        'polynom_decay': graph.polynom_decay if hasattr(graph, 'polynom_decay') else 0.8, 
                        'nodes': nodes_data
                    }
                    project_data['graphs'].append(graph_data)

                with open(filepath, 'w', encoding='utf-8') as f:
                    json.dump(project_data, f, cls=NumpyEncoder, indent=2)
                
                self.status_bar.show_success(f"Project saved to {filepath}")
                print(f"Project saved: {len(graph_list)} graphs.")

            except Exception as e:
                self.status_bar.show_error(f"Save failed: {e}")
                print(f"Save failed: {e}")
                import traceback
                traceback.print_exc()




    def fixed_save_all_graphs_dialog(self):
        """Korrigierte Version der save_all_graphs_dialog Methode."""
        if not graph_list:
            QMessageBox.warning(self, "Save Error", "No graphs to save!")
            return

        filepath, _ = QFileDialog.getSaveFileName(
            self, "Save Project", "", "JSON Files (*.json);;All Files (*)"
        )

        if filepath:
            if not filepath.endswith('.json'):
                filepath += '.json'
            
            try:
                project_data = {
                    'meta': {
                        'version': '2.1', 
                        'type': 'neuroticks_project',
                        'timestamp': str(np.datetime64('now'))
                    },
                    'graphs': []
                }

                for graph in graph_list:
                    # Skip virtuelle Graphen (z.B. RetinaTestTab): nicht exportieren
                    if getattr(graph, 'is_virtual', False):
                        continue
                    nodes_data = []
                    for node in graph.node_list:
                        
                        cleaned_devices = []
                        if hasattr(node, 'devices'):
                            for dev in node.devices:
                                dev_copy = dev.copy()
                                if 'runtime_gid' in dev_copy:
                                    del dev_copy['runtime_gid']
                                if 'params' in dev_copy:
                                    dev_copy['params'] = _clean_params(dev_copy['params'])
                                cleaned_devices.append(dev_copy)

                        safe_params = node.parameters.copy() if hasattr(node, 'parameters') else {}
                        if 'devices' in safe_params:
                            del safe_params['devices']

                        node_data = {
                            'id': node.id,
                            'name': node.name,
                            'graph_id': graph.graph_id,
                            'parameters': _clean_params(safe_params),
                            'positions': [pos.tolist() if isinstance(pos, np.ndarray) else list(pos)
                                        for pos in node.positions] if node.positions else [],
                            'center_of_mass': list(node.center_of_mass),
                            'connections': _serialize_connections(node.connections),
                            'devices': cleaned_devices,
                            'types': node.types if hasattr(node, 'types') else [],
                            'neuron_models': node.neuron_models if hasattr(node, 'neuron_models') else [],
                            'distribution': list(node.distribution) if hasattr(node, 'distribution') and node.distribution else [],
                            'parent_id': node.parent.id if hasattr(node, 'parent') and node.parent else None,
                            'next_ids': [n.id for n in node.next] if hasattr(node, 'next') else [],
                            'prev_ids': [n.id for n in node.prev] if hasattr(node, 'prev') else [],
                        }
                        nodes_data.append(node_data)

                    graph_data = {
                        'graph_id': graph.graph_id,
                        'graph_name': getattr(graph, 'graph_name', f'Graph_{graph.graph_id}'),
                        'max_nodes': graph.max_nodes,
                        'init_position': list(graph.init_position),
                        'polynom_max_power': graph.polynom_max_power,
                        'polynom_decay': graph.polynom_decay if hasattr(graph, 'polynom_decay') else 0.8, 
                        'nodes': nodes_data
                    }
                    project_data['graphs'].append(graph_data)

                with open(filepath, 'w', encoding='utf-8') as f:
                    json.dump(project_data, f, cls=NumpyEncoder, indent=2)
                
                self.status_bar.show_success(f"Project saved to {filepath}")
                print(f"Project saved: {len(graph_list)} graphs.")

            except Exception as e:
                self.status_bar.show_error(f"Save failed: {e}")
                print(f"Save failed: {e}")
                import traceback
                traceback.print_exc()












    def load_all_graphs_dialog(self):
        filepath, _ = QFileDialog.getOpenFileName(
            self, "Load Graph", "", "JSON Files (*.json);;All Files (*)"
        )

        if not filepath:
            return

        try:
            self.status_bar.set_status("Loading project...", color="#2196F3")
            self.status_bar.set_progress(10)
            QApplication.processEvents()

            with open(filepath, 'r', encoding='utf-8') as f:
                project_data = json.load(f)

            if 'graphs' not in project_data:
                raise ValueError("Invalid file format: 'graphs' key missing")

            print("\nResetting Environment for Load...")
            
            # Stop simulation and invalidate stale refs before ResetKernel
            global graph_list
            if hasattr(self, 'sim_timer'):
                self.sim_timer.stop()
            self.live_recorders = []
            _invalidate_nest_refs(graph_list)
            
            nest.ResetKernel()
            
            # Drop dopa-VT cache: GIDs from the previous kernel are dead.
            
            clear_dopa_vt_cache()
            graph_list.clear()
            
            state.next_graph_id = 0
            state.graph_parameters.clear()

            total_graphs = len(project_data['graphs'])
            
            for i, g_data in enumerate(project_data['graphs']):
                self.status_bar.set_status(f"Building Graph {i+1}/{total_graphs}...")
                self.status_bar.set_progress(20 + int(40 * (i/total_graphs)))
                QApplication.processEvents()

                gid = g_data['graph_id']
                
                if gid >= state.next_graph_id:
                    state.next_graph_id = gid + 1

                graph = Graph(
                    graph_name=g_data.get('graph_name', 'LoadedGraph'),
                    graph_id=gid,
                    parameter_list=[],
                    polynom_max_power=g_data.get('polynom_max_power', 5),
                    position=g_data.get('init_position', [0,0,0]),
                    max_nodes=g_data.get('max_nodes', 100)
                )
                
                for nd in g_data['nodes']:
                    params = nd['parameters'].copy()
                    params['id'] = nd['id']
                    params['name'] = nd['name']
                    params['graph_id'] = nd['graph_id']
                    params['connections'] = nd.get('connections', [])
                    
                    if 'types' in nd and 'types' not in params:
                        params['types'] = nd['types']
                    if 'neuron_models' in nd and 'neuron_models' not in params:
                        params['neuron_models'] = nd['neuron_models']

                    if 'devices' in nd:
                        params['devices'] = nd['devices']
                    
                    if 'center_of_mass' in nd:
                        params['center_of_mass'] = np.array(nd['center_of_mass'])
                    
                    # FIX: Ensure population_nest_params is correctly loaded
                    # Priority: nd['parameters']['population_nest_params'] > nd['population_nest_params']
                    if 'population_nest_params' not in params or not params['population_nest_params']:
                        # Check if it's at top level (older format)
                        if 'population_nest_params' in nd and nd['population_nest_params']:
                            params['population_nest_params'] = nd['population_nest_params']
                    
                    # Debug output for parameter loading
                    pop_params = params.get('population_nest_params', [])
                    if pop_params:
                        print(f"  Loading Node {nd['id']} ({nd['name']}): {len(pop_params)} pop_nest_params")
                        for idx, p in enumerate(pop_params):
                            if p:
                                print(f"    Pop {idx}: V_th={p.get('V_th', 'N/A')}, C_m={p.get('C_m', 'N/A')}, t_ref={p.get('t_ref', 'N/A')}")
                    
                    new_node = graph.create_node(
                        parameters=params,
                        is_root=(nd['id']==0),
                        auto_build=False
                    )
                    
                    # NUR Struktur + Positionen hier setzen — populate_node
                    # läuft am Ende zentral via rebuild_all_graphs(reset_nest=
                    # False). Damit verhalten sich Load-Graph und
                    # Reinstantiate-Network exakt gleich, und es gibt
                    # keine doppelten NEST-Populationen.
                    saved_positions = nd.get('positions')
                    if saved_positions:
                        new_node.positions = [np.array(pos) for pos in saved_positions]
                    # else: positions bleiben leer — rebuild_all_graphs ruft
                    # build() für jeden Node mit leerer self.positions auf.
                    
                    if nd.get('distribution'):
                        new_node.distribution = nd['distribution']
                    
                    # population_nest_params auf den Node syncen — das sieht
                    # populate_node() später als Fallback wenn parameters
                    # leer sind.
                    new_node.population_nest_params = params.get('population_nest_params', [])

                graph_list.append(graph)
                print(f"Graph '{graph.graph_name}' loaded (ID: {gid}).")


            print("Reconstructing graph topology...")
            # Build a flat lookup over ALL graphs so we can resolve
            # cross-graph targets when populating prev/next from
            # node.connections. Without this, prev only contains
            # same-graph predecessors and Node.remove() can't clean up
            # cross-graph links → dangling refs after delete.
            global_lookup = {}
            for g_obj in graph_list:
                for n_obj in g_obj.node_list:
                    global_lookup[(g_obj.graph_id, n_obj.id)] = n_obj
            
            for g_data in project_data['graphs']:
                gid = g_data['graph_id']
                current_graph_obj = next((g for g in graph_list if g.graph_id == gid), None)
                
                if not current_graph_obj:
                    continue
                
                node_map = {n.id: n for n in current_graph_obj.node_list}

                for nd in g_data['nodes']:
                    node_id = nd['id']
                    node_obj = node_map.get(node_id)
                    
                    if not node_obj: continue

                    parent_id = nd.get('parent_id')
                    if parent_id is not None and parent_id in node_map:
                        node_obj.parent = node_map[parent_id]


                    for nid in nd.get('next_ids', []):
                        if nid in node_map:
                            target_node = node_map[nid]
                            if target_node not in node_obj.next:
                                node_obj.next.append(target_node)
                            if node_obj not in target_node.prev:
                                target_node.prev.append(node_obj)

                    for pid in nd.get('prev_ids', []):
                        if pid in node_map:
                            source_node = node_map[pid]
                            if source_node not in node_obj.prev:
                                node_obj.prev.append(source_node)
                            if node_obj not in source_node.next:
                                source_node.next.append(node_obj)
                    
                    # Cross-graph backref pass: every connection in this
                    # node's connections list represents an edge to
                    # (target_graph_id, target_node_id). Resolve via the
                    # global lookup and call add_neighbor so target.prev
                    # knows about us. add_neighbor is idempotent.
                    for conn in (node_obj.connections or []):
                        try:
                            tgt = conn.get('target', {}) or {}
                            tgt_key = (tgt.get('graph_id'), tgt.get('node_id'))
                            tgt_node = global_lookup.get(tgt_key)
                            if tgt_node is not None:
                                node_obj.add_neighbor(tgt_node)
                        except Exception:
                            pass


            # ─── ZENTRALER POPULATE-PASS via rebuild_all_graphs ───────
            # Statt populate_node inline im Main-Loop (was bei thin-Files
            # mit leeren positions[] für Cone/Blob/CCW/Grid leere
            # Populationen erzeugte) delegieren wir an die identische
            # Logik die der "Reinstantiate Network" Button nutzt:
            #   1. Pro Node: build() falls self.positions leer
            #   2. populate_node() für alle
            # Kernel ist bereits oben mit nest.ResetKernel() gewipt,
            # deshalb reset_nest=False (sonst wären die Topologie-Refs
            # nochmal invalidiert).
            self.status_bar.set_status("Building NEST populations...", color="#FF9800")
            self.status_bar.set_progress(70)
            QApplication.processEvents()
            
            rebuild_stats = self.rebuild_all_graphs(
                target_graphs=graph_list,
                reset_nest=False,
                rebuild_positions=False,
                verbose=True,
            )
            print(f"[Load] Rebuild summary: {rebuild_stats['nodes_rebuilt']} nodes, "
                  f"{rebuild_stats['populations_created']} populations, "
                  f"{len(rebuild_stats['errors'])} errors")
            if rebuild_stats['errors']:
                for err in rebuild_stats['errors'][:10]:
                    print(f"  ✗ {err}")

            if hasattr(self, 'tools_widget'):
                self.tools_widget.update_graphs(graph_list)
                
            self.status_bar.set_status("Recreating Connections...")
            self.status_bar.set_progress(80)
            QApplication.processEvents()

            graphs_dict = {g.graph_id: g for g in graph_list}
            
            created, failed, _ = create_nest_connections_from_stored(graphs_dict, verbose=True)

            self.status_bar.set_status("Refreshing View...")
            self.status_bar.set_progress(95)
            QApplication.processEvents()

            self.update_visualizations()
            self.graph_overview.update_tree()
            self.connection_tool.refresh()
            self.graph_editor.refresh_graph_list()

            if hasattr(self, 'graph_builder'):
                self.graph_builder.reset()

            msg = f"Loaded {total_graphs} graphs. Connections: {created} created, {failed} failed."
            self.status_bar.show_success("Project loaded successfully!")
            print(f"\n{msg}")
            QMessageBox.information(self, "Load Complete", msg)

        except Exception as e:
            self.status_bar.show_error(f"Load failed: {e}")
            print(f"Load failed: {e}")
            import traceback
            traceback.print_exc()
            QMessageBox.critical(self, "Load Error", str(e))



    # ════════════════════════════════════════════════════════════════
    #  THIN-MODE LOADING / SAVING
    #  Append-only Loader für Graphen aus 'thin' JSONs (positions
    #  optional). Kein Kernel-Reset, kein Pos-Constraint — Graphen
    #  werden additiv an die laufende Session angehängt. graph_ids
    #  werden automatisch um einen Offset verschoben falls eine
    #  Kollision mit existierenden Graphen droht. Connection-Targets
    #  innerhalb der geladenen Menge werden mit-remappt; cross-graph-
    #  refs auf bereits geladene Graphen bleiben gültig.
    # ════════════════════════════════════════════════════════════════

    def load_thin_graphs_dialog(self):
        filepath, _ = QFileDialog.getOpenFileName(
            self, "Load Thin Graph(s)", "", "JSON Files (*.json);;All Files (*)"
        )
        if not filepath:
            return
        
        global graph_list
        try:
            self.status_bar.set_status("Loading thin graph(s)...", color="#2196F3")
            self.status_bar.set_progress(10)
            QApplication.processEvents()
            
            # Peek: welche graph_ids will das File belegen?
            with open(filepath, 'r', encoding='utf-8') as f:
                preview = json.load(f)
            
            if 'graphs' in preview:
                wanted_ids = [int(g.get('graph_id', i)) for i, g in enumerate(preview['graphs'])]
            elif 'graph' in preview:
                wanted_ids = [int(preview['graph'].get('graph_id', 0))]
            else:
                wanted_ids = [0]
            
            existing_ids = {g.graph_id for g in graph_list}
            collision = bool(existing_ids & set(wanted_ids))
            
            if collision and existing_ids:
                # Schiebe alle gewollten IDs um (max(existing)+1 - min(wanted))
                # nach oben — bewahrt relative Abstände, vermeidet Kollisionen.
                offset = (max(existing_ids) + 1) - min(wanted_ids)
            else:
                offset = 0
            
            print(f"\n[ThinLoad] file wants graph_ids={wanted_ids}, "
                  f"existing={sorted(existing_ids)}, offset={offset}")
            
            self.status_bar.set_progress(25)
            QApplication.processEvents()
            
            # Toolbox macht den Heavy-Lifting Teil: Nodes erstellen,
            # Positionen (build() oder direkt aus JSON), populate_node()
            # für NEST-Populationen + Auto-Devices, Topologie restaurieren.
            # build_connections=False weil wir gleich die WidgetLib-Routine
            # nehmen für vollen Feature-Support (anisotropic / spatial /
            # distance-dependent).
            # populate=False: NEST-Populationen erstellen wir gleich
            # zentral via rebuild_all_graphs — die selbe Routine die der
            # "Reinstantiate Network" Button benutzt. Damit verhalten sich
            # Import-Thin und Reinstantiate-Network exakt gleich.
            new_graphs = Graph.load_all_from_json(
                filepath,
                populate=False,
                build_connections=False,
                id_offset=offset,
                verbose=True,
            )
            
            self.status_bar.set_progress(60)
            QApplication.processEvents()
            
            # Anhängen + WidgetLib-Counter mit-tracken
            for g in new_graphs:
                graph_list.append(g)
                if g.graph_id >= state.next_graph_id:
                    state.next_graph_id = g.graph_id + 1
            
            # ─── ZENTRALER POPULATE-PASS via rebuild_all_graphs ───────
            # Gleiche Routine wie der "Reinstantiate Network" Button.
            # reset_nest=False, weil wir append-only laden — wir wollen
            # die existierende Session nicht wegwerfen. Pro neuem Node:
            #   1. build() falls self.positions leer (thin-mode)
            #   2. populate_node() erstellt NEST-Populationen
            self.status_bar.set_status("Building NEST populations...", color="#FF9800")
            self.status_bar.set_progress(70)
            QApplication.processEvents()
            
            rebuild_stats = self.rebuild_all_graphs(
                target_graphs=new_graphs,
                reset_nest=False,
                rebuild_positions=False,
                verbose=True,
            )
            print(f"[ThinLoad] Rebuild summary: {rebuild_stats['nodes_rebuilt']} nodes, "
                  f"{rebuild_stats['populations_created']} populations, "
                  f"{len(rebuild_stats['errors'])} errors")
            if rebuild_stats['errors']:
                for err in rebuild_stats['errors'][:10]:
                    print(f"  ✗ {err}")
            
            self.status_bar.set_status("Wiring connections (new graphs only)...")
            self.status_bar.set_progress(80)
            QApplication.processEvents()
            
            # Connections: NUR für die neu geladenen Graphen aufbauen
            # (existierende sind schon im Kernel). Lookups gehen aber
            # gegen die VOLLE Registry — sonst können Cross-Graph-
            # Connections in die existierende Session nicht aufgelöst
            # werden.
            from neuroticks.core.connection_executor import validate_connection_params
            full_registry = {g.graph_id: g for g in graph_list}
            created = 0
            failed = 0
            
            for ng in new_graphs:
                for node in ng.node_list:
                    for conn in (node.connections or []):
                        try:
                            src = conn.get('source', {}) or {}
                            tgt = conn.get('target', {}) or {}
                            sg = full_registry.get(int(src.get('graph_id', -1)))
                            tg = full_registry.get(int(tgt.get('graph_id', -1)))
                            if sg is None or tg is None:
                                failed += 1
                                continue
                            sn = sg.get_node(int(src.get('node_id', -1)))
                            tn = tg.get_node(int(tgt.get('node_id', -1)))
                            if sn is None or tn is None:
                                failed += 1
                                continue
                            sp_id = int(src.get('pop_id', 0))
                            tp_id = int(tgt.get('pop_id', 0))
                            if (sp_id >= len(sn.population) or tp_id >= len(tn.population)
                                or sn.population[sp_id] is None or tn.population[tp_id] is None):
                                failed += 1
                                continue
                            sp = sn.population[sp_id]
                            tp = tn.population[tp_id]
                            if len(sp) == 0 or len(tp) == 0:
                                failed += 1
                                continue
                            
                            cs, ss, _w = validate_connection_params(conn.get('params', {}))
                            if cs.get('rule') == 'one_to_one' and len(sp) != len(tp):
                                print(f"  ✗ {conn.get('name', '?')}: one_to_one size mismatch "
                                      f"({len(sp)} vs {len(tp)})")
                                failed += 1
                                continue
                            nest.Connect(sp, tp, cs, ss)
                            created += 1
                        except Exception as e:
                            print(f"  ✗ Connection {conn.get('name', '?')}: {e}")
                            failed += 1
            
            self.status_bar.set_status("Refreshing view...")
            self.status_bar.set_progress(95)
            QApplication.processEvents()
            
            if hasattr(self, 'tools_widget'):
                self.tools_widget.update_graphs(graph_list)
            self.update_visualizations()
            self.graph_overview.update_tree()
            self.connection_tool.refresh()
            self.graph_editor.refresh_graph_list()
            if hasattr(self, 'graph_builder'):
                self.graph_builder.reset()
            
            offset_msg = f" (id_offset={offset})" if offset else ""
            msg = (f"Thin-loaded {len(new_graphs)} graph(s){offset_msg}. "
                   f"Connections: {created} created, {failed} failed.")
            self.status_bar.show_success("Thin graph(s) loaded.")
            print(f"\n{msg}")
            QMessageBox.information(self, "Load Complete", msg)
        
        except Exception as e:
            self.status_bar.show_error(f"Thin load failed: {e}")
            print(f"Thin load failed: {e}")
            import traceback
            traceback.print_exc()
            QMessageBox.critical(self, "Load Error", str(e))

    def save_thin_graphs_dialog(self):
        if not graph_list:
            QMessageBox.warning(self, "Save Error", "No graphs to save!")
            return
        
        # Drei Optionen: Auto (WFC-only), Always-Include, Never-Include.
        # Auto ist der intelligente Default — speichert Positionen NUR
        # für tool_type='custom' (WFC, nicht-deterministisch). Tools wie
        # Cone/Blob/CCW werden auf load() frisch regeneriert (deterministisch
        # aus den Parametern), sparen also Filesize ohne Verlust.
        msg = QMessageBox(self)
        msg.setIcon(QMessageBox.Icon.Question)
        msg.setWindowTitle("Save Thin Graph(s)")
        msg.setText("How to handle positions?")
        msg.setInformativeText(
            "• AUTO  = save positions only for WFC-custom nodes (the only "
            "non-deterministic case). Cone/Blob/CCW get rebuilt from "
            "parameters on load. Recommended.\n"
            "• YES   = always save positions (preserves every realization, "
            "largest file).\n"
            "• NO    = never save positions (smallest file, but stochastic "
            "WFC realizations will differ on reload)."
        )
        btn_auto = msg.addButton("Auto (WFC only)", QMessageBox.ButtonRole.AcceptRole)
        btn_yes  = msg.addButton("Always Include", QMessageBox.ButtonRole.YesRole)
        btn_no   = msg.addButton("Thin (No Positions)", QMessageBox.ButtonRole.NoRole)
        msg.addButton("Cancel", QMessageBox.ButtonRole.RejectRole)
        msg.exec()
        clicked = msg.clickedButton()
        if clicked is btn_auto:
            include_positions = 'auto'
        elif clicked is btn_yes:
            include_positions = True
        elif clicked is btn_no:
            include_positions = False
        else:
            return
        
        filepath, _ = QFileDialog.getSaveFileName(
            self, "Save Thin Graph(s)", "", "JSON Files (*.json);;All Files (*)"
        )
        if not filepath:
            return
        if not filepath.endswith('.json'):
            filepath += '.json'
        
        # Falls nur ein Graph: schreibe single-graph Format (kompatibel
        # mit WidgetLib.load_graph). Mehrere Graphen → Projekt-Format.
        try:
            real_graphs = [g for g in graph_list if not getattr(g, 'is_virtual', False)]
            if not real_graphs:
                QMessageBox.warning(self, "Save Error", "No real graphs to save (all virtual).")
                return
            
            if len(real_graphs) == 1:
                real_graphs[0].to_json(filepath, include_positions=include_positions, verbose=True)
            else:
                # Projekt-Format: serialisiere jeden Graph einzeln, packe in graphs[].
                # Für 'auto' wird per-Node entschieden (siehe to_json).
                project_data = {
                    'meta': {
                        'version': 'thin-1.0',
                        'type': 'neuroticks_thin_project',
                        'include_positions': include_positions,
                        'timestamp': str(np.datetime64('now')),
                    },
                    'graphs': []
                }
                for g in real_graphs:
                    nodes_data = []
                    for node in g.node_list:
                        if include_positions == 'auto':
                            tt = (node.parameters or {}).get('tool_type', 'custom')
                            include_pos_for_this = (tt == 'custom')
                        else:
                            include_pos_for_this = bool(include_positions)
                        nodes_data.append(g._serialize_node(
                            node,
                            include_positions=include_pos_for_this,
                            include_devices=True,
                            include_connections=True,
                        ))
                    project_data['graphs'].append({
                        'graph_id': int(g.graph_id),
                        'graph_name': g.graph_name,
                        'max_nodes': int(g.max_nodes) if g.max_nodes else len(nodes_data),
                        'init_position': (g.init_position.tolist()
                                          if isinstance(g.init_position, np.ndarray)
                                          else list(g.init_position)),
                        'polynom_max_power': int(g.polynom_max_power),
                        'polynom_decay': float(g.polynom_decay),
                        'nodes': nodes_data,
                    })
                with open(filepath, 'w', encoding='utf-8') as f:
                    json.dump(project_data, f, indent=2)
                tag = ("auto" if include_positions == 'auto'
                       else "with positions" if include_positions
                       else "thin (no positions)")
                print(f"Thin project saved: {len(real_graphs)} graphs → {filepath}  [{tag}]")
            
            self.status_bar.show_success(f"Thin graph(s) saved to {filepath}")
        except Exception as e:
            self.status_bar.show_error(f"Save failed: {e}")
            print(f"Thin save failed: {e}")
            import traceback
            traceback.print_exc()
            QMessageBox.critical(self, "Save Error", str(e))

    def merge_graphs_dialog(self):

        filepath, _ = QFileDialog.getOpenFileName(
            self, "Merge Graphs (Add to existing)", "",
            "JSON Files (*.json);;All Files (*)"
        )

        if not filepath:
            return

        try:
            self.status_bar.set_status("Loading graphs to merge...", color="#9C27B0")
            self.status_bar.set_progress(5)
            QApplication.processEvents()

            with open(filepath, 'r', encoding='utf-8') as f:
                project_data = json.load(f)

            graphs_to_load = []
            
            if 'graphs' in project_data:
                graphs_to_load = project_data['graphs']
            elif 'graph' in project_data:
                single_graph = project_data['graph'].copy()
                single_graph['nodes'] = project_data.get('nodes', [])
                graphs_to_load = [single_graph]
            else:
                raise ValueError("Invalid file format: no 'graph' or 'graphs' key")

            if not graphs_to_load:
                QMessageBox.warning(self, "Empty File", "No graphs found in file!")
                return

            if graph_list:
                max_existing_id = max(g.graph_id for g in graph_list)
                id_offset = max_existing_id + 1
            else:
                id_offset = 0
            
            print(f"MERGE GRAPHS (Offset: {id_offset})")

            self.status_bar.set_status(f"Merging {len(graphs_to_load)} graph(s)...", color="#9C27B0")
            self.status_bar.set_progress(15)
            QApplication.processEvents()

            id_mapping = {}
            for g_data in graphs_to_load:
                old_id = g_data.get('graph_id', 0)
                new_id = old_id + id_offset
                id_mapping[old_id] = new_id
            
            merged_graphs = []
            total_nodes = 0
            total_connections = 0

            for i, g_data in enumerate(graphs_to_load):
                self.status_bar.set_status(f"Building Graph {i+1}/{len(graphs_to_load)}...")
                QApplication.processEvents()

                old_graph_id = g_data.get('graph_id', i)
                new_graph_id = id_mapping[old_graph_id]
                
                graph_name = g_data.get('graph_name', f'MergedGraph_{new_graph_id}')
                
                graph = Graph(
                    graph_name=graph_name,
                    graph_id=new_graph_id,
                    parameter_list=[],
                    polynom_max_power=g_data.get('polynom_max_power', 5),
                    polynom_decay=g_data.get('polynom_decay', 0.8), 
                    position=g_data.get('init_position', [0, 0, 0]),
                    max_nodes=g_data.get('max_nodes', 100)
                )

                nodes_data = g_data.get('nodes', [])
                nodes_data = sorted(nodes_data, key=lambda x: x.get('id', 0))
                
                for nd in nodes_data:
                    params = nd.get('parameters', {}).copy()
                    
                    params['id'] = nd.get('id', 0)
                    params['name'] = nd.get('name', f"Node_{nd.get('id', 0)}")
                    params['graph_id'] = new_graph_id
                    
                    if 'center_of_mass' in nd:
                        params['center_of_mass'] = np.array(nd['center_of_mass'])

                    original_connections = nd.get('connections', [])
                    adjusted_connections = []
                    
                    for conn in original_connections:
                        new_conn = copy.deepcopy(conn)
                        
                        if 'source' in new_conn and new_conn['source']:
                            old_src = new_conn['source'].get('graph_id')
                            if old_src in id_mapping: new_conn['source']['graph_id'] = id_mapping[old_src]
                        
                        if 'target' in new_conn and new_conn['target']:
                            old_tgt = new_conn['target'].get('graph_id')
                            if old_tgt in id_mapping: new_conn['target']['graph_id'] = id_mapping[old_tgt]
                        
                        adjusted_connections.append(new_conn)
                        total_connections += 1
                    
                    params['connections'] = adjusted_connections
                    

                    devices_data = nd.get('devices', [])

                    cleaned_devices = []
                    for dev in devices_data:
                        d_copy = copy.deepcopy(dev)
                        d_copy['runtime_gid'] = None 
                        cleaned_devices.append(d_copy)
                    
                    params['devices'] = cleaned_devices


                    is_root = (nd.get('id', 0) == 0)
                    parent_id = nd.get('parent_id')
                    parent = graph.get_node(parent_id) if parent_id is not None else None
                    
                    new_node = graph.create_node(
                        parameters=params,
                        other=parent,
                        is_root=is_root,
                        auto_build=False
                    )
                    
                    if nd.get('positions'):
                        new_node.positions = [np.array(pos) for pos in nd['positions']]
                        if 'center_of_mass' in nd:
                            new_node.center_of_mass = np.array(nd['center_of_mass'])
                    
                    new_node.devices = cleaned_devices
                    new_node.connections = adjusted_connections
                    
                    if 'neuron_models' in nd:
                        new_node.neuron_models = nd['neuron_models']
                    if 'types' in nd:
                        new_node.types = nd['types']
                        new_node.population = [None] * len(nd['types'])

                    total_nodes += 1

                for nd in nodes_data:
                    node = graph.get_node(nd.get('id'))
                    if not node: continue
                    for next_id in nd.get('next_ids', []):
                        nxt = graph.get_node(next_id)
                        if nxt and nxt not in node.next: node.next.append(nxt)
                    for prev_id in nd.get('prev_ids', []):
                        prv = graph.get_node(prev_id)
                        if prv and prv not in node.prev: node.prev.append(prv)

                print(f"   Populating NEST neurons for {graph_name}...")
                for node in graph.node_list:
                    if not hasattr(node, 'positions') or not node.positions:
                        node.build()
                    elif all(len(p) == 0 for p in node.positions if p is not None):
                        node.build()
                    
                    node.populate_node()

                graph_list.append(graph)
                merged_graphs.append(graph)

            if hasattr(self, 'tools_widget'):
                self.tools_widget.update_graphs(graph_list)
            
            if graph_list:
                state.next_graph_id = max(g.graph_id for g in graph_list) + 1

            self.status_bar.set_status("Creating NEST connections...", color="#9C27B0")
            QApplication.processEvents()

            conn_created = 0
            conn_failed = 0
            
            graphs_dict = {g.graph_id: g for g in graph_list}
            executor = ConnectionExecutor(graphs_dict)
            
            all_new_conns = []
            for g in merged_graphs:
                for n in g.node_list:
                    if hasattr(n, 'connections'):
                        all_new_conns.extend(n.connections)
            
            success, fail, _ = executor.execute_all(all_new_conns)
            conn_created = success
            conn_failed = fail

            # Refresh UI
            self.status_bar.set_status("Refreshing view...", color="#9C27B0")
            self.update_visualizations()
            self.graph_overview.update_tree()
            self.connection_tool.refresh()
            self.graph_editor.refresh_graph_list()
            
            if hasattr(self, 'blink_widget'):
                self.blink_widget.build_scene()

            msg = f"Merged {len(merged_graphs)} graphs. Devices restored. {conn_created} connections created."
            self.status_bar.show_success(msg)
            print(msg)
            
        except Exception as e:
            self.status_bar.show_error(f"Merge failed: {e}")
            print(f"Merge failed: {e}")
            import traceback
            traceback.print_exc()
            QMessageBox.critical(self, "Merge Error", str(e))
