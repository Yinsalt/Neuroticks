"""Headless-Simulation aus der GUI heraus."""
from PyQt6.QtCore import QTimer
from PyQt6.QtWidgets import QApplication, QMessageBox


class HeadlessMixin:
    """Start, Fortschritt und Abschluss von Headless-Läufen."""

    def start_headless_simulation(self, duration):

        print(f"\n>>> STARTING ROBUST HEADLESS SIMULATION ({duration} ms) <<<")
        
        self.sim_dashboard.set_ui_locked(True)
        self.simulation_view.setEnabled(False)
        self.btn_view_simulation.setEnabled(False)
        
        self.status_bar.set_status("HEADLESS SIMULATION RUNNING...", color="#E65100")
        self.status_bar.set_progress(0)
        QApplication.processEvents()
        
        if hasattr(self, 'blink_widget') and self.blink_widget:
            self.blink_widget.stop_simulation()
            if hasattr(self.blink_widget, 'timer'): self.blink_widget.timer.stop()
            
        if hasattr(self, 'simulation_view') and self.simulation_view:
            self.simulation_view.stop_rendering_safe()

        self._ensure_spike_recorders()
        
        try:
            kernel_time = self._get_nest_time()
            self.headless_target_time = kernel_time + duration
            self.headless_start_time = kernel_time
        except: 
            self.headless_target_time = duration
            self.headless_start_time = 0.0


        min_chunk = 50.0
        max_chunk = 500.0
        dynamic_chunk = duration / 50.0 
        self.headless_step_size = max(min_chunk, min(max_chunk, dynamic_chunk))
        
        print(f"   -> Optimization: Chunk size set to {self.headless_step_size:.1f} ms")

        self.headless_timer = QTimer()
        self.headless_timer.timeout.connect(self.headless_loop_step)
        self.headless_timer.start(0)

    def headless_loop_step(self):
        try:
            current_time = self._get_nest_time()
            
            remaining = self.headless_target_time - current_time
            
            if remaining <= 0.001:
                self.finish_headless_simulation()
                return

            step_to_take = min(self.headless_step_size, remaining)

            self._simulate_step_and_update(step_to_take)

            total_duration = self.headless_target_time - self.headless_start_time
            if total_duration > 0:
                elapsed = current_time - self.headless_start_time + step_to_take
                prog = int((elapsed / total_duration) * 100)
                self.status_bar.set_progress(prog)
            
        except Exception as e:
            self.headless_timer.stop()
            self.stop_headless_simulation(error_msg=str(e))

    def stop_headless_simulation(self, error_msg=None):
        if hasattr(self, 'headless_timer'):
            self.headless_timer.stop()
            
        print(">>> Headless Simulation Stopped.")
        
        if error_msg:
            self.status_bar.show_error(f"Headless Error: {error_msg}")
            QMessageBox.critical(self, "Simulation Error", error_msg)
        else:
            self.status_bar.set_status("Simulation stopped by user.", "#D32F2F")
            
        self.collect_simulation_results(0)
        self._restore_ui_after_headless()

    def finish_headless_simulation(self):
        self.headless_timer.stop()
        
        final_time = self._get_nest_time()
        self.update_global_time_display(final_time)
        
        print(f">>> Headless Simulation Finished at {final_time:.1f} ms.")
        self.status_bar.set_status("Collecting Data...", "#1976D2")
        QApplication.processEvents()
        
        self.collect_simulation_results(0)
        
        self.status_bar.show_success(f"Headless Run Complete ({final_time:.1f} ms). Check Data Tab.")
        self._restore_ui_after_headless()

    def _restore_ui_after_headless(self):
        self.sim_dashboard.set_ui_locked(False)
        self.simulation_view.setEnabled(True)
        self.btn_view_simulation.setEnabled(True)
        self.status_bar.set_progress(100)
        
        if self.main_stack.currentIndex() == 1: 
             if hasattr(self, 'blink_widget') and self.blink_widget:
                 self.blink_widget.start_simulation()
                 if hasattr(self.blink_widget, 'timer'): self.blink_widget.timer.start(30)
