"""Hauptfenster der Anwendung."""
from neuroticks.gui import bootstrap  # noqa: F401
from neuroticks.gui.main_window.window import MainWindow  # noqa: E402,F401
