"""Namen der Retina-Populationen und gültige Eingangsauflösungen."""

# ============================================================================
#  SECTION 1: BIOLOGIE-REFERENZ (als Code-Kommentar)
# ============================================================================
#
# Die Retina hat ZWEI parallele Pfade vom Photorezeptor bis zum Sehnerv.
# Sie sind anatomisch UND funktional getrennt, landen in verschiedenen
# LGN-Schichten und codieren unterschiedliche Bildaspekte.
#
# MIDGET-PFAD (hohe Auflösung, Farbe, Parvo-LGN)
#   Fovea:      1 Zapfen -> 1 Midget-Bipolar -> 1 Midget-Ganglion  (1:1:1)
#   Peripheral: 2-3 Zapfen pro Midget-Bipolar, 3 Bipolars pro Ganglion
#   --> Kleine rezeptive Felder, langsame Integration, rot/grün-Gegenfarben.
#       Deswegen liest du mit der Fovea und siehst Farben im Zentrum.
#
# PARASOL-PFAD (Bewegung, Kontrast, Magno-LGN)
#   Diffuse Bipolar integriert ~8 Zapfen
#   Parasol-Ganglion integriert ~6 Bipolars
#   Parasol existiert nur peripheral (keine foveale Parasol-Population!)
#   --> Große rezeptive Felder, schnelle Antwort, achromatisch.
#       Deswegen siehst du Bewegung auch am Rand des Blickfelds.
#
# ON vs OFF: jeder Pfad kommt doppelt vor — ON-Zellen feuern bei lokalem
# Helligkeitsanstieg, OFF-Zellen bei Abfall. Zusammen codieren sie sowohl
# positive als auch negative Kontraste (und vermeiden negative Feuerraten).
#
# HORIZONTAL-ZELLEN: laterale Inhibition auf Bipolar-Ebene.
#   Bilden das "Surround" im klassischen Center-Surround-RF. Ohne sie würde
#   die Retina nur absolute Helligkeit codieren statt lokalen Kontrast.
#
# AMACRINE: laterale Inhibition auf Ganglien-Ebene + temporale Verarbeitung.
#   Zuständig u.a. für transiente Antworten und Bewegungssensitivität.
#   Hier als AdEx (aeif_cond_exp) modelliert wegen Adaptations-Dynamik.
#
# SCHICHTUNG (von außen nach innen, Richtung Licht->Sehnerv):
#   Photorezeptoren -> Horizontal -> Bipolar -> Amacrine -> Ganglion
#   Im Code wird das durch abnehmende Kugelradien nachgebaut (radius_step).


# ============================================================================
#  SECTION 2: POPULATIONS-NAMEN ALS KONSTANTEN
# ============================================================================
#
# Alle Populationen werden über String-Keys angesprochen (self.populations,
# self.positions, self.counts, mapping etc.). Die Namen hier festzupinnen
# verhindert Tippfehler-Bugs, die sonst erst zur Laufzeit auffallen würden,
# und ermöglicht IDE-Autovervollständigung.

# --- PHOTOREZEPTOREN ---
# Drei Zapfentypen (L/M/S) + Stäbchen. L und M existieren foveal UND peripher,
# S nur peripher (die Fovea hat biologisch fast keine S-Zapfen, deswegen
# siehst du Blau mittig schlechter als Rot/Grün). Rods nur peripher.

POP_L_FOVEAL = 'L_foveal'
POP_M_FOVEAL = 'M_foveal'
POP_L_PERIPHERAL = 'L_peripheral'
POP_M_PERIPHERAL = 'M_peripheral'
POP_S_PERIPHERAL = 'S_peripheral'
POP_RODS = 'rods'

PHOTORECEPTOR_POPS = [
    POP_L_FOVEAL, POP_M_FOVEAL,
    POP_L_PERIPHERAL, POP_M_PERIPHERAL, POP_S_PERIPHERAL,
    POP_RODS,
]

# --- HORIZONTAL ---
# Foveal und peripher getrennt, weil Dichte/Reichweite stark unterschiedlich.
POP_HORIZONTAL_FOVEAL = 'horizontal_foveal'
POP_HORIZONTAL_PERIPHERAL = 'horizontal_peripheral'

# --- MIDGET-BIPOLARS ---
# Getrennt ON/OFF und getrennt foveal/peripher -> 4 Populationen.
# Foveal ist Midget die DOMINANTE Bipolar-Klasse (hohe Auflösung, 1:1).
POP_MIDGET_ON_BIP_FOVEAL = 'midget_ON_bipolar_foveal'
POP_MIDGET_OFF_BIP_FOVEAL = 'midget_OFF_bipolar_foveal'
POP_MIDGET_ON_BIP_PERIPHERAL = 'midget_ON_bipolar_peripheral'
POP_MIDGET_OFF_BIP_PERIPHERAL = 'midget_OFF_bipolar_peripheral'

# --- PARASOL-BIPOLARS ---
# Nur peripher! Der Parasol-Pfad existiert in der zentralen Fovea nicht.
# Biologisch: die Foveola wird vollständig vom Midget-System bedient,
# Parasol-Dendriten sind zu groß um dort Platz zu finden.
POP_PARASOL_ON_BIP = 'parasol_ON_bipolar'
POP_PARASOL_OFF_BIP = 'parasol_OFF_bipolar'

# --- KONIOZELLULÄRE BAHN (S-Cone-Bipolar + small-bistratified Ganglion) ---
# Eigene parallele Bahn für Blau-Information, neben Midget und Parasol.
# Pfad: S-Zapfen -> BB-Bipolar (Blue-cone-bistratified) -> small-bistratified
# Ganglion -> LGN K-Schichten. Nur peripher, weil die Foveola praktisch
# keine S-Zapfen hat (gleicher Grund wieso wir Blau zentral schlechter sehen).
# RF-Bauplan nach Dacey 1996: Center = +S, Surround = -(L+M) -> Blue-Yellow-
# Opponenz. Genau das machen wir hier durch zwei Eingangsgewichte: positiv
# vom S-Zapfen, negativ von benachbarten L+M-Zapfen.
POP_KONIO_S_BIP = 'konio_S_bipolar_peripheral'
POP_KONIO_GANG = 'konio_ganglion_peripheral'

# --- AMACRINE ---
POP_AMACRINE_FOVEAL = 'amacrine_foveal'
POP_AMACRINE_PERIPHERAL = 'amacrine_peripheral'

# --- GANGLIEN (Output der Retina -> Sehnerv -> LGN) ---
# Das sind die einzigen Populationen, die ein Downstream-Target
# (z.B. LGN) direkt abgreifen sollte. Siehe get_output_populations().
POP_MIDGET_ON_GANG_FOVEAL = 'midget_ON_ganglion_foveal'
POP_MIDGET_OFF_GANG_FOVEAL = 'midget_OFF_ganglion_foveal'
POP_MIDGET_ON_GANG_PERIPHERAL = 'midget_ON_ganglion_peripheral'
POP_MIDGET_OFF_GANG_PERIPHERAL = 'midget_OFF_ganglion_peripheral'

POP_PARASOL_ON_GANG = 'parasol_ON_ganglion'
POP_PARASOL_OFF_GANG = 'parasol_OFF_ganglion'

BIPOLAR_POPS = [
    POP_MIDGET_ON_BIP_FOVEAL, POP_MIDGET_OFF_BIP_FOVEAL,
    POP_MIDGET_ON_BIP_PERIPHERAL, POP_MIDGET_OFF_BIP_PERIPHERAL,
    POP_PARASOL_ON_BIP, POP_PARASOL_OFF_BIP,
    POP_KONIO_S_BIP,
]

GANGLION_POPS = [
    POP_MIDGET_ON_GANG_FOVEAL, POP_MIDGET_OFF_GANG_FOVEAL,
    POP_MIDGET_ON_GANG_PERIPHERAL, POP_MIDGET_OFF_GANG_PERIPHERAL,
    POP_PARASOL_ON_GANG, POP_PARASOL_OFF_GANG,
    POP_KONIO_GANG,
]

# Erlaubte Input-Auflösungen: Zweierpotenzen von 32 bis 16384.
# Zweierpotenz-Beschränkung ist kein biologisches Muss, sondern eine
# Safeguard gegen versehentliche krumme Werte aus Godot. Bei Bedarf lockern.
VALID_INPUT_RESOLUTIONS = {32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384}
