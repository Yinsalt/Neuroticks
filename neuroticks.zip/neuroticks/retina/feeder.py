"""RetinaInputFeeder: wandelt Bild-Frames in Photorezeptor-Ströme um."""
from typing import Dict, List, Optional, Tuple

import nest
import numpy as np

from neuroticks.retina.defaults import DEFAULT_FEEDER_CONFIG
from neuroticks.retina.populations import (
    POP_L_FOVEAL, POP_L_PERIPHERAL, POP_M_FOVEAL, POP_M_PERIPHERAL, POP_RODS,
    POP_S_PERIPHERAL, VALID_INPUT_RESOLUTIONS,
)

def _validate_resolution(resolution: Tuple[int, int]) -> None:
    """Prüft dass resolution aus Zweierpotenzen zwischen 32 und 16384 besteht.

    Warnt ab 2048x2048 -> ~4 Mio Pixel pro Frame, spürbare Kosten im
    feed()-Sampling. Kein hartes Limit, nur ein Hinweis an den User.
    """
    if not isinstance(resolution, (tuple, list)) or len(resolution) != 2:
        raise ValueError(f"resolution muss (H, W) Tupel sein, bekam {resolution}")
    h, w = resolution
    for val, name in [(h, 'H'), (w, 'W')]:
        if val not in VALID_INPUT_RESOLUTIONS:
            raise ValueError(
                f"Ungültige {name}={val}. Erlaubt sind Zweierpotenzen "
                f"von 32 bis 16384: {sorted(VALID_INPUT_RESOLUTIONS)}"
            )
    if h * w >= 2048 * 2048:
        print(f"WARNING: input_resolution {resolution} ist sehr groß "
              f"({h*w:,} Pixel). Erwarte hohen Speicherverbrauch pro Frame.")


# ============================================================================
#  SECTION 5: INPUT-FEEDER
# ============================================================================
#
# Der RetinaInputFeeder ist die externe Schnittstelle für visuellen Input.
# Er existiert als eigenständiges Objekt, das von Retina.create_input_feeder()
# erzeugt wird. Einmal erzeugt kann er außerhalb der Retina-Klasse benutzt
# werden — z.B. in einer Godot-Loop, die einzelne Frames reinreicht.
#
# Der Feeder kapselt:
#   - NEST-Generator-NodeCollections (step_current oder poisson)
#   - Verbindungen Generator -> Bipolar
#   - Mapping Bipolar -> Photorezeptor-Indizes
#   - Sampling-Logik (3D-Position -> Pixel im Eingangsbild)
#   - Polaritäts-Logik (ON sieht Helligkeit, OFF sieht Dunkelheit)


class RetinaInputFeeder:
    """
    Externe Input-Schnittstelle für eine Retina.

    Wird von Retina.create_input_feeder(config) erzeugt. Danach eigenständig
    nutzbar — hält keine Referenz auf das Retina-Objekt.

    Thread-safety: nein.

    Datenfluss pro feed():
      Frame (H,W,3) + Intensity (H,W)
        -> ggf. resizen auf config['input_resolution']
        -> pro Photorezeptor den Pixel-Wert an seiner 3D-Position samplen
        -> pro Bipolar den Mittelwert seiner zugeordneten Photorezeptoren
        -> Weber-Fechner-Adaptation: Abweichung vom globalen Bild-Mittel
        -> ON vs OFF: Vorzeichen umdrehen für OFF
        -> Amplitude [0,1] auf Strom (pA) oder Rate (Hz) skalieren
        -> in die NEST-Generatoren schreiben
    """

    def __init__(self,
                 config: Dict,
                 bipolar_populations: Dict[str, 'nest.NodeCollection'],
                 bipolar_to_photo_mapping: Dict[str, List],
                 origin: np.ndarray,
                 world_radius: float,
                 min_delay: float):
        # User-Config über die Defaults drüberlegen.
        self.config = {**DEFAULT_FEEDER_CONFIG, **config}
        _validate_resolution(self.config['input_resolution'])

        # Alles was wir von der Retina brauchen wird HIER reingereicht —
        # danach ist der Feeder unabhängig.
        self._bipolar_pops = bipolar_populations
        self._mapping = bipolar_to_photo_mapping
        self._origin = np.asarray(origin, dtype=float)
        self._world_radius = world_radius
        self._min_delay = min_delay

        self.generator_type = self.config['generator_type']
        if self.generator_type not in ('step_current', 'poisson'):
            raise ValueError(
                f"generator_type muss 'step_current' oder 'poisson' sein, "
                f"bekam '{self.generator_type}'"
            )

        # Adaptation-Modus validieren.
        self.adaptation_mode = self.config.get('adaptation_mode', 'weber')
        if self.adaptation_mode not in ('weber', 'cone_cascade'):
            raise ValueError(
                f"adaptation_mode muss 'weber' oder 'cone_cascade' sein, "
                f"bekam '{self.adaptation_mode}'"
            )

        # generators: pro Bipolar-Population eine NodeCollection mit
        # EINEM Generator pro Bipolar-Neuron (1:1 Verbindung).
        self.generators: Dict[str, 'nest.NodeCollection'] = {}
        # Photo-Positionen werden per set_photo_positions() nachgereicht,
        # weil sie ans feed()-Zeitpunkt-Sampling gebunden sind (nicht ans Setup).
        self._photo_positions_cache: Optional[Dict[str, np.ndarray]] = None

        # Cone-Cascade-Bundle: wird in set_photo_positions() erzeugt
        # (braucht die Cone-Counts). None wenn adaptation_mode='weber'.
        self._cone_cascade = None

        # ------------------------------------------------------------------
        # FEM (Fixational Eye Movements) — Drift-State
        # ------------------------------------------------------------------
        # Drei Komponenten:
        #   - Drift (langsamer OU Random Walk, persistent state)
        #   - Microsaccaden (gelegentliche Spruenge, Poisson getriggert)
        #   - Tremor (hochfrequentes Wackeln, pro Frame additives Rauschen)
        #
        # Alle drei werden auf dieselbe (dy, dx) Position addiert; die
        # finale Verschiebung wird vor dem Pixel-Sampling angewandt.
        self._fem_enabled = bool(self.config.get('fem_enabled', False))
        self._fem_ms_enabled = bool(self.config.get('fem_microsaccades_enabled',
                                                      False))
        self._fem_tremor_enabled = bool(self.config.get('fem_tremor_enabled',
                                                          False))
        # Master-Switch: wird ueberhaupt was angewandt?
        self._fem_any_active = (self._fem_enabled or
                                  self._fem_ms_enabled or
                                  self._fem_tremor_enabled)

        if self._fem_any_active:
            seed = self.config.get('fem_seed')
            self._fem_rng = np.random.default_rng(seed)
            self._fem_position = np.zeros(2, dtype=np.float64)
            self._fem_dt_s = 0.050  # Annahme: 50ms pro Frame

            # --- Drift Parameter (OU) ---
            if self._fem_enabled:
                D = float(self.config['fem_drift_diffusion_px2_per_s'])
                k = float(self.config['fem_drift_pull_per_s'])
                self._fem_decay = 1.0 - k * self._fem_dt_s
                self._fem_noise_std = np.sqrt(2.0 * D * self._fem_dt_s)

            # --- Microsaccade Parameter ---
            if self._fem_ms_enabled:
                # Erwartungswert pro Frame: rate_per_s * dt
                self._fem_ms_p_per_frame = (
                    float(self.config['fem_microsaccade_rate_per_s'])
                    * self._fem_dt_s
                )
                self._fem_ms_log_median = float(self.config[
                    'fem_microsaccade_amplitude_log_median_px'])
                self._fem_ms_log_sigma = float(self.config[
                    'fem_microsaccade_amplitude_log_sigma'])
                # Stats fuer Diagnose
                self._fem_ms_count = 0
                self._fem_ms_last_amplitude = 0.0

            # --- Tremor Parameter ---
            if self._fem_tremor_enabled:
                self._fem_tremor_std = float(self.config['fem_tremor_std_px'])
        else:
            self._fem_rng = None
            self._fem_position = None

        self._build_generators()

    def _build_generators(self):
        """Erzeugt Generator-Knoten und verbindet sie mit den Bipolars.

        Zwei Modi:
          step_current: direkte Stromeinspeisung in pA. Deterministisch,
                        perfekt für Kontrolle der Feuerraten.
          poisson: stochastische Spike-Events mit variabler Rate.
                   Biologischer, aber mehr Varianz pro Trial.
        """
        gen_model = ('step_current_generator'
                     if self.generator_type == 'step_current'
                     else 'poisson_generator')

        for bip_name, bip_pop in self._bipolar_pops.items():
            n = len(bip_pop)
            if n == 0:
                continue

            # EIN Generator pro Bipolar-Neuron — so kann jeder Bipolar
            # individuell je nach Pixel-Input angesteuert werden.
            gens = nest.Create(gen_model, n)
            self.generators[bip_name] = gens

            if self.generator_type == 'step_current':
                # step_current_generator injiziert einen Strom, kein Spike.
                # weight=1.0 lässt den gesetzten Ampere-Wert unverändert
                # durchlaufen (Skalierung passiert über amplitude_values).
                nest.Connect(
                    gens, bip_pop, 'one_to_one',
                    syn_spec={'weight': 1.0, 'delay': self._min_delay},
                )
            else:
                # poisson_generator: Spikes mit Poisson-verteiltem Inter-
                # Spike-Intervall. Hier skaliert das Gewicht die synaptische
                # Stärke pro Event.
                weight = self.config['poisson_weight_nS']
                nest.Connect(
                    gens, bip_pop, 'one_to_one',
                    syn_spec={'weight': weight, 'delay': self._min_delay},
                )

    def set_photo_positions(self, photo_positions: Dict[str, np.ndarray]):
        """
        Wird von Retina.create_input_feeder() aufgerufen um die Positionen
        der Photorezeptoren zu übergeben (für Frame-Sampling).

        Bei adaptation_mode='cone_cascade' wird ZUSÄTZLICH eine
        Phototransduktions-Kaskade initialisiert (eine pro Cone-Population).
        """
        self._photo_positions_cache = photo_positions

        # Wenn cone_cascade-Mode: Bundle initialisieren mit den richtigen
        # Cone-Counts pro Population.
        if self.adaptation_mode == 'cone_cascade':
            try:
                from neuroticks.retina.cone_cascade import RetinaCascadeBundle, STIMULUS_GAIN
            except ImportError as e:
                raise ImportError(
                    "adaptation_mode='cone_cascade' benötigt das cone_cascade-Modul. "
                    f"Import fehlgeschlagen: {e}"
                )

            # Cone-Counts aus den Photo-Positionen ableiten.
            # Rods werden bewusst weggelassen — Cone-Modell ist nicht für
            # Stäbchen kalibriert (andere Kinetik).
            cone_counts = {}
            for pop_name, positions in photo_positions.items():
                if pop_name == POP_RODS:
                    continue  # Rods bleiben außen vor
                # Strip "POP_" prefix-equivalent: 'L_foveal' nicht 'L_FOVEAL'
                # Die POP_*-Konstanten heißen aber schon 'L_foveal' (siehe oben).
                cone_counts[pop_name] = len(positions)

            stimulus_gain = self.config.get('cone_cascade_stimulus_gain')
            if stimulus_gain is None:
                stimulus_gain = STIMULUS_GAIN

            self._cone_cascade = RetinaCascadeBundle(
                cone_counts=cone_counts,
                stimulus_gain=stimulus_gain,
                verbose=False,
            )

    def feed(self, lms_frame: np.ndarray, intensity_frame: np.ndarray) -> None:
        """
        Überträgt EIN Frame auf die Retina.

        Args:
            lms_frame: (H, W, 3) Array mit L/M/S-Kanälen, Werte in [0, 1]
            intensity_frame: (H, W) Array, Werte in [0, 1]

        Auflösung des Frames darf von der Feeder-Config abweichen — wird
        dann intern via scipy.ndimage.zoom angepasst. Gleiche Auflösung ist
        effizienter.

        Call-Pattern im closed-loop:
          for frame in godot_frames:
              feeder.feed(lms, intensity)
              nest.Simulate(sim_step_ms)   # typisch 20-50 ms
              spikes = recorder.get(...)
        """
        if self._photo_positions_cache is None:
            raise RuntimeError(
                "Photo-Positionen nicht gesetzt. Feeder muss über "
                "Retina.create_input_feeder() erzeugt werden."
            )

        # Auflösungs-Mismatch? Dann resizen. Kostet extra Rechenzeit —
        # deswegen am besten Godot-Seite direkt in der Ziel-Auflösung rendern.
        target_res = self.config['input_resolution']
        if lms_frame.shape[:2] != target_res:
            lms_frame, intensity_frame = self._resize_frame(
                lms_frame, intensity_frame, target_res
            )

        # FEM (Fixational Eye Movements): Bild leicht verschieben.
        # Macht nur was wenn mindestens eine FEM-Komponente aktiv ist
        # (Drift, Microsaccaden oder Tremor). State wird in-place
        # in self._fem_position aktualisiert.
        if self._fem_any_active:
            lms_frame, intensity_frame = self._apply_fem(
                lms_frame, intensity_frame
            )

        # Drei-Phasen-Pipeline:
        # 1. Sampling: welcher Photorezeptor sieht welchen Pixel?
        # 2. (optional) Phototransduktion: Pixel -> Cone-Adaptation
        # 3. Update: pro Bipolar Mittel bilden, ON/OFF flippen, in NEST pushen.
        photo_values = self._sample_frame(lms_frame, intensity_frame)

        # Phase 2: Phototransduktions-Adaptation (optional)
        # Wenn cone_cascade aktiv: Pixel-Werte durch die ODE-Kaskade
        # transformieren. Output ist im selben Dict-Format wie photo_values,
        # nur dass die Werte jetzt Cone-Antworten in [0,1] sind statt
        # rohe Pixel-Helligkeiten.
        # Rods werden NICHT transformiert (Cascade ist Cone-spezifisch).
        if self._cone_cascade is not None:
            photo_values = self._apply_cone_cascade(photo_values)

        if self.generator_type == 'step_current':
            self._update_step_current(photo_values)
        else:
            self._update_poisson(photo_values)

    def _apply_fem(self, lms_frame, intensity_frame):
        """Wendet alle aktiven FEM-Komponenten auf das Bild an.

        Drei Komponenten werden additiv auf (dy, dx) kombiniert:

        1. DRIFT (persistent state, OU random walk):
           pos += -k*pos*dt + N(0, sqrt(2D*dt))
           Diskret: pos = pos*decay + noise

        2. MICROSACCADES (event-getriggert, Poisson):
           Pro Frame mit Wkt p = rate*dt: Sprung in zufaelliger Richtung
           mit log-normal-verteilter Amplitude. Wird zur Drift-Position
           addiert (nicht ersetzt) -> biologisch korrekt: Sakkade ueber-
           lagert Drift, beide werden danach gemeinsam zurueck-pulled.

        3. TREMOR (kein State, pro Frame additiv):
           tremor = N(0, std_px) pro Achse, NICHT akkumuliert.
           Wird zur finalen Position addiert ohne in self._fem_position
           gespeichert zu werden -> bleibt high-frequency.

        Die finale Position (dy, dx) = drift_pos + tremor wird via
        scipy.ndimage.shift bilinear auf das Bild angewandt.

        Args:
            lms_frame:       (H, W, 3) float Array
            intensity_frame: (H, W) float Array

        Returns:
            Shifted (lms_frame, intensity_frame) Tupel. Originale werden
            nicht modifiziert.
        """
        from scipy.ndimage import shift as ndi_shift

        # --- 1. DRIFT: OU-Schritt, State updaten ---
        if self._fem_enabled:
            noise = self._fem_rng.normal(0.0, self._fem_noise_std, size=2)
            self._fem_position = self._fem_position * self._fem_decay + noise

        # --- 2. MICROSACCADES: Poisson-Trigger ---
        if self._fem_ms_enabled:
            # Per-Frame-Wkt einer Sakkade
            if self._fem_rng.random() < self._fem_ms_p_per_frame:
                # Log-normale Amplitude in Pixeln
                amplitude = self._fem_rng.lognormal(
                    mean=self._fem_ms_log_median,
                    sigma=self._fem_ms_log_sigma,
                )
                # Richtung gleichmaessig in [0, 2pi)
                theta = self._fem_rng.uniform(0.0, 2.0 * np.pi)
                jump = np.array([
                    amplitude * np.sin(theta),  # dy
                    amplitude * np.cos(theta),  # dx
                ])
                # Sprung zur aktuellen Position addieren
                self._fem_position = self._fem_position + jump
                self._fem_ms_count += 1
                self._fem_ms_last_amplitude = float(amplitude)

        # --- 3. TREMOR: additives Rauschen, NICHT persistent ---
        if self._fem_tremor_enabled:
            tremor = self._fem_rng.normal(0.0, self._fem_tremor_std, size=2)
        else:
            tremor = np.zeros(2)

        # Finale Verschiebung = Drift-Position + Tremor (nicht persistiert)
        final_pos = self._fem_position + tremor
        dy, dx = float(final_pos[0]), float(final_pos[1])

        # Fast-path bei verschwindender Verschiebung
        if abs(dy) < 1e-3 and abs(dx) < 1e-3:
            return lms_frame, intensity_frame

        # bilinear (order=1), reflect-Padding am Rand.
        lms_shifted = ndi_shift(
            lms_frame, shift=(dy, dx, 0), order=1, mode='reflect'
        )
        intensity_shifted = ndi_shift(
            intensity_frame, shift=(dy, dx), order=1, mode='reflect'
        )
        return lms_shifted, intensity_shifted

    # Backwards-compat alias: alter Code rief _apply_drift direkt auf.
    _apply_drift = _apply_fem

    def get_fem_position(self):
        """Aktuelle FEM-Position (dy, dx) in Pixeln. Für Diagnose.

        Returns:
            np.ndarray (2,) oder None wenn keine FEM-Komponente aktiv.
        """
        if not self._fem_any_active:
            return None
        return self._fem_position.copy()

    def get_fem_stats(self) -> Dict:
        """Diagnose-Stats fuer FEM. Returns dict mit Zaehlern."""
        if not self._fem_any_active:
            return {'fem_active': False}
        stats = {
            'fem_active': True,
            'drift_enabled': self._fem_enabled,
            'microsaccades_enabled': self._fem_ms_enabled,
            'tremor_enabled': self._fem_tremor_enabled,
            'current_position_px': self._fem_position.copy(),
        }
        if self._fem_ms_enabled:
            stats['microsaccade_count'] = int(self._fem_ms_count)
            stats['microsaccade_last_amplitude_px'] = self._fem_ms_last_amplitude
        return stats

    def reset_fem(self):
        """Setzt den FEM-State zurück. Nützlich zwischen Trials."""
        if self._fem_any_active:
            self._fem_position[:] = 0.0
            if self._fem_ms_enabled:
                self._fem_ms_count = 0
                self._fem_ms_last_amplitude = 0.0

    def _apply_cone_cascade(self,
                              photo_values: Dict[str, np.ndarray]
                             ) -> Dict[str, np.ndarray]:
        """Treibt die Cone-Cascade über einen Frame und liefert
        transformierte photo_values zurück.

        Die Cascade arbeitet pro Cone-Population (L_foveal, M_foveal,
        L_peripheral, M_peripheral, S_peripheral). Rods werden
        unverändert durchgereicht (keine Cascade für sie).

        Returns: Dict mit derselben Struktur wie der Input, aber Werte
                 sind jetzt Cone-Antworten in [0,1] statt Pixel-Helligkeiten.
                 Konvention: 1.0 = Cone stark hyperpolarisiert (hell-Antwort),
                             0.0 = Cone bei Dunkel-Baseline.
        """
        # Bestimme die Substep-Anzahl basierend auf der Sim-Frame-Zeit.
        # ANNAHME: nest.biological_time wurde zwischen den feed()-Aufrufen
        # genau einen Sim-Frame weitergetrieben. Wir wissen hier nicht direkt,
        # wie lang der Frame war — daher nehmen wir 50ms als Default und
        # erlauben Override via config['cone_cascade_n_substeps'].
        dt_ms = self.config.get('cone_cascade_dt_ms', 1.0)
        # 50 substeps × dt_ms=1.0 = 50ms Sim-Frame.
        # Bei dt_ms=0.5 -> 100 substeps für 50ms; bei dt_ms=0.1 -> 500.
        n_substeps = int(round(50.0 / dt_ms))

        # Inputs für die Cascade aufbauen — nur die 5 Cone-Pops, keine Rods.
        cascade_inputs = {}
        for pop_name, pixels in photo_values.items():
            if pop_name == POP_RODS:
                continue
            if pop_name in self._cone_cascade.cascades:
                cascade_inputs[pop_name] = pixels

        # Cascade ausführen — Output ist normiert auf [0,1].
        cascade_outputs = self._cone_cascade.step_all(
            cascade_inputs, dt_ms=dt_ms, n_substeps=n_substeps,
            normalized=True,
        )

        # Neues photo_values-Dict bauen: Cone-Pops aus Cascade,
        # Rods unverändert übernehmen.
        new_photo_values = dict(photo_values)  # flache Kopie
        new_photo_values.update(cascade_outputs)
        return new_photo_values

    def _resize_frame(self, lms_frame, intensity_frame, target_res):
        """Skaliert Frames auf die Ziel-Auflösung mit bilinearer Interpolation.

        order=1 = bilinear. Bikubisch (order=3) wäre schöner, aber hier
        geht's um den Input für die Retina — bilinear reicht dicke.
        """
        from scipy.ndimage import zoom
        src_h, src_w = lms_frame.shape[:2]
        tgt_h, tgt_w = target_res
        sh = tgt_h / src_h
        sw = tgt_w / src_w
        # (sh, sw, 1) für lms: 1 = keine Skalierung auf der Channel-Achse.
        lms_resized = zoom(lms_frame, (sh, sw, 1), order=1)
        intensity_resized = zoom(intensity_frame, (sh, sw), order=1)
        return lms_resized, intensity_resized

    def _sample_frame(self, lms_frame, intensity_frame) -> Dict[str, np.ndarray]:
        """
        Sampelt den Frame an jeder Photorezeptor-Position.

        3D -> 2D Projektion: X,Z auf Bildebene, origin abgezogen damit
        das Sampling relativ zur Retina funktioniert.

        VEREINFACHUNG: Wir projizieren direkt orthogonal, statt eine
        echte Linse + Strahlengang zu simulieren. Das heißt: kein
        Bildumkehrung wie in einer realen Optik, kein Sehfeld-Winkel,
        kein Blendenmodell. Der Input-Frame wird einfach in uv-Koordinaten
        auf die xz-Ebene gemappt. Für closed-loop RL reicht das —
        die Agenten lernen ja die Pixel-zu-Retina-Beziehung implizit.

        Nur X und Z werden genutzt; Y (Tiefe) wird ignoriert. Die Kappe
        ist eine Halbkugel in +y, also haben alle Photorezeptoren
        ähnliche y-Werte und unterschiedliche x/z — das mappt sauber
        auf ein 2D-Bild.
        """
        H, W = lms_frame.shape[:2]
        world_r = self._world_radius
        origin = self._origin

        def sample(positions: np.ndarray, channel_idx: Optional[int]) -> np.ndarray:
            if len(positions) == 0:
                return np.zeros(0)
            # Relativ zum Retina-Zentrum (wichtig für origin != 0).
            rel = positions - origin
            x = rel[:, 0]
            z = rel[:, 2]
            # Mapping [-world_r, +world_r] -> [0, 1]
            u = (x / world_r + 1.0) / 2.0
            v = (z / world_r + 1.0) / 2.0
            # Diskrete Pixel-Koordinaten, geclippt damit Randpunkte nicht out-of-bounds gehen.
            col = np.clip((u * W).astype(int), 0, W - 1)
            row = np.clip((v * H).astype(int), 0, H - 1)
            # channel_idx None -> Intensitätsbild (für Rods, die achromatisch sind)
            if channel_idx is None:
                return intensity_frame[row, col]
            # Sonst: L=0 (rot-Kanal), M=1 (grün-Kanal), S=2 (blau-Kanal)
            return lms_frame[row, col, channel_idx]

        pp = self._photo_positions_cache
        return {
            POP_L_FOVEAL: sample(pp[POP_L_FOVEAL], 0),
            POP_M_FOVEAL: sample(pp[POP_M_FOVEAL], 1),
            POP_L_PERIPHERAL: sample(pp[POP_L_PERIPHERAL], 0),
            POP_M_PERIPHERAL: sample(pp[POP_M_PERIPHERAL], 1),
            POP_S_PERIPHERAL: sample(pp[POP_S_PERIPHERAL], 2),
            POP_RODS: sample(pp[POP_RODS], None),
        }

    def _compute_bipolar_amplitudes(self,
                                      photo_values: Dict[str, np.ndarray]) -> Dict[str, np.ndarray]:
        """
        Pro Bipolar-Population: Array [0,1] von Aktivierungen.

        ZWEI MODI (abhängig von self.adaptation_mode):

        WEBER (Default): Globaler Mittelwert-Subtract + contrast_gain.
          Statisch, kein Zeitverhalten. ON-Bipolar feuert wenn lokal heller
          als Bildmittel, OFF wenn dunkler.

            ON-Bipolar:  amp = (intensity - mean) * gain + 0.5
            OFF-Bipolar: amp = (mean - intensity) * gain + 0.5

        CONE_CASCADE: Photo-Werte kommen schon ad-adaptiert aus der
          Phototransduktions-Kaskade ([0,1] mit Konvention "1 = hell").
          Wir bilden nur den lokalen Cone-Mittelwert pro Bipolar und
          invertieren für OFF. Kein globaler Mittelwert, weil die Adaptation
          bereits in der Cascade stattgefunden hat.

            ON-Bipolar:  amp = local_cone_mean         (direkt)
            OFF-Bipolar: amp = 1.0 - local_cone_mean   (invertiert)

        In beiden Fällen ist das Ergebnis [0,1] und wird später auf pA
        skaliert.
        """
        if self.adaptation_mode == 'cone_cascade':
            return self._compute_bipolar_amplitudes_cascade(photo_values)
        else:
            return self._compute_bipolar_amplitudes_weber(photo_values)

    def _compute_bipolar_amplitudes_weber(self,
                                            photo_values: Dict[str, np.ndarray]
                                           ) -> Dict[str, np.ndarray]:
        """Klassischer Weber-Adaptations-Modus (siehe Doku in _compute_bipolar_amplitudes)."""
        # --- Schritt 1: Globaler Bildmittelwert ---
        # Über ALLE Photorezeptor-Werte gemittelt (inkl. Rods), damit L/M/S-
        # Zapfen und Stäbchen dieselbe Baseline sehen. Das ist eine grobe
        # Vereinfachung der realen Weber-Adaptation (die im Retina-
        # biologisch eher auf Zell-Ebene stattfindet), funktioniert aber
        # robust gegen Helligkeitssprünge in Game-Frames.
        all_values = np.concatenate([v for v in photo_values.values() if len(v) > 0])
        global_mean = float(all_values.mean()) if len(all_values) > 0 else 0.5

        # --- Schritt 2: Kontrast-Gain aus Config ---
        gain = self.config.get('contrast_gain', 2.0)

        result = {}
        for bip_name, mapping in self._mapping.items():
            if bip_name not in self.generators:
                continue

            n_bip = len(mapping)
            local_means = np.zeros(n_bip)
            for bip_idx, photo_list in enumerate(mapping):
                if not photo_list:
                    continue
                vals = [photo_values[pop_name][idx] for pop_name, idx in photo_list]
                local_means[bip_idx] = np.mean(vals)

            # ON/OFF-Inversion
            if 'OFF' in bip_name:
                amplitudes = (global_mean - local_means) * gain + 0.5
            else:
                amplitudes = (local_means - global_mean) * gain + 0.5

            amplitudes = np.clip(amplitudes, 0.0, 1.0)
            result[bip_name] = amplitudes

        return result

    def _compute_bipolar_amplitudes_cascade(self,
                                              photo_values: Dict[str, np.ndarray]
                                             ) -> Dict[str, np.ndarray]:
        """Cone-Cascade-Modus: photo_values sind schon adaptiert ([0,1]).

        Konvention nach RetinaCascadeBundle.step_all(normalized=True):
          photo_value = 1.0  -> Cone stark hyperpolarisiert (Hell-Antwort)
          photo_value = 0.0  -> Cone bei Dunkel-Baseline

        POPULATION-NORMALIZED VARIANT (May 2026):
        Die naive Formel `ON = local, OFF = 1 - local` setzt voraus dass
        die Cascade-Output-Verteilung um 0.5 zentriert ist. In der Praxis
        ist sie aber bimodal (Cones im Dunklen ~0, Cones im Hellen ~0.8)
        und die Verteilung pro Bipolar-Population ist meist nicht um 0.5
        zentriert -- siehe diag_cascade_amps.py: foveal mean ~0.86,
        peripheral mean ~0.32 bei einem dunklen Frame.

        Fix: pro Bipolar-Population den Mittelwert der `local_means` als
        Referenz nehmen, ON/OFF symmetrisch dazu definieren mit einem
        Kontrast-Gain (analog zur Weber-Adaptation auf Pixel-Ebene). Das
        bricht den 'die ON-Pfade sterben weil das Bild zu dunkel ist'-Bug.

        Wichtige Eigenschaft: ON_foveal und OFF_foveal teilen sich
        dasselbe Mapping (siehe _compute_bipolar_to_photo_mapping), also
        ist local_means identisch -> Subtraktion des Mittelwerts liefert
        symmetrische +/- Werte fuer ON/OFF -> ON/OFF-Symmetrie wiederhergestellt.
        """
        # Kontrast-Gain pro Population. 2.0 ist konservativ und vermeidet
        # massives Clippen bei der finalen [0,1]-Begrenzung. Bei stark
        # dynamischen Szenen kann ein hoeherer Wert noch sinnvoll sein.
        gain = self.config.get('contrast_gain', 2.0)

        result = {}
        for bip_name, mapping in self._mapping.items():
            if bip_name not in self.generators:
                continue

            n_bip = len(mapping)
            local_means = np.zeros(n_bip)
            for bip_idx, photo_list in enumerate(mapping):
                if not photo_list:
                    continue
                vals = [photo_values[pop_name][idx] for pop_name, idx in photo_list]
                local_means[bip_idx] = np.mean(vals)

            # Population-Mittelwert als ON/OFF-Trennlinie statt 0.5.
            # Bei n=1 (kann passieren bei sehr kleinen Skalen) faellt's
            # auf den klassischen Cascade-Pfad zurueck.
            #
            # WICHTIG: das ist ein RAEUMLICHER Mittelwert (instant, pro
            # Frame neu berechnet), KEIN zeitlicher Tiefpass.
            # Wir haben zeitliche Adaptation ueber tau probiert (May 2026),
            # das interferierte aber mit der Cone-Cascade Ca-Adaptation
            # und gab falsche ON/OFF-Antworten bei stationaerem Stimulus.
            # Temporales Tracking ist Aufgabe der Cone-Cascade (Ca-Feedback
            # tau=50ms), nicht der pop_mean-Schicht.
            if n_bip > 1:
                pop_mean = float(local_means.mean())
            else:
                pop_mean = 0.5

            # ON/OFF symmetrisch um den Pop-Mittelwert,
            # mit gain skaliert, dann auf [0,1] geclippt
            if 'OFF' in bip_name:
                amplitudes = (pop_mean - local_means) * gain + 0.5
            else:
                amplitudes = (local_means - pop_mean) * gain + 0.5

            amplitudes = np.clip(amplitudes, 0.0, 1.0)
            result[bip_name] = amplitudes

        return result

    def _update_step_current(self, photo_values: Dict[str, np.ndarray]):
        """Schreibt neue Strom-Amplituden in die step_current_generators."""
        amplitudes_all = self._compute_bipolar_amplitudes(photo_values)

        max_current = self.config['max_current_pa']
        # WICHTIG: amplitude_times muss in der Zukunft liegen, sonst
        # verwirft NEST den Eintrag. Deswegen +min_delay auf biological_time.
        current_time = nest.biological_time
        next_time = current_time + self._min_delay

        for bip_name, amps in amplitudes_all.items():
            gens = self.generators[bip_name]
            # Skalierung: [0,1] -> [0, max_current_pa] in pA.
            currents = (amps * max_current).astype(float)
            # Jeder Generator bekommt seinen individuellen Wert.
            # TODO: das ist eine Python-Schleife über ~n Generatoren —
            # könnte für große Populationen gebündelt werden, aber
            # NEST's set() hat keine einfache vektorisierte API für
            # step_current_generator-Listen.
            for i, gen in enumerate(gens):
                gen.set(
                    amplitude_times=[next_time],
                    amplitude_values=[float(currents[i])],
                )

    def _update_poisson(self, photo_values: Dict[str, np.ndarray]):
        """Schreibt neue Raten in die poisson_generators."""
        amplitudes_all = self._compute_bipolar_amplitudes(photo_values)
        max_rate = self.config['max_rate_hz']

        for bip_name, amps in amplitudes_all.items():
            gens = self.generators[bip_name]
            # Skalierung: [0,1] -> [0, max_rate_hz] in Hz.
            # Hier geht die vektorisierte Version — poisson_generator
            # nimmt eine Liste für 'rate' direkt an.
            rates = (amps * max_rate).astype(float)
            gens.set(rate=rates.tolist())
