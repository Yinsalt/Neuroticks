"""Retina-Modell: Populationen, Feeder, Skalen, Phototransduktion."""
