"""Duck-typed Graph/Node-Adapter, damit die Retina in den Live-Ansichten erscheint."""
from __future__ import annotations

import numpy as np

# ===========================================================================
#  VIRTUAL GRAPH ADAPTER
# ===========================================================================
#
# Wir wollen die Retina-Populationen im Live-Tab sehen wie normale Neuronen.
# Die Live-Widgets iterieren alle ueber graph_list und greifen auf
# node.positions, node.neuron_models, node.id etc. zu.
#
# Statt alle Widgets anzufassen, bauen wir einen duck-typed Adapter:
# eine Graph-aehnliche Klasse mit is_virtual=True, deren node_list aus
# VirtualRetinaNode-Objekten besteht.

NEURON_MODEL_BY_POP = {
    # Mapping Retina-Pop-Name -> NEST-Modell-String (fuer Farbwahl im Live-Viz)
    # Fallback ist iaf_psc_alpha, das hat eine Default-Farbe.
    'L_foveal':                          'iaf_cond_alpha',
    'M_foveal':                          'iaf_cond_alpha',
    'L_peripheral':                      'iaf_cond_alpha',
    'M_peripheral':                      'iaf_cond_alpha',
    'S_peripheral':                      'iaf_cond_alpha',
    'rods':                              'iaf_cond_alpha',
    'horizontal_foveal':                 'iaf_cond_alpha',
    'horizontal_peripheral':             'iaf_cond_alpha',
    'midget_ON_bipolar_foveal':          'iaf_cond_alpha',
    'midget_OFF_bipolar_foveal':         'iaf_cond_alpha',
    'midget_ON_bipolar_peripheral':      'iaf_cond_alpha',
    'midget_OFF_bipolar_peripheral':     'iaf_cond_alpha',
    'parasol_ON_bipolar':                'iaf_cond_alpha',
    'parasol_OFF_bipolar':               'iaf_cond_alpha',
    'amacrine_foveal':                   'aeif_cond_alpha',
    'amacrine_peripheral':               'aeif_cond_alpha',
    'midget_ON_ganglion_foveal':         'aeif_cond_alpha',
    'midget_OFF_ganglion_foveal':        'aeif_cond_alpha',
    'midget_ON_ganglion_peripheral':     'aeif_cond_alpha',
    'midget_OFF_ganglion_peripheral':    'aeif_cond_alpha',
    'parasol_ON_ganglion':               'aeif_cond_alpha',
    'parasol_OFF_ganglion':              'aeif_cond_alpha',
}


class VirtualRetinaNode:
    """Duck-typed Node replacement for a retina population."""

    def __init__(self, node_id, name, positions_array, neuron_model,
                 nest_pop, center_of_mass):
        self.id = node_id
        self.name = name
        # positions: list[np.ndarray] - eine Liste pro Pop (Live-Viz erwartet das)
        self.positions = [positions_array] if positions_array is not None and len(positions_array) else []
        self.neuron_models = [neuron_model]
        self.types = [0]
        self.center_of_mass = np.array(center_of_mass, dtype=float) if center_of_mass is not None else np.zeros(3)
        self.distribution = []
        self.connections = []
        self.devices = []
        self.next = []
        self.prev = []
        self.parent = None
        self.parameters = {
            'id': node_id,
            'name': name,
            'neuron_models': [neuron_model],
            'types': [0],
            'connections': [],
            'devices': [],
        }
        # Mit population emulieren wir die NodeCollection-Struktur von normal Nodes
        self.population = [nest_pop] if nest_pop is not None else []
        self.nest_connections = []
        self.nest_references = {}
        # Main.py's _distribute_simulation_data erwartet node.results.
        # Auch wenn VirtualRetinaNode keine Devices hat, wird es hier sicherheitshalber
        # vorbereitet (der Reset-Loop oder _ensure_spike_recorders kann naemlich
        # doch was dran haengen).
        self.results = {'history': []}

    # -- No-ops fuer Kompatibilitaet mit dem Reset-Flow in Main.py --
    # Main.reset_and_restart() ruft auf jedem Node build() und populate_node().
    # Der Virtual-Node hat nichts zu bauen (Retina lebt im nest-Kernel bereits),
    # aber die Methoden muessen existieren damit der Reset nicht crasht.
    def build(self, *args, **kwargs):
        return self

    def populate_node(self, *args, **kwargs):
        return self

    def connect(self, *args, **kwargs):
        pass

    def verify_and_report(self, *args, **kwargs):
        pass

    def instantiate_devices(self, *args, **kwargs):
        pass

    def add_neighbor(self, other):
        pass

    def remove_neighbor_if_isolated(self, other):
        pass


class VirtualRetinaGraph:
    """Duck-typed Graph replacement for the retina. Gets registered in graph_list."""

    def __init__(self, graph_id, retina: "Retina"):
        self.graph_id = graph_id
        self.graph_name = "__RetinaTest__"
        self.is_virtual = True   # <--- das Flag fuer Save-Filter
        self.node_list = []
        self.nodes = 0
        self._next_id = 0
        self.max_nodes = 100
        self.polynom_max_power = 5
        self.polynom_decay = 0.8
        self.global_offset = [0, 0, 0]
        self._retina_ref = retina
        self._build_nodes(retina)

    def _build_nodes(self, retina):
        positions = retina.get_positions()
        counts = retina.get_counts()

        node_id = 0
        for pop_name, pop_nodecol in retina.populations.items():
            pts = positions.get(pop_name, None)
            if pts is None or (hasattr(pts, '__len__') and len(pts) == 0):
                continue
            pts_arr = np.asarray(pts, dtype=float)
            # COM aus Punktwolke
            com = pts_arr.mean(axis=0) if len(pts_arr) > 0 else np.zeros(3)
            model = NEURON_MODEL_BY_POP.get(pop_name, 'iaf_psc_alpha')
            node = VirtualRetinaNode(
                node_id=node_id,
                name=pop_name,
                positions_array=pts_arr,
                neuron_model=model,
                nest_pop=pop_nodecol,
                center_of_mass=com,
            )
            self.node_list.append(node)
            node_id += 1
        self._next_id = node_id
        self.nodes = len(self.node_list)

    def get_node(self, node_id):
        for n in self.node_list:
            if n.id == node_id:
                return n
        return None

    # Kompatibilitaet: wenn save_changes() und aehnliches aus WidgetLib diese
    # Methoden callt, brechen wir nicht sondern tun nichts.
    def remove_node(self, node):
        pass

    def build_connections(self, external_graphs=None):
        pass

    def create_node(self, **kwargs):
        raise RuntimeError("VirtualRetinaGraph is non-editable")
