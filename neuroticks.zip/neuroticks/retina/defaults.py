"""Default-Parameter der Retina, der Neuronenmodelle und des Input-Feeders."""
from typing import Dict

# ============================================================================
#  SECTION 4: DEFAULT-PARAMETER
# ============================================================================

DEFAULT_PARAMS: Dict = {

    # --- GEOMETRIE ---
    # Abstrakte Weltkoordinaten (keine realen mm/µm). radius=2.0 ist eine
    # bequeme Einheit für KD-Tree-Distanzen und die 3D-Visualisierung.
    'radius': 2.0,
    # Foveola = Zentrum der Fovea, höchste Zapfendichte. 5° ist der
    # biologische Wert für den reinen Zapfen-Bereich ohne Stäbchen.
    'foveola_angle_deg': 5.0,
    # Iris-Rand bei ~120°: bis dahin reicht die funktionale Retina.
    'iris_angle_deg': 120.0,
    # Positions-Jitter. 0.02 = 2% Rauschen -> sichtbar aber nicht chaotisch.
    'noise': 0.02,

    # Origin-Offset für mehrere Agenten
    # Default (0,0,0). Für mehrere Retinas: Abstände >= 3 * radius empfohlen,
    # damit sich die Kugeln nicht überlappen.
    'origin': (0.0, 0.0, 0.0),

    # Layer-Stacking: jede innere Schicht bekommt etwas kleineren Radius.
    # radius_step=0.02 -> Layer i hat Radius r*(1 - 0.02*i), aber gekappt
    # bei max_radius_delta damit die Ganglien nicht im Kugelzentrum landen.
    'radius_step': 0.02,
    'max_radius_delta': 0.25,

    # --- POPULATIONSGRÖSSEN (primäre Steuerung) ---
    # Skalierbar — für Debugging klein lassen, für finale Runs hochdrehen.
    # Biologisch hat ein menschliches Auge ~6 Mio Zapfen + 120 Mio Stäbchen;
    # diese Werte sind stark runterskaliert aber biologisch plausibel im
    # Verhältnis (Rods ca. 10-20x Zapfenzahl).
    'n_cones_foveal': 150,
    'n_cones_peripheral': 600,
    'n_S_cones': 60,           # Nur peripher. S-Anteil bei ~5-10% der Zapfen.
    'n_rods': 6000,

    # L-Zapfen-Anteil (Rot-empfindlich) unter L+M. Biologisch ~60-70%,
    # daher 0.667. Der Rest wird M.
    'L_fraction': 0.667,

    # --- KONVERGENZ ---
    # Fovea: 1:1:1 — das ist DER strukturelle Grund für hohe Sehschärfe.
    'k_cones_per_midget_bipolar_foveal': 1,
    'k_bipolars_per_midget_ganglion_foveal': 1,
    # Peripher: mehrere Zapfen konvergieren. Auflösung runter, SNR rauf.
    'k_cones_per_midget_bipolar_peripheral': 3,
    'k_bipolars_per_midget_ganglion_peripheral': 3,
    # Parasol: starke Konvergenz -> große rezeptive Felder, schnell/grob.
    'k_cones_per_parasol_bipolar': 8,
    'k_bipolars_per_parasol_ganglion': 6,

    # Konio: 1 S-Zapfen direkt als Center (via Feeder-Strom analog zu Midget),
    # Yellow-Surround kommt NICHT direkt von L+M-Zapfen — die sind parrot_neurons
    # und spiken nicht — sondern von Midget-ON-Bipolaren peripheral, die L+M
    # bereits encoden und spiken. k_midget_surround = wie viele Midget-Bipolare
    # auf einen Konio-Bipolar inhibitorisch wirken. 2 Bipolars konvergieren
    # auf 1 Konio-Ganglion.
    'k_S_cones_per_konio_bipolar': 1,
    'k_midget_surround_per_konio_bipolar': 2,
    'k_konio_bipolars_per_konio_ganglion': 2,

    # Horizontal-RF-Größen. Peripher größer, weil Horizontals dort weite
    # laterale Reichweite haben (Gap Junctions in realer Retina).
    'k_cones_per_horizontal_foveal': 5,
    'k_cones_per_horizontal_peripheral': 12,
    # Wie viele Horizontals inhibieren EIN Bipolar (Surround-Stärke).
    'k_horizontals_surround_per_cone': 3,

    # Amacrine-Konnektivität: mehrere Bipolars -> Amacrine,
    # und eine Amacrine inhibiert mehrere Ganglien + Feedback auf Bipolars.
    'k_bipolars_per_amacrine': 8,
    'k_amacrines_per_ganglion': 5,
    'k_amacrines_per_bipolar_feedback': 3,

    # --- POPULATIONS-RATIOS ---
    # Parasol macht nur ~10% der Ganglien aus (biologisch realistisch).
    'parasol_to_midget_ratio_peripheral': 0.10,
    # Konio macht ca. 8-10% der Ganglien aus, je nach Spezies. Eigentlich
    # 1:1 mit S-Zapfen pro Bipolar, dann ~2:1 zu Ganglion -> Anzahl folgt
    # direkt aus n_S_cones.
    'konio_ganglion_to_bipolar_ratio': 0.5,
    # Horizontal-Dichte: 1 Horizontal pro ~5-10 Zapfen.
    'horizontal_to_cone_ratio_foveal': 0.2,
    'horizontal_to_cone_ratio_peripheral': 0.1,
    # Amacrine: ~1/3 der Bipolar-Anzahl.
    'amacrine_to_bipolar_ratio': 0.3,

    # --- RIBBON-SYNAPSEN ---
    # Echte Bipolars haben Ribbon-Synapsen mit 10-100 Vesikelfreisetzungen
    # pro AP. Wir emulieren das durch mehrfache Connect-Aufrufe
    # (n_ribbon parallele Synapsen mit vollem Gewicht).
    # Validiert bei 20 -> gesunde Midget/Parasol-Feuerraten (10-50 Hz).
    'ribbon_bipolar_to_ganglion': 20,
    'ribbon_horizontal': 3,
    'ribbon_amacrine': 3,
    # Konio-Bahn ist anatomisch dünner als Midget — entsprechend kleinerer
    # ribbon-Faktor. 10 ist ein konservativer Mittelwert.
    'ribbon_konio': 10,

    # --- SHORT-TERM-PLASTICITY (Tsodyks-Markram, opt-in) ---
    # Aktiviert über 'synapse_model' (siehe unten). Wenn synapse_model =
    # 'static_synapse' (Default), werden diese Parameter ignoriert.
    #
    # Wenn synapse_model = 'tsodyks2_synapse': Ribbon-Synapsen bekommen
    # echte Vesikel-Pool-Depletion mit exponentieller Erholung. Pro Spike
    # wird Anteil U vom verfügbaren Pool freigesetzt; Pool erholt sich
    # mit tau_rec.
    #
    # Steady-State bei rein depressiver Synapse (tau_fac=0, u=U konstant)
    # und Input-Rate nu:
    #     x_ss = 1 / (1 + U * nu * tau_rec_seconds)
    # Effektive Synapsen-Stärke = weight * U * x_ss.
    #
    # PARAMETER-KALIBRIERUNG:
    # U=0.2 ist niedrig genug damit selbst bei 100 Hz Bipolar-Rate
    # ~10% des Pools verfügbar bleiben (statt der 1-2% mit U=0.5).
    # Damit verhindern wir das "Synapse stirbt bei hoher Rate"-Problem.
    # tau_fac=0 -> rein depressiv, keine Facilitation (matched primaten-
    # retinale Ribbon-Synapsen, Singer & Diamond 2006).
    #
    # Cone-Pedikel hat schnellere Recovery (~150ms, Choi et al. 2005),
    # Bipolar-Terminal langsamer (~500ms, Singer & Diamond 2006,
    # Oesch & Diamond 2011).
    'synapse_model': 'static_synapse',     # Default = alter Code-Pfad

    # Pro Synapsen-Typ getrennte STP-Parameter:
    # tau_rec auf die echten Operating-Raten der retinalen Bipolare/Amacrines
    # kalibriert (BC peripheral OFF ~80 Hz, Amacrine ~100 Hz, Horizontal
    # peripheral ~175 Hz). Bei den Raten würden längere tau_rec den
    # Vesikel-Pool dauerhaft auf < 10% drücken; daher kürzer als
    # Literatur-Defaults für niedrigere Kortex-Raten.
    'stp_bipolar_to_ganglion': {  # Bipolar-Terminal (BC -> RGC, BC -> AC)
        'U': 0.2,
        'tau_rec': 100.0,   # ms — May 2026: weiter verkuerzt von 200ms
                            # auf 100ms damit System auf Frame-Aenderungen
                            # (~50ms) reagiert statt zu integrieren.
                            # Gewichte entsprechend angepasst (Faktor 0.62)
        'tau_fac': 0.0,     # rein depressiv
    },
    'stp_horizontal': {  # OPL — Cone-Pedikel-artig
        'U': 0.2,
        'tau_rec': 60.0,    # ms — verkuerzt von 100ms fuer schnelle HC-Antwort
        'tau_fac': 0.0,
    },
    'stp_amacrine': {  # IPL — Amacrine-Output auf BC/RGC
        'U': 0.2,
        'tau_rec': 80.0,    # ms — verkuerzt von 150ms fuer responsives AC-Feedback
        'tau_fac': 0.0,
    },
    'stp_konio': {  # Konio-Pfad
        'U': 0.2,
        'tau_rec': 100.0,   # ms — verkuerzt von 200ms (analog BC->RGC)
        'tau_fac': 0.0,
    },

    # --- SYNAPTISCHE GEWICHTE (nS) ---
    # Positive = exzitatorisch, negative = inhibitorisch. In NEST werden
    # inhibitorische Synapsen über negative Gewichte bei iaf_cond_exp
    # realisiert (Umleitung auf tau_syn_in).
    'w_horizontal_to_cone': -0.5,        # Surround-Inhibition
    'w_bipolar_to_horizontal': 0.8,      # Drive auf HC.
                                          # May 2026: erst 1.0 -> 0.6 (HC peripheral
                                          # default 177 Hz war ueber biologisch),
                                          # dann auf 0.8 hoch weil 0.6 HC foveal
                                          # auf 3.8 Hz gedrueckt hat. 0.8 ist der
                                          # Kompromiss: HC peripheral ~150 Hz,
                                          # HC foveal ~8 Hz.
    'w_bipolar_to_ganglion_midget': 3.0, # Midget: starker einzelner Input
    'w_bipolar_to_ganglion_parasol': 2.5,# Parasol: viele Inputs, etwas schwächer
    'w_bipolar_to_amacrine': 1.0,        # Drive auf AC (frueher 1.5).
                                          # Reduziert May 2026 weil AC_peripheral
                                          # default bei 107 Hz statt biologischer
                                          # ~70-80 Hz operierte.
    'w_amacrine_to_ganglion': -1.0,
    'w_amacrine_to_bipolar': -0.8,
    # Konio: Center-Strom kommt via Feeder (S-Cone-Helligkeit -> step_current),
    # genau wie bei Midget. Der Yellow-Surround entsteht durch INHIBITORISCHE
    # Synapsen von Midget-ON-Bipolaren peripheral (die L+M-Helligkeit codieren
    # und spiken). w_midget_to_konio_bipolar negativ -> wenn L+M-Region hell,
    # wird Konio-Bipolar gehemmt. Das erzeugt direkt am Bipolar Blue-Yellow-
    # Opponenz (Dacey 1996). w_konio_bip_to_ganglion entspricht Midget-Stärke;
    # die ribbon-Multiplicity ist hier kleiner.
    'w_midget_to_konio_bipolar': -1.5,
    'w_konio_bipolar_to_ganglion': 3.0,

    # --- SIMULATION ---
    # NEST min_delay: Untergrenze für alle Synapsen-Delays.
    # 1.0 ms ist konservativ und erlaubt grobes Parallelisieren.
    'min_delay': 1.0,

    # --- GRID-BUCKET-MAPPING ---
    # Auflösung der internen Pixel-Bucket-Maps. Default 32x32 matcht das
    # cortikale Adapter-Grid in V1-V6. Über get_grid_maps(resolution=(H,W))
    # können on-the-fly auch andere Auflösungen berechnet werden.
    'bucket_resolution': (32, 32),
}


DEFAULT_NEURON_PARAMS: Dict = {

    # Photorezeptoren: parrot_neurons in NEST.
    # parrot_neuron leitet eingehende Spikes 1:1 weiter, hat selbst keine
    # Dynamik. Wir brauchen sie nur als Positions-Anker — echte Photo-
    # rezeptoren spiken ohnehin nicht (graded potentials), der visuelle
    # Input geht über step_current_generator DIREKT in die Bipolars.

    # Horizontal: Standard iaf_cond_exp (LIF mit konduktanz-basierten Syn.)
    # Kein Adaptationsterm nötig — Horizontals feuern eher kontinuierlich
    # und modulieren lateral.
    'horizontal': {
        "C_m": 250.0, "g_L": 8.33,      # tau_m = C_m/g_L ~ 30 ms (langsam)
        "E_L": -70.0, "E_ex": 0.0, "E_in": -85.0,
        "V_th": -57.0, "V_reset": -70.0, "t_ref": 2.0,
        "tau_syn_ex": 3.0, "tau_syn_in": 8.0,
        "I_e": 0.0,
    },

    # Bipolar ON: Standard LIF.
    # Photorezeptor-Input kommt als Strom (step_current_generator),
    # nicht als synaptische Events.
    'bipolar_on': {
        # Kein Dark-Current — Strom kommt via step_current_generator
        # V_th auf -58 mV gesenkt -> Rheobase = g_L * (V_th - E_L) = 20 * 12 = 240 pA
        # Zusammen mit max_current_pa=800 im Feeder ergibt das einen gesunden
        # Arbeitsbereich: typische Bipolars feuern bei 20-70 Hz je nach Input.
        "C_m": 200.0, "g_L": 20.0,      # tau_m = 10 ms (schnell genug für Frames)
        "E_L": -70.0, "E_ex": 0.0, "E_in": -85.0,
        "V_th": -58.0, "V_reset": -70.0, "t_ref": 2.0,
        "tau_syn_ex": 1.5, "tau_syn_in": 4.0,
        "I_e": 0.0,
    },

    # Bipolar OFF: IDENTISCHE Neuron-Parameter wie ON.
    # Der Unterschied liegt NICHT im Neuronenmodell sondern im Feeder:
    # _compute_bipolar_amplitudes() invertiert das Vorzeichen für OFF-Zellen.
    # Dadurch bleibt ON/OFF-Symmetrie exakt erhalten.
    'bipolar_off': {
        # Invertierung passiert im Feeder, nicht hier.
        # V_th auf -58 mV gesenkt -> Rheobase 240 pA (symmetrisch zu ON)
        "C_m": 200.0, "g_L": 20.0,
        "E_L": -70.0, "E_ex": 0.0, "E_in": -85.0,
        "V_th": -58.0, "V_reset": -70.0, "t_ref": 2.0,
        "tau_syn_ex": 1.5, "tau_syn_in": 4.0,
        "I_e": 0.0,
    },

    # Amacrine: Adaptive Exponential IaF (aeif_cond_exp).
    # Der Adaptations-Term w (über a, b, tau_w) ist hier WICHTIG — echte
    # Amacrines zeigen starke Spike-Frequency-Adaptation, das erzeugt
    # transiente Antworten auf Bewegung/Kontraständerung.
    'amacrine': {
        "C_m": 200.0, "g_L": 10.0,
        "E_L": -70.0, "V_th": -55.0, "V_reset": -60.0, "t_ref": 2.0,
        # a = sub-threshold adaptation, b = spike-triggered adaptation jump,
        # tau_w = wie schnell w zurückkehrt. Delta_T = exponential slope.
        "a": 2.0, "b": 40.0, "tau_w": 100.0, "Delta_T": 2.0, "V_peak": 0.0,
        "E_ex": 0.0, "E_in": -85.0,
        "tau_syn_ex": 2.0, "tau_syn_in": 5.0,
    },

    # Midget-Ganglien: AdEx. Stärkere Adaptation als Amacrine,
    # liefert saubere sustained/transient-Antworten.
    'midget_ganglion': {
        "C_m": 250.0, "g_L": 12.0,
        "E_L": -70.0, "V_th": -52.0, "V_reset": -60.0, "t_ref": 2.0,
        "a": 4.0, "b": 80.0, "tau_w": 150.0, "Delta_T": 2.0, "V_peak": 0.0,
        "E_ex": 0.0, "E_in": -85.0,
        "tau_syn_ex": 2.0, "tau_syn_in": 5.0,
    },

    # Parasol-Ganglien: AdEx, aber SCHNELLER (kleineres tau_w, kürzere
    # t_ref, kleineres tau_syn). Das matcht die biologische Rolle
    # "schnelle Bewegungsdetektion" -> hohe Feuerraten bei Flickern.
    'parasol_ganglion': {
        "C_m": 400.0, "g_L": 20.0,
        "E_L": -70.0, "V_th": -50.0, "V_reset": -60.0, "t_ref": 1.0,
        "a": 2.0, "b": 60.0, "tau_w": 80.0, "Delta_T": 2.0, "V_peak": 0.0,
        "E_ex": 0.0, "E_in": -85.0,
        "tau_syn_ex": 1.0, "tau_syn_in": 3.0,
    },
}


DEFAULT_FEEDER_CONFIG: Dict = {
    'generator_type': 'step_current',
    'input_resolution': (64, 64),
    'max_current_pa': 800.0,     # Validierter Default. Versuch der Reduktion
                                  # auf 350 zeigte: Bipolar-Raten sind nicht
                                  # durch Step-Current allein bestimmt, sondern
                                  # durch das Equilibrium aus Step-Current
                                  # plus Horizontal/Amacrine-Inhibition. Eine
                                  # Reduktion drueckt die Inhibitoren mit
                                  # runter, das Equilibrium bleibt im
                                  # gleichen Bereich (~80 Hz fuer OFF
                                  # peripheral). Daher 800 als Original.
    'max_rate_hz': 4000.0,
    'poisson_weight_nS': 2.0,
    'contrast_gain': 2.0,         # Verstärkung der Mittel-adaptierten Kontraste.
                                  # 1.0 = nur Mittel abziehen, 2.0 = doppelt verstärkt,
                                  # höher = empfindlicher für kleine Kontraste.

    # ------------------------------------------------------------------------
    # Photorezeptor-Adaptations-Modus
    # ------------------------------------------------------------------------
    # 'weber':         Globaler Mittelwert-Subtract * contrast_gain (Default).
    #                  Statisch, keine Zeitdynamik. Schnell und robust.
    #
    # 'cone_cascade':  Biophysische Angueyra-Phototransduktion.
    #                  Pro Cone eine ODE-Kaskade mit persistenten State.
    #                  Liefert biologisch korrekte Time-to-peak (~35ms),
    #                  Light Adaptation und Dark Recovery.
    #                  Braucht cone_cascade.py.
    'adaptation_mode': 'weber',

    # Substep-Größe der Cone-Cascade in ms. 1.0 ist ein robuster Default.
    # Nur relevant bei adaptation_mode='cone_cascade'.
    'cone_cascade_dt_ms': 1.0,

    # Skalierung der Cone-Cascade-Stimulus-Empfindlichkeit. Default aus
    # cone_cascade.STIMULUS_GAIN. Höher = empfindlicher für kleine
    # Helligkeitsunterschiede.
    'cone_cascade_stimulus_gain': None,    # None = aus dem Modul nehmen

    # ------------------------------------------------------------------------
    # Fixational Eye Movements (FEM)
    # ------------------------------------------------------------------------
    # Wenn aktiv, wird das Bild vor dem Sampling pro Frame leicht
    # verschoben. Das modelliert echte Augenbewegungen (Drift) während
    # einer Fixation. Effekt: jeder Cone sieht über mehrere Frames
    # leicht unterschiedliche Pixel -> macht die Cone-Cascade-Adaptation
    # natürlicher (weniger statisches Sättigen) und ist Voraussetzung
    # damit High-Frequency-Content in der visuellen Szene überhaupt
    # transmittiert wird (ohne Bewegung adaptieren Cones komplett weg).
    #
    # IMPLEMENTIERT: Drift (Ornstein-Uhlenbeck Random Walk)
    # NOCH NICHT: Microsaccaden, Tremor (Anlauf 4)
    #
    # Drift-Mathematik (pro Achse, kontinuierlich):
    #   dx/dt = -k*x + sqrt(2D) * eta(t)
    # Diskretisiert (dt = sim_ms_per_frame / 1000):
    #   x_new = x_old * (1 - k*dt) + N(0, sqrt(2*D*dt))
    # D ist die Diffusionskonstante in pixel²/sec.
    # k ist die OU-Rückstellrate in 1/sec (verhindert dass der Blickpunkt
    # unbegrenzt davondriftet; biologisch durch okulomotorische Reflexe).
    #
    # KALIBRIERUNG (scale=3 -> 128x128 für ~5° Sichtfeld, 25.6 px/°):
    # Literatur: Drift ~50-100 arcmin²/s ≈ 18 px²/s.
    # OU-Pull k ≈ 2/s -> Stabilitätsfenster ~3 px Std-Dev von Origin.
    'fem_enabled': False,                       # opt-in (alle FEM-Komponenten)
    'fem_drift_diffusion_px2_per_s': 18.0,      # px²/s
    'fem_drift_pull_per_s': 2.0,                # 1/s, OU-Rückstellung
    'fem_seed': None,                            # None = nicht-deterministisch

    # ------------------------------------------------------------------------
    # Microsaccaden (FEM Phase 2)
    # ------------------------------------------------------------------------
    # Schnelle ruckartige Sprünge alle ~1s waehrend Fixation. Amplitude
    # 3-30 arcmin, Dauer 10-30ms (im Modell instantan pro Frame). Setzen
    # die Drift-Position auf einen neuen Zielpunkt vom aktuellen Punkt aus,
    # in zufaelliger Richtung, log-normal verteilter Amplitude.
    #
    # Inter-Saccade-Intervall: exponentiell verteilt mit Rate
    # `fem_microsaccade_rate_per_s`. 1.0 -> im Schnitt 1 Sakkade pro Sekunde.
    # Amplitude: log-normal mit median = exp(mu) px, std = sigma in log-px.
    # Default median ~2.5 px (6 arcmin @ scale=3), sigma=0.5 -> typischer
    # Range 1-7 px.
    #
    # Effekt biologisch: Re-Zentriert die Drift (verhindert dass das Auge
    # zu weit wegwandert) und stimuliert Cones die sonst adaptieren wuerden.
    'fem_microsaccades_enabled': False,         # opt-in fuer Microsaccaden
    'fem_microsaccade_rate_per_s': 1.0,         # ~1 Sakkade/sec (Literatur)
    'fem_microsaccade_amplitude_log_median_px': 0.92,  # log(2.5px) ~ 6 arcmin
    'fem_microsaccade_amplitude_log_sigma': 0.5,        # log-normal Streuung

    # ------------------------------------------------------------------------
    # Tremor (FEM Phase 2)
    # ------------------------------------------------------------------------
    # Hochfrequentes Zittern, ~30-100 Hz, Amplitude ~0.1-1 arcmin.
    # Bei scale=3 (1px ≈ 2.34 arcmin) ist Tremor SUBPIXEL (~0.4 arcmin =
    # 0.17 px) -> wirkt nur durch Anti-Aliasing der bilinearen Interpolation
    # und ist effektiv nicht-detektierbar.
    #
    # WARNUNG: Bei scale<=3 hat Tremor praktisch keinen Effekt. Erst ab
    # scale=4 (1px ≈ 1.17 arcmin) wird Tremor sub-pixel relevant.
    #
    # Modelliert als white noise pro Frame mit Std `fem_tremor_std_px`.
    # Im Gegensatz zu Drift KEIN Persistenz-State - Tremor ist additiv pro Frame.
    'fem_tremor_enabled': False,                # opt-in fuer Tremor
    'fem_tremor_std_px': 0.17,                  # ~0.4 arcmin @ scale=3
}
