"""Punktverteilungen auf der Retina-Kugelschale und Nachbarschaftssuche."""
from typing import Optional

import numpy as np

# ============================================================================
#  SECTION 3: GEOMETRIE-HELPER
# ============================================================================
#
# Positionsgeneratoren arbeiten in lokalen Koordinaten um (0,0,0).
# Der origin-Offset wird erst nach der Generierung in der Retina-Klasse
# aufaddiert — so bleiben Nachbarschaftsberechnungen konsistent, weil
# kNN translations-invariant ist.


def uniform_cap_points(n: int, r: float, angle_deg: float,
                       noise: float = 0.0) -> np.ndarray:
    """Gleichmäßig verteilte Punkte auf einer Kugelkappe (Foveola).

    Fibonacci-Spirale auf der Kugel: bringt n Punkte weitgehend
    gleichverteilt auf die Kappe zwischen y=cos(angle) und y=1.
    Alternative wäre zufälliges Sampling, aber Fibonacci hat deutlich
    geringere Klumpen-Varianz bei kleinen n — wichtig bei ~150 Zapfen
    in der Foveola, wo Zufall sichtbare Löcher hinterlassen würde.
    """
    if n <= 0:
        return np.zeros((0, 3))

    angle_rad = np.radians(angle_deg)
    # Die Kappe reicht in y-Richtung von cos(angle) bis 1 (Nordpol).
    # Y ist die "nach vorne"-Achse: Fovea schaut in +y-Richtung.
    y_min = np.cos(angle_rad)
    y_max = 1.0
    # Goldener Winkel ~137.5° — Fibonacci-Spiralkonstante für gleichmäßige
    # Verteilung ohne offensichtliche Streifen/Ringe.
    golden_angle = np.pi * (3.0 - np.sqrt(5.0))

    pts = np.zeros((n, 3))
    for i in range(n):
        # t läuft von 0 bis 1 -> y läuft von y_max (Pol) bis y_min (Rand).
        t = i / (n - 1) if n > 1 else 0.5
        y = y_max - t * (y_max - y_min)
        theta = golden_angle * i
        # Noise simuliert biologische Unregelmäßigkeit. Foveale Zapfen sind
        # sehr regelmäßig gepackt, deswegen wird noise hier meist gering
        # gewählt (noise * 0.3 im Aufrufer).
        if noise > 0:
            y = np.clip(y + np.random.uniform(-1, 1) * noise, y_min, y_max)
            theta += np.random.uniform(-1, 1) * noise * np.pi
        # rxz = Radius in der xz-Ebene bei gegebenem y (Pythagoras auf
        # Einheitskugel), dann mit r skaliert.
        rxz = np.sqrt(max(0, 1.0 - y ** 2))
        pts[i] = [np.cos(theta) * rxz * r, y * r, np.sin(theta) * rxz * r]

    return pts


def uniform_sphere_band(n: int, r: float, a0_deg: float, a1_deg: float,
                         noise: float = 0.0) -> np.ndarray:
    """Gleichmäßig verteilte Punkte auf einem Kugelband (Peripherie).

    Gleiche Fibonacci-Logik wie uniform_cap_points, aber mit UNTERER und
    OBERER Winkelgrenze statt bis zum Pol. Das Band entspricht dem Bereich
    zwischen Foveola-Rand (a0 ~5°) und Iris-Rand (a1 ~120°).

    Warum nicht bis 180°? Biologisch endet die Retina an der ora serrata
    (~110°); dahinter sitzt die Iris.
    """
    if n <= 0:
        return np.zeros((0, 3))

    # cos() ist monoton fallend auf [0, pi], also y_max bei kleinerem Winkel.
    y_max = np.cos(np.radians(a0_deg))
    y_min = np.cos(np.radians(a1_deg))
    if y_min >= y_max:
        raise ValueError(f"Ungültige Winkel: {a0_deg}° / {a1_deg}°")

    golden_angle = np.pi * (3.0 - np.sqrt(5.0))

    pts = np.zeros((n, 3))
    for i in range(n):
        t = i / (n - 1) if n > 1 else 0.5
        y = y_max - t * (y_max - y_min)
        theta = golden_angle * i
        if noise > 0:
            y = np.clip(y + np.random.uniform(-1, 1) * noise, y_min, y_max)
            theta += np.random.uniform(-1, 1) * noise * np.pi
        rxz = np.sqrt(max(0, 1.0 - y ** 2))
        pts[i] = [np.cos(theta) * rxz * r, y * r, np.sin(theta) * rxz * r]

    return pts


def radial_project(points: np.ndarray, new_radius: float,
                    center: Optional[np.ndarray] = None) -> np.ndarray:
    """
    Projiziert Punkte auf eine Kugel mit neuem Radius.
    Wenn center gegeben: Projektion um dieses Zentrum, sonst um (0,0,0).

    Genutzt um Bipolars/Ganglien GENAU UNTER den fovealen Zapfen zu
    platzieren (1:1:1-Alignment). Jeder foveale Zapfen wirft sozusagen
    einen Schatten nach innen durch die retinalen Schichten.
    """
    if len(points) == 0:
        return points
    if center is None:
        center = np.zeros(3)
    relative = points - center
    norms = np.linalg.norm(relative, axis=1, keepdims=True)
    # Division-by-zero Schutz: Punkt im Zentrum -> bleibt im Zentrum.
    norms[norms == 0] = 1.0
    return center + relative * (new_radius / norms)


def nearest_k_indices(sources: np.ndarray, targets: np.ndarray,
                       k: int) -> np.ndarray:
    """
    Für jede Target-Position: Indizes der k nächsten Sources.

    Herzstück der räumlichen Konnektivität. KD-Tree statt naiver
    Distanzmatrix, weil wir schnell in die 10k+ Knoten-Region kommen.

    WICHTIG: kNN ist translations-invariant. Wenn sources und targets
    beide um denselben Offset verschoben sind, bleiben die Nachbarschaften
    identisch. Das macht origin-Offset unproblematisch — wir können
    Positionen vor ODER nach dem Offset-Addieren vergleichen.
    """
    if len(sources) == 0 or len(targets) == 0:
        return np.zeros((0, k), dtype=int)

    from scipy.spatial import cKDTree
    # k kann nicht größer als die Anzahl Sources sein (kDTree würde sonst
    # NaN/-1 zurückgeben, je nach scipy-Version).
    k = min(k, len(sources))
    tree = cKDTree(sources)
    _, idx = tree.query(targets, k=k)
    # cKDTree gibt bei k=1 ein 1D-Array zurück — wir wollen konsistent 2D.
    if k == 1:
        idx = idx.reshape(-1, 1)
    return idx
