"""
===============================================================================
RETINA v2 — Biologisch plausible Retina mit räumlicher Konnektivität
===============================================================================

Eine von Grund auf überarbeitete Retina-Simulation für NEST, mit Fokus auf:

  1. BIOLOGISCH KORREKTE KONVERGENZ via nearest-neighbor
     Jede Zelle wird explizit mit ihren räumlichen Nachbarn verbunden.
     Keine pairwise_bernoulli Zufallsverbindungen mehr.

  2. MIDGET vs PARASOL STRIKT GETRENNT
     Zwei parallele Pfade vom Zapfen bis zur Ganglienzelle. Midget =
     hohe Auflösung/Farbe/Parvo-LGN. Parasol = Bewegung/Kontrast/Magno-LGN.

  3. PHOTOREZEPTOREN ALS STROMQUELLEN, NICHT ALS SPIKES
     Echte Photorezeptoren spiken nicht. Wir modellieren sie als
     parrot_neurons (nur für Positionsreferenz) und injizieren den
     visuellen Input als Strom DIREKT in die Bipolars.

  4. HORIZONTAL + AMACRINE für laterale Verarbeitung

  5. MEHRERE AGENTEN via frei wählbarem origin-Offset

  6. SEPARATER INPUT-FEEDER als eigenständiges Objekt

===============================================================================
PUBLIC API
===============================================================================

    from retina import Retina

    retina = Retina(params={'n_cones_foveal': 300, 'origin': (10, 0, 0)})
    retina.build()
    retina.connect()

    feeder_config = {
        'generator_type': 'step_current',
        'input_resolution': (64, 64),
        'max_current_pa': 400.0,
    }
    feeder = retina.create_input_feeder(feeder_config)

    pops = retina.get_populations()
    nest.Connect(pops['midget_ON_ganglion_foveal'], my_lgn_target,
                 'one_to_one', {'weight': 2.0, 'delay': 1.0})

    feeder.feed(lms_frame, intensity_frame)
    nest.Simulate(50.0)

===============================================================================
"""
from typing import Dict, List, Optional, Tuple

import nest
import numpy as np

from neuroticks.retina.defaults import DEFAULT_NEURON_PARAMS, DEFAULT_PARAMS
from neuroticks.retina.feeder import RetinaInputFeeder
from neuroticks.retina.geometry import (
    nearest_k_indices, radial_project, uniform_cap_points, uniform_sphere_band,
)
from neuroticks.retina.populations import (
    BIPOLAR_POPS, GANGLION_POPS, PHOTORECEPTOR_POPS, POP_AMACRINE_FOVEAL,
    POP_AMACRINE_PERIPHERAL, POP_HORIZONTAL_FOVEAL, POP_HORIZONTAL_PERIPHERAL,
    POP_KONIO_GANG, POP_KONIO_S_BIP, POP_L_FOVEAL, POP_L_PERIPHERAL, POP_M_FOVEAL,
    POP_M_PERIPHERAL, POP_MIDGET_OFF_BIP_FOVEAL, POP_MIDGET_OFF_BIP_PERIPHERAL,
    POP_MIDGET_OFF_GANG_FOVEAL, POP_MIDGET_OFF_GANG_PERIPHERAL, POP_MIDGET_ON_BIP_FOVEAL,
    POP_MIDGET_ON_BIP_PERIPHERAL, POP_MIDGET_ON_GANG_FOVEAL, POP_MIDGET_ON_GANG_PERIPHERAL,
    POP_PARASOL_OFF_BIP, POP_PARASOL_OFF_GANG, POP_PARASOL_ON_BIP, POP_PARASOL_ON_GANG,
    POP_RODS, POP_S_PERIPHERAL,
)

# ============================================================================
#  SECTION 6: DIE RETINA-KLASSE
# ============================================================================


class Retina:
    """
    Biologisch strukturierte Retina mit räumlicher Konnektivität.

    Nach build() + connect():
        populations     Dict[str, NodeCollection]  — alle NEST-Populationen
        positions       Dict[str, np.ndarray]      — 3D-Positionen inkl origin
        counts          Dict[str, int]             — Populationsgrößen
    """

    # ------------------------------------------------------------------------
    # Init
    # ------------------------------------------------------------------------

    def __init__(self,
                 params: Optional[Dict] = None,
                 neuron_params: Optional[Dict] = None,
                 verbose: bool = True):
        self.verbose = verbose

        # Merge-Strategie: User-Params überschreiben Defaults, fehlende Keys
        # kommen aus DEFAULT_PARAMS. So kann der User punktuell einzelne
        # Werte override-n ohne das ganze Dict ausfüllen zu müssen.
        self.params = {**DEFAULT_PARAMS, **(params or {})}

        # Origin validieren — muss (x,y,z) sein, sonst bricht das Multi-Agent-
        # Setup später subtil.
        origin = self.params['origin']
        self._origin = np.asarray(origin, dtype=float)
        if self._origin.shape != (3,):
            raise ValueError(f"origin muss (x,y,z) sein, bekam {origin}")

        # Neuron-Params: pro Zelltyp Deep-Merge. Der User kann z.B. nur
        # {'bipolar_on': {'V_th': -60.0}} reinreichen und bekommt den Rest
        # aus DEFAULT_NEURON_PARAMS['bipolar_on'].
        user_neurons = neuron_params or {}
        self.neuron_params = {}
        for key, defaults in DEFAULT_NEURON_PARAMS.items():
            self.neuron_params[key] = {**defaults, **user_neurons.get(key, {})}

        # Werden in build() befüllt:
        self.populations: Dict[str, 'nest.NodeCollection'] = {}
        self.positions: Dict[str, np.ndarray] = {}
        self.counts: Dict[str, int] = {}

        # Wird in build() via _compute_bipolar_to_photo_mapping gefüllt,
        # und an den Feeder weitergereicht.
        self._bipolar_to_photo_mapping: Dict[str, List] = {}

        # Grid-Bucket-Maps (sparse): pop_name -> dict[(row, col) -> [nest_id]]
        # Wird in build() via _compute_grid_maps() gefüllt.
        self._grid_maps: Dict[str, Dict[Tuple[int, int], List[int]]] = {}
        self._id_to_bucket: Dict[str, Dict[int, Tuple[int, int]]] = {}

        # State-Flags verhindern doppeltes build()/connect() — sonst würden
        # doppelte Neuronen und Synapsen in NEST entstehen.
        self._built = False
        self._connected = False

    # ------------------------------------------------------------------------
    # Populations-Größen aus biologischen Ratios
    # ------------------------------------------------------------------------

    def compute_counts(self) -> Dict[str, int]:
        """Leitet alle Populationsgrößen aus den biologischen Ratios ab.

        Die "primären" Größen sind n_cones_foveal, n_cones_peripheral,
        n_S_cones, n_rods. Alles andere wird als feste Ratio davon berechnet.
        Dadurch reicht im Config das Skalieren von z.B. n_cones_peripheral
        um die ganze Retina zu vergrößern, ohne einzelne Populationen
        aus dem biologischen Gleichgewicht zu bringen.
        """
        p = self.params

        n_fov = p['n_cones_foveal']
        n_periph = p['n_cones_peripheral']
        n_S = p['n_S_cones']
        n_rods = p['n_rods']

        # --- Zapfen-Aufteilung L/M ---
        # L_fraction=0.667 -> 2:1 Verhältnis L:M (biologisch typisch).
        # S wird separat gezählt, ist KEIN Anteil von n_periph.
        L_frac = p['L_fraction']
        n_L_fov = int(round(n_fov * L_frac))
        n_M_fov = n_fov - n_L_fov
        n_L_periph = int(round(n_periph * L_frac))
        n_M_periph = n_periph - n_L_periph

        # --- Midget foveal: 1:1:1 ---
        # Für jeden fovealen Zapfen ein Bipolar und ein Ganglion.
        # Das ist KEINE Design-Entscheidung sondern biologische Realität.
        n_midget_bip_fov = n_fov
        n_midget_gang_fov = n_fov

        # --- Midget peripheral: Konvergenz ---
        # Bipolars konvergieren k_c2b Zapfen, Ganglien konvergieren k_b2g Bipolars.
        # max(1, ...) verhindert Zero-Division bei sehr kleinen Populationen.
        k_c2b = p['k_cones_per_midget_bipolar_peripheral']
        k_b2g = p['k_bipolars_per_midget_ganglion_peripheral']
        n_midget_bip_periph = max(1, n_periph // k_c2b)
        n_midget_gang_periph = max(1, n_midget_bip_periph // k_b2g)

        # --- Parasol ---
        # Nur ~10% der Midget-Ganglien (parasol_to_midget_ratio_peripheral).
        # Bipolar-Anzahl ergibt sich rückwärts aus dem Konvergenzfaktor:
        # wenn 6 Bipolars pro Ganglion nötig sind, brauchen wir 6x so viele Bipolars.
        n_parasol_gang = max(1, int(n_midget_gang_periph *
                                     p['parasol_to_midget_ratio_peripheral']))
        n_parasol_bip = max(1, n_parasol_gang *
                             p['k_bipolars_per_parasol_ganglion'])

        # --- Konio ---
        # 1 Bipolar pro S-Zapfen (Center via 1:1), Konvergenz zu Ganglion mit
        # 'konio_ganglion_to_bipolar_ratio'. Bei n_S=60 ergibt das 60 Bipolare
        # und 30 Ganglien — eine kleine, aber nicht null Population.
        n_konio_bip = max(5, n_S)
        n_konio_gang = max(5, int(round(n_konio_bip *
                                         p['konio_ganglion_to_bipolar_ratio'])))

        # --- Horizontal ---
        # Als Anteil der Zapfenanzahl. Periph schließt S-Zapfen mit ein,
        # weil Horizontals auch S-Input verarbeiten (für S-Off-Pfad).
        n_horiz_fov = max(5, int(n_fov * p['horizontal_to_cone_ratio_foveal']))
        n_horiz_periph = max(10, int((n_periph + n_S) *
                                      p['horizontal_to_cone_ratio_peripheral']))

        # --- Amacrine ---
        # ~30% der Gesamt-Bipolar-Anzahl (ON+OFF zusammen, daher *2).
        # Foveal: nur Midget-Bipolars (Parasol+Konio existieren foveal nicht).
        # Peripheral: Midget + Parasol + Konio. Konio einfach (kein ON/OFF-Split).
        n_amac_fov = max(5, int((n_midget_bip_fov * 2) *
                                 p['amacrine_to_bipolar_ratio']))
        n_amac_periph = max(10, int(
            (n_midget_bip_periph * 2 + n_parasol_bip * 2 + n_konio_bip) *
            p['amacrine_to_bipolar_ratio']
        ))

        self.counts = {
            POP_L_FOVEAL: n_L_fov,
            POP_M_FOVEAL: n_M_fov,
            POP_L_PERIPHERAL: n_L_periph,
            POP_M_PERIPHERAL: n_M_periph,
            POP_S_PERIPHERAL: n_S,
            POP_RODS: n_rods,

            POP_HORIZONTAL_FOVEAL: n_horiz_fov,
            POP_HORIZONTAL_PERIPHERAL: n_horiz_periph,

            # ON und OFF GLEICHE Anzahl — exakte Symmetrie pro Pfad.
            POP_MIDGET_ON_BIP_FOVEAL: n_midget_bip_fov,
            POP_MIDGET_OFF_BIP_FOVEAL: n_midget_bip_fov,
            POP_MIDGET_ON_BIP_PERIPHERAL: n_midget_bip_periph,
            POP_MIDGET_OFF_BIP_PERIPHERAL: n_midget_bip_periph,

            POP_PARASOL_ON_BIP: n_parasol_bip,
            POP_PARASOL_OFF_BIP: n_parasol_bip,

            # Konio: keine ON/OFF-Trennung — der bistratified Bipolar feuert
            # auf Blue-Yellow-Differenz, nicht auf separate Polaritäten.
            POP_KONIO_S_BIP: n_konio_bip,

            POP_AMACRINE_FOVEAL: n_amac_fov,
            POP_AMACRINE_PERIPHERAL: n_amac_periph,

            POP_MIDGET_ON_GANG_FOVEAL: n_midget_gang_fov,
            POP_MIDGET_OFF_GANG_FOVEAL: n_midget_gang_fov,
            POP_MIDGET_ON_GANG_PERIPHERAL: n_midget_gang_periph,
            POP_MIDGET_OFF_GANG_PERIPHERAL: n_midget_gang_periph,

            POP_PARASOL_ON_GANG: n_parasol_gang,
            POP_PARASOL_OFF_GANG: n_parasol_gang,

            POP_KONIO_GANG: n_konio_gang,
        }

        return self.counts

    # ------------------------------------------------------------------------
    # Positions-Generierung mit Origin-Offset
    # ------------------------------------------------------------------------

    def _generate_positions(self) -> Dict[str, np.ndarray]:
        """
        Generiert alle 3D-Positionen lokal um (0,0,0), addiert am Ende origin.
        Layer-Stacking: mehrere Schichten mit abnehmendem Radius.

        LAYER-REIHENFOLGE (von außen nach innen, in Lichtrichtung):
          Layer 0: Photorezeptoren (am weitesten außen — Licht kommt von innen!)
          Layer 1: Horizontal
          Layer 2: Midget-Bipolars
          Layer 3: Parasol-Bipolars
          Layer 4: Amacrine
          Layer 5: Ganglien (innen — Axone bilden den Sehnerv)

        Biologisch sind die Layers natürlich invertiert (Licht muss erst
        durch alle inneren Schichten, bevor es die Photorezeptoren trifft,
        außer in der Fovea wo die Schichten zur Seite geschoben sind).
        Wir machen das hier umgekehrt, weil es für 3D-Visualisierung
        intuitiver ist (Photorezeptoren "schauen" nach außen).
        """
        p = self.params
        c = self.counts
        r = p['radius']
        noise = p['noise']
        fov_a = p['foveola_angle_deg']
        iris_a = p['iris_angle_deg']
        step = p['radius_step']
        max_delta = p['max_radius_delta']

        def layer_radius(layer_idx: int) -> float:
            # Jeder Layer liegt step*r weiter innen als der vorige,
            # aber insgesamt nicht mehr als max_delta vom Außenradius.
            # Das verhindert, dass die Ganglien-Schicht im Zentrum kollabiert.
            delta = min(layer_idx * step * r, max_delta)
            return r - delta

        pos = {}

        # --- Layer 0: Photorezeptoren ---
        # Fovea = reine Zapfen (Stäbchen peripher). S-Zapfen nur peripher.
        # noise * 0.3 foveal: dichte regelmäßige Packung, kaum Jitter.
        r_photo = layer_radius(0)
        pos[POP_L_FOVEAL] = uniform_cap_points(
            c[POP_L_FOVEAL], r_photo, fov_a, noise * 0.3)
        pos[POP_M_FOVEAL] = uniform_cap_points(
            c[POP_M_FOVEAL], r_photo, fov_a, noise * 0.3)
        pos[POP_L_PERIPHERAL] = uniform_sphere_band(
            c[POP_L_PERIPHERAL], r_photo, fov_a, iris_a, noise)
        pos[POP_M_PERIPHERAL] = uniform_sphere_band(
            c[POP_M_PERIPHERAL], r_photo, fov_a, iris_a, noise)
        pos[POP_S_PERIPHERAL] = uniform_sphere_band(
            c[POP_S_PERIPHERAL], r_photo, fov_a, iris_a, noise)
        pos[POP_RODS] = uniform_sphere_band(
            c[POP_RODS], r_photo, fov_a, iris_a, noise)

        # --- Layer 1: Horizontal ---
        r_horiz = layer_radius(1)
        pos[POP_HORIZONTAL_FOVEAL] = uniform_cap_points(
            c[POP_HORIZONTAL_FOVEAL], r_horiz, fov_a, noise * 0.5)
        pos[POP_HORIZONTAL_PERIPHERAL] = uniform_sphere_band(
            c[POP_HORIZONTAL_PERIPHERAL], r_horiz, fov_a, iris_a, noise)

        # --- Layer 2: Midget-Bipolars ---
        # Foveal: ALIGNMENT mit Zapfen! Kombinierte L+M-Positionen
        # werden radial nach innen projiziert. So liegt jeder foveale
        # Midget-Bipolar EXAKT unter seinem zugehörigen Zapfen
        # — das ist Voraussetzung für die 1:1:1-Foveal-Architektur.
        foveal_cone_pos_local = np.vstack([pos[POP_L_FOVEAL], pos[POP_M_FOVEAL]])
        r_bip = layer_radius(2)
        pos[POP_MIDGET_ON_BIP_FOVEAL] = radial_project(foveal_cone_pos_local, r_bip)
        pos[POP_MIDGET_OFF_BIP_FOVEAL] = radial_project(foveal_cone_pos_local, r_bip)

        # Peripheral: freie Verteilung, wird über kNN mit Zapfen verbunden.
        pos[POP_MIDGET_ON_BIP_PERIPHERAL] = uniform_sphere_band(
            c[POP_MIDGET_ON_BIP_PERIPHERAL], r_bip, fov_a, iris_a, noise)
        pos[POP_MIDGET_OFF_BIP_PERIPHERAL] = uniform_sphere_band(
            c[POP_MIDGET_OFF_BIP_PERIPHERAL], r_bip, fov_a, iris_a, noise)

        # --- Layer 3: Parasol-Bipolars ---
        # NUR peripheral — keine Foveal-Version (biologisch kein Parasol-Pfad
        # in der Foveola). Eigener Layer-Radius damit sie sich nicht mit
        # Midget-Bipolars überlagern bei KD-Tree-Queries.
        r_parasol_bip = layer_radius(3)
        pos[POP_PARASOL_ON_BIP] = uniform_sphere_band(
            c[POP_PARASOL_ON_BIP], r_parasol_bip, fov_a, iris_a, noise)
        pos[POP_PARASOL_OFF_BIP] = uniform_sphere_band(
            c[POP_PARASOL_OFF_BIP], r_parasol_bip, fov_a, iris_a, noise)

        # --- Layer 3 (Konio-Bipolar): teilt sich den Radius mit Parasol ---
        # Beide sind periphere "parallele" Pfade neben Midget. Es gibt keinen
        # Konio-Konflikt mit Parasol bei kNN, weil sie nie als gemeinsame
        # Source/Target gequeryt werden. uniform_sphere_band statt 1:1-Align
        # mit S-Zapfen, weil n_konio_bip auf max(5, n_S) gefloort ist und so
        # bei sehr kleinen S-Pops nicht in eine Index-Mismatch läuft. Das
        # 1:1-Mapping zum Center-S-Zapfen erledigt ohnehin _compute_bipolar_
        # to_photo_mapping per kNN.
        pos[POP_KONIO_S_BIP] = uniform_sphere_band(
            c[POP_KONIO_S_BIP], r_parasol_bip, fov_a, iris_a, noise)

        # --- Layer 4: Amacrine ---
        r_amac = layer_radius(4)
        pos[POP_AMACRINE_FOVEAL] = uniform_cap_points(
            c[POP_AMACRINE_FOVEAL], r_amac, fov_a, noise)
        pos[POP_AMACRINE_PERIPHERAL] = uniform_sphere_band(
            c[POP_AMACRINE_PERIPHERAL], r_amac, fov_a, iris_a, noise)

        # --- Layer 5: Ganglien ---
        # Foveal wieder mit radial_project() aus Zapfen-Positionen für
        # 1:1:1-Alignment. Peripheral frei verteilt.
        r_gang = layer_radius(5)
        pos[POP_MIDGET_ON_GANG_FOVEAL] = radial_project(foveal_cone_pos_local, r_gang)
        pos[POP_MIDGET_OFF_GANG_FOVEAL] = radial_project(foveal_cone_pos_local, r_gang)
        pos[POP_MIDGET_ON_GANG_PERIPHERAL] = uniform_sphere_band(
            c[POP_MIDGET_ON_GANG_PERIPHERAL], r_gang, fov_a, iris_a, noise)
        pos[POP_MIDGET_OFF_GANG_PERIPHERAL] = uniform_sphere_band(
            c[POP_MIDGET_OFF_GANG_PERIPHERAL], r_gang, fov_a, iris_a, noise)
        pos[POP_PARASOL_ON_GANG] = uniform_sphere_band(
            c[POP_PARASOL_ON_GANG], r_gang, fov_a, iris_a, noise)
        pos[POP_PARASOL_OFF_GANG] = uniform_sphere_band(
            c[POP_PARASOL_OFF_GANG], r_gang, fov_a, iris_a, noise)
        pos[POP_KONIO_GANG] = uniform_sphere_band(
            c[POP_KONIO_GANG], r_gang, fov_a, iris_a, noise)

        # --- ORIGIN-OFFSET ---
        # Erst JETZT addieren, am Ende. Alle kNN-Berechnungen oben (v.a.
        # radial_project) laufen in lokalen Koordinaten — das vermeidet
        # numerische Fehler bei großen Origin-Werten und stellt sicher,
        # dass Multi-Agent-Retinas exakt gleich strukturiert sind.
        if not np.allclose(self._origin, 0):
            for name in pos:
                if len(pos[name]) > 0:
                    pos[name] = pos[name] + self._origin

        return pos

    # ------------------------------------------------------------------------
    # BUILD
    # ------------------------------------------------------------------------

    def build(self) -> 'Retina':
        """Erzeugt alle NEST-Populationen mit Positionen und Neuronenmodellen.

        Reihenfolge wichtig: zuerst counts+positions (reine Python-Logik),
        dann nest.Create() für jede Population. Positionen werden über
        nest.spatial.free() angeheftet — das erlaubt spätere räumliche
        Queries in NEST selbst (nutzen wir aktuell nicht, könnte aber für
        Visualisierung oder NEST-interne spatial connect_layers nützlich
        werden).
        """
        if self._built:
            if self.verbose:
                print("WARNING: Retina bereits gebaut")
            return self

        # min_delay muss VOR Connect gesetzt werden, damit NEST die
        # Synapsen-Queues richtig dimensioniert. try/except weil in
        # manchen NEST-Versionen set() fehlschlägt wenn bereits Knoten
        # existieren — in dem Fall vertrauen wir auf den bestehenden Wert.
        try:
            nest.set(min_delay=self.params['min_delay'])
        except Exception:
            pass

        self.compute_counts()
        self.positions = self._generate_positions()

        if self.verbose:
            total = sum(self.counts.values())
            print(f"\n=== BUILD: {total:,} Zielneuronen (origin={tuple(self._origin)}) ===")

        np_p = self.neuron_params

        # --- Photorezeptoren als parrot_neurons ---
        # parrot_neuron ist ein spike-transparentes Neuron: es hat kein
        # eigenes Membranpotenzial, sondern leitet eingehende Spikes einfach
        # weiter. Wir brauchen sie hier NUR für die Position — der visuelle
        # Input geht via step_current_generator direkt in die Bipolars.
        # edge_wrap=False: keine periodischen Randbedingungen (keine Kugel-
        # Toroid-Magie).
        for name in PHOTORECEPTOR_POPS:
            positions = self.positions[name]
            if len(positions) == 0:
                continue
            self.populations[name] = nest.Create(
                'parrot_neuron',
                positions=nest.spatial.free(positions.tolist(), edge_wrap=False),
            )

        # --- Horizontal: iaf_cond_exp ---
        # Leaky Integrate-and-Fire mit konduktanz-basierten Synapsen.
        # Keine Adaptation — Horizontals sollen möglichst linear integrieren.
        for name in [POP_HORIZONTAL_FOVEAL, POP_HORIZONTAL_PERIPHERAL]:
            positions = self.positions[name]
            if len(positions) == 0:
                continue
            self.populations[name] = nest.Create(
                'iaf_cond_exp',
                positions=nest.spatial.free(positions.tolist(), edge_wrap=False),
                params=np_p['horizontal'],
            )

        # --- Midget-Bipolars ON ---
        # Foveal + peripheral mit demselben Neuronenmodell (bipolar_on).
        # Unterschied foveal vs peripheral liegt nur in der Anzahl und in
        # der Konnektivität, nicht im Einzel-Neuron.
        for name in [POP_MIDGET_ON_BIP_FOVEAL, POP_MIDGET_ON_BIP_PERIPHERAL]:
            positions = self.positions[name]
            if len(positions) == 0:
                continue
            self.populations[name] = nest.Create(
                'iaf_cond_exp',
                positions=nest.spatial.free(positions.tolist(), edge_wrap=False),
                params=np_p['bipolar_on'],
            )

        # --- Midget-Bipolars OFF ---
        # Gleiches Modell (bipolar_off hat identische Parameter wie bipolar_on).
        # Trennung existiert nur, damit ein User die Parameter bei Bedarf
        # separat überschreiben könnte.
        for name in [POP_MIDGET_OFF_BIP_FOVEAL, POP_MIDGET_OFF_BIP_PERIPHERAL]:
            positions = self.positions[name]
            if len(positions) == 0:
                continue
            self.populations[name] = nest.Create(
                'iaf_cond_exp',
                positions=nest.spatial.free(positions.tolist(), edge_wrap=False),
                params=np_p['bipolar_off'],
            )

        # --- Parasol-Bipolars ---
        # Keine eigenen Parasol-Neuronenparameter — nutzen bipolar_on/off.
        # Unterschied zu Midget: nur die Konnektivität (mehr Zapfen pro Bipolar,
        # größere rezeptive Felder).
        for name, model_key in [(POP_PARASOL_ON_BIP, 'bipolar_on'),
                                 (POP_PARASOL_OFF_BIP, 'bipolar_off')]:
            positions = self.positions[name]
            if len(positions) == 0:
                continue
            self.populations[name] = nest.Create(
                'iaf_cond_exp',
                positions=nest.spatial.free(positions.tolist(), edge_wrap=False),
                params=np_p[model_key],
            )

        # --- Konio-Bipolar (BB-bistratified) ---
        # Auch iaf_cond_exp mit bipolar_on-Params. Die Blue-Yellow-Opponenz
        # entsteht ausschließlich durch die Eingangsgewichte (positiv von S,
        # negativ von L+M) — das Neuron selbst ist nichts Besonderes.
        if POP_KONIO_S_BIP in self.positions:
            positions = self.positions[POP_KONIO_S_BIP]
            if len(positions) > 0:
                self.populations[POP_KONIO_S_BIP] = nest.Create(
                    'iaf_cond_exp',
                    positions=nest.spatial.free(positions.tolist(), edge_wrap=False),
                    params=np_p['bipolar_on'],
                )

        # --- Amacrine: aeif_cond_exp ---
        # Adaptive Exponential IaF. Brauchen wir wegen der Adaptation —
        # Amacrines zeigen starke transiente Antworten.
        for name in [POP_AMACRINE_FOVEAL, POP_AMACRINE_PERIPHERAL]:
            positions = self.positions[name]
            if len(positions) == 0:
                continue
            self.populations[name] = nest.Create(
                'aeif_cond_exp',
                positions=nest.spatial.free(positions.tolist(), edge_wrap=False),
                params=np_p['amacrine'],
            )

        # --- Midget-Ganglien: aeif_cond_exp ---
        # Ganglien adaptieren biologisch ebenfalls — sustained vs transient
        # Antworten sind teilweise durch Spike-Frequenz-Adaptation geprägt.
        for name in [POP_MIDGET_ON_GANG_FOVEAL, POP_MIDGET_OFF_GANG_FOVEAL,
                     POP_MIDGET_ON_GANG_PERIPHERAL, POP_MIDGET_OFF_GANG_PERIPHERAL]:
            positions = self.positions[name]
            if len(positions) == 0:
                continue
            self.populations[name] = nest.Create(
                'aeif_cond_exp',
                positions=nest.spatial.free(positions.tolist(), edge_wrap=False),
                params=np_p['midget_ganglion'],
            )

        # --- Parasol-Ganglien: aeif_cond_exp, schneller parametrisiert ---
        for name in [POP_PARASOL_ON_GANG, POP_PARASOL_OFF_GANG]:
            positions = self.positions[name]
            if len(positions) == 0:
                continue
            self.populations[name] = nest.Create(
                'aeif_cond_exp',
                positions=nest.spatial.free(positions.tolist(), edge_wrap=False),
                params=np_p['parasol_ganglion'],
            )

        # --- Konio-Ganglion (small-bistratified): aeif_cond_exp ---
        # Wir nutzen midget_ganglion-Parameter (langsame Antwort, hohe
        # Adaptation), weil small-bistratified-Zellen biologisch eher
        # sustained antworten — passt zum Midget-Profil. Wer eine schnellere
        # Konio-Antwort will, kann auf parasol_ganglion umschalten.
        if POP_KONIO_GANG in self.positions:
            positions = self.positions[POP_KONIO_GANG]
            if len(positions) > 0:
                self.populations[POP_KONIO_GANG] = nest.Create(
                    'aeif_cond_exp',
                    positions=nest.spatial.free(positions.tolist(), edge_wrap=False),
                    params=np_p['midget_ganglion'],
                )

        # --- Mapping für den Feeder ---
        # MUSS nach _generate_positions() passieren, aber KANN vor connect()
        # stehen (das Mapping betrifft nur die Feeder-Sampling-Logik,
        # nicht die intra-retinalen Verbindungen).
        self._compute_bipolar_to_photo_mapping()

        # --- Grid-Bucket-Mapping ---
        # Pro Pop: dict[(row, col) -> [nest_id]] in der Default-Resolution.
        # Wird via get_grid_maps() für externe Bucket-Connect-Logik genutzt.
        self._compute_grid_maps()

        self._built = True

        if self.verbose:
            actual = sum(len(p) for p in self.populations.values())
            print(f"Gebaut: {actual:,} Neuronen über {len(self.populations)} Populationen")

        return self

    # ------------------------------------------------------------------------
    # Bipolar -> Photorezeptor Mapping
    # ------------------------------------------------------------------------

    def _compute_bipolar_to_photo_mapping(self):
        """
        Für jeden Bipolar: welche Photorezeptor-Indizes "beobachtet" er?
        Wird vom Feeder beim feed() benutzt.

        Struktur:
          self._bipolar_to_photo_mapping[bip_name] = [
              [(photo_pop, photo_idx), ...],   # Bipolar 0
              [(photo_pop, photo_idx), ...],   # Bipolar 1
              ...
          ]

        Jeder Eintrag ist eine Liste von (pop_name, idx)-Tupeln, damit ein
        Bipolar z.B. sowohl L- als auch M-Zapfen mischen kann (Parasol-Pfad).

        Biologisch: das entspricht den Dendriten-Baum eines Bipolars.
        Foveal sehr schmal (1 Zapfen), peripheral breiter (3-8 Zapfen).
        """
        p = self.params
        self._bipolar_to_photo_mapping = {}

        # --- Midget foveal: strikt 1:1 ---
        # Alignment existiert schon über radial_project() in _generate_positions.
        # Hier nur Index-Zuordnung: Bipolar i gehört zu Zapfen i (erst alle L,
        # dann alle M — so wurde auch foveal_cone_pos_local gebaut).
        n_L_fov = self.counts[POP_L_FOVEAL]
        n_M_fov = self.counts[POP_M_FOVEAL]
        fov_mapping = []
        for i in range(n_L_fov):
            fov_mapping.append([(POP_L_FOVEAL, i)])
        for i in range(n_M_fov):
            fov_mapping.append([(POP_M_FOVEAL, i)])
        # Dasselbe Mapping für ON und OFF — beide "schauen" denselben Zapfen.
        # Der Unterschied kommt erst im Feeder (Vorzeichen-Flip).
        self._bipolar_to_photo_mapping[POP_MIDGET_ON_BIP_FOVEAL] = fov_mapping
        self._bipolar_to_photo_mapping[POP_MIDGET_OFF_BIP_FOVEAL] = fov_mapping

        # --- Midget peripheral: k nächste L/M-Zapfen ---
        # S wird NICHT mitgenommen — Midget-Pfad ist biologisch auf L/M
        # beschränkt (S hat einen eigenen spezialisierten Bipolar-Typ).
        L_periph_pos = self.positions[POP_L_PERIPHERAL]
        M_periph_pos = self.positions[POP_M_PERIPHERAL]
        combined_periph = np.vstack([L_periph_pos, M_periph_pos])
        n_L = len(L_periph_pos)

        for bip_name in [POP_MIDGET_ON_BIP_PERIPHERAL, POP_MIDGET_OFF_BIP_PERIPHERAL]:
            if bip_name not in self.positions:
                continue
            bip_pos = self.positions[bip_name]
            k = p['k_cones_per_midget_bipolar_peripheral']
            # kNN im kombinierten L+M-Array.
            neighbor_idx = nearest_k_indices(combined_periph, bip_pos, k)

            # Indizes zurück in (pop_name, local_idx) auflösen.
            # Trick: wenn idx < n_L, ist es ein L-Zapfen mit Index idx,
            # sonst ein M-Zapfen mit Index idx - n_L.
            mapping = []
            for indices in neighbor_idx:
                targets = []
                for idx in indices:
                    idx = int(idx)
                    if idx < n_L:
                        targets.append((POP_L_PERIPHERAL, idx))
                    else:
                        targets.append((POP_M_PERIPHERAL, idx - n_L))
                mapping.append(targets)
            self._bipolar_to_photo_mapping[bip_name] = mapping

        # --- Parasol: k nächste L/M/S-Zapfen ---
        # Im Gegensatz zu Midget: S MIT dabei! Parasol ist achromatisch,
        # summiert alle Zapfentypen und verliert damit Farbinformation
        # zugunsten hoher Empfindlichkeit.
        S_periph_pos = self.positions[POP_S_PERIPHERAL]
        combined_parasol = np.vstack([L_periph_pos, M_periph_pos, S_periph_pos])
        n_L_p = len(L_periph_pos)
        n_M_p = len(M_periph_pos)

        for bip_name in [POP_PARASOL_ON_BIP, POP_PARASOL_OFF_BIP]:
            if bip_name not in self.positions:
                continue
            bip_pos = self.positions[bip_name]
            k = p['k_cones_per_parasol_bipolar']
            neighbor_idx = nearest_k_indices(combined_parasol, bip_pos, k)

            # Drei-Stufen-Auflösung: L / M / S je nach Index-Bereich.
            mapping = []
            for indices in neighbor_idx:
                targets = []
                for idx in indices:
                    idx = int(idx)
                    if idx < n_L_p:
                        targets.append((POP_L_PERIPHERAL, idx))
                    elif idx < n_L_p + n_M_p:
                        targets.append((POP_M_PERIPHERAL, idx - n_L_p))
                    else:
                        targets.append((POP_S_PERIPHERAL, idx - n_L_p - n_M_p))
                mapping.append(targets)
            self._bipolar_to_photo_mapping[bip_name] = mapping

        # --- Konio-Bipolar: nur S-Zapfen als Center ---
        # Hier mappen wir AUSSCHLIESSLICH den nächsten S-Zapfen pro Konio-
        # Bipolar. Den Yellow-Surround (L+M) erzeugen wir NICHT über das
        # Feeder-Mapping, sondern in _connect_konio_pathway via inhibitorische
        # Synapsen von Midget-ON-Bipolaren — analog zur Horizontal-Surround-
        # Strategie, weil Photorezeptoren als parrot_neurons nicht spiken
        # können und als Synapsen-Quelle für Inhibition unbrauchbar sind.
        if POP_KONIO_S_BIP in self.positions and len(S_periph_pos) > 0:
            konio_pos = self.positions[POP_KONIO_S_BIP]
            k_S = p['k_S_cones_per_konio_bipolar']
            # Safeguard: bei sehr kleinen S-Pops nie mehr fragen als vorhanden.
            k_S = min(k_S, len(S_periph_pos))
            neighbor_idx = nearest_k_indices(S_periph_pos, konio_pos, k_S)
            mapping = []
            for indices in neighbor_idx:
                targets = [(POP_S_PERIPHERAL, int(idx)) for idx in indices]
                mapping.append(targets)
            self._bipolar_to_photo_mapping[POP_KONIO_S_BIP] = mapping

    # ========================================================================
    # CONNECT — nachbarschafts-basierte Verdrahtung
    # ========================================================================

    def connect(self) -> 'Retina':
        """Baut alle intra-retinalen Verbindungen.

        Reihenfolge:
          1. Horizontal laterale Inhibition (Surround-Bildung)
          2. Bipolar -> Midget-Ganglion (Center-Signal, foveal + peripheral)
          3. Bipolar -> Parasol-Ganglion (nur peripheral)
          4. Amacrine-Zirkus (Input von Bipolars, Feedback auf Bipolars,
             Inhibition auf Ganglien)

        Die Reihenfolge ist unkritisch, alles sind nur Connect-Aufrufe —
        aber so bleibt die Logik nah am biologischen Pfad.
        """
        if not self._built:
            raise RuntimeError("build() muss vor connect() laufen")
        if self._connected:
            if self.verbose:
                print("WARNING: bereits verbunden")
            return self

        if self.verbose:
            print("\n=== CONNECT ===")

        self._connect_horizontal_lateral()
        self._connect_bipolar_to_midget_ganglion()
        self._connect_bipolar_to_parasol_ganglion()
        self._connect_konio_pathway()
        self._connect_amacrine_circuit()

        self._connected = True

        if self.verbose:
            total = len(nest.GetConnections())
            print(f"Intra-retinale Verbindungen: {total:,}")

        return self

    # ------------------------------------------------------------------------
    # Connection-Primitive
    # ------------------------------------------------------------------------

    def _resolve_synapse(self, stp_key: str) -> Tuple[str, Optional[Dict]]:
        """Liefert (synapse_model, stp_params) für eine Synapsen-Klasse.

        Liest 'synapse_model' aus self.params (global pro Retina).
        Bei 'static_synapse' wird stp_params = None zurückgegeben.
        Bei 'tsodyks2_synapse' wird das passende stp_<key>-Dict aus
        self.params geholt.

        Args:
            stp_key: einer von 'bipolar_to_ganglion', 'horizontal',
                     'amacrine', 'konio'. Pro Klasse können in den
                     Default-Params eigene U/tau_rec/tau_fac gesetzt sein.

        Returns:
            Tuple (synapse_model_str, stp_params_dict_or_None).
        """
        syn_model = self.params.get('synapse_model', 'static_synapse')
        if syn_model == 'static_synapse':
            return syn_model, None
        if syn_model != 'tsodyks2_synapse':
            raise ValueError(
                f"synapse_model muss 'static_synapse' oder 'tsodyks2_synapse' "
                f"sein, bekam '{syn_model}'"
            )
        stp_dict_key = f'stp_{stp_key}'
        stp = self.params.get(stp_dict_key)
        if stp is None:
            raise ValueError(
                f"synapse_model='tsodyks2_synapse' aber '{stp_dict_key}' "
                f"nicht in params gesetzt. Verfügbar: "
                f"{[k for k in self.params if k.startswith('stp_')]}"
            )
        # Validierung minimal: alle drei Keys da?
        for required in ('U', 'tau_rec', 'tau_fac'):
            if required not in stp:
                raise ValueError(
                    f"stp_{stp_key} fehlt Schlüssel '{required}': {stp}"
                )
        return syn_model, stp

    def _connect_nearest(self, src_pop, src_positions, tgt_pop, tgt_positions,
                          k: int, weight: float, delay: float = 1.0,
                          n_ribbon: int = 1,
                          synapse_model: str = 'static_synapse',
                          stp_params: Optional[Dict] = None):
        """
        Jedes Target bekommt seine k räumlich nächsten Sources als Inputs.

        ZWEI MODI je nach synapse_model:

        'static_synapse' (Default, alter Pfad):
            Ribbon-Synapse via n_ribbon parallele Static-Connects.
            Effektive synaptische Stärke = n_ribbon * weight.
            Keine Short-Term-Plasticity, keine Vesikel-Pool-Dynamik.

        'tsodyks2_synapse' (biophysisch):
            EINE Synapse pro Source-Target-Paar mit Tsodyks-Markram
            Short-Term-Depression. Vesikel-Pool wird bei jedem Spike
            entleert (Anteil U) und erholt sich exponentiell (tau_rec).
            Effektive Stärke = weight * n_ribbon, weil die Steady-State-
            Synapse mit U*x_ss ≈ U/(1+U*nu*tau_rec) gedämpft ist.
            stp_params muss U, tau_rec, tau_fac enthalten.
        """
        if len(src_pop) == 0 or len(tgt_pop) == 0 or k == 0:
            return

        k = min(k, len(src_pop))
        neighbor_idx = nearest_k_indices(src_positions, tgt_positions, k)

        src_list = src_pop.tolist()
        tgt_list = tgt_pop.tolist()

        # syn_spec einmal aufbauen, je nach Modus.
        if synapse_model == 'tsodyks2_synapse':
            if stp_params is None:
                raise ValueError(
                    "tsodyks2_synapse braucht stp_params={U, tau_rec, tau_fac}"
                )
            # Bei STP: ribbon-Multiplicity wird ins Gewicht eingerechnet,
            # NICHT als parallele Synapsen. Das ist mathematisch äquivalent
            # zu einer Synapse mit n_ribbon-fachem Gewicht, aber WICHTIG:
            # alle n_ribbon "Vesikel-Pools" teilen sich denselben State.
            # Real ist das auch so — eine Ribbon hat einen Pool, nicht 20.
            effective_weight = weight * n_ribbon
            syn_spec = {
                'synapse_model': 'tsodyks2_synapse',
                'weight': effective_weight,
                'delay': delay,
                'U': stp_params['U'],
                'tau_rec': stp_params['tau_rec'],
                'tau_fac': stp_params['tau_fac'],
            }
            n_ribbon_loops = 1  # Nur einmal connecten
        else:
            syn_spec = {'weight': weight, 'delay': delay}
            n_ribbon_loops = n_ribbon

        for tgt_idx, src_indices in enumerate(neighbor_idx):
            tgt_node = nest.NodeCollection([tgt_list[tgt_idx]])
            src_nodes = nest.NodeCollection(sorted(set(
                src_list[si] for si in src_indices
            )))
            for _ in range(n_ribbon_loops):
                nest.Connect(
                    src_nodes, tgt_node,
                    conn_spec='all_to_all',
                    syn_spec=syn_spec,
                )

    def _connect_one_to_one_ribbon(self, src_pop, tgt_pop, weight: float,
                                     delay: float = 1.0, n_ribbon: int = 1,
                                     synapse_model: str = 'static_synapse',
                                     stp_params: Optional[Dict] = None):
        """1:1 mit Ribbon-Multiplicity oder STP.

        Siehe _connect_nearest für die Modi.
        """
        if len(src_pop) == 0 or len(tgt_pop) == 0:
            return
        if len(src_pop) != len(tgt_pop):
            raise ValueError(
                f"1:1 erfordert gleiche Größe: {len(src_pop)} vs {len(tgt_pop)}"
            )

        if synapse_model == 'tsodyks2_synapse':
            if stp_params is None:
                raise ValueError(
                    "tsodyks2_synapse braucht stp_params={U, tau_rec, tau_fac}"
                )
            effective_weight = weight * n_ribbon
            syn_spec = {
                'synapse_model': 'tsodyks2_synapse',
                'weight': effective_weight,
                'delay': delay,
                'U': stp_params['U'],
                'tau_rec': stp_params['tau_rec'],
                'tau_fac': stp_params['tau_fac'],
            }
            nest.Connect(src_pop, tgt_pop, 'one_to_one', syn_spec=syn_spec)
        else:
            for _ in range(n_ribbon):
                nest.Connect(src_pop, tgt_pop, 'one_to_one',
                             syn_spec={'weight': weight, 'delay': delay})

    # ------------------------------------------------------------------------
    # Spezifische Connection-Routinen
    # ------------------------------------------------------------------------

    def _connect_horizontal_lateral(self):
        """Horizontal: Input von Bipolars, inhib Feedback auf Bipolars.

        WICHTIGER HINWEIS ZUR VEREINFACHUNG:
        Biologisch bekommen Horizontal-Zellen ihren Input direkt von den
        Photorezeptoren (Zapfen). Wir können das aber nicht so modellieren,
        weil unsere Photorezeptoren parrot_neurons sind und keine Spikes
        auslösen — der visuelle Input geht via step_current_generator an
        die Bipolars. Deswegen greifen wir HIER den OFF-Bipolar als Proxy
        für das Photorezeptor-Signal ab (OFF-Bipolar feuert invers zur
        lokalen Helligkeit, ist aber der schnellste Signalweg nach dem
        Input).

        Die resultierende Inhibition auf die Bipolars bildet dann das
        klassische Center-Surround-RF: ein Bipolar ist aktiv wenn sein
        Center hell ist UND der Surround dunkel — genau die Voraussetzung
        für Kanten- und Kontrast-Detektion.
        """
        p = self.params

        # STP-Konfiguration für diese Synapsen-Klasse
        syn_model, stp_params = self._resolve_synapse('horizontal')

        # --- Foveal-Zirkus ---
        hf = self.populations.get(POP_HORIZONTAL_FOVEAL)
        if hf is not None and POP_MIDGET_OFF_BIP_FOVEAL in self.populations:
            # Input: OFF-Bipolars foveal -> Horizontal (exzitatorisch, w=1.0).
            # k_cones_per_horizontal_foveal=5 -> jede Horizontal sammelt
            # über ~5 Bipolars -> räumliche Integration.
            self._connect_nearest(
                src_pop=self.populations[POP_MIDGET_OFF_BIP_FOVEAL],
                src_positions=self.positions[POP_MIDGET_OFF_BIP_FOVEAL],
                tgt_pop=hf,
                tgt_positions=self.positions[POP_HORIZONTAL_FOVEAL],
                k=p['k_cones_per_horizontal_foveal'],
                weight=p['w_bipolar_to_horizontal'], delay=1.0,
                n_ribbon=p['ribbon_horizontal'],
                synapse_model=syn_model, stp_params=stp_params,
            )
            # Feedback: Horizontal -> OFF-Bipolars (inhibitorisch).
            # Vorher nur OFF foveal — May 2026 erweitert auf ON+OFF foveal,
            # weil ON-foveal sonst bei dichten Stim-Mustern saturiert (142 Hz
            # statt biologischer ~50-80 Hz). Biologisch realistischer:
            # Horizontals inhibieren H1/H2-Subtypen-vermittelt beide Pfade.
            for bip_name in [POP_MIDGET_OFF_BIP_FOVEAL, POP_MIDGET_ON_BIP_FOVEAL]:
                if bip_name in self.populations:
                    self._connect_nearest(
                        src_pop=hf,
                        src_positions=self.positions[POP_HORIZONTAL_FOVEAL],
                        tgt_pop=self.populations[bip_name],
                        tgt_positions=self.positions[bip_name],
                        k=p['k_horizontals_surround_per_cone'],
                        weight=p['w_horizontal_to_cone'],
                        delay=1.5,
                        n_ribbon=p['ribbon_horizontal'],
                        synapse_model=syn_model, stp_params=stp_params,
                    )

        # --- Peripheral-Zirkus ---
        # Hier vollständiger: Input kommt von Midget-OFF UND Parasol-OFF,
        # Feedback geht auf ALLE vier Bipolar-Typen (ON+OFF × Midget+Parasol).
        hp = self.populations.get(POP_HORIZONTAL_PERIPHERAL)
        if hp is not None:
            # Exzitatorischer Input von OFF-Bipolars (beide Pfade).
            for bip_name in [POP_MIDGET_OFF_BIP_PERIPHERAL, POP_PARASOL_OFF_BIP]:
                if bip_name in self.populations:
                    self._connect_nearest(
                        src_pop=self.populations[bip_name],
                        src_positions=self.positions[bip_name],
                        tgt_pop=hp,
                        tgt_positions=self.positions[POP_HORIZONTAL_PERIPHERAL],
                        k=p['k_cones_per_horizontal_peripheral'],
                        weight=p['w_bipolar_to_horizontal'], delay=1.0,
                        n_ribbon=p['ribbon_horizontal'],
                        synapse_model=syn_model, stp_params=stp_params,
                    )
            # Inhibitorischer Feedback auf ALLE Bipolar-Typen peripheral.
            # Dadurch entsteht das Surround für alle vier Pfade.
            for bip_name in [POP_MIDGET_OFF_BIP_PERIPHERAL, POP_PARASOL_OFF_BIP,
                             POP_MIDGET_ON_BIP_PERIPHERAL, POP_PARASOL_ON_BIP]:
                if bip_name in self.populations:
                    self._connect_nearest(
                        src_pop=hp,
                        src_positions=self.positions[POP_HORIZONTAL_PERIPHERAL],
                        tgt_pop=self.populations[bip_name],
                        tgt_positions=self.positions[bip_name],
                        k=p['k_horizontals_surround_per_cone'],
                        weight=p['w_horizontal_to_cone'],
                        delay=1.5,
                        n_ribbon=p['ribbon_horizontal'],
                        synapse_model=syn_model, stp_params=stp_params,
                    )

    def _connect_bipolar_to_midget_ganglion(self):
        """Midget-Bipolar -> Midget-Ganglion. Foveal 1:1, peripheral k nearest.

        HIER wird der Midget-Pfad geschlossen. Foveal ist das die kritische
        1:1:1-Verbindung (Zapfen -> Bipolar -> Ganglion), die im menschlichen
        Auge die höchste Sehschärfe erzeugt.
        """
        p = self.params
        w = abs(p['w_bipolar_to_ganglion_midget'])
        n_ribbon = p['ribbon_bipolar_to_ganglion']  # = 20 (validiert)
        syn_model, stp_params = self._resolve_synapse('bipolar_to_ganglion')

        # --- Foveal: strikt 1:1 ---
        self._connect_one_to_one_ribbon(
            self.populations[POP_MIDGET_ON_BIP_FOVEAL],
            self.populations[POP_MIDGET_ON_GANG_FOVEAL],
            weight=w, delay=1.0, n_ribbon=n_ribbon,
            synapse_model=syn_model, stp_params=stp_params,
        )
        self._connect_one_to_one_ribbon(
            self.populations[POP_MIDGET_OFF_BIP_FOVEAL],
            self.populations[POP_MIDGET_OFF_GANG_FOVEAL],
            weight=w, delay=1.0, n_ribbon=n_ribbon,
            synapse_model=syn_model, stp_params=stp_params,
        )

        # --- Peripheral ---
        k = p['k_bipolars_per_midget_ganglion_peripheral']
        self._connect_nearest(
            src_pop=self.populations[POP_MIDGET_ON_BIP_PERIPHERAL],
            src_positions=self.positions[POP_MIDGET_ON_BIP_PERIPHERAL],
            tgt_pop=self.populations[POP_MIDGET_ON_GANG_PERIPHERAL],
            tgt_positions=self.positions[POP_MIDGET_ON_GANG_PERIPHERAL],
            k=k, weight=w, delay=1.0, n_ribbon=n_ribbon,
            synapse_model=syn_model, stp_params=stp_params,
        )
        self._connect_nearest(
            src_pop=self.populations[POP_MIDGET_OFF_BIP_PERIPHERAL],
            src_positions=self.positions[POP_MIDGET_OFF_BIP_PERIPHERAL],
            tgt_pop=self.populations[POP_MIDGET_OFF_GANG_PERIPHERAL],
            tgt_positions=self.positions[POP_MIDGET_OFF_GANG_PERIPHERAL],
            k=k, weight=w, delay=1.0, n_ribbon=n_ribbon,
            synapse_model=syn_model, stp_params=stp_params,
        )

    def _connect_bipolar_to_parasol_ganglion(self):
        """Parasol-Bipolar -> Parasol-Ganglion (k nearest).

        Nur peripheral. k=6 -> Parasol-Ganglion integriert über 6 Bipolars,
        das ergibt zusammen mit 8 Zapfen pro Bipolar ein RF aus ~48 Zapfen
        (mit Overlap durchaus ~30-40 effektive Zapfen pro Parasol-RF —
        passt zur biologisch dokumentierten Größe).
        """
        p = self.params
        w = abs(p['w_bipolar_to_ganglion_parasol'])
        n_ribbon = p['ribbon_bipolar_to_ganglion']
        k = p['k_bipolars_per_parasol_ganglion']
        syn_model, stp_params = self._resolve_synapse('bipolar_to_ganglion')

        self._connect_nearest(
            src_pop=self.populations[POP_PARASOL_ON_BIP],
            src_positions=self.positions[POP_PARASOL_ON_BIP],
            tgt_pop=self.populations[POP_PARASOL_ON_GANG],
            tgt_positions=self.positions[POP_PARASOL_ON_GANG],
            k=k, weight=w, delay=0.8, n_ribbon=n_ribbon,
            synapse_model=syn_model, stp_params=stp_params,
        )
        self._connect_nearest(
            src_pop=self.populations[POP_PARASOL_OFF_BIP],
            src_positions=self.positions[POP_PARASOL_OFF_BIP],
            tgt_pop=self.populations[POP_PARASOL_OFF_GANG],
            tgt_positions=self.positions[POP_PARASOL_OFF_GANG],
            k=k, weight=w, delay=0.8, n_ribbon=n_ribbon,
            synapse_model=syn_model, stp_params=stp_params,
        )

    def _connect_konio_pathway(self):
        """Konio-Bahn: Yellow-Surround-Inhibition + Bipolar -> Ganglion.

        Drei-Schritt-Aufbau:
          1. Midget-ON-Bipolar peripheral -> Konio-Bipolar (INHIBITORISCH).
             Yellow-Surround. Midget-ON-peripheral ist unser Proxy für L+M-
             Helligkeit (genau wie Horizontal-Surround Midget-OFF als L+M-
             Proxy nutzt — selbe Strategie, andere Vorzeichen-Konvention).
          2. Konio-Bipolar -> Konio-Ganglion (EXZITATORISCH).
             k=2 nächste Bipolare pro Ganglion.

        Center-Strom (S-Cone -> Konio-Bipolar) kommt NICHT hier, sondern via
        Feeder als step_current — analog Midget-Bipolaren. Die Mapping-Logik
        in _compute_bipolar_to_photo_mapping liefert die richtigen S-Indizes
        pro Konio-Bipolar.

        Wichtig: dieser Pfad existiert nur peripheral, weil POP_KONIO_S_BIP
        und POP_KONIO_GANG nur peripheral angelegt werden (S-Zapfen fehlen
        in der Foveola).
        """
        if POP_KONIO_S_BIP not in self.populations:
            return
        if POP_KONIO_GANG not in self.populations:
            return

        p = self.params
        syn_model, stp_params = self._resolve_synapse('konio')

        # --- Step 1: Midget-ON-Bipolar peripheral -> Konio-Bipolar (Yellow-Surround) ---
        # Negatives Gewicht erzeugt die Inhibition. Wir nehmen Midget-ON statt
        # Midget-OFF, weil Midget-ON ON-Antwort auf L+M-Helligkeit liefert
        # (entspricht "Gelb hell"). Bei Midget-OFF wäre das Vorzeichen invers.
        if POP_MIDGET_ON_BIP_PERIPHERAL in self.populations:
            w_surround = -abs(p['w_midget_to_konio_bipolar'])
            k_surround = p['k_midget_surround_per_konio_bipolar']
            n_ribbon_surround = p['ribbon_konio']
            self._connect_nearest(
                src_pop=self.populations[POP_MIDGET_ON_BIP_PERIPHERAL],
                src_positions=self.positions[POP_MIDGET_ON_BIP_PERIPHERAL],
                tgt_pop=self.populations[POP_KONIO_S_BIP],
                tgt_positions=self.positions[POP_KONIO_S_BIP],
                k=k_surround,
                weight=w_surround,
                delay=1.5,
                n_ribbon=n_ribbon_surround,
                synapse_model=syn_model, stp_params=stp_params,
            )

        # --- Step 2: Konio-Bipolar -> Konio-Ganglion ---
        w_kg = abs(p['w_konio_bipolar_to_ganglion'])
        k_kg = p['k_konio_bipolars_per_konio_ganglion']
        n_ribbon_kg = p['ribbon_konio']
        self._connect_nearest(
            src_pop=self.populations[POP_KONIO_S_BIP],
            src_positions=self.positions[POP_KONIO_S_BIP],
            tgt_pop=self.populations[POP_KONIO_GANG],
            tgt_positions=self.positions[POP_KONIO_GANG],
            k=k_kg,
            weight=w_kg,
            delay=1.0,
            n_ribbon=n_ribbon_kg,
            synapse_model=syn_model, stp_params=stp_params,
        )

    def _connect_amacrine_circuit(self):
        """Amacrine: Input von Bipolars, inhib Output auf Bipolars + Ganglien.

        Dreischritt:
          1. Bipolar -> Amacrine (exzitatorisch)
          2. Amacrine -> Ganglion (inhibitorisch) — moduliert Output
          3. Amacrine -> Bipolar (inhibitorisch, Feedback) — reziprok

        Die Delays stufen sich: Input (1.0ms) -> Inhibition-auf-Ganglion (1.5ms)
        -> Feedback-auf-Bipolar (2.0ms). Dadurch folgt die Inhibition zeitlich
        der Aktivierung — das erzeugt transiente Antworten (Bipolar-Burst
        wird schnell durch Amacrine-Feedback gedämpft).

        Peripheral: ALLE vier Bipolar-Typen beteiligt.
        Foveal: NUR Midget-ON/OFF (kein Parasol-Pfad foveal).
        """
        p = self.params
        # Gewichte: abs(...) stellt sicher dass Input positiv, Inhibition negativ.
        w_bip_in = abs(p['w_bipolar_to_amacrine'])
        w_amac_gang = -abs(p['w_amacrine_to_ganglion'])
        w_amac_bip = -abs(p['w_amacrine_to_bipolar'])
        k_bip2amac = p['k_bipolars_per_amacrine']
        k_amac2gang = p['k_amacrines_per_ganglion']
        k_amac2bip = p['k_amacrines_per_bipolar_feedback']
        n_ribbon = p['ribbon_amacrine']
        syn_model, stp_params = self._resolve_synapse('amacrine')

        # --- Peripheral-Zirkus ---
        ap = self.populations.get(POP_AMACRINE_PERIPHERAL)
        if ap is not None:
            ap_pos = self.positions[POP_AMACRINE_PERIPHERAL]

            # Step 1: Bipolar -> Amacrine (exzitatorisch).
            for bip_name in [POP_MIDGET_ON_BIP_PERIPHERAL, POP_MIDGET_OFF_BIP_PERIPHERAL,
                             POP_PARASOL_ON_BIP, POP_PARASOL_OFF_BIP]:
                if bip_name not in self.populations:
                    continue
                self._connect_nearest(
                    src_pop=self.populations[bip_name],
                    src_positions=self.positions[bip_name],
                    tgt_pop=ap, tgt_positions=ap_pos,
                    k=k_bip2amac, weight=w_bip_in, delay=1.0,
                    n_ribbon=n_ribbon,
                    synapse_model=syn_model, stp_params=stp_params,
                )

            # Step 2: Amacrine -> Ganglion (inhibitorisch).
            for gang_name in [POP_MIDGET_ON_GANG_PERIPHERAL, POP_MIDGET_OFF_GANG_PERIPHERAL,
                              POP_PARASOL_ON_GANG, POP_PARASOL_OFF_GANG]:
                if gang_name not in self.populations:
                    continue
                self._connect_nearest(
                    src_pop=ap, src_positions=ap_pos,
                    tgt_pop=self.populations[gang_name],
                    tgt_positions=self.positions[gang_name],
                    k=k_amac2gang, weight=w_amac_gang, delay=1.5,
                    n_ribbon=n_ribbon,
                    synapse_model=syn_model, stp_params=stp_params,
                )

            # Step 3: Amacrine -> Bipolar (inhibitorisches Feedback).
            for bip_name in [POP_MIDGET_ON_BIP_PERIPHERAL, POP_MIDGET_OFF_BIP_PERIPHERAL,
                             POP_PARASOL_ON_BIP, POP_PARASOL_OFF_BIP]:
                if bip_name not in self.populations:
                    continue
                self._connect_nearest(
                    src_pop=ap, src_positions=ap_pos,
                    tgt_pop=self.populations[bip_name],
                    tgt_positions=self.positions[bip_name],
                    k=k_amac2bip, weight=w_amac_bip, delay=2.0,
                    n_ribbon=n_ribbon,
                    synapse_model=syn_model, stp_params=stp_params,
                )

        # --- Foveal-Zirkus ---
        af = self.populations.get(POP_AMACRINE_FOVEAL)
        if af is not None:
            af_pos = self.positions[POP_AMACRINE_FOVEAL]

            for bip_name in [POP_MIDGET_ON_BIP_FOVEAL, POP_MIDGET_OFF_BIP_FOVEAL]:
                if bip_name in self.populations:
                    self._connect_nearest(
                        src_pop=self.populations[bip_name],
                        src_positions=self.positions[bip_name],
                        tgt_pop=af, tgt_positions=af_pos,
                        k=min(k_bip2amac, len(self.populations[bip_name])),
                        weight=w_bip_in, delay=1.0, n_ribbon=n_ribbon,
                        synapse_model=syn_model, stp_params=stp_params,
                    )

            for gang_name in [POP_MIDGET_ON_GANG_FOVEAL, POP_MIDGET_OFF_GANG_FOVEAL]:
                if gang_name in self.populations:
                    self._connect_nearest(
                        src_pop=af, src_positions=af_pos,
                        tgt_pop=self.populations[gang_name],
                        tgt_positions=self.positions[gang_name],
                        k=min(k_amac2gang, len(af)),
                        weight=w_amac_gang, delay=1.5, n_ribbon=n_ribbon,
                        synapse_model=syn_model, stp_params=stp_params,
                    )

    # ========================================================================
    # FEEDER ERZEUGEN
    # ========================================================================

    def create_input_feeder(self, config: Optional[Dict] = None) -> RetinaInputFeeder:
        """
        Erzeugt einen RetinaInputFeeder als externe Input-Schnittstelle.

        Args:
            config: Dict, mergt mit DEFAULT_FEEDER_CONFIG.
                Keys: 'generator_type' ('step_current' oder 'poisson'),
                      'input_resolution' (Zweierpotenz-Tuple),
                      'max_current_pa', 'max_rate_hz', 'poisson_weight_nS'

        Returns:
            Eigenständiger Feeder für externe Nutzung.

        Der Feeder wird NICHT in self gespeichert — der Caller ist dafür
        verantwortlich, ihn zu halten. Damit kann theoretisch auch mehrere
        Feeder an eine Retina gehängt werden (z.B. für A/B-Testing von
        Input-Modi), aber das ist eher ein edge-case.
        """
        if not self._built:
            raise RuntimeError("build() muss vor create_input_feeder() laufen")

        config = config or {}

        # Nur Bipolar-Populationen an den Feeder geben — Photorezeptoren
        # sind parrot_neurons und bekommen keinen Input (siehe Section 1).
        bipolar_pops = {
            name: self.populations[name]
            for name in BIPOLAR_POPS
            if name in self.populations
        }

        feeder = RetinaInputFeeder(
            config=config,
            bipolar_populations=bipolar_pops,
            bipolar_to_photo_mapping=self._bipolar_to_photo_mapping,
            origin=self._origin,
            world_radius=self.params['radius'],
            min_delay=self.params['min_delay'],
        )

        # Photo-Positionen nachreichen — die braucht der Feeder für das
        # 3D->2D-Sampling in _sample_frame.
        photo_positions = {
            name: self.positions[name]
            for name in PHOTORECEPTOR_POPS
            if name in self.positions
        }
        feeder.set_photo_positions(photo_positions)

        if self.verbose:
            total_gens = sum(len(g) for g in feeder.generators.values())
            print(f"\n=== FEEDER: {feeder.generator_type}, "
                  f"{total_gens} Generatoren, "
                  f"resolution={feeder.config['input_resolution']} ===")

        return feeder

    # ========================================================================
    # PUBLIC API
    # ========================================================================
    # Alle Getter geben Kopien/flache Kopien zurück, damit der Caller
    # nicht versehentlich den Retina-State mutieren kann.

    def get_populations(self) -> Dict[str, 'nest.NodeCollection']:
        """Alle NEST-Populationen als Dict. Für eigene Connect-Aufrufe."""
        return dict(self.populations)

    def get_output_populations(self) -> Dict[str, 'nest.NodeCollection']:
        """Nur die Ganglien — das sind die "Sehnerv-Fasern".

        Hier an den LGN dran-connecten. Alle anderen Populationen sind
        intra-retinale Stufen und sollten kein Downstream-Target haben.
        """
        return {k: v for k, v in self.populations.items() if k in GANGLION_POPS}

    def get_photoreceptor_populations(self) -> Dict[str, 'nest.NodeCollection']:
        """Nur die Photorezeptoren (parrot_neurons). Primär für Debugging/Viz."""
        return {k: v for k, v in self.populations.items() if k in PHOTORECEPTOR_POPS}

    def get_positions(self) -> Dict[str, np.ndarray]:
        """3D-Positionen aller Populationen (inkl. Origin-Offset)."""
        return dict(self.positions)

    def get_counts(self) -> Dict[str, int]:
        """Populationsgrößen."""
        return dict(self.counts)

    def get_origin(self) -> np.ndarray:
        """Origin-Offset (für Multi-Agent-Setups nützlich). copy() weil np-Array."""
        return self._origin.copy()

    # ------------------------------------------------------------------------
    # Grid-Bucket-Mapping (Position → Pixel-Bucket → NEST-IDs)
    # ------------------------------------------------------------------------

    def _compute_grid_maps(self):
        """Build-time: cache Default-Grid-Maps für alle Pops.

        Resultat in self._grid_maps und self._id_to_bucket.
        """
        H, W = self.params['bucket_resolution']
        if self.verbose:
            print(f"\n=== GRID-MAPS (default cache): bucket_resolution=({H}, {W}) ===")

        grid_maps, id_to_bucket = self._compute_grid_for_resolution(
            H, W, verbose=self.verbose)
        self._grid_maps = grid_maps
        self._id_to_bucket = id_to_bucket

    def _compute_grid_for_resolution(self, H: int, W: int,
                                      verbose: bool = False
                                     ) -> Tuple[
                                         Dict[str, Dict[Tuple[int, int], List[int]]],
                                         Dict[str, Dict[int, Tuple[int, int]]]
                                     ]:
        """Berechne (forward, reverse) Grid-Maps für beliebige (H, W)-Auflösung.

        Logik identisch zu Feeder._sample_frame: x->col, z->row, y ignoriert.
        """
        world_r = self.params['radius']
        origin = self._origin

        grid_maps: Dict[str, Dict[Tuple[int, int], List[int]]] = {}
        id_to_bucket: Dict[str, Dict[int, Tuple[int, int]]] = {}

        for pop_name, pop in self.populations.items():
            positions = self.positions.get(pop_name)
            if positions is None or len(positions) == 0:
                continue

            rel = positions - origin
            x = rel[:, 0]
            z = rel[:, 2]
            u = (x / world_r + 1.0) / 2.0
            v = (z / world_r + 1.0) / 2.0
            col = np.clip((u * W).astype(int), 0, W - 1)
            row = np.clip((v * H).astype(int), 0, H - 1)

            nest_ids = pop.tolist()
            grid: Dict[Tuple[int, int], List[int]] = {}
            id_map: Dict[int, Tuple[int, int]] = {}
            for idx, nest_id in enumerate(nest_ids):
                key = (int(row[idx]), int(col[idx]))
                if key not in grid:
                    grid[key] = []
                grid[key].append(nest_id)
                id_map[nest_id] = key

            grid_maps[pop_name] = grid
            id_to_bucket[pop_name] = id_map

            if verbose:
                max_occ = max((len(v) for v in grid.values()), default=0)
                print(f"  {pop_name:<35}  n={len(nest_ids):>6}  "
                      f"occupied_buckets={len(grid):>6}  max_per_bucket={max_occ}")

        return grid_maps, id_to_bucket

    def get_grid_maps(self, resolution: Optional[Tuple[int, int]] = None
                      ) -> Dict[str, Dict[Tuple[int, int], List[int]]]:
        """Pixel-Bucket-Mapping pro Population (sparse).

        Args:
            resolution: optional (H, W). None = cached default.
                        Sonst on-the-fly für andere Auflösung.

        Returns:
            Dict[pop_name -> Dict[(row, col) -> list[nest_id]]].
        """
        if resolution is None:
            return dict(self._grid_maps)
        H, W = resolution
        if not isinstance(H, int) or not isinstance(W, int):
            raise ValueError(f"resolution muss (int, int) sein, bekam {resolution}")
        if H < 2 or W < 2:
            raise ValueError(f"resolution zu klein: {resolution}, mindestens (2, 2)")
        grid_maps, _ = self._compute_grid_for_resolution(H, W, verbose=False)
        return grid_maps

    def get_id_to_bucket(self, resolution: Optional[Tuple[int, int]] = None
                         ) -> Dict[str, Dict[int, Tuple[int, int]]]:
        """Reverse-Map: nest_id -> (row, col) pro Population."""
        if resolution is None:
            return dict(self._id_to_bucket)
        H, W = resolution
        _, id_to_bucket = self._compute_grid_for_resolution(H, W, verbose=False)
        return id_to_bucket

    def get_bucket_resolution(self) -> Tuple[int, int]:
        """Aktive Default-Bucket-Resolution (H, W)."""
        return tuple(self.params['bucket_resolution'])

    # ========================================================================
    # DIAGNOSTIK
    # ========================================================================

    def print_counts(self):
        """Sauber formatierter Größenreport, gruppiert nach Zelltyp."""
        if not self.counts:
            self.compute_counts()

        print("\n=== POPULATIONS-GRÖSSEN ===")
        # Gruppierung spiegelt die Pathway-Struktur wider: Photorezeptoren
        # oben, dann Horizontal, dann Bipolar (Midget+Parasol), dann Amacrine,
        # dann Ganglien unten (output layer).
        groups = [
            ("Photoreceptors", PHOTORECEPTOR_POPS),
            ("Horizontal", [POP_HORIZONTAL_FOVEAL, POP_HORIZONTAL_PERIPHERAL]),
            ("Midget Bipolars", [POP_MIDGET_ON_BIP_FOVEAL, POP_MIDGET_OFF_BIP_FOVEAL,
                                   POP_MIDGET_ON_BIP_PERIPHERAL, POP_MIDGET_OFF_BIP_PERIPHERAL]),
            ("Parasol Bipolars", [POP_PARASOL_ON_BIP, POP_PARASOL_OFF_BIP]),
            ("Amacrine", [POP_AMACRINE_FOVEAL, POP_AMACRINE_PERIPHERAL]),
            ("Midget Ganglions", [POP_MIDGET_ON_GANG_FOVEAL, POP_MIDGET_OFF_GANG_FOVEAL,
                                    POP_MIDGET_ON_GANG_PERIPHERAL, POP_MIDGET_OFF_GANG_PERIPHERAL]),
            ("Parasol Ganglions", [POP_PARASOL_ON_GANG, POP_PARASOL_OFF_GANG]),
        ]
        for group_name, pops in groups:
            print(f"\n  [{group_name}]")
            for pop in pops:
                if pop in self.counts:
                    print(f"    {pop:<40} {self.counts[pop]:>6}")

        print(f"\n  TOTAL: {sum(self.counts.values()):,}")

    def create_spike_recorders(self, attach: bool = True) -> Dict[str, 'nest.NodeCollection']:
        """Erzeugt einen spike_recorder pro Population.

        Convenience-Methode fürs Debugging — verbindet ALLE Populationen
        inklusive Photorezeptoren (die spiken zwar nicht selbst, aber
        nested-Connects könnten indirekt Events erzeugen, v.a. wenn jemand
        die parrot_neurons später ersetzt).

        Für Production lieber selektiv aufzeichnen (nur Ganglien ->
        spart massiv RAM bei langen Simulationen).

        Args:
            attach: Wenn False, wird kein einziger Recorder erzeugt;
                    Methode liefert ein leeres Dict. Spiegelt das
                    connect_recorders-Flag von retina_factory.build_retina_array
                    für API-Konsistenz; default True für Backwards-Compat.
        """
        if not attach:
            return {}
        recorders = {}
        for name, pop in self.populations.items():
            sr = nest.Create('spike_recorder')
            nest.Connect(pop, sr)
            recorders[name] = sr
        return recorders
