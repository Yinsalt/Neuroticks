"""Gemeinsamer, veränderlicher Laufzeit-Zustand (Graph-Liste, ID-Zähler, Flags).

Werte, die neu gebunden werden (next_graph_id, POLYNOM_NOISE_LEVEL,
_nest_simulation_has_run, successful_neuron_models), immer als ``state.NAME``
ansprechen - nie per ``from neuroticks.state import NAME`` kopieren.
"""
from neuron_toolbox import successful_neuron_models

current_graph_metadata = []
graph_parameters = {}
next_graph_id = 0
POLYNOM_NOISE_LEVEL = 0.05

_nest_simulation_has_run = False


graph_list = []
