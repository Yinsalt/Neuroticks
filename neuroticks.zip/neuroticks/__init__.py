"""Neuroticks: GUI und Werkzeuge zum Bauen und Simulieren von NEST-Netzwerken."""
