"""Kernlogik: Verbindungen, Graph-Aufbau, Export."""
