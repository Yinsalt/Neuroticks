"""Validierung und Ausführung von Verbindungen in NEST (ConnectionExecutor)."""
from typing import Any, Dict, List, Tuple

import nest

from neuron_toolbox import clear_dopa_vt_cache, dopa_vt_to_param_value, get_or_create_dopa_vt
from neuroticks.constants.synapses import CONNECTION_RULES, SYNAPSE_MODELS
from neuroticks.utils.nest_helpers import get_receptor_type_for_model
from neuroticks.utils.spatial import (
    create_anisotropic_weight, create_distance_dependent_delay,
    create_distance_dependent_probability, create_distance_dependent_weight,
    create_nest_mask,
)

def create_connection_dict(
    connection_id: int,
    name: str,
    source_graph_id: int,
    source_node_id: int,
    source_pop_id: int,
    target_graph_id: int,
    target_node_id: int,
    target_pop_id: int,
    rule: str = 'all_to_all',
    synapse_model: str = 'static_synapse',
    weight: float = 1.0,
    delay: float = 1.0,
    allow_autapses: bool = False,
    allow_multapses: bool = True,
    **extra_params
) -> Dict[str, Any]:
    return {
        'id': connection_id,
        'name': name,
        'source': {
            'graph_id': source_graph_id,
            'node_id': source_node_id,
            'pop_id': source_pop_id
        },
        'target': {
            'graph_id': target_graph_id,
            'node_id': target_node_id,
            'pop_id': target_pop_id
        },
        'params': {
            'rule': rule,
            'synapse_model': synapse_model,
            'weight': weight,
            'delay': delay,
            'allow_autapses': allow_autapses,
            'allow_multapses': allow_multapses,
            **extra_params
        }
    }


def validate_delay(delay: float, resolution: float = None) -> float:
    if resolution is None:
        try:
            resolution = nest.resolution
        except Exception:
            resolution = 0.1
    
    if delay < resolution:
        print(f"⚠ Delay {delay}ms < resolution {resolution}ms, adjusting to {resolution}ms")
        return resolution
    return delay


def validate_connection_params(params: Dict[str, Any]) -> Tuple[Dict, Dict, List[str]]:
    warnings = []
    
    gui_keys = {
        'use_spatial',
        'mask_type', 'mask_radius', 'mask_inner_radius', 'mask_size',
        'lower_left', 'upper_right',
        'major_axis', 'minor_axis', 'polar_axis',
        'distance_dependent_weight', 'dist_factor', 'dist_offset',
        'weight_mode',
        'p_profile', 'p_sigma',
        'distance_dependent_delay', 'delay_factor',
        'use_anchor', 'anchor',
        'anisotropic_weight', 'aniso_mode',
        'aniso_theta_deg', 'aniso_freq', 'aniso_sigma',
        'custom_name', 'base_model', 'topology_type'
    }

    rule = params.get('rule', 'all_to_all')
    synapse_model = params.get('synapse_model', 'static_synapse')
    use_spatial = bool(params.get('use_spatial', False))
    
    conn_spec = {'rule': rule}
    
    if rule in CONNECTION_RULES:
        rule_params = CONNECTION_RULES[rule]['params']
        for p in rule_params:
            if p in params:
                conn_spec[p] = params[p]
    
    if rule == 'fixed_indegree' and 'indegree' not in conn_spec: conn_spec['indegree'] = 1
    if rule == 'fixed_outdegree' and 'outdegree' not in conn_spec: conn_spec['outdegree'] = 1
    if rule == 'fixed_total_number' and 'N' not in conn_spec: conn_spec['N'] = 10
    if rule == 'pairwise_bernoulli' and 'p' not in conn_spec: conn_spec['p'] = 0.1
    
    # Distance-dependent connection probability — only meaningful for bernoulli
    if use_spatial and rule == 'pairwise_bernoulli':
        profile = params.get('p_profile', 'constant')
        sigma = float(params.get('p_sigma', 1.0))
        p_max = float(conn_spec.get('p', 1.0))
        if profile != 'constant':
            try:
                conn_spec['p'] = create_distance_dependent_probability(p_max, profile, sigma)
            except Exception as e:
                warnings.append(f"distance-dep p ({profile}) failed: {e} → using constant {p_max}")
                conn_spec['p'] = p_max
    
    conn_spec['allow_autapses'] = params.get('allow_autapses', True)
    conn_spec['allow_multapses'] = params.get('allow_multapses', True)
    
    syn_spec = {'synapse_model': synapse_model}
    
    # Weight: scalar / distance-dependent / anisotropic
    base_weight = float(params.get('weight', 1.0))
    if use_spatial and params.get('anisotropic_weight'):
        try:
            syn_spec['weight'] = create_anisotropic_weight(
                base_weight,
                theta_deg=float(params.get('aniso_theta_deg', 0.0)),
                freq=float(params.get('aniso_freq', 1.0)),
                mode=params.get('aniso_mode', 'cosine'),
                sigma=float(params.get('aniso_sigma', 1.0)),
            )
        except Exception as e:
            warnings.append(f"anisotropic weight failed: {e} → using base {base_weight}")
            syn_spec['weight'] = base_weight
    elif use_spatial and params.get('distance_dependent_weight'):
        mode = params.get('weight_mode', 'linear')
        factor = float(params.get('dist_factor', 1.0))
        offset = float(params.get('dist_offset', 0.0))
        try:
            syn_spec['weight'] = create_distance_dependent_weight(
                base_weight, factor, offset, mode
            )
        except Exception as e:
            warnings.append(f"distance-dep weight failed: {e} → using base {base_weight}")
            syn_spec['weight'] = base_weight
    else:
        syn_spec['weight'] = base_weight
    
    # Delay: scalar or distance-dependent
    base_delay = validate_delay(float(params.get('delay', 1.0)))
    if use_spatial and params.get('distance_dependent_delay'):
        factor = float(params.get('delay_factor', 0.0))
        try:
            syn_spec['delay'] = create_distance_dependent_delay(base_delay, factor, 'linear')
        except Exception as e:
            warnings.append(f"distance-dep delay failed: {e} → using base {base_delay}")
            syn_spec['delay'] = base_delay
    else:
        syn_spec['delay'] = base_delay
    
    if 'receptor_type' in params and params['receptor_type'] != 0:
        syn_spec['receptor_type'] = int(params['receptor_type'])

    known_syn_params = set()
    if synapse_model in SYNAPSE_MODELS:
        model_params_def = SYNAPSE_MODELS[synapse_model].get('params', {})
        for param_name in model_params_def:
            known_syn_params.add(param_name)
            if param_name in params:
                syn_spec[param_name] = params[param_name]
    
    handled_keys = {'rule', 'synapse_model', 'weight', 'delay',
                    'allow_autapses', 'allow_multapses', 'indegree',
                    'outdegree', 'N', 'p', 'receptor_type'}
    
    for key, value in params.items():
        if key in handled_keys: continue
        if key in gui_keys: continue
        if key in known_syn_params: continue
        
        warnings.append(f"Ignored unknown parameter '{key}' (not in known synapse params)")
    
    return conn_spec, syn_spec, warnings


class ConnectionExecutor:

    
    def __init__(self, graphs: Dict[int, Any]):

        self.graphs = graphs
        self._connection_counter = 0
        self._created_models: List[str] = []
        # Note: dopamine volume_transmitters are managed by the shared
        # module-level cache in neuron_toolbox (_DOPA_VT_CACHE) so that
        # both this executor and the Node._build_single_connection path
        # see the same vt's. See get_or_create_dopa_vt / clear_dopa_vt_cache.
    
    def _get_next_connection_id(self) -> int:
        self._connection_counter += 1
        return self._connection_counter
    
    def _get_population(self, graph_id: int, node_id: int, pop_id: int):
        if graph_id not in self.graphs:
            return None, f"Graph {graph_id} not found"
        
        graph = self.graphs[graph_id]
        node = graph.get_node(node_id)
        
        if node is None:
            return None, f"Node {node_id} not in Graph {graph_id}"
        
        if not node.population:
            return None, f"Node {node_id} has no populations"
        
        if pop_id >= len(node.population):
            return None, f"Pop {pop_id} not in Node {node_id}"
        
        pop = node.population[pop_id]
        if pop is None or len(pop) == 0:
            return None, f"Pop {pop_id} is empty"
        
        return pop, None
    
    def _get_or_create_vt(self, da_source: Dict[str, int]):
        """
        Thin wrapper around the shared module-level dopa-vt cache from
        neuron_toolbox. Kept as an instance method so call sites in
        execute_connection don't need to change.
        """
        return get_or_create_dopa_vt(
            da_source,
            graph_registry=self.graphs,
        )
    


    def execute_connection(self, connection: Dict[str, Any]) -> Tuple[bool, str]:
        import copy
        import time
        
        try:
            source_info = connection['source']
            target_info = connection['target']
            params = connection.get('params', {})
            conn_name = connection.get('name', f"Conn_{connection.get('id', '?')}")
            
            src_pop, err = self._get_population(
                source_info['graph_id'],
                source_info['node_id'],
                source_info['pop_id']
            )
            if err:
                return False, f"Source: {err}"
            
            tgt_pop, err = self._get_population(
                target_info['graph_id'],
                target_info['node_id'],
                target_info['pop_id']
            )
            if err:
                return False, f"Target: {err}"
            
            topo_type = params.get('topology_type')
            
            if topo_type == 'ring_ccw':
                src_ids = nest.GetStatus(src_pop, 'global_id')
                tgt_ids = nest.GetStatus(tgt_pop, 'global_id')
                
                n = len(src_ids)
                if len(tgt_ids) != n:
                    return False, f"CCW Ring requires equal size (Src: {n}, Tgt: {len(tgt_ids)})"
                
                w = float(params.get('weight', 10.0))
                d = float(params.get('delay', 1.0))
                
                pre_neurons = []
                post_neurons = []
                
                for i in range(n):
                    pre = src_ids[i]
                    post = tgt_ids[(i + 1) % n]
                    pre_neurons.append(pre)
                    post_neurons.append(post)
                
                nest.Connect(pre_neurons, post_neurons,
                             {'rule': 'one_to_one'},
                             {'weight': w, 'delay': d, 'synapse_model': 'static_synapse'})

                try:
                    src_graph = self.graphs.get(source_info['graph_id'])
                    if src_graph:
                        src_node_obj = src_graph.get_node(source_info['node_id'])
                        if src_node_obj:
                            if not hasattr(src_node_obj, 'connections'):
                                src_node_obj.connections = []
                            
                            exists = False
                            for existing in src_node_obj.connections:
                                if existing.get('id') == connection.get('id'):
                                    exists = True; break
                            
                            if not exists:
                                conn_copy = copy.deepcopy(connection)
                                src_node_obj.connections.append(conn_copy)
                                # Sync mit parameters['connections'] -- beide sind
                                # Save-Quellen (Main.py 2092 + 2098). Drift hier
                                # erzeugt inkonsistente JSON-Saves (outer hat conn,
                                # inner nicht). Gleiche Referenz, damit GUI-Edits
                                # in beide Listen propagieren.
                                if 'connections' not in src_node_obj.parameters:
                                    src_node_obj.parameters['connections'] = []
                                src_node_obj.parameters['connections'].append(conn_copy)
                            
                            # Backref pflegen: damit Node.remove() später
                            # diese Connection in src_node_obj.connections
                            # findet (über tgt_node.prev). add_neighbor ist
                            # idempotent — bei CCW-Self-Loop egal, bei
                            # Cross-Node-Ring kritisch.
                            try:
                                tgt_g = self.graphs.get(connection.get('target', {}).get('graph_id'))
                                if tgt_g:
                                    tgt_n = tgt_g.get_node(connection.get('target', {}).get('node_id'))
                                    if tgt_n:
                                        src_node_obj.add_neighbor(tgt_n)
                            except Exception:
                                pass
                except Exception as e:
                    print(f"Warning: Could not save ring connection to model: {e}")
                
                return True, f"✓ CCW Ring created ({n} connections)"

            
            try:
                target_model = nest.GetStatus(tgt_pop, 'model')[0]
            except Exception:
                target_model = 'unknown'
            
            if 'ht_neuron' in str(target_model):
                rec_map = {1: 'AMPA', 2: 'NMDA', 3: 'GABA_A', 4: 'GABA_B'}
                current_rec = params.get('receptor_type', 0)
                if isinstance(current_rec, int) and current_rec in rec_map:
                    params['receptor_type'] = rec_map[current_rec]
                elif current_rec == 0:
                    params.pop('receptor_type', None)
            
            rule = params.get('rule', 'all_to_all')
            conn_spec = {'rule': rule}
            
            if rule == 'fixed_indegree':
                conn_spec['indegree'] = int(params.get('indegree', 1))
            elif rule == 'fixed_outdegree':
                conn_spec['outdegree'] = int(params.get('outdegree', 1))
            elif rule == 'fixed_total_number':
                conn_spec['N'] = int(params.get('N', 1))
            elif 'bernoulli' in rule:
                conn_spec['p'] = float(params.get('p', 0.1))
            
            conn_spec['allow_autapses'] = params.get('allow_autapses', True)
            conn_spec['allow_multapses'] = params.get('allow_multapses', True)
            
            if params.get('use_spatial', False):
                mask_type = params.get('mask_type', 'spherical')
                mask_params = {
                    'radius': params.get('mask_radius', 1.0),
                    'r': params.get('mask_radius', 1.0),
                    'inner_radius': params.get('mask_inner_radius', 0.0),
                    'outer_radius': params.get('mask_radius', 1.0),
                    'mask_inner_radius': params.get('mask_inner_radius', 0.0),
                    'mask_radius': params.get('mask_radius', 1.0),
                    'size': params.get('mask_radius', 1.0),
                    'use_anchor': params.get('use_anchor', False),
                    'anchor': params.get('anchor', None),
                    # Asymmetric box and ellipsoid axes pass-through
                    'lower_left': params.get('lower_left', None),
                    'upper_right': params.get('upper_right', None),
                    'major_axis': params.get('major_axis', None),
                    'minor_axis': params.get('minor_axis', None),
                    'polar_axis': params.get('polar_axis', None),
                }
                
                # Map old aliases to canonical names; new types pass through.
                mask_type_map = {
                    'sphere': 'spherical', 'spherical': 'spherical',
                    'box': 'rectangular', 'rectangular': 'rectangular',
                    'box_asym': 'box_asym',
                    'doughnut': 'doughnut',
                    'elliptical': 'elliptical',
                    'ellipsoidal': 'ellipsoidal',
                }
                actual_type = mask_type_map.get(mask_type, 'spherical')
                mask = create_nest_mask(actual_type, mask_params)
                if mask is not None:
                    conn_spec['mask'] = mask
                
                # Distance-dependent connection probability (gauss/exp/linear).
                if 'bernoulli' in rule:
                    profile = params.get('p_profile', 'constant')
                    if profile != 'constant':
                        p_max = float(params.get('p', 1.0))
                        sigma = float(params.get('p_sigma', 1.0))
                        try:
                            conn_spec['p'] = create_distance_dependent_probability(
                                p_max, profile, sigma
                            )
                        except Exception as e:
                            print(f"distance-dep p failed: {e} (using constant {p_max})")
            
            base_model = params.get('synapse_model', 'static_synapse')
            no_delay = base_model in ['gap_junction', 'rate_connection_instantaneous']
            
            # Dopamine-modulated synapses need a volume_transmitter bound at
            # CopyModel time, otherwise NEST refuses with BadProperty. Each
            # dopa connection must declare a 'da_source' field naming the pop
            # that provides dopamine spikes. vt's are cached per DA source so
            # multiple dopa connections from the same DA pop share one vt.
            vt_for_this_conn = None
            if 'stdp_dopamine' in base_model:
                da_source_info = connection.get('da_source')
                if da_source_info is None:
                    return False, (
                        f"{base_model} requires 'da_source' field "
                        "(specify which population provides dopamine spikes)"
                    )
                vt_for_this_conn, vt_err = self._get_or_create_vt(da_source_info)
                if vt_err:
                    return False, f"VT setup failed: {vt_err}"
            
            control_keys = {
                'rule', 'indegree', 'outdegree', 'N', 'p',
                'synapse_model', 'weight', 'delay',
                'allow_autapses', 'allow_multapses', 'receptor_type',
                'use_spatial', 'mask_type', 'mask_radius', 'mask_inner_radius',
                'lower_left', 'upper_right',
                'major_axis', 'minor_axis', 'polar_axis',
                'distance_dependent_weight', 'dist_factor', 'dist_offset',
                'weight_mode',
                'p_profile', 'p_sigma',
                'distance_dependent_delay', 'delay_factor',
                'use_anchor', 'anchor',
                'anisotropic_weight', 'aniso_mode',
                'aniso_theta_deg', 'aniso_freq', 'aniso_sigma',
                'custom_name', 'no_delay', 'base_model'
            }
            
            model_params = {
                k: v for k, v in params.items()
                if k not in control_keys and v is not None
            }
            
            # Inject vt into model_params — must happen even if model_params
            # was otherwise empty, else CopyModel won't trigger and we'd
            # connect with the unbound base model (BadProperty).
            if vt_for_this_conn is not None:
                try:
                    vt_prop_name, vt_prop_value = dopa_vt_to_param_value(vt_for_this_conn)
                    model_params[vt_prop_name] = vt_prop_value
                except Exception as e:
                    return False, f"vt property setup failed: {e}"
            
            final_model = base_model
            if model_params:
                ts = int(time.time() * 1e6)
                custom_name = params.get('custom_name') or f"{base_model}_{self._connection_counter}_{ts}"
                try:
                    nest.CopyModel(base_model, custom_name, model_params)
                    final_model = custom_name
                    self._created_models.append(custom_name)
                except Exception as e:
                    print(f"CopyModel failed: {e}, using {base_model}")
            
            syn_spec = {'synapse_model': final_model}
            
            weight = float(params.get('weight', 1.0))
            if params.get('use_spatial') and params.get('anisotropic_weight'):
                # Anisotropic (orientation-tuned) takes precedence over plain
                # distance-dependent weight if both are accidentally enabled.
                syn_spec['weight'] = create_anisotropic_weight(
                    weight,
                    theta_deg=float(params.get('aniso_theta_deg', 0.0)),
                    freq=float(params.get('aniso_freq', 1.0)),
                    mode=params.get('aniso_mode', 'cosine'),
                    sigma=float(params.get('aniso_sigma', 1.0)),
                )
            elif params.get('use_spatial') and params.get('distance_dependent_weight'):
                mode = params.get('weight_mode', 'linear')
                factor = float(params.get('dist_factor', 1.0))
                offset = float(params.get('dist_offset', 0.0))
                syn_spec['weight'] = create_distance_dependent_weight(weight, factor, offset, mode)
            else:
                syn_spec['weight'] = weight
            
            if not no_delay:
                delay = float(params.get('delay', 1.0))
                base_delay = max(delay, nest.resolution)
                if params.get('use_spatial') and params.get('distance_dependent_delay'):
                    factor = float(params.get('delay_factor', 0.0))
                    syn_spec['delay'] = create_distance_dependent_delay(base_delay, factor, 'linear')
                else:
                    syn_spec['delay'] = base_delay
            
            receptor = params.get('receptor_type')
            if receptor is not None and receptor != 0:
                syn_spec['receptor_type'] = receptor
            else:
                # Auto-detect MC models
                try:
                    target_model = nest.GetStatus(tgt_pop[0], 'model')[0]
                    auto_receptor = get_receptor_type_for_model(target_model, excitatory=(weight >= 0))
                    if auto_receptor > 0:
                        syn_spec['receptor_type'] = auto_receptor
                except Exception: pass  # Model may not support receptor_type
            
            if rule == 'one_to_one' and len(src_pop) != len(tgt_pop):
                return False, f"one_to_one size mismatch: {len(src_pop)} vs {len(tgt_pop)}"
            
            nest.Connect(src_pop, tgt_pop, conn_spec, syn_spec)
            
            try:
                src_graph = self.graphs.get(source_info['graph_id'])
                tgt_graph = self.graphs.get(target_info['graph_id'])

                if src_graph and tgt_graph:
                    src_node_obj = src_graph.get_node(source_info['node_id'])
                    tgt_node_obj = tgt_graph.get_node(target_info['node_id'])

                    if src_node_obj and tgt_node_obj:
                        
                        if not hasattr(src_node_obj, 'connections'):
                            src_node_obj.connections = []
                        
                        exists = False
                        for existing in src_node_obj.connections:
                            if existing.get('id') == connection.get('id'):
                                exists = True
                                break
                        
                        if not exists:
                            conn_copy = copy.deepcopy(connection)
                            src_node_obj.connections.append(conn_copy)
                            # Sync mit parameters['connections'] -- beide sind
                            # Save-Quellen (Main.py 2092 + 2098). Drift hier
                            # erzeugt inkonsistente JSON-Saves.
                            if 'connections' not in src_node_obj.parameters:
                                src_node_obj.parameters['connections'] = []
                            src_node_obj.parameters['connections'].append(conn_copy)
                            
                        src_node_obj.add_neighbor(tgt_node_obj)
                    
                return True, f"✓ {conn_name} created"

            except Exception as save_err:
                print(f"Warning: Connection created in NEST but failed to save to Model: {save_err}")
                return True, f"✓ {conn_name} (Model save failed)"

        except Exception as e:
            import traceback
            traceback.print_exc()
            return False, str(e)


    def execute_pending_connections(self, connections: List[Dict[str, Any]]) -> Tuple[int, int, List[Dict[str, Any]]]:

        success_count = 0
        fail_count = 0
        failed_items = []

        print(f"Processing {len(connections)} pending connections...")

        for conn in connections:
            success, msg = self.execute_connection(conn)
            
            if success:
                success_count += 1
                print(f"  {msg}")
            else:
                fail_count += 1
                conn['error'] = msg
                failed_items.append(conn)
                print(f"  ✗ {conn.get('name', '?')}: {msg}")

        return success_count, fail_count, failed_items
    
    def execute_all(self, connections: List[Dict[str, Any]],
                   progress_callback=None) -> Tuple[int, int, List[str]]:
        
        created = 0
        failed = 0
        errors = []
        total = len(connections)
        
        print(f"\nCreating {total} connections...")
        
        for i, conn in enumerate(connections):
            success, msg = self.execute_connection(conn)
            
            if success:
                created += 1
                print(f"  {msg}")
            else:
                failed += 1
                err_msg = f"✗ {conn.get('name', '?')}: {msg}"
                errors.append(err_msg)
                print(f"  {err_msg}")
            
            if progress_callback:
                progress_callback(i + 1, total, msg)
        
        print(f"\nConnections: {created} created, {failed} failed")
        
        return created, failed, errors
    
    def cleanup_custom_models(self):

        self._created_models.clear()
        # Drop cached vt references — they're dead gids after ResetKernel.
        # Uses the shared cache from neuron_toolbox, so this also resets
        # the Node._build_single_connection path's view of vt's.
        try:
            clear_dopa_vt_cache()
        except NameError:
            # neuron_toolbox not imported with * at module level (defensive)
            pass
