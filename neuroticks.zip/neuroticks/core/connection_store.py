"""Gespeicherte Verbindungen: neu aufbauen, bereinigen, exportieren, importieren."""
import copy
import time
from typing import Any, Dict, List, Optional, Tuple

import nest

from neuron_toolbox import clear_dopa_vt_cache, dopa_vt_to_param_value, get_or_create_dopa_vt
from neuroticks import state
from neuroticks.core.connection_executor import validate_connection_params

def prune_dangling_connections(
    graphs: Dict[int, Any],
    verbose: bool = True
) -> int:
    """
    Walks every node.connections list and drops entries whose source or
    target node no longer exists in the current graphs. Also walks the
    parameters['connections'] mirror.
    
    This is the safety net for in-memory drift: cross-graph predecessors
    that were never registered in node.prev (e.g. because the project
    file was loaded with an older code path), or any other case where
    Node.remove() couldn't reach a connection entry.
    
    Returns: number of dangling connections removed.
    """
    # Build a fast lookup of (graph_id, node_id) -> bool over what exists
    # right now. Use the actual node_list as ground truth (not node_dict
    # — that one was bugged for a while; this function is the cleanup).
    alive = set()
    for g in graphs.values():
        for n in g.node_list:
            alive.add((g.graph_id, n.id))
    
    def _is_alive(endpoint):
        if not isinstance(endpoint, dict):
            return False
        return (endpoint.get('graph_id'), endpoint.get('node_id')) in alive
    
    removed = 0
    for graph_id, graph in graphs.items():
        for node in graph.node_list:
            if not getattr(node, 'connections', None):
                continue
            kept = []
            for conn in node.connections:
                src_ok = _is_alive(conn.get('source', {}))
                tgt_ok = _is_alive(conn.get('target', {}))
                if src_ok and tgt_ok:
                    kept.append(conn)
                else:
                    removed += 1
                    if verbose:
                        s = conn.get('source', {})
                        t = conn.get('target', {})
                        nm = conn.get('name', '?')
                        why = []
                        if not src_ok: why.append(f"src G{s.get('graph_id')}N{s.get('node_id')} gone")
                        if not tgt_ok: why.append(f"tgt G{t.get('graph_id')}N{t.get('node_id')} gone")
                        print(f"  prune: dropping {nm} ({', '.join(why)})")
            node.connections = kept
            
            # Mirror in parameters['connections'] if present
            if hasattr(node, 'parameters') and isinstance(node.parameters, dict):
                if 'connections' in node.parameters and node.parameters['connections']:
                    node.parameters['connections'] = [
                        c for c in node.parameters['connections']
                        if _is_alive(c.get('source', {})) and _is_alive(c.get('target', {}))
                    ]
    
    if verbose and removed > 0:
        print(f"prune_dangling_connections: dropped {removed} stale connection(s)")
    return removed


def _find_reward_trigger_fallback(graphs: Dict[int, Any]) -> Optional[Dict]:
    """Backward-compat: locate a single REWARD_TRIGGER node across all graphs.
    
    Used when loading a project from before format v221 — those saves don't
    have da_source on stdp_dopamine_synapse connections. If exactly one node
    named REWARD_TRIGGER (case-sensitive — that's the canonical name in
    Basal Ganglia) exists with a non-empty population[0], we use it as the
    default da_source. Zero or multiple matches → returns None and the
    caller raises a clear error so the user can fix it in the editor.
    """
    candidates = []
    for graph in graphs.values():
        for node in getattr(graph, 'node_list', []):
            if getattr(node, 'name', '') != 'REWARD_TRIGGER':
                continue
            pops = getattr(node, 'population', None) or []
            if not pops or pops[0] is None or len(pops[0]) == 0:
                continue
            candidates.append({
                'graph_id': int(graph.graph_id),
                'node_id':  int(node.id),
                'pop_id':   0,
            })
    if len(candidates) == 1:
        return candidates[0]
    return None


def create_nest_connections_from_stored(
    graphs: Dict[int, Any],
    verbose: bool = True
) -> Tuple[int, int, List[Dict]]:
    
    total_created = 0
    total_failed = 0
    failed_connections = []
    
    if verbose:
        print("\n" + "="*60)
        print("RECREATING ALL STORED CONNECTIONS")
        print("="*60)
    
    # Safety net: drop any connection pointing at a node that no longer
    # exists. Catches drift from older project loads, mid-session deletes
    # that couldn't reach cross-graph predecessors, etc.
    prune_dangling_connections(graphs, verbose=verbose)
    
    all_connections = []
    
    for graph_id, graph in graphs.items():
        if verbose:
            print(f"\nGraph {graph_id} ({graph.graph_name}):")
        
        for node in graph.node_list:
            if node.connections:
                if verbose:
                    print(f"Node {node.id} ({node.name}): {len(node.connections)} connections")
                
                for conn in node.connections:
                    all_connections.append(conn)
    
    if not all_connections:
        if verbose:
            print("\nNo stored connections found")
        return 0, 0, []
    
    if verbose:
        print(f"\nTotal connections to recreate: {len(all_connections)}")
    
    for conn in all_connections:
        conn_name = conn.get('name', f"Connection_{conn['id']}")
        source = conn['source']
        target = conn['target']
        params = conn['params']
        
        try:
            source_graph = graphs.get(source['graph_id'])
            target_graph = graphs.get(target['graph_id'])
            
            if source_graph is None:
                raise ValueError(f"Source graph {source['graph_id']} not found")
            if target_graph is None:
                raise ValueError(f"Target graph {target['graph_id']} not found")
            
            source_node = source_graph.get_node(source['node_id'])
            target_node = target_graph.get_node(target['node_id'])
            
            if source_node is None:
                raise ValueError(f"Source node {source['node_id']} not found")
            if target_node is None:
                raise ValueError(f"Target node {target['node_id']} not found")
            
            if not source_node.population or source['pop_id'] >= len(source_node.population):
                raise ValueError(f"Source population {source['pop_id']} not available")
            if not target_node.population or target['pop_id'] >= len(target_node.population):
                raise ValueError(f"Target population {target['pop_id']} not available")
            
            source_pop = source_node.population[source['pop_id']]
            target_pop = target_node.population[target['pop_id']]
            
            if source_pop is None or len(source_pop) == 0:
                raise ValueError("Source population is empty")
            if target_pop is None or len(target_pop) == 0:
                raise ValueError("Target population is empty")
            
            conn_spec, syn_spec, warnings = validate_connection_params(params)
            
            if conn_spec['rule'] == 'one_to_one' and len(source_pop) != len(target_pop):
                raise ValueError(f"one_to_one: size mismatch ({len(source_pop)} vs {len(target_pop)})")
            
            # ── Dopamine-modulated synapses need a volume_transmitter ──
            # bound at CopyModel time, otherwise nest.Connect() throws
            # BadProperty: 'required parameter "volume_transmitter" not set'.
            # The Connection-Tool's executor handles this in execute_connection
            # (line ~7099); the same logic must live here too, otherwise
            # *every* Dopa connection fails on project load. v223 has 33 of
            # them — that's exactly the symptom the user reported.
            base_model = syn_spec.get('synapse_model', 'static_synapse')
            if 'stdp_dopamine' in base_model:
                da_source = conn.get('da_source')
                
                # Backward-compat: pre-v221 saves don't have da_source. If
                # the project has exactly one node named REWARD_TRIGGER we
                # use that as the default. Anything more ambiguous (zero or
                # multiple candidates) requires manual fix in the editor.
                if da_source is None:
                    fallback = _find_reward_trigger_fallback(graphs)
                    if fallback is not None:
                        da_source = fallback
                        # Persist the fallback back onto the connection so the
                        # next save no longer needs the heuristic. User-visible
                        # warning so they know we made a decision.
                        conn['da_source'] = dict(fallback)
                        if verbose:
                            print(f"  ⚠ {conn_name}: da_source missing — "
                                  f"falling back to single REWARD_TRIGGER "
                                  f"({fallback}). Will be persisted on next save.")
                    else:
                        raise ValueError(
                            f"{base_model} requires 'da_source' field. "
                            f"Pre-v221 saves are missing this. "
                            f"Open the connection in the Connection Editor, "
                            f"pick a DA-source pop, save, and reload."
                        )
                
                vt, vt_err = get_or_create_dopa_vt(da_source, graph_registry=graphs)
                if vt_err:
                    raise ValueError(f"vt setup failed: {vt_err}")
                
                # Build a CopyModel'd variant with vt + dopa params bound at
                # the model level (NEST refuses these via syn_spec). All other
                # params stay on syn_spec.
                vt_prop_name, vt_prop_value = dopa_vt_to_param_value(vt)
                model_overrides = {vt_prop_name: vt_prop_value}
                dopa_keys = ('tau_plus', 'tau_c', 'tau_n',
                             'A_plus', 'A_minus', 'b', 'n', 'c',
                             'Wmax', 'Wmin')
                for k in dopa_keys:
                    if k in params and params[k] is not None:
                        model_overrides[k] = params[k]
                
                ts = int(time.time() * 1e6)
                cloned_name = (params.get('custom_name')
                               or f"{base_model}_load_{conn.get('id', '?')}_{ts}")
                try:
                    nest.CopyModel(base_model, cloned_name, model_overrides)
                    syn_spec['synapse_model'] = cloned_name
                except Exception as e:
                    raise ValueError(f"CopyModel for {base_model} failed: {e}")
            
            nest.Connect(source_pop, target_pop, conn_spec, syn_spec)
            
            total_created += 1
            if verbose:
                print(f"  ✓ {conn_name}: G{source['graph_id']}N{source['node_id']}P{source['pop_id']} → "
                      f"G{target['graph_id']}N{target['node_id']}P{target['pop_id']}")
        
        except Exception as e:
            total_failed += 1
            print(f"  ✗ {conn_name}: {str(e)}")
            error_msg = str(e)
            failed_connections.append({**conn, 'error': error_msg})
            if verbose:
                print(f"  ✗ {conn_name}: {error_msg}")
    
    if verbose:
        print(f"✓ Created: {total_created} | ✗ Failed: {total_failed}")
    
    return total_created, total_failed, failed_connections


def repopulate_all_graphs(graphs: Dict[int, Any], verbose: bool = False) -> int:

    total_pops = 0
    
    if verbose:
        print("REPOPULATING ALL GRAPHS")
    
    for graph_id, graph in graphs.items():
        if verbose:
            print(f"\nGraph {graph_id} ({graph.graph_name}):")
        
        for node in graph.node_list:
            try:
                if not node.positions or all(len(c) == 0 for c in node.positions):
                    if verbose:
                        print(f"Building Node {node.id}...")
                    node.build()
                
                if verbose:
                    print(f"Populating Node {node.id}...")
                node.populate_node()
                
                n_pops = len(node.population) if node.population else 0
                total_pops += n_pops
                
                if verbose:
                    print(f"    ✓ {n_pops} populations created")
            
            except Exception as e:
                if verbose:
                    print(f"    ✗ Error: {e}")
    
    if verbose:
        print(f"\n✓ Total populations created: {total_pops}")
    
    return total_pops


def safe_nest_reset_and_repopulate(
    graphs: Dict[int, Any],
    enable_structural_plasticity: bool = False,
    verbose: bool = True
) -> Dict[str, Any]:
    
    if verbose:
        print("# SAFE NEST RESET AND REPOPULATE")
    
    if verbose:
        print("\nResetting NEST kernel...")
    
    import os
    output_dir = "Simulation_History"
    os.makedirs(output_dir, exist_ok=True)
    
    nest.ResetKernel()
    
    # CRITICAL: clear the dopa-VT cache BEFORE rebuilding. The cache holds
    # NodeCollection refs from the previous kernel — those GIDs are dead
    # after ResetKernel and any new dopa connection would fail with
    # 'UnknownNode' or worse, silently bind to the wrong neuron.
    clear_dopa_vt_cache()
    
    nest.SetKernelStatus({
        "data_path": output_dir,      
        "overwrite_files": True,      
        "print_time": False,
        "resolution": 0.1
    })

    state._nest_simulation_has_run = False
    
    if enable_structural_plasticity:
        try:
            nest.EnableStructuralPlasticity()
            if verbose:
                print("✓ Structural plasticity enabled")
        except Exception as e:
            if verbose:
                print(f"Could not enable structural plasticity: {e}")
            enable_structural_plasticity = False
    
    total_pops = repopulate_all_graphs(graphs, verbose=verbose)
    
    created, failed, failed_list = create_nest_connections_from_stored(graphs, verbose=verbose)
    
    result = {
        'populations_created': total_pops,
        'connections_created': created,
        'connections_failed': failed,
        'failed_connections': failed_list,
        'structural_plasticity': enable_structural_plasticity
    }
    
    if verbose:
        print("# RESET COMPLETE")
        print(f"# Populations: {total_pops}")
        print(f"# Connections: {created} created, {failed} failed")
    
    return result


def get_all_connections_summary(graphs: Dict[int, Any]) -> Dict[str, Any]:

    summary = {
        'total_connections': 0,
        'by_graph': {},
        'by_synapse_model': {},
        'by_rule': {}
    }
    
    for graph_id, graph in graphs.items():
        graph_conns = 0
        
        for node in graph.node_list:
            n_conns = len(node.connections) if node.connections else 0
            graph_conns += n_conns
            
            for conn in (node.connections or []):
                params = conn.get('params', {})
                
                model = params.get('synapse_model', 'static_synapse')
                summary['by_synapse_model'][model] = summary['by_synapse_model'].get(model, 0) + 1
                
                rule = params.get('rule', 'all_to_all')
                summary['by_rule'][rule] = summary['by_rule'].get(rule, 0) + 1
        
        summary['by_graph'][graph_id] = graph_conns
        summary['total_connections'] += graph_conns
    
    return summary


def clear_all_connections(graphs: Dict[int, Any], verbose: bool = True) -> int:
    
    total_cleared = 0
    
    for graph_id, graph in graphs.items():
        for node in graph.node_list:
            if node.connections:
                n = len(node.connections)
                node.connections = []
                total_cleared += n
    
    if verbose:
        print(f"✓ Cleared {total_cleared} connections from all graphs")
    
    return total_cleared


def export_connections_to_dict(graphs: Dict[int, Any]) -> List[Dict]:
    
    all_connections = []
    
    for graph_id, graph in graphs.items():
        for node in graph.node_list:
            for conn in (node.connections or []):
                all_connections.append(copy.deepcopy(conn))
    
    return all_connections


def import_connections_from_dict(
    graphs: Dict[int, Any],
    connections: List[Dict],
    clear_existing: bool = True
) -> int:
    
    if clear_existing:
        clear_all_connections(graphs, verbose=False)
    
    imported = 0
    
    for conn in connections:
        source = conn.get('source', {})
        graph_id = source.get('graph_id')
        node_id = source.get('node_id')
        
        if graph_id in graphs:
            node = graphs[graph_id].get_node(node_id)
            if node is not None:
                conn_copy = copy.deepcopy(conn)
                node.connections.append(conn_copy)
                # Sync mit parameters['connections'] -- beide sind Save-Quellen
                # (Main.py 2092 + 2098). Drift hier erzeugt inkonsistente
                # JSON-Saves nach Import-Workflow.
                if 'connections' not in node.parameters:
                    node.parameters['connections'] = []
                node.parameters['connections'].append(conn_copy)
                
                # Backref pflegen: ohne add_neighbor sind nach Import alle
                # prev-Listen leer und Node.remove() saeubert nichts.
                try:
                    tgt = conn.get('target', {})
                    tgt_graph = graphs.get(tgt.get('graph_id'))
                    if tgt_graph:
                        tgt_node = tgt_graph.get_node(tgt.get('node_id'))
                        if tgt_node:
                            node.add_neighbor(tgt_node)
                except Exception:
                    pass
                
                imported += 1
    
    return imported


def create_connection_from_gui_params(
    source_graph_id: int,
    source_node_id: int,
    source_pop_id: int,
    target_graph_id: int,
    target_node_id: int,
    target_pop_id: int,
    rule: str,
    synapse_model: str,
    weight: float,
    delay: float,
    allow_autapses: bool = False,
    allow_multapses: bool = True,
    connection_name: str = None,
    indegree: int = None,
    outdegree: int = None,
    N: int = None,
    p: float = None,
    **synapse_params
) -> Dict[str, Any]:
    
    params = {
        'rule': rule,
        'synapse_model': synapse_model,
        'weight': weight,
        'delay': delay,
        'allow_autapses': allow_autapses,
        'allow_multapses': allow_multapses,
    }
    
    if indegree is not None:
        params['indegree'] = indegree
    if outdegree is not None:
        params['outdegree'] = outdegree
    if N is not None:
        params['N'] = N
    if p is not None:
        params['p'] = p
    
    params.update(synapse_params)
    
    return {
        'source_graph_id': source_graph_id,
        'source_node_id': source_node_id,
        'source_pop_id': source_pop_id,
        'target_graph_id': target_graph_id,
        'target_node_id': target_node_id,
        'target_pop_id': target_pop_id,
        'params': params,
        'name': connection_name
    }
