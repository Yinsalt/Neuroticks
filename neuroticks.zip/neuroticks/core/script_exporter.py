"""Export eines Projekts als eigenständiges Headless-Skript (run.py + graphs.json)."""
import json
import os
import shutil

import numpy as np

from neuroticks.paths import PROJECT_ROOT

class ScriptExporter:
    def __init__(self, graph_list):
        self.graph_list = graph_list

    def export_project(self, parent_dir, folder_name, duration=1000.0, threads=1):
        # 1. Create Project Directory
        base_path = os.path.join(parent_dir, folder_name)
        try:
            os.makedirs(base_path, exist_ok=True)
        except Exception as e:
            print(f"Error creating directory: {e}")
            return False

        # 2. Define File Paths
        json_filename = "graphs.json"
        script_filename = "run.py"
        toolbox_filename = "neuron_toolbox.py"
        models_filename = "functional_models.json"
        
        json_path = os.path.join(base_path, json_filename)
        script_path = os.path.join(base_path, script_filename)
        toolbox_dest_path = os.path.join(base_path, toolbox_filename)
        models_dest_path = os.path.join(base_path, models_filename)

        # 3. Serialize and Write JSON
        project_data = self._serialize_graphs()
        try:
            with open(json_path, 'w', encoding='utf-8') as f:
                # Local import to ensure encoder is available
                from neuroticks.utils.serialization import NumpyEncoder 
                json.dump(project_data, f, cls=NumpyEncoder, indent=2)
        except Exception as e:
            print(f"Error saving JSON: {e}")
            return False

        # 4. Copy Auxiliary Files (Toolbox & Models)
        current_dir = PROJECT_ROOT
        
        # Copy neuron_toolbox.py
        try:
            src_path = "neuron_toolbox.py"
            if not os.path.exists(src_path):
                src_path = os.path.join(current_dir, "neuron_toolbox.py")

            if os.path.exists(src_path):
                shutil.copy(src_path, toolbox_dest_path)
            else:
                print(f"Warning: neuron_toolbox.py not found.")
        except Exception as e:
            print(f"Error copying toolbox: {e}")

        # Copy functional_models.json
        try:
            mod_path = "functional_models.json"
            if not os.path.exists(mod_path):
                mod_path = os.path.join(current_dir, "functional_models.json")
            
            if os.path.exists(mod_path):
                shutil.copy(mod_path, models_dest_path)
            else:
                print("Warning: functional_models.json not found.")
        except Exception as e:
            print(f"Error copying models json: {e}")

        # 5. Generate and Write Python Script
        script_content = self._get_template(json_filename, duration, threads)
        try:
            with open(script_path, 'w', encoding='utf-8') as f:
                f.write(script_content)
        except Exception as e:
            print(f"Error saving script: {e}")
            return False

        print(f"Export successful to: {base_path}")
        return True

    def _serialize_graphs(self):
        from neuroticks.utils.serialization import _clean_params, _serialize_connections
        
        data = {'graphs': []}
        for graph in self.graph_list:
            nodes_data = []
            for node in graph.node_list:
                positions = [pos.tolist() if isinstance(pos, np.ndarray) else list(pos) 
                             for pos in node.positions] if hasattr(node, 'positions') and node.positions else []
                
                devices = []
                source_devs = getattr(node, 'devices', [])
                if not source_devs and 'devices' in node.parameters:
                    source_devs = node.parameters['devices']

                for d in source_devs:
                    d_copy = d.copy()
                    if 'runtime_gid' in d_copy: del d_copy['runtime_gid']
                    if 'params' in d_copy: d_copy['params'] = _clean_params(d_copy['params'])
                    devices.append(d_copy)

                safe_params = _clean_params(node.parameters) if hasattr(node, 'parameters') else {}
                
                # FIX: Get population_nest_params from BOTH sources, preferring node.parameters
                pop_nest_params = []
                # First try node.parameters (most reliable source after editing)
                if hasattr(node, 'parameters') and 'population_nest_params' in node.parameters:
                    pop_nest_params = node.parameters.get('population_nest_params', [])
                # Fallback to node attribute
                if not pop_nest_params and hasattr(node, 'population_nest_params'):
                    pop_nest_params = getattr(node, 'population_nest_params', [])
                
                # Clean the params
                cleaned_pop_params = [_clean_params(p) if p else {} for p in pop_nest_params]
                
                # Debug: Log what we're saving
                if cleaned_pop_params:
                    print(f"  Saving Node {node.id} ({node.name}): {len(cleaned_pop_params)} pop_nest_params")
                    for idx, p in enumerate(cleaned_pop_params):
                        if p:
                            print(f"    Pop {idx}: V_th={p.get('V_th', 'N/A')}, C_m={p.get('C_m', 'N/A')}, t_ref={p.get('t_ref', 'N/A')}")
                
                # Per-pop shape_params_per_pop is the single most important
                # array for tool-type nodes (CCW / Cone / Blob). It already
                # rides along inside safe_params, but we mirror it on the
                # top-level so the headless run.py can pick it up via either
                # path (matches load_and_build's fallback logic).
                shape_params_per_pop = (
                    node.parameters.get('shape_params_per_pop')
                    if hasattr(node, 'parameters') else None
                ) or []
                # Clean any numpy values
                cleaned_shape_pp = [_clean_params(sp) if sp else {} for sp in shape_params_per_pop]
                
                node_data = {
                    'id': node.id,
                    'name': getattr(node, 'name', f"Node_{node.id}"),
                    'graph_id': graph.graph_id,
                    'neuron_models': node.neuron_models,
                    'positions': positions,
                    'devices': devices,
                    'connections': _serialize_connections(node.connections) if hasattr(node, 'connections') else [],
                    'population_nest_params': cleaned_pop_params,
                    'shape_params_per_pop': cleaned_shape_pp,
                    'tool_type': safe_params.get('tool_type', 'custom'),
                    'parameters': safe_params
                }
                
                if hasattr(node, 'center_of_mass'):
                    node_data['center_of_mass'] = list(node.center_of_mass) if isinstance(node.center_of_mass, np.ndarray) else node.center_of_mass
                if hasattr(node, 'types'):
                    node_data['types'] = list(node.types)

                nodes_data.append(node_data)
            
            data['graphs'].append({
                'graph_id': graph.graph_id,
                'graph_name': getattr(graph, 'graph_name', f'Graph_{graph.graph_id}'),
                'max_nodes': graph.max_nodes,
                'init_position': list(graph.init_position) if hasattr(graph, 'init_position') else [0,0,0],
                'polynom_max_power': getattr(graph, 'polynom_max_power', 5),
                'polynom_decay': getattr(graph, 'polynom_decay', 0.8),
                'nodes': nodes_data
            })
        return data
    def _get_template(self, json_filename, duration, threads):
        return f'''"""
Headless run script for a Neuroticks project export.

Layout:
  ./graphs.json            project data (nodes, connections, devices)
  ./neuron_toolbox.py      core builders (Graph, Node, populate_node)
  ./functional_models.json model presets (optional, for graph creator UI)
  ./run.py                 this file
  ./Simulation_History/    output JSON files (created on first run)

What this script does:
  1. Resets NEST and loads graphs.json
  2. Rebuilds every graph + node (per-pop shape_params, neuron models,
     NEST params, devices) — uses the same populate_node() path as the GUI
  3. Cross-graph backref pass so prune_dangling_connections() can clean
     up stale references safely
  4. Builds connections via Graph.build_connections() with the full set
     of spatial features (mask, distance-dep p / weight / delay,
     anchor offsets, anisotropic / orientation-tuned weights)
  5. Runs nest.Simulate() in DUMP_INTERVAL chunks, flushing recorders
     after each chunk
  6. Writes a history JSON loadable in the Neuroticks History browser
"""
import nest
import numpy as np
import json
import os
import sys
import copy
from pathlib import Path
from datetime import datetime
from neuron_toolbox import Graph, Node, PolynomGenerator

# === CONFIGURATION ===
JSON_FILENAME = "{json_filename}"
SIM_DURATION = {duration}
DUMP_INTERVAL = 2000.0
OUTPUT_DIR = Path("Simulation_History")
NUM_THREADS = {threads}

# Build-time prints can be silenced by toggling this BEFORE load_and_build().
# Maps to neuron_toolbox.VERBOSE_BUILD if available.
VERBOSE_BUILD = False


class NumpyNestEncoder(json.JSONEncoder):
    def default(self, obj):
        if hasattr(obj, "tolist"): return obj.tolist()
        if isinstance(obj, (np.int64, np.int32, np.integer)): return int(obj)
        if isinstance(obj, (np.float64, np.float32, np.floating)): return float(obj)
        if isinstance(obj, np.ndarray): return obj.tolist()
        return super().default(obj)


def _get_nest_time():
    """NEST 3.x exposes simulated time as biological_time. The legacy
    \\"time\\" key returns 0 in 3.8 and was the source of a long-running
    timer bug in the GUI. Same fix here for consistency in logs."""
    try:
        st = nest.GetKernelStatus()
        return float(st.get("biological_time", st.get("time", 0.0)) or 0.0)
    except Exception:
        return 0.0


def load_and_build():
    print("Initializing NEST...")
    nest.ResetKernel()
    nest.SetKernelStatus({{
        "resolution": 0.1,
        "print_time": False,
        "local_num_threads": NUM_THREADS,
    }})
    try:
        nest.EnableStructuralPlasticity()
    except Exception:
        # Not all NEST builds enable this by default — non-fatal.
        pass

    # Toggle build-time verbosity in neuron_toolbox if the flag exists
    try:
        import neuron_toolbox
        if hasattr(neuron_toolbox, "VERBOSE_BUILD"):
            neuron_toolbox.VERBOSE_BUILD = bool(VERBOSE_BUILD)
    except Exception:
        pass

    script_dir = os.path.dirname(os.path.abspath(__file__))
    json_path = os.path.join(script_dir, JSON_FILENAME)
    if not os.path.exists(json_path):
        print(f"CRITICAL ERROR: JSON file not found: {{json_path}}")
        sys.exit(1)

    with open(json_path, "r") as f:
        data = json.load(f)

    graphs = {{}}
    print(f"Loading {{len(data.get('graphs', []))}} graphs...")

    for g_data in data.get("graphs", []):
        g_id = g_data["graph_id"]
        graph = Graph(
            graph_name=g_data.get("graph_name", f"Graph_{{g_id}}"),
            graph_id=g_id,
            max_nodes=g_data.get("max_nodes", 100),
            position=g_data.get("init_position", [0, 0, 0]),
            polynom_max_power=g_data.get("polynom_max_power", 5),
            polynom_decay=g_data.get("polynom_decay", 0.8),
        )

        sorted_nodes = sorted(g_data.get("nodes", []), key=lambda x: x.get("id", 0))
        for nd in sorted_nodes:
            params = (nd.get("parameters", {{}}) or {{}}).copy()
            devs = nd.get("devices", []) or []
            pop_nest_params = nd.get("population_nest_params", []) or []

            # Per-pop shape params (CCW / Cone / Blob geometry, syn config,
            # connection rule, etc.). Only present in newer saves; older
            # files just have node-global tool params, which the build
            # functions already fall back to.
            shape_params_per_pop = (
                params.get("shape_params_per_pop")
                or nd.get("shape_params_per_pop")
                or []
            )

            params.update({{
                "id": nd["id"],
                "name": nd["name"],
                "graph_id": g_id,
                "connections": nd.get("connections", []),
                "devices": devs,
                "neuron_models": nd.get("neuron_models", ["iaf_psc_alpha"]),
                "types": nd.get("types", [0]),
                "population_nest_params": pop_nest_params,
                "shape_params_per_pop": shape_params_per_pop,
            }})

            if "positions" in nd and nd["positions"]:
                params["positions"] = [np.array(p) for p in nd["positions"]]

            node = graph.create_node(
                parameters=params,
                is_root=(nd["id"] == 0),
                auto_build=False,
            )

            if "center_of_mass" in nd:
                node.center_of_mass = np.array(nd["center_of_mass"])
            if "positions" in params:
                node.positions = params["positions"]

            node.connections = nd.get("connections", [])
            node.devices = devs
            node.population_nest_params = pop_nest_params

            # Some node types need build() before populate (e.g. WFC custom
            # without serialized positions). Tool nodes generate their own
            # positions inside populate_node().
            if not getattr(node, "positions", None):
                try:
                    node.build()
                except Exception:
                    pass
            elif all(len(p) == 0 for p in node.positions if p is not None):
                try:
                    node.build()
                except Exception:
                    pass

            node.populate_node()

        graphs[g_id] = graph

    # --- Cross-graph topology backrefs ---
    # Without this, prev/next lists only contain same-graph predecessors.
    # If anything later wants to walk inverse edges (e.g. lifecycle cleanup),
    # it would miss every cross-graph link. Mirrors the GUI project-load fix.
    print("Reconstructing cross-graph topology...")
    global_lookup = {{(g.graph_id, n.id): n for g in graphs.values() for n in g.node_list}}
    for graph in graphs.values():
        for node in graph.node_list:
            for conn in (node.connections or []):
                tgt = conn.get("target", {{}}) or {{}}
                tn = global_lookup.get((tgt.get("graph_id"), tgt.get("node_id")))
                if tn is not None and hasattr(node, "add_neighbor"):
                    try:
                        node.add_neighbor(tn)
                    except Exception:
                        pass

    print("Building Connections...")
    for graph in graphs.values():
        graph.build_connections(external_graphs=graphs)

    return graphs


def cache_active_recorders(graphs):
    active_recorders = []
    for graph in graphs.values():
        for node in graph.node_list:
            if not hasattr(node, "devices"):
                continue
            for dev in node.devices:
                gid_col = dev.get("runtime_gid")
                if gid_col is None:
                    continue
                try:
                    if hasattr(gid_col, "tolist"):
                        gid_int = int(gid_col.tolist()[0])
                    elif isinstance(gid_col, list):
                        gid_int = int(gid_col[0])
                    else:
                        gid_int = int(gid_col)
                except (ValueError, TypeError, IndexError):
                    continue

                model = dev.get("model", "")
                if "recorder" in model or "meter" in model:
                    try:
                        node_handle = nest.NodeCollection([gid_int])
                        active_recorders.append({{
                            "handle": node_handle,
                            "graph_id": graph.graph_id,
                            "node_id": node.id,
                            "device_id": str(dev["id"]),
                            "model": model,
                        }})
                    except Exception as e:
                        print(f"Error caching device {{gid_int}}: {{e}}")

    print(f"Cached {{len(active_recorders)}} active recording devices.")
    if len(active_recorders) == 0:
        print("WARNING: No spike_recorders or multimeters found.")
        print("  Simulation will run but no data will be collected.")
    return active_recorders


def collect_and_flush(active_recorders):
    """Pull buffered events out of every recorder and reset the counter,
    so memory doesn't grow unbounded over long runs."""
    collected = {{}}
    total_events = 0

    for rec in active_recorders:
        try:
            status = nest.GetStatus(rec["handle"])[0]
            n_events = status.get("n_events", 0)
            if n_events > 0:
                events = status.get("events", {{}})
                clean_data = {{
                    k: v.tolist() if isinstance(v, np.ndarray) else list(v)
                    for k, v in events.items()
                }}
                key = (rec["graph_id"], rec["node_id"], rec["device_id"])
                collected[key] = {{"model": rec["model"], "data": clean_data}}
                total_events += n_events
                nest.SetStatus(rec["handle"], {{"n_events": 0}})
        except Exception as e:
            print(f"Read error on device {{rec['device_id']}}: {{e}}")

    return collected, total_events


def build_history_file(graphs, accumulated_runs):
    history = {{
        "meta": {{
            "version": "3.0",
            "type": "neuroticks_history",
            "timestamp": str(datetime.now()),
            "source": "headless_export",
        }},
        "graphs": [],
    }}

    for graph in graphs.values():
        g_entry = {{
            "graph_id": graph.graph_id,
            "graph_name": getattr(graph, "graph_name", f"Graph_{{graph.graph_id}}"),
            "nodes": [],
        }}

        for node in graph.node_list:
            clean_devices = []
            for dev in getattr(node, "devices", []):
                d_copy = dev.copy()
                d_copy.pop("runtime_gid", None)
                clean_devices.append(d_copy)

            n_entry = {{
                "id": node.id,
                "name": getattr(node, "name", f"Node_{{node.id}}"),
                "neuron_models": getattr(node, "neuron_models", []),
                "types": getattr(node, "types", []),
                "devices": clean_devices,
                "results": {{"history": []}},
            }}

            for run_data in accumulated_runs:
                run_entry = {{"devices": {{}}}}
                for (gid, nid, did), dev_result in run_data.items():
                    if gid == graph.graph_id and nid == node.id:
                        run_entry["devices"][did] = dev_result
                if run_entry["devices"]:
                    n_entry["results"]["history"].append(run_entry)

            g_entry["nodes"].append(n_entry)

        history["graphs"].append(g_entry)
    return history


def main():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = OUTPUT_DIR / f"history_headless_{{timestamp}}.json"

    print(f"Simulation START. Output: {{output_file}}")
    graphs = load_and_build()
    recorders = cache_active_recorders(graphs)

    current_time = 0.0
    step_count = 0
    accumulated_runs = []

    print(f"Simulating {{SIM_DURATION}} ms (dump every {{DUMP_INTERVAL}} ms)...")
    while current_time < SIM_DURATION:
        step = min(DUMP_INTERVAL, SIM_DURATION - current_time)
        nest.Simulate(step)
        # Use NEST's biological_time as the authoritative clock; fall back
        # to local accumulation if anything goes sideways.
        nest_t = _get_nest_time()
        current_time = max(current_time + step, nest_t)
        step_count += 1

        run_data, n_events = collect_and_flush(recorders)
        accumulated_runs.append(run_data)

        pct = current_time / SIM_DURATION * 100
        print(f"  [{{pct:5.1f}}%] {{current_time:.0f}}/{{SIM_DURATION:.0f}} ms  |  {{n_events}} events collected")

    print("\\nBuilding history file...")
    history = build_history_file(graphs, accumulated_runs)
    with open(output_file, "w") as f:
        json.dump(history, f, cls=NumpyNestEncoder)

    total_recordings = 0
    for g in history["graphs"]:
        for n in g["nodes"]:
            for run in n["results"]["history"]:
                total_recordings += len(run.get("devices", {{}}))

    size_mb = output_file.stat().st_size / (1024 * 1024)
    print(f"\\nSimulation FINISHED.")
    print(f"  File:       {{output_file}}")
    print(f"  Size:       {{size_mb:.1f}} MB")
    print(f"  Steps:      {{step_count}}")
    print(f"  Recordings: {{total_recordings}} device entries")
    print(f"\\nLoadable in the Neuroticks History Browser.")


if __name__ == "__main__":
    main()
'''
