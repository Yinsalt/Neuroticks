"""Kompatibilitäts-Shim: der Inhalt von WidgetLib.py liegt jetzt im Paket ``neuroticks``.

Bestehende Skripte (z. B. server.py) können weiter ``import WidgetLib`` schreiben.
Neuer Code importiert direkt aus den unten genannten Modulen.
"""
# flake8: noqa
from neuroticks.constants.node_tools import (
    extract_shape_params, node_parameters1, NODE_TOOLS, SHAPE_PARAM_DEFAULTS,
    SHAPE_PARAM_KEYS, TOOL_PARAM_KEYS,
)
from neuroticks.constants.synapses import CONNECTION_RULES, SYNAPSE_MODELS
from neuroticks.core.connection_executor import (
    ConnectionExecutor, create_connection_dict, validate_connection_params, validate_delay,
)
from neuroticks.core.connection_store import (
    _find_reward_trigger_fallback, clear_all_connections, create_connection_from_gui_params,
    create_nest_connections_from_stored, export_connections_to_dict,
    get_all_connections_summary, import_connections_from_dict, prune_dangling_connections,
    repopulate_all_graphs, safe_nest_reset_and_repopulate,
)
from neuroticks.core.node_parameters import generate_node_parameters_list
from neuroticks.core.script_exporter import ScriptExporter
from neuroticks.gui.dashboards.analysis_dashboard import AnalysisDashboard
from neuroticks.gui.dashboards.live_connection_controller import LiveConnectionController
from neuroticks.gui.dashboards.live_dashboard import (
    LiveDataDashboard, LivePlotWidget, NodeLiveGroup, PopulationRatePlot,
)
from neuroticks.gui.dashboards.simulation_dashboard import SimulationDashboardWidget
from neuroticks.gui.dashboards.time_series import TimeSeriesPlotWidget
from neuroticks.gui.visualization.blinking_network import BlinkingNetworkWidget
from neuroticks.gui.visualization.flow_field import FlowFieldWidget
from neuroticks.gui.visualization.simulation_view import (
    ElectrodeItem, InjectorButton, SafeGLViewWidget, SimulationViewWidget,
)
from neuroticks.gui.widgets.connection_editor import ConnectionEditorWidget, ConnectionParamWidget
from neuroticks.gui.widgets.connection_tool import (
    ConnectionQueueWidget, ConnectionTargetRow, ConnectionTool,
)
from neuroticks.gui.widgets.device_tools import (
    DeviceConfigPage, DeviceHelpWidget, DeviceTargetSelector, ToolsWidget,
)
from neuroticks.gui.widgets.dialogs import PositionDialog
from neuroticks.gui.widgets.flow_layout import FlowLayout
from neuroticks.gui.widgets.graph_creator import GraphCreatorWidget
from neuroticks.gui.widgets.graph_editor import EditGraphWidget
from neuroticks.gui.widgets.graph_info import GraphInfoWidget
from neuroticks.gui.widgets.graph_overview import GraphNameColorWidget, GraphOverviewWidget
from neuroticks.gui.widgets.input_fields import (
    _set_visible, CheckboxField, DoubleInputField, DropdownField, IntegerInputField,
)
from neuroticks.gui.widgets.neuron_parameters import NeuronParametersWidget, NodeParametersWidget
from neuroticks.gui.widgets.polynomial_widgets import (
    PolynomialBuilderWidget, PolynomialManagerWidget, PolynomialTermRow,
    PolynomialTrioWidget,
)
from neuroticks.gui.widgets.python_console import PythonConsoleWidget
from neuroticks.gui.widgets.save_load import (
    add_save_load_buttons, SaveLoadWidget, SimulationControlWidget,
)
from neuroticks.gui.widgets.structures import StructuresWidget
from neuroticks.gui.widgets.synapse_widgets import (
    InlineSynapseConfig, SynapseCreationWidget, SynapseParamWidget,
)
from neuroticks.gui.widgets.tool_inspector import ToolInspectorWidget
from neuroticks.state import (
    _nest_simulation_has_run, current_graph_metadata, graph_parameters, next_graph_id,
    POLYNOM_NOISE_LEVEL,
)
from neuroticks.utils.nest_helpers import (
    build_gid_to_meta_map, get_mc_recordables, get_receptor_type_for_model, MC_MODELS,
    safe_get_model, safe_get_status, validate_SYNAPSE_MODELS,
)
from neuroticks.utils.polynomials import generate_biased_polynomial, generate_random_polynomial
from neuroticks.utils.serialization import (
    _clean_params, _serialize_connections, load_graph, NumpyEncoder, save_graph,
)
from neuroticks.utils.spatial import (
    create_anisotropic_weight, create_distance_dependent_delay,
    create_distance_dependent_probability, create_distance_dependent_weight,
    create_nest_mask, create_nest_mask_safe,
)
from neuron_toolbox import *

__all__ = [
    'SYNAPSE_MODELS',
    "DeviceConfigPage",
    "AnalysisDashboard",
    "LiveConnectionController",
    "LiveDataDashboard",
    'create_nest_mask',
    "SimulationControlWidget",
    "SimulationDashboardWidget",
    'create_distance_dependent_weight',
    'SynapseParamWidget',
    "SimulationViewWidget",
    'SynapseCreationWidget',
    'ConnectionExecutor',
    'ConnectionQueueWidget',
    'BlinkingNetworkWidget',
    'FlowFieldWidget',
    'GraphCreatorWidget',
    "StructuresWidget",
    'EditGraphWidget',
    'GraphOverviewWidget',
    'ConnectionTool',
    'ConnectionEditorWidget',
    'ConnectionParamWidget',
    'ToolsWidget',
    'SimulationControlWidget',
    'graph_parameters',
    'next_graph_id',
    '_clean_params',
    '_serialize_connections',
    'NumpyEncoder',
    'create_nest_connections_from_stored',
    'prune_dangling_connections',
    'safe_nest_reset_and_repopulate',
    'repopulate_all_graphs',
    'get_all_connections_summary',
    'export_connections_to_dict',
    'import_connections_from_dict',
    '_nest_simulation_has_run'
]
